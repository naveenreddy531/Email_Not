package com.allcomm.kafka.integration;

import org.springframework.beans.BeansException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

//import it.ozimov.springboot.mail.configuration.EnableEmailTools;



@SpringBootApplication
//@EnableEmailTools
public class JsonToDbApplication {
	
	//private ApplicationContext applicationContext;

	public static void main(String[] args) {
		SpringApplication.run(JsonToDbApplication.class, args);
	}

}
