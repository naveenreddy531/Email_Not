package com.allcomm.kafka.integration.controller;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.allcomm.kafka.integration.emailservice.SendNotiFicationService;
import com.allcomm.kafka.integration.jsonbean.Ibp;
import com.allcomm.kafka.integration.jsonbean.KafkaDealsDetail;
import com.allcomm.kafka.integration.jsonbean.ListPriceInfo;
import com.allcomm.kafka.integration.service.DealManager;
import com.allcomm.kafka.integration.service.IBPManager;
import com.allcomm.kafka.integration.service.PricingManager;

@RestController
public class AllcommKafkaControll {
	@Autowired
	private DealManager dealManager;

	@Autowired
	private IBPManager ibpManager;

	@Autowired
	private JavaMailSender sender;

	@Autowired
	private SendNotiFicationService emailNotificationService;

	@Autowired
	private PricingManager pricingManager;


	
	/**
	 * API to send Mail notification for "Special Pricing Deal Summary" with Excel Sheet
	 * @return mails with excel as attachement
	 */

	@GetMapping("/sendSplPricingMailAtt")
	public String sayHellow() {
		String response = "";
		try {
			response = emailNotificationService.sendEmailNotification();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@GetMapping("/sendMail")
	public String sendMail() {
		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			String[] address = { "prawesh.kumar@wipro.com", "naveenr@hpe.com" };
			helper.setFrom("pricing@hpe.com");
			helper.setTo(address);
			helper.setText("Greetings :)");
			helper.setSubject("Mail From Spring Boot");
		} catch (MessagingException e) {
			e.printStackTrace();
			return "Error while sending mail ..";
		}
		sender.send(message);
		return "Mail Sent Success!";
	}

	@RequestMapping("/sendMailAtt")
	public String sendMailAttachment() throws MessagingException {
		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		try {
			String[] address = { "prawesh.kumar@wipro.com", "naveenr@hpe.com" };
			helper.setFrom("pricing@hpe.com");
			helper.setTo(address);
			// helper.setTo("naveenr@hpe.com");
			helper.setText("Greetings :)\n Please find the attached docuemnt for your reference.");
			helper.setSubject("Mail From Spring Boot");
			ClassPathResource file = new ClassPathResource("hpe.png");
			helper.addAttachment("document.PNG", file);
		} catch (MessagingException e) {
			e.printStackTrace();
			return "Error while sending mail ..";
		}
		sender.send(message);
		return "Mail Sent Success!";
	}

	@PostMapping(value = "/updateDeal", consumes = { "application/json" })
	public String updateDeal(@RequestBody List<KafkaDealsDetail> kafkaDealsDetails) {

		System.out.println(kafkaDealsDetails.size());
		System.out.println(kafkaDealsDetails.get(0).getDEALHEADER1().getCustomerPartyIdentifier());
		dealManager.updateDeals(kafkaDealsDetails);
		return "updated....";

	}

	@PostMapping(value = "/updateIBP", consumes = { "application/json" })
	public String updateIBP(@RequestBody Ibp ibpModel) {

		ibpManager.updateIBP(ibpModel.getZOMDEALINDICATIVE().getIDOC().getZDEALINDICATIVE());
		return "updated";
	}

	@PostMapping(value = "/updateLP", consumes = { "application/json" })
	public String updateLP(@RequestBody List<ListPriceInfo> listPriceInfos) {
		pricingManager.updateListPrice(listPriceInfos);
		return "updated";
	}

}
