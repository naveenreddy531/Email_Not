package com.allcomm.kafka.integration.emailUtil;

public class KafkaSpecialPricingReportConstants {
	

	public static final String AllcommSearchPricingWeb = "AllcommSearchPricingWeb";
	public static final String AllcommSearchPricingWebQuickSearch = "AllcommSearchQuickSearch";

	public static final String AllCommStandardReportName = "StandardReport";
	public static final String AllCommSpecialPriceName = "SpecialReport";

	
	public static final String productSpecialPricingHeader[] = { "S.NO", "Hierarchy Id", "Product Id", "PL", "Description",
			"Quantity", "Offering", "Offer Type", "Begin Date", "End Date", "RQ", "Order Min", "Reseller Min",
			"Reseller Max", "Ln Max", "List Price", "Std Discount", "Component Id", "Converted Product", "Bundle Id",
			"UCID", "Offering BDNet", "Exchange Rate Factor", "TBA", "Converted Price" };

	public static final String ReportExcelHeader[] = { "Country Code", "Product Number", "PL", "PL Description",
			"Short Description", "Long Description", "Disc Hierarchy", "Disc Hierarchy Family ID",
			"Disc Hierarchy Series Description", "Disc Hierarchy Series ID", "Disc Hierarchy Model Description",
			"Disc Hierarchy Model ID", "Previous List Price", "New List Price", "List Price", "Effective Date",
			"Qty Break", "UOM", "PA Percentage Discount", "Exhibit Number", "Price Change Code", "Price Change Date",
			"PLC Status", "PLC Effective Date", "Replacement Product", "Product Change Code", "Product Change Date",
			"UPC Code", "Serialization", "Warranty Code", "Weight", "Unit of Weight", "Date Time Stamp" };
	
	public static final String dealSpecialPricingHeader[] ={ "DealNumber", "version","DealType", "OrderDate", "dealSellout", "versionValidity",
			"lastModified", "discountType", "discounts", "bundleMode", "mcCode", "businessModel", "businessGroup", "businessUnit","status", "leadCountry",
			"additionalCountry", "countryPriceCode", "currencyPriceCode", "priceTeamCode", "salesContact",
			"stockProtection", "stackable", "complexDeal", "dealRegId", "customerSegment", "dealDescription", "comments", "firstTier","finalTier"};

	public static final String dailyDeltaPP[] = { "Category", "Partner Name", "PA Number", "Country", "Currency",
			"Incoterm", "Product Number", "Product Qty Break", "PL", "PL Description", "Long Description",
			"Short Description", "Previous List Price", "List Price", "List Price Effective Date", "Previous Net Price",
			"Net Price", "PA Discount Percentage", "Net Price Effective Date", "Exhibit Number", "Price Change Code",
			"Price Change Date", "Replacement Product", "Product Class ID", "Product Class Description", "Model",
			"Model Description", "Family", "Family Description", "Series", "Series Description", "Product Change Code",
			"Product Change Date", "PLC Status", "PLC Effective Date", "Date Time Stamp" };
	
	public static final String dailyListPrice[] = {"Partner Name","Country","Currency","Incoterm","Product Number","PL","PL Description","Long Description","Short Description",
			"Previous List Price","List Price","List Price Effective Date","Price Change Code","Price Change Date","Replacement Product","Product Class ID","Product Class Description","Model",
			"Model Description","Family","Family Description","Series","Series Description","Product Change Code","Product Change Date","PLC Status","PLC Effective Date","UOM","Product Qty Break",
			"Product Dimensions","Dimensions Unit","Product Gross Weight","Serialization Flag","Volume","Volume Unit","Warranty Code","Weight Unit","EAN Code","Date Time Stamp"};

	public static final String dailyPurchasePrice[] = { "Partner Name", "PA Number", "Country", "Currency",
			"Incoterm", "Product Number", "Product Qty Break", "PL", "PL Description", "Long Description",
			"Short Description", "Previous List Price", "List Price", "List Price Effective Date", "Previous Net Price",
			"Net Price", "PA Discount Percentage", "Net Price Effective Date", "Exhibit Number", "Price Change Code",
			"Price Change Date", "Replacement Product", "Product Class ID", "Product Class Description", "Model",
			"Model Description", "Family", "Family Description", "Series", "Series Description", "Product Change Code",
			"Product Change Date", "PLC Status", "PLC Effective Date","UOM",
			"Product Dimensions","Dimensions Unit","Product Gross Weight","Serialization Flag","Volume","Volume Unit","Warranty Code","Weight Unit","EAN Code","UPC Code","Date Time Stamp"};

	public static final String checkEffectiveDate[]={"List Price Effective Date","Net Price Effective Date","PLC Effective Date"};
	
	//Name of other portlets
	public static final String  excelDeltaPP="D:\\excelDeltaPP.xlsx";
	public static final String TextDeltaPP="D:\\TextDeltaPP.txt";
	public static final String XMLDeltaPP="D:\\XMLDeltaPP.xml";
	public static final String excelWeeklyDeltaPP="D:\\excelWeeklyDeltaPP.xlsx";
	public static final String TextWeeklyDeltaPP="D:\\TextWeeklyDeltaPP.txt";
	public static final String  XMLWeeklyDeltaPP="D:\\XMLWeeklyDeltaPP.xml";
	public static final String excelDailyPurchasePrice="D:\\excelDailyPurchasePrice.xlsx";
	public static final String TextDailyPurchasePrice="D:\\TextDailyPurchasePrice.txt";
	public static final String XMLDailyPurchasePrice="D:\\XMLDailyPurchasePrice.xml";
	public static final String excelDailyListPrice="D:\\excelDailyListPrice.xlsx";
	public static final String TextDailyListPrice="D:\\TextDailyListPrice.txt";	
    public static final String XMLDailyListPrice="D:\\XMLDailyListPrice.xml";

	public static final String AllcommSearchTrainingmaterial = "AllcommSearchTrainingmaterial";
	public static final String AllcommSearchAdminresourcesExtendedWeb = "AllcommSearchAdminresourcesExtendedWeb";
	public static final String AllcommSearchRelatedtools = "AllcommSearchRelatedtools";
	public static final String AllcommSearchAdminresourcesWeb = "AllcommSearchAdminresourcesWeb";
	public static final String AllcommSearchAdminLogtools = "AllcommSearchAdminLogtools";
	public static final String PartnerRegExcelDownloadFileName = "Partner Details";


}
