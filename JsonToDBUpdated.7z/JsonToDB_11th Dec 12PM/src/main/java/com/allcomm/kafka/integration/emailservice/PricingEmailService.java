package com.allcomm.kafka.integration.emailservice;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

@Component
public interface PricingEmailService {
	
	public JSONArray getDealDetailsFileData(List<Long> sapDocNos) throws FileNotFoundException;
	
	public Map<String ,String> convertDealJsonObjectToLinkedHashMap(JSONObject deal);
	
	public Map<String ,String> convertProductJsonObjectToLinkedHashMap(JSONObject prodObject);

}
