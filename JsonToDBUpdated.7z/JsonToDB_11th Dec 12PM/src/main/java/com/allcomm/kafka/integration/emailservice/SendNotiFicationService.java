package com.allcomm.kafka.integration.emailservice;

import java.io.File;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
public interface SendNotiFicationService {
	
	public String sendEmailNotification()throws Exception;
	
	public String sendMailAttachment(List<File> files) throws MessagingException;

}
