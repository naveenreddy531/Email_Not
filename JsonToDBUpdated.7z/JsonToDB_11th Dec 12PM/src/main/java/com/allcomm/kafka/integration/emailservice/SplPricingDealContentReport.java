package com.allcomm.kafka.integration.emailservice;

import java.io.File;

import org.json.JSONArray;
import org.springframework.stereotype.Component;

@Component
public interface SplPricingDealContentReport {
	public File excelFileDownloadService(JSONArray jsonArray);
	public File xmlFileDownloadService(JSONArray jsonArray);
	public File textFileDownloadService(JSONArray jsonArray);

}
