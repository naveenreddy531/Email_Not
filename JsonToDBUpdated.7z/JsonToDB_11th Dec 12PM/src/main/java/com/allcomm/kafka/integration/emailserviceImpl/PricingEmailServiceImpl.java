package com.allcomm.kafka.integration.emailserviceImpl;

import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.allcomm.kafka.integration.emailservice.PricingEmailService;
import com.allcomm.kafka.integration.entities.DealBundleHeader;
import com.allcomm.kafka.integration.entities.DealBundleLine;
import com.allcomm.kafka.integration.entities.DealHeader;
import com.allcomm.kafka.integration.entities.DealProductTab;
import com.allcomm.kafka.integration.entities.DealResellerA;
import com.allcomm.kafka.integration.entities.DealResellerB;
import com.allcomm.kafka.integration.entities.PriceCommDealStatus;
import com.allcomm.kafka.integration.entities.PriceCommDealSubtype;
import com.allcomm.kafka.integration.repository.DealAddCtryPrcDiscriptorRepo;
import com.allcomm.kafka.integration.repository.DealBundleHeaderRepo;
import com.allcomm.kafka.integration.repository.DealBundleLineRepo;
import com.allcomm.kafka.integration.repository.DealHeaderRepo;
import com.allcomm.kafka.integration.repository.DealProductTabRepo;
import com.allcomm.kafka.integration.repository.PriceCommDealStatusRepo;
import com.allcomm.kafka.integration.repository.PriceCommDealSubtypeRepo;
import com.allcomm.kafka.integration.repository.ResellerARepo;
import com.allcomm.kafka.integration.repository.ResellerBRepo;

@Component
public class PricingEmailServiceImpl implements PricingEmailService{
	
	@Autowired
	private DealHeaderRepo dealHeaderRepo;

	@Autowired
	private DealAddCtryPrcDiscriptorRepo dealAddCtryPrcDiscriptorRep;

	@Autowired
	private ResellerARepo dealResellerARepo;

	@Autowired
	private ResellerBRepo dealResellerBRepo;

	@Autowired
	private DealBundleLineRepo dealBundleLineRepo;

	@Autowired
	private PriceCommDealSubtypeRepo priceCommDealSubtypeRepo;

	@Autowired
	private PriceCommDealStatusRepo priceCommDealStatusRepo;

	@Autowired
	private DealProductTabRepo dealProductTabRepo;

	@Autowired
	private DealBundleHeaderRepo dealBundleHeaderRepo;
	
	/*This method : form a JSONArray for files from data base*/
	public JSONArray getDealDetailsFileData(List<Long> sapDocNos) throws FileNotFoundException {

		JSONArray dealArray = new JSONArray();
		List<DealHeader> dealList = dealHeaderRepo.findAll();
		List<String> list = null;
		JSONArray addCtry = null;

		for (Long sapDoc : sapDocNos) {
			if (sapDoc != null) {
				list = dealAddCtryPrcDiscriptorRep.findAddCtryBySapDocNo(sapDoc);
				addCtry = new JSONArray(list);
				System.out.println("--NORMAL-" + addCtry);
			}

		}
		String AddCtrystr = String.join(",", list);

		if (dealList != null) {
			for (DealHeader deals : dealList) {
				JSONObject dealFinal = new JSONObject();
				LinkedHashMap<String, String> dealLinkedListReseller = new LinkedHashMap<>();
				JSONArray ResellerArray = new JSONArray();
				/* Reseller A name from DEAL_RESELLER_A*/
				if (Long.valueOf(deals.getSapDocumentNo()) != null) {
					List<Long> queryResellera = dealResellerARepo.findResellerABySapDocNo(deals.getSapDocumentNo());
					if (queryResellera != null && !queryResellera.equals(null)) {
						List<DealResellerA> resellerA = dealResellerARepo.findAllBySapDocNo(deals.getSapDocumentNo());
						for (int d = 0; d < resellerA.size(); d++) {
							DealResellerA reselleraname = resellerA.get(d);
							dealLinkedListReseller.put("ResellerA", reselleraname.getResellerASoldTo());
						}
					} else {

						dealLinkedListReseller.put("ResellerA", "");
					}
					/* Reseller B name from DEAL_RESELLER_B*/
					List<Long> queryResellerb = dealResellerBRepo.findResellerBBySapDocNo(deals.getSapDocumentNo());
					if (queryResellerb != null && !queryResellerb.equals(null)) {
						List<DealResellerB> resellerB = dealResellerBRepo.findAllBySapDocNo(deals.getSapDocumentNo());
						for (int e = 0; e < resellerB.size(); e++) {
							DealResellerB resellerbname = resellerB.get(e);
							dealLinkedListReseller.put("ResellerB", resellerbname.getResellerBSoldTo());
						}
					} else {
						dealLinkedListReseller.put("ResellerB", "");
					}
				}
				ResellerArray.put(dealLinkedListReseller);
				dealFinal.put("resellerDetails", ResellerArray);
				
				LinkedHashMap<String, String> dealLinkedList = new LinkedHashMap<>();
				dealLinkedList.put("DealNumber", Long.toString(deals.getDealID()));
				dealLinkedList.put("OpportunityID", deals.getOpportunityId());
				dealLinkedList.put("DealVersion", Long.toString(deals.getVersionNumber()));
				dealLinkedList.put("EndCustomer", deals.getCustNoPartyId());
				dealLinkedList.put("DealDescription", deals.getDealDescription());
				if (deals.getDealValidityFromDate() != null && !(deals.getDealValidityFromDate()).equals(null)) {
					String pattern = "yyyy-MM-dd";
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
					String fromDate = simpleDateFormat.format(deals.getDealValidityFromDate());
					dealLinkedList.put("DealSelloutStartDate", fromDate.toString());
				} else {
					dealLinkedList.put("DealSelloutStartDate", "");
				}
				String toDate = null;
				if (deals.getDealValidityToDate() != null && !(deals.getDealValidityToDate()).equals(null)) {
					String pattern = "yyyy-MM-dd";
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
					if (deals.getDealValidityToDate() != null) {
						toDate = simpleDateFormat.format(deals.getDealValidityToDate());
						System.out.println(toDate);
					}
					dealLinkedList.put("DealSelloutEndDate", toDate.toString());
				} else {
					dealLinkedList.put("DealSelloutEndDate", "");
				}
				if (deals.getVersionDate() != null) {
					String pattern = "yyyy-MM-dd";
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
					String versionDate = simpleDateFormat.format(deals.getVersionDate());
					System.out.println(versionDate);

					dealLinkedList.put("VersionValidityDate", versionDate.toString());
				} else {
					dealLinkedList.put("VersionValidityDate", "");
				}
				if (deals.getLastModifiedDate() != null) {
					String pattern = "yyyy-MM-dd HH:mm:ss";
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
					String lastmodifiedDate = simpleDateFormat.format(deals.getLastModifiedDate());
					System.out.println(lastmodifiedDate);
					System.out.println(lastmodifiedDate.toString());

					dealLinkedList.put("LastModified", lastmodifiedDate.toString());
				} else {
					dealLinkedList.put("LastModified", "");
				}
				dealLinkedList.put("DealType", deals.getDealType());
				dealLinkedList.put("DiscountType", Double.toString(deals.getTotalAdditionalDiscount()));
				dealLinkedList.put("RTMDesc", deals.getRtmRoutToMarket());
				dealLinkedList.put("GeoScope", deals.getGeographicScope());
				dealLinkedList.put("LeadCountry", deals.getLeadCountry());
				dealLinkedList.put("AdditionalCountries", AddCtrystr);
				dealLinkedList.put("CountryPriceCode", deals.getLeadCountry());
				dealLinkedList.put("CurrencyPriceCode", deals.getCurrency());
				dealLinkedList.put("PriceTermCode", deals.getPriceTermCode());
				if (Long.valueOf(deals.getSapDocumentNo()) != null) {
					List<Long> queryMultiCountry = dealBundleLineRepo
							.findDealBundleLineBySapDocNo(deals.getSapDocumentNo());
					if (queryMultiCountry != null && !queryMultiCountry.equals(null)) {
						List<DealBundleLine> mcountry = dealBundleLineRepo.findAllBySapDocNo(deals.getSapDocumentNo());
						 /*if(Long.valueOf(mcountry.get(0).getAuthAdd())!=null) {*/
						for (int b = 0; b < mcountry.size(); b++) {
							DealBundleLine multiCountry = mcountry.get(b);
							dealLinkedList.put("MultiCountry", multiCountry.getVerifiedMulticountryFlag());
						}
					} else {
						dealLinkedList.put("MultiCountry", "");
					}
				}
				dealLinkedList.put("VersionExpired", deals.getDealVersionStatus());
				/*Reseller A name from DEAL_RESELLER_A*/
				if (Long.valueOf(deals.getSapDocumentNo()) != null) {
					List<Long> queryResellerA = dealResellerARepo.findResellerABySapDocNo(deals.getSapDocumentNo());
					if (queryResellerA != null && !queryResellerA.equals(null)) {
						List<DealResellerA> resellerA = dealResellerARepo.findAllBySapDocNo(deals.getSapDocumentNo());
						for (int d = 0; d < resellerA.size(); d++) {
							DealResellerA resellerAname = resellerA.get(d);
							dealLinkedList.put("ResellerA", resellerAname.getResellerAName());
						}
					} else {
						dealLinkedList.put("ResellerA", "");
					}

					/*Reseller B name from DEAL_RESELLER_B*/
					List<Long> queryResellerB = dealResellerBRepo.findResellerBBySapDocNo(deals.getSapDocumentNo());
					if (queryResellerB != null && !queryResellerB.equals(null)) {
						List<DealResellerB> ResellerB = dealResellerBRepo.findAllBySapDocNo(deals.getSapDocumentNo());
						for (int e = 0; e < ResellerB.size(); e++) {
							DealResellerB resellerBname = ResellerB.get(e);
							dealLinkedList.put("ResellerB", resellerBname.getResellerBName());

						}
					} else {
						dealLinkedList.put("ResellerB", "");
					}
				}
				dealLinkedList.put("SalesContact", "");
				dealLinkedList.put("DealComment", "");
				dealLinkedList.put("StockProtection", "");
				dealLinkedList.put("NumberOfDays", Long.toString(deals.getProtectionDays()));
				/*Deal Sub Type Description from PRICE_COMM_DEAL_SUBTYPE Table*/
				List<String> queryDealSubType = null;
				if (deals.getPromoExclusion() != null) {
					queryDealSubType = priceCommDealSubtypeRepo.findDealSubTypeByPromoTypeCd(deals.getPromoExclusion());
				}
				if (queryDealSubType != null) {
					List<PriceCommDealSubtype> dealsubType = priceCommDealSubtypeRepo
							.findAllBypromoTypeCD(deals.getPromoExclusion());
					for (int e = 0; e < dealsubType.size(); e++) {
						PriceCommDealSubtype subType = dealsubType.get(e);
						dealLinkedList.put("DealSubType", subType.getPromoTypeDesc());
					}
				} else {
					dealLinkedList.put("DealSubType", "");
				}
				dealLinkedList.put("PromoStackable", "");
				dealLinkedList.put("StackedDeals", "");
				dealLinkedList.put("ComplexDeal", deals.getComplexDealFlag());
				dealLinkedList.put("MCCharge", deals.getMcChangeCode());
				dealLinkedList.put("CustomerAffiliates", "");
				dealLinkedList.put("AccountingRate", "");
				dealLinkedList.put("OrdMinQuantity", "");// refer product
				dealLinkedList.put("LnMaxQty", "");// refer product linkedlist
				dealLinkedList.put("AccumulationType", "");// Bundle
				dealLinkedList.put("BusinessGroup", deals.getLeadBG());
				dealLinkedList.put("BusinessUnit", deals.getLeadBU());

				 /*Deal Status Description from PRICE_COMM_DEAL_STATUS Table*/
				List<String> queryStatus = null;
				if (deals.getDealStatus() != null) {
					queryStatus = priceCommDealStatusRepo.findDealStatusBystatusTypeCd(deals.getDealStatus());
				}
				if (queryStatus != null) {
					List<PriceCommDealStatus> status = priceCommDealStatusRepo
							.findAllBystatusTypeCd(deals.getDealStatus());
					for (int i = 0; i < status.size(); i++) {
						PriceCommDealStatus dlStatus = status.get(i);
						dealLinkedList.put("DealStatus", dlStatus.getStatusTypeDesc());
					}
				} else {
					dealLinkedList.put("DealStatus", "");
				}
				dealLinkedList.put("Orderable", "");// product number from DEAL
				// PRODUCT TAB
				dealLinkedList.put("SpecialFeatures", "");
				dealLinkedList.put("TotalDiscountDeal", ""); // deal value
				dealLinkedList.put("BundleAccumulatorFlag", "");//
				dealLinkedList.put("GLPFlag", "");// GLP_DEAL from Deal header
				dealLinkedList.put("CustomerEngagement", "");// FROM DEAL
				dealLinkedList.put("DealRegistrationId", ""); // deal_reg_id
				dealLinkedList.put("CustomerSegment", deals.getCustSegment());
				dealLinkedList.put("EclipseDeal", Long.toString(deals.getEclipseDealNumber()));

				dealFinal.put("dealDetails", dealLinkedList);
				List<DealProductTab> productList = null;
				if (Long.valueOf(deals.getSapDocumentNo()) != null) {
					productList = dealProductTabRepo.findAllBySapDocNO(deals.getSapDocumentNo());
				}
				JSONArray productArray = new JSONArray();
				if (!productList.isEmpty()) {
					for (DealProductTab products : productList) {
						LinkedHashMap<String, String> productLinkedList = new LinkedHashMap<String, String>();
						/*
						 * productLinkedList.put("Ord_Min_Quantity",
						 * Long.toString(products.getORD_MIN_QUANTITY()));
						 * productLinkedList.put("Ln_Max_Qty", Long.toString(products.getLN_MAX_QTY()));
						 */
						/*
						 * productLinkedList.put("Accumulation_Type","");// Bundle accumulation mode
						 * from DEAL HEADER productLinkedList.put("Orderable","");// product number from
						 * DEAL PRODUCT TAB productLinkedList.put("Special_Features","");
						 * productLinkedList.put("Total_discount_deal",""); //deal value discount from
						 * DEAL PRODUCT TAB productLinkedList.put("Bundle_Accumulator_Flag","");/ /
						 * productLinkedList.put("GLP_Flag","");// GLP_DEAL from Deal header
						 * productLinkedList.put("Customer_Engagement","");// FROM DEAL HEADER
						 * productLinkedList.put("Deal_Registration_Id",""); //deal_reg_id from deal
						 * header
						 */
						/*Linked list creation for Line Type Name change*/
						if (products.getLineType().equalsIgnoreCase("PL")) {
							productLinkedList.put("LineType", "Product Line");
							productLinkedList.put("ProductNumber", "");
							productLinkedList.put("OptionCode", "");
							productLinkedList.put("BundleID", "");
							productLinkedList.put("ComponentID", "");
							productLinkedList.put("ProductLine", products.getProdLine());
							productLinkedList.put("ProductFamily", "");
							productLinkedList.put("SourceBundleIDUCID", ""); // source
							productLinkedList.put("Quantity", "");// quantity from
							productLinkedList.put("ProductDescription", products.getDesc());
							if (!Double.toString(products.getListPrice()).equals(null) && Double.toString(products.getListPrice()) != null) {
								DecimalFormat df2 = new DecimalFormat(".##");
								productLinkedList.put("ListPrice", df2.format(products.getListPrice()));
							}
							if (!Double.toString(products.getStdDisc()).equals(null) && Double.toString(products.getStdDisc()) != null) {
								DecimalFormat df2 = new DecimalFormat(".##");
								productLinkedList.put("StdDiscPct", df2.format(products.getStdDisc()));
							}
							productLinkedList.put("DiscPct", ""); // std disc from
							productLinkedList.put("Offering", "");
							productLinkedList.put("OfferType", "");
							productLinkedList.put("AddlDiscountPctOffListPrice", "");
							productLinkedList.put("NewItem", "");// item number in
							productLinkedList.put("NewRQ", "");
							productLinkedList.put("ConfigCheckIsPending", "");// special
							productLinkedList.put("LineNumber", "");
							productLinkedList.put("RemainingQty", "");// rem
							productLinkedList.put("MinOrderQty", "");// ord min
							productLinkedList.put("MaxDealQty", "");// ln max qty
							productLinkedList.put("MinResellerQty", "");// template
							// gap
							productLinkedList.put("MaxResellerQty", "");// template
							// gap
							productLinkedList.put("EffectiveDatesFrom", "");
							productLinkedList.put("EffectiveDatesTo", "");
							productLinkedList.put("BPrice", "");
							productArray.put(productLinkedList);
						} else if (products.getLineType().equalsIgnoreCase("PN")) {
							productLinkedList.put("LineType", "Part Number");
							productLinkedList.put("ProductNumber", products.getProdNo());
							productLinkedList.put("OptionCode", products.getOptCode());
							productLinkedList.put("BundleID", "");
							productLinkedList.put("ComponentID", "");
							productLinkedList.put("ProductLine", products.getProdLine());
							productLinkedList.put("ProductFamily", "");
							productLinkedList.put("SourceBundleIDUCID", ""); // source
							productLinkedList.put("Quantity", "");// quantity from
							productLinkedList.put("ProductDescription", products.getDesc());
							if (!Double.toString(products.getListPrice()).equals(null) && Double.toString(products.getListPrice()) != null) {
								DecimalFormat df2 = new DecimalFormat(".##");
								productLinkedList.put("ListPrice", df2.format(products.getListPrice()));
							}
							if (!Double.toString(products.getStdDisc()).equals(null) && Double.toString(products.getStdDisc()) != null) {
								DecimalFormat df2 = new DecimalFormat(".##");
								productLinkedList.put("StdDiscPct", df2.format(products.getStdDisc()));
							}

							productLinkedList.put("DiscPct", ""); // std disc from
							productLinkedList.put("Offering", "");
							productLinkedList.put("OfferType", "");
							productLinkedList.put("AddlDiscountPctOffListPrice", "");
							productLinkedList.put("NewItem", "");// item number in
							productLinkedList.put("NewRQ", "");
							productLinkedList.put("ConfigCheckIsPending", "");// special
							productLinkedList.put("LineNumber", "");
							productLinkedList.put("RemainingQty", "");// rem
							productLinkedList.put("MinOrderQty", "");// ord min
							productLinkedList.put("MaxDealQty", "");// ln max qty
							productLinkedList.put("MinResellerQty", "");// template
							// gap
							productLinkedList.put("MaxResellerQty", "");// template
							// gap
							productLinkedList.put("EffectiveDatesFrom", "");
							productLinkedList.put("EffectiveDatesTo", "");
							productLinkedList.put("BPrice", "");
							productArray.put(productLinkedList);
						} else if (products.getLineType().equalsIgnoreCase("PF")) {
							productLinkedList.put("LineType", "Product Family");
							productLinkedList.put("ProductNumber", "");
							productLinkedList.put("OptionCode", "");
							productLinkedList.put("BundleID", "");
							productLinkedList.put("ComponentID", "");
							/*productLinkedList.put("Bundle_ID",Long.toString(bundles.getCONFIG_ID()));*/
							/*bundle no from bundle line*/
							 /*productLinkedList.put("Component_ID",bundles.getPRODUCT_NUMBER());*/
							 /*Reading scale id from bundle line*/
							productLinkedList.put("ProductLine", products.getProdLine());
							productLinkedList.put("ProductFamily", products.getProdFamily());
							productLinkedList.put("SourceBundleIDUCID", ""); // source
							productLinkedList.put("Quantity", "");// quantity from

							productLinkedList.put("ProductDescription", products.getDesc());
							if (!Double.toString(products.getListPrice()).equals(null) && Double.toString(products.getListPrice()) != null) {
								DecimalFormat df2 = new DecimalFormat(".##");
								productLinkedList.put("ListPrice", df2.format(products.getListPrice()));
							}
							if (!Double.toString(products.getStdDisc()).equals(null) && Double.toString(products.getStdDisc()) != null) {
								DecimalFormat df2 = new DecimalFormat(".##");
								productLinkedList.put("StdDiscPct", df2.format(products.getStdDisc()));
							}
							productLinkedList.put("DiscPct", ""); // std disc from
							productLinkedList.put("Offering", "");
							productLinkedList.put("OfferType", "");
							 /*productLinkedList.put("Offer_Type",products.getPRC_TYPE());*/
							productLinkedList.put("AddlDiscountPctOffListPrice", "");
							productLinkedList.put("NewItem", "");// item number in
							/*Reading data from  bundle line*/
							productLinkedList.put("NewRQ", "");
							productLinkedList.put("ConfigCheckIsPending", "");
							productLinkedList.put("LineNumber", "");
							productLinkedList.put("RemainingQty", "");
							productLinkedList.put("MinOrderQty", "");
							productLinkedList.put("MaxDealQty", "");
							productLinkedList.put("MinResellerQty", "");
							productLinkedList.put("MaxResellerQty", "");
							productLinkedList.put("EffectiveDatesFrom", "");
							productLinkedList.put("EffectiveDatesTo", "");
							productLinkedList.put("BPrice", "");

							productArray.put(productLinkedList);
						}

						if (products.getLineType().equalsIgnoreCase("BD") && products.getSapDocNo() != null) {
							List<DealBundleHeader> bundles = dealBundleHeaderRepo
									.findAllBySapDocNo(products.getSapDocNo());

							for (DealBundleHeader bundle : bundles) {
								LinkedHashMap<String, String> productbundleLinkedList = new LinkedHashMap<String, String>();

								productbundleLinkedList.put("LineType", "Bundle");
								productbundleLinkedList.put("ProductNumber", "");
								productbundleLinkedList.put("OptionCode", "");
								productbundleLinkedList.put("BundleID", Long.toString(bundle.getConfigId()));
								productbundleLinkedList.put("ComponentID", "");
								productbundleLinkedList.put("ProductLine", products.getProdLine());
								productbundleLinkedList.put("ProductFamily", "");
								productbundleLinkedList.put("SourceBundleIDUCID", ""); // source
								productbundleLinkedList.put("Quantity", "");// quantity from
								productbundleLinkedList.put("ProductDescription", bundle.getProdDesc());
								if (!Double.toString(products.getListPrice()).equals(null) && Double.toString(products.getListPrice()) != null) {
									DecimalFormat df2 = new DecimalFormat(".##");
									productbundleLinkedList.put("ListPrice", df2.format(products.getListPrice()));
								}
								if (!Double.toString(products.getStdDisc()).equals(null) && Double.toString(products.getStdDisc()) != null) {
									DecimalFormat df2 = new DecimalFormat(".##");
									productbundleLinkedList.put("StdDiscPct", df2.format(products.getStdDisc()));
								}
								productbundleLinkedList.put("DiscPct", "");
								productbundleLinkedList.put("Offering", "");
								productbundleLinkedList.put("OfferType", "");
								productbundleLinkedList.put("AddlDiscountPctOffListPrice", "");
								productbundleLinkedList.put("NewItem", "");
								productbundleLinkedList.put("NewRQ", "");
								productbundleLinkedList.put("ConfigCheckIsPending", "");
								productbundleLinkedList.put("LineNumber", "");
								productbundleLinkedList.put("RemainingQty", "");
								productbundleLinkedList.put("MinOrderQty", "");
								productbundleLinkedList.put("MaxDealQty", "");
								productbundleLinkedList.put("MinResellerQty", "");
								productbundleLinkedList.put("MaxResellerQty", "");
								productbundleLinkedList.put("EffectiveDatesFrom", "");
								productbundleLinkedList.put("EffectiveDatesTo", "");
								productbundleLinkedList.put("BPrice", "");

								if (!Long.valueOf(bundle.getConfigId()).equals(null)
										&& Long.valueOf(bundle.getConfigId()) != null) {
									String configId = Long.toString(bundle.getConfigId());
									List<DealBundleLine> bundleList = dealBundleLineRepo.findAllByConfigId(configId);

									if (!bundleList.isEmpty()) {
										JSONArray bundleArray = new JSONArray();
										for (DealBundleLine bundleLine : bundleList) {

											JSONObject bundleCompLinkedList = new JSONObject();
											bundleCompLinkedList.put("Comp_LineType", "BundleDetails");
											bundleCompLinkedList.put("Comp_BundleID",
													bundleLine.getConfigId().toString());
											bundleCompLinkedList.put("Comp_ComponentID", "");
											bundleCompLinkedList.put("Comp_OptionCode", bundleLine.getOptCode());
											bundleCompLinkedList.put("Comp_ProductLine", bundleLine.getPl());
											bundleCompLinkedList.put("Comp_Quantity",
													Double.toString(bundleLine.getQty()));
											bundleCompLinkedList.put("Comp_ProductDescription",
													bundleLine.getDiscription());
											bundleCompLinkedList.put("Comp_ListPrice", bundleLine.getListPrice());
											bundleCompLinkedList.put("Comp_StdDiscPct", bundleLine.getStdDisc());
											bundleCompLinkedList.put("Comp_DiscPct", "");
											bundleCompLinkedList.put("Comp_Offering", "");
											bundleCompLinkedList.put("Comp_OfferType", "");
											bundleCompLinkedList.put("Comp_Add_lDiscountPctOffListPrice", "");
											bundleCompLinkedList.put("Comp_NewItem", "");
											bundleCompLinkedList.put("Comp_NewRQ", "");
											bundleCompLinkedList.put("Comp_ConfigCheckIsPending", "");
											bundleCompLinkedList.put("Comp_LineNumber", "");
											bundleCompLinkedList.put("Comp_EffectiveDatesFrom", "");
											bundleCompLinkedList.put("Comp_EffectiveDatesTo", "");
											bundleCompLinkedList.put("Comp_BPrice", "");

											bundleArray.put(bundleCompLinkedList);

										}
										/* bundleConfigId.put(configId, bundleArray); */

										productbundleLinkedList.put("bundle", bundleArray.toString());

									}

								}
								productArray.put(productbundleLinkedList);
							}
							
						}

					}
					dealFinal.put("productDetails", productArray);

				}

				dealArray.put(dealFinal);

			}
		}

		return dealArray;

	}
	
	/*This method : To convert Deal JSONObject to LinkedHashMap*/
	public Map<String ,String> convertDealJsonObjectToLinkedHashMap(JSONObject deal){
		Map<String, String> dealObj = new LinkedHashMap<String, String>();
		
		dealObj.put("DealNumber", dataCheck(deal, "DealNumber"));
		dealObj.put("OpportunityID", dataCheck(deal, "OpportunityID"));		
		dealObj.put("DealVersion", dataCheck(deal, "DealVersion"));
		dealObj.put("EndCustomer", dataCheck(deal, "EndCustomer"));
		dealObj.put("DealDescription", dataCheck(deal, "DealDescription"));
		dealObj.put("DealSelloutStartDate", dataCheck(deal, "DealSelloutStartDate"));		
		dealObj.put("DealSelloutEndDate", dataCheck(deal, "DealSelloutEndDate"));		
		dealObj.put("VersionValidityDate", dataCheck(deal, "VersionValidityDate"));
		dealObj.put("LastModified", dataCheck(deal, "LastModified"));	
		dealObj.put("DealType", dataCheck(deal, "DealType"));		
		dealObj.put("DiscountType", dataCheck(deal, "DiscountType"));		
		dealObj.put("RTMDesc", dataCheck(deal, "RTMDesc"));		
		dealObj.put("GeoScope", dataCheck(deal, "GeoScope"));		
		dealObj.put("LeadCountry", dataCheck(deal, "LeadCountry"));	
		dealObj.put("AdditionalCountries", dataCheck(deal, "AdditionalCountries"));		
		dealObj.put("CountryPriceCode", dataCheck(deal, "CountryPriceCode"));		
		dealObj.put("CurrencyPriceCode", dataCheck(deal, "CurrencyPriceCode"));		
		dealObj.put("PriceTermCode", dataCheck(deal, "PriceTermCode"));	
		dealObj.put("MultiCountry", dataCheck(deal, "MultiCountry"));		
		dealObj.put("VersionExpired", dataCheck(deal, "VersionExpired"));	
		dealObj.put("ResellerA", dataCheck(deal, "ResellerA"));	
		dealObj.put("ResellerB", dataCheck(deal, "ResellerB"));		
		dealObj.put("SalesContact", dataCheck(deal, "SalesContact"));	
		dealObj.put("DealComment", dataCheck(deal, "DealComment"));		
		dealObj.put("StockProtection", dataCheck(deal, "StockProtection"));		
		dealObj.put("NumberOfDays", dataCheck(deal, "NumberOfDays"));		
		dealObj.put("DealSubType", dataCheck(deal, "DealSubType"));		
		dealObj.put("PromoStackable", dataCheck(deal, "PromoStackable"));		
		dealObj.put("StackedDeals", dataCheck(deal, "StackedDeals"));	
		dealObj.put("ComplexDeal", dataCheck(deal, "ComplexDeal"));		
		dealObj.put("MCCharge", dataCheck(deal, "MCCharge"));	
		dealObj.put("CustomerAffiliates", dataCheck(deal, "CustomerAffiliates"));		
		dealObj.put("AccountingRate", dataCheck(deal, "AccountingRate"));		
		dealObj.put("OrdMinQuantity", dataCheck(deal, "OrdMinQuantity"));	
		dealObj.put("LnMaxQty", dataCheck(deal, "LnMaxQty"));	
		dealObj.put("AccumulationType", dataCheck(deal, "AccumulationType"));	
		dealObj.put("BusinessGroup", dataCheck(deal, "BusinessGroup"));	
		dealObj.put("BusinessUnit", dataCheck(deal, "BusinessUnit"));		
		dealObj.put("DealStatus", dataCheck(deal, "DealStatus"));		
		dealObj.put("Orderable", dataCheck(deal, "Orderable"));	
		dealObj.put("SpecialFeatures", dataCheck(deal, "SpecialFeatures"));	
		dealObj.put("TotalDiscountDeal", dataCheck(deal, "TotalDiscountDeal"));	
		dealObj.put("BundleAccumulatorFlag", dataCheck(deal, "BundleAccumulatorFlag"));	
		dealObj.put("GLPFlag", dataCheck(deal, "GLPFlag"));		
		dealObj.put("CustomerEngagement", dataCheck(deal, "CustomerEngagement"));	
		dealObj.put("DealRegistrationId", dataCheck(deal, "DealRegistrationId"));		
		dealObj.put("CustomerSegment", dataCheck(deal, "CustomerSegment"));	
		dealObj.put("EclipseDeal", dataCheck(deal, "EclipseDeal"));	
		
		return dealObj;
		
		
	}

	/*This method : To convert Product JSONObject to LinkedHashMap*/
public Map<String ,String> convertProductJsonObjectToLinkedHashMap(JSONObject prodObject){
		
	Map<String, String> productObj = new LinkedHashMap<String, String>();
	
	productObj.put("LineType", dataCheck(prodObject, "LineType"));
	productObj.put("ProductNumber", dataCheck(prodObject, "ProductNumber"));
	productObj.put("OptionCode", dataCheck(prodObject, "OptionCode"));
	productObj.put("BundleID", dataCheck(prodObject, "BundleID"));
	productObj.put("ComponentID", dataCheck(prodObject, "ComponentID"));
	productObj.put("ProductLine", dataCheck(prodObject, "ProductLine"));
	productObj.put("ProductFamily", dataCheck(prodObject, "ProductFamily"));
	productObj.put("SourceBundleIDUCID", dataCheck(prodObject, "SourceBundleIDUCID"));
	productObj.put("Quantity", dataCheck(prodObject, "Quantity"));
	productObj.put("ProductDescription", dataCheck(prodObject, "ProductDescription"));
	productObj.put("ListPrice", dataCheck(prodObject, "ListPrice"));
	productObj.put("StdDiscPct", dataCheck(prodObject, "StdDiscPct"));
	productObj.put("DiscPct", dataCheck(prodObject, "DiscPct"));
	productObj.put("Offering", dataCheck(prodObject, "Offering"));
	productObj.put("OfferType", dataCheck(prodObject, "OfferType"));
	productObj.put("AddlDiscountPctOffListPrice",dataCheck(prodObject, "AddlDiscountPctOffListPrice"));
	productObj.put("NewItem", dataCheck(prodObject, "NewItem"));
	productObj.put("NewRQ", dataCheck(prodObject, "NewRQ"));
	productObj.put("ConfigCheckIsPending", dataCheck(prodObject, "ConfigCheckIsPending"));
	productObj.put("LineNumber", dataCheck(prodObject, "LineNumber"));
	productObj.put("RemainingQty", dataCheck(prodObject, "RemainingQty"));
	productObj.put("MinOrderQty", dataCheck(prodObject, "MinOrderQty"));
	productObj.put("MaxDealQty", dataCheck(prodObject, "MaxDealQty"));
	productObj.put("MinResellerQty", dataCheck(prodObject, "MinResellerQty"));
	productObj.put("MaxResellerQty", dataCheck(prodObject, "MaxResellerQty"));
	productObj.put("EffectiveDatesFrom", dataCheck(prodObject, "EffectiveDatesFrom"));
	productObj.put("EffectiveDatesTo",dataCheck(prodObject, "EffectiveDatesTo"));
	productObj.put("BPrice", dataCheck(prodObject, "BPrice"));
	/*if(prodObject.has("LineType") && prodObject.get("LineType")!=null && prodObject.get("LineType")=="bundle"||prodObject.get("LineType")=="Bundle")  {*/
	if(prodObject.has("Bundle") || prodObject.has("bundle") )  {
	productObj.put("bundle", dataCheck(prodObject, "bundle"));
	}
	return productObj;
		
	}
	
/*This method : To validate the data*/
private String dataCheck(JSONObject jsonObject, String key) {
	String data = "";
	if (jsonObject.has(key)) {
		if (key.equalsIgnoreCase("Comp_ListPrice") || key.equalsIgnoreCase("Comp_StdDiscPct")) {
			long value = jsonObject.getLong(key);
			return data = Long.toString(value);
		} else {
			return data = jsonObject.getString(key);
		}
	} else {
		return data;
	}
}


}
