package com.allcomm.kafka.integration.emailserviceImpl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.allcomm.kafka.integration.emailservice.PricingEmailService;
import com.allcomm.kafka.integration.emailservice.SendNotiFicationService;
import com.allcomm.kafka.integration.emailservice.SplPricingDealContentReport;
import com.allcomm.kafka.integration.emailservice.SplPricingDealSummaryReport;
import com.allcomm.kafka.integration.entities.DealHeader;
import com.allcomm.kafka.integration.repository.DealHeaderRepo;

@Component
public class SendNotiFicationServiceImpl implements SendNotiFicationService{

	@Autowired
	private DealHeaderRepo dealHeaderRepo;
	
	@Autowired
	private JavaMailSender sender;

	@Autowired
	private PricingEmailService pricingEmailServiceImpl;

	@Autowired
	private SplPricingDealSummaryReport splPricingDealSummaryReport;

	@Autowired
	private SplPricingDealContentReport splPricingDealContentReport;

	public String sendEmailNotification()throws Exception {

		List<DealHeader> headers = dealHeaderRepo.findAll();
		List<Long> sapDocNos =new ArrayList<Long>();
		String emailMsg ="";
		List<File> files = new ArrayList<File>();
		File file = null;
		for (DealHeader header : headers) {
			if(header.getCustNoPartyId()!=null && header.getCustNoPartyId()!= ""&& Long.valueOf(header.getSapDocumentNo())!= null) {
			sapDocNos.add(header.getSapDocumentNo());
			}
		}
		
		JSONArray jsonArray = new JSONArray();
		/* Getting JSON Array response to form reports */
		jsonArray = pricingEmailServiceImpl.getDealDetailsFileData(sapDocNos);
		/* Forming Excel sheet with given json response */
		file = splPricingDealSummaryReport.excelFileDownloadService(jsonArray);
		files.add(file);
		/* Sending mail with Excel attachment */
//		emailMsg = sendMailAttachment(file);
		
		/* Getting JSON Array response to form reports */
		jsonArray = pricingEmailServiceImpl.getDealDetailsFileData(sapDocNos);
		/* Forming Xml file with given json response */
		file = splPricingDealSummaryReport.xmlFileDownloadService(jsonArray);
		files.add(file);		
		/* Sending mail with Xml attachment */
//		emailMsg = sendMailAttachment(file);
		
		/* Getting JSON Array response to form reports */
		jsonArray = pricingEmailServiceImpl.getDealDetailsFileData(sapDocNos);
		/* Forming Text file with given json response */
		file = splPricingDealSummaryReport.textFileDownloadService(jsonArray);
		files.add(file);
		/* Sending mail with Text fil attachment */
//		emailMsg = sendMailAttachment(file);
		
		/* Getting JSON Array response to form reports */
		jsonArray = pricingEmailServiceImpl.getDealDetailsFileData(sapDocNos);
		/* Forming Excel sheet with given json response */
		file = splPricingDealContentReport.excelFileDownloadService(jsonArray);
		files.add(file);
		/* Sending mail with Excel attachment */
//		emailMsg =sendMailAttachment(file);
		
		/* Getting JSON Array response to form reports */
		jsonArray = pricingEmailServiceImpl.getDealDetailsFileData(sapDocNos);
		/* Forming Xml file with given json response */
		file = splPricingDealContentReport.xmlFileDownloadService(jsonArray);
		files.add(file);
		/* Sending mail with Xml attachment */
//		emailMsg = sendMailAttachment(file);
		
		/* Getting JSON Array response to form reports */
		jsonArray = pricingEmailServiceImpl.getDealDetailsFileData(sapDocNos);
		/* Forming Text file with given json response */
		file = splPricingDealContentReport.textFileDownloadService(jsonArray);
		files.add(file);
		/* Sending mail with Text attachment */
		emailMsg = sendMailAttachment(files);
		
		return emailMsg;
	}
	
	public String sendMailAttachment(List<File> files) throws MessagingException {
		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		try {
			String[] address = { "prawesh.kumar@wipro.com"};//,"rohan.palan@hpe.com","sathiskumar.chelladurai@hpe.com","sanjeew-ranjan.kumar@hpe.com","nbalaji@hpe.com" };
			helper.setFrom("pricing@hpe.com");
			helper.setTo(address);
			helper.setText(
					"Hi Rohan/Sathis,\n\n Please find the attached files for 'DealContent' & 'DealSummary' and validate with bussiness approved template.\nLet me know if any changes requried.");
			helper.setSubject("Kafka subscription testing mail.");
			// ClassPathResource file = new ClassPathResource("hpe.png");
			for(File file : files) {
				helper.addAttachment(file.getName(), file);	
			}
			
		} catch (MessagingException e) {
			e.printStackTrace();
			return "Error while sending mail ..";
		}
		sender.send(message);
		return "Mail Sent Success!";
	}
	
}