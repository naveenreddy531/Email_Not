package com.allcomm.kafka.integration.emailserviceImpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.activation.FileDataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.allcomm.kafka.integration.emailUtil.KafkaSpecialPricingReportConstants;
import com.allcomm.kafka.integration.emailservice.SplPricingDealSummaryReport;

@Component
public class SplPricingDealSummaryReportImpl implements SplPricingDealSummaryReport {

	@Autowired
	private PricingEmailServiceImpl pricingEmailServiceImpl;

	public File excelFileDownloadService(JSONArray jsonArray) {
		  File file=null;

			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(KafkaSpecialPricingReportConstants.AllCommSpecialPriceName);
			XSSFRow rowhead = sheet.createRow((short) 0);
			JSONObject details1 = new JSONObject();
			JSONObject prodHeader = new JSONObject();
			int n = 0;
			for (int j = 0; j <= jsonArray.length(); j++) {
				if (n == 0) {
					JSONObject jsons = new JSONObject();
					jsons = jsonArray.getJSONObject(j);
					if (jsons.has("dealDetails") && jsons.has("productDetails") && jsons.has("resellerDetails")) {
						details1 = jsons;
						n++;
					}
				}
			}
			
		/*	Reading Deal header from JSONObject*/
			JSONObject detail = details1.getJSONObject("dealDetails");
			Map<String, String> dealHead = pricingEmailServiceImpl.convertDealJsonObjectToLinkedHashMap(detail);

			String[] dealHeader = dealHead.keySet().toArray(new String[dealHead.size()]);
			int i = 0;
			for (String head : dealHeader) {
				rowhead.createCell(i).setCellValue(head);
				i++;
			}
			
			/*	Reading Product header from JSONObject*/
			if (details1.has("productDetails") && details1.getJSONArray("productDetails").length() > 0) {
				prodHeader = details1.getJSONArray("productDetails").getJSONObject(0);
			}
			Map<String, String> productHead = pricingEmailServiceImpl
					.convertProductJsonObjectToLinkedHashMap(prodHeader);
			String[] productHeader = productHead.keySet().toArray(new String[productHead.size()]);
			for (String head : productHeader) {
				
				if (!head.equalsIgnoreCase("bundle")) {
				rowhead.createCell(i).setCellValue(head);
				i++;
			}
			}
			
			/*JSONObject iteration from JSONArray to write in Excel sheet*/
			int horRow = 1;
			for (int h = 0; h < jsonArray.length(); h++) {
				JSONObject details = jsonArray.getJSONObject(h);
				JSONArray prodDetails = null;
				if (details.has("productDetails") && details.getJSONArray("productDetails").length() > 0) {
					prodDetails = details.getJSONArray("productDetails");
				} else {
					prodDetails = new JSONArray();
				}
				/*Reading Deal data(Deal JSONObject) from JSONArray*/
				Map<String, String> dealObj = pricingEmailServiceImpl.convertDealJsonObjectToLinkedHashMap(details.getJSONObject("dealDetails"));
				for (int rowIndex = 0; rowIndex < prodDetails.length(); rowIndex++) {
					Row row = sheet.createRow(horRow);
					int columnIndex = 0;
					Set<String> dealKeySet1 = (Set<String>) dealObj.keySet();
					Iterator<String> dealKeys1 = dealKeySet1.iterator();
					while (dealKeys1.hasNext()) {
						String key = dealKeys1.next();
						Cell cell;
						cell = row.createCell(columnIndex);

						if ((dealObj.get(key)).matches("[0-9.]+") && (dealObj.get(key)).length() >= 1) {
							if (dealObj.get(key).contains(".")) {
								double result = Double.parseDouble(dealObj.get(key));
								CellStyle style;

								style = workbook.createCellStyle();
								style.setAlignment(CellStyle.ALIGN_LEFT);
								cell.setCellValue(result);
								cell.setCellStyle(style);
							} else {
								int result = Integer.parseInt((dealObj.get(key)));
								CellStyle style;

								style = workbook.createCellStyle();
								style.setAlignment(CellStyle.ALIGN_LEFT);
								cell.setCellValue(result);
								cell.setCellStyle(style);
							}
						} else {

							cell.setCellValue(dealObj.get(key));
						}

						columnIndex++;

					}
					/*Reading Product data(Product JSONObject) from JSONArray one by one*/
					Map<String, String> productObj = pricingEmailServiceImpl.convertProductJsonObjectToLinkedHashMap(prodDetails.getJSONObject(rowIndex));
					if (!productObj.isEmpty() && productObj!=null) {
						Set<String> keySet1 = (Set<String>) productObj.keySet();
						Iterator<String> keys1 = keySet1.iterator();

						while (keys1.hasNext()) {
							String key = keys1.next();

							if (key.equals("bundle")) {
								int bundleHorRow = horRow + 1;
								try {
									JSONArray bundleArray = new JSONArray(productObj.get(key).toString());
									for (int budleComp = 0; budleComp < bundleArray.length(); budleComp++) {
										Row bundleRow = sheet.createRow(bundleHorRow);
										JSONObject bundleCompLinkedList = bundleArray
												.getJSONObject(budleComp);
//										Iterator<String> bundleKeys1 = bundleCompLinkedList.keys();
										int bundleColumnIndex = 0;
										Iterator<Cell> cellIterator = row.cellIterator();
										while (cellIterator.hasNext()) {
											Cell cell = cellIterator.next();
											if (!((cell.CELL_TYPE_STRING == cell.getCellType()) && productObj
													.get("LineType").equals(cell.getStringCellValue()))) {
												Cell bundcell = bundleRow.createCell(bundleColumnIndex);
												switch (cell.getCellType()) {
												case Cell.CELL_TYPE_NUMERIC:
													CellStyle style;
													style = workbook.createCellStyle();
													style.setAlignment(CellStyle.ALIGN_LEFT);
													cell.setCellStyle(style);
													bundcell.setCellValue(cell.getNumericCellValue());
													bundcell.setCellStyle(style);
													break;
												case Cell.CELL_TYPE_STRING:
													bundcell.setCellValue(cell.getStringCellValue());
													break;
												}
												bundleColumnIndex++;
											} else {
												break;
											}
										}
										
										int cellIndex = bundleColumnIndex;
										Cell cell;
										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(bundleCompLinkedList.get("Comp_LineType").toString());
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue("");
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList,"Comp_OptionCode"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										if ((bundleCompLinkedList.get("Comp_BundleID").toString()
												.matches("[0-9.]+"))
												&& (bundleCompLinkedList.get("Comp_BundleID")).toString()
														.length() >= 1) {
											int result = Integer
													.parseInt(bundleCompLinkedList.get("Comp_BundleID").toString());
											CellStyle style;
											style = workbook.createCellStyle();
											style.setAlignment(CellStyle.ALIGN_LEFT);
											cell.setCellValue(result);
											cell.setCellStyle(style);
										}
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(bundleCompLinkedList.get("Comp_ComponentID").toString());
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList,"Comp_ProductLine"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue("");
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue("");
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										if ((bundleCompLinkedList.get("Comp_Quantity").toString()
												.matches("[0-9.]+"))
												&& (bundleCompLinkedList.get("Comp_Quantity")).toString()
														.length() >= 1) {

											if (bundleCompLinkedList.get("Comp_Quantity").toString()
													.contains(".")) {
												double result = Double.parseDouble(
														bundleCompLinkedList.get("Comp_Quantity").toString());
												CellStyle style;

												style = workbook.createCellStyle();
												style.setAlignment(CellStyle.ALIGN_LEFT);
												cell.setCellValue(result);
												cell.setCellStyle(style);
											}
										}

										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(
												dataCheck(bundleCompLinkedList,"Comp_ProductDescription"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(bundleCompLinkedList.get("Comp_ListPrice").toString());
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(bundleCompLinkedList.get("Comp_StdDiscPct").toString());
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList, "Comp_DiscPct"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList, "Comp_Offering"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList,"Comp_OfferType"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList, "Comp_Add_lDiscountPctOffListPrice"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList,"Comp_NewItem"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList,"Comp_NewRQ"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList,"Comp_ConfigCheckIsPending"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList, "Comp_LineNumber"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue("");
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue("");
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue("");
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue("");
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue("");
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList, "Comp_EffectiveDatesFrom"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList,"Comp_EffectiveDatesTo"));
										cellIndex++;

										cell = bundleRow.createCell(cellIndex);
										cell.setCellValue(dataCheck(bundleCompLinkedList,"Comp_BPrice"));
										cellIndex++;

										bundleColumnIndex = cellIndex;
										bundleHorRow++;
									}
									horRow = bundleHorRow - 1;

								} catch (Exception e) {
									e.printStackTrace();
								}

							} else {
								Cell cell;
								cell = row.createCell(columnIndex);
								cell.setCellValue(productObj.get(key).toString());
								System.out.println("-------");
								if ((productObj.get(key)).matches("[0-9.]+")
										&& (productObj.get(key)).length() >= 1) {
									if (productObj.get(key).contains(".")) {
										double result = Double.parseDouble(productObj.get(key));
										CellStyle style;

										style = workbook.createCellStyle();
										style.setAlignment(CellStyle.ALIGN_LEFT);
										cell.setCellValue(result);
										cell.setCellStyle(style);
									} else {
										int result = Integer.parseInt((productObj.get(key)));
										CellStyle style;

										style = workbook.createCellStyle();
										style.setAlignment(CellStyle.ALIGN_LEFT);
										cell.setCellValue(result);
										cell.setCellStyle(style);
									}

								}
							}

							columnIndex++;

						}

					}
					horRow++;
					System.out.println("horRow" + horRow);
				}
			}
			String excelFileName = "";
			FileOutputStream fos = null;
			try {
				excelFileName = KafkaSpecialPricingReportConstants.AllCommSpecialPriceName + "-DealSummary.xlsx";
				/*Writing output to a temporary excel file*/
				file = new File(excelFileName);
				fos = new FileOutputStream(file);
				workbook.write(fos);
				fos.close();				
				FileDataSource fds = new FileDataSource(file);
				file = fds.getFile();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally {
				try {
					fos.flush();
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return file;
	}

	public File xmlFileDownloadService(JSONArray jsonArray) {

		File file = null;
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			Element rootElement = doc.createElementNS("https://h21033.www2.hp.com https://h21033.www2.hp.com/deal9.xsd",
					"Deals");
			doc.appendChild(rootElement);
			for (int h = 0; h < jsonArray.length(); h++) {
				JSONObject details = jsonArray.getJSONObject(h);
				JSONArray prodDetails = null;
				if (details.has("productDetails") && details.getJSONArray("productDetails").length() > 0) {
					prodDetails = details.getJSONArray("productDetails");
				} else {
					prodDetails = new JSONArray();
				}
				JSONObject detail = details.getJSONObject("dealDetails");
				Map<String, String> dealObj = pricingEmailServiceImpl.convertDealJsonObjectToLinkedHashMap(detail);

				Element deal = doc.createElement("Deal");
				Set<String> dealKeySet = (Set<String>) dealObj.keySet();
				Iterator<String> dealKeys = dealKeySet.iterator();
				while (dealKeys.hasNext()) {
					String key = dealKeys.next();
					if (key.equalsIgnoreCase("AdditionalCountries")) {
						String[] parts = dealObj.get(key).split(",");
						Element addCountry = doc.createElement("AdditionalCountries");
						for (String countrykey : parts) {
							Element node = doc.createElement("Country");
							node.appendChild(doc.createTextNode(countrykey));
							addCountry.appendChild(node);
						}
						deal.appendChild(addCountry);
					} else if (key.equalsIgnoreCase("ResellerA")) {
						Element ResellerAList = doc.createElement("ResellerAList");
						Element node = doc.createElement("ResellerA");
						Element childnode = doc.createElement("RslrAName");
						childnode.appendChild(doc.createTextNode(dealObj.get(key).toString()));
						node.appendChild(childnode);
						Element childnodeA = doc.createElement("Party_ID");

						node.appendChild(childnodeA);
						ResellerAList.appendChild(node);
						deal.appendChild(ResellerAList);
					} else if (key.equalsIgnoreCase("ResellerB")) {
						Element ResellerBList = doc.createElement("ResellerBList");
						Element node = doc.createElement("ResellerB");
						Element childnode = doc.createElement("RslrBName");
						childnode.appendChild(doc.createTextNode(dealObj.get(key).toString()));
						node.appendChild(childnode);
						Element childnodeA = doc.createElement("Party_ID");
						node.appendChild(childnodeA);
						ResellerBList.appendChild(node);
						deal.appendChild(ResellerBList);
					} else {
						Element nodeB = doc.createElement(key);
						nodeB.appendChild(doc.createTextNode(dealObj.get(key).toString()));
						deal.appendChild(nodeB);
						rootElement.appendChild(deal);
					}

				}

				if (prodDetails.length() > 0 && prodDetails != null) {
					for (int rowIndex = 0; rowIndex < prodDetails.length(); rowIndex++) {
						Element product = doc.createElement("Product");
						JSONObject prodDetail = new JSONObject(prodDetails.get(rowIndex).toString());
						Map<String, String> prodObj = pricingEmailServiceImpl
								.convertProductJsonObjectToLinkedHashMap(prodDetail);
						Set<String> keySet = (Set<String>) prodObj.keySet();
						Iterator<String> keys = keySet.iterator();
						while (keys.hasNext()) {
							String productkey = keys.next();
							try {
								if (productkey.equalsIgnoreCase("bundle")) {
									Element bundleCompList = doc.createElement("BundleComponentList");

									JSONArray bundleArray = new JSONArray(prodObj.get(productkey));
									for (int bundleIndex = 0; bundleIndex < bundleArray.length(); bundleIndex++) {

										Element bundleComp = doc.createElement("BundleComponent");
										JSONObject bundleObj = (JSONObject) bundleArray.getJSONObject(bundleIndex);
									
										Element node1 = doc.createElement("Comp_BundleID");
										node1.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_BundleID")));
										bundleComp.appendChild(node1);

										Element node2 = doc.createElement("Comp_ComponentID");
										node2.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_ComponentID")));
										bundleComp.appendChild(node2);

										Element node3 = doc.createElement("Comp_OptionCode");
										node3.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_OptionCode")));
										bundleComp.appendChild(node3);

										Element node4 = doc.createElement("Comp_ProductLine");
										node4.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_ProductLine")));
										bundleComp.appendChild(node4);

										Element node5 = doc.createElement("Comp_Quantity");
										node5.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_Quantity")));
										bundleComp.appendChild(node5);

										Element node6 = doc.createElement("Comp_ProductDescription");
										node6.appendChild(
												doc.createTextNode(dataCheck(bundleObj, "Comp_ProductDescription")));
										bundleComp.appendChild(node6);

										Element node7 = doc.createElement("Comp_ListPrice");
										node7.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_ListPrice")));
										bundleComp.appendChild(node7);

										Element node8 = doc.createElement("Comp_StdDiscPct");
										node8.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_StdDiscPct")));
										bundleComp.appendChild(node8);

										Element node9 = doc.createElement("Comp_DiscPct");
										node9.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_DiscPct")));
										bundleComp.appendChild(node9);

										Element node10 = doc.createElement("Comp_Offering");
										node10.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_Offering")));
										bundleComp.appendChild(node10);

										Element node11 = doc.createElement("Comp_OfferType");
										node11.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_OfferType")));
										bundleComp.appendChild(node11);

										Element node12 = doc.createElement("Comp_Add_lDiscountPctOffListPrice");
										node12.appendChild(doc.createTextNode(
												dataCheck(bundleObj, "Comp_Add_lDiscountPctOffListPrice")));
										bundleComp.appendChild(node12);

										Element node13 = doc.createElement("Comp_NewItem");
										node13.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_NewItem")));
										bundleComp.appendChild(node13);

										Element node14 = doc.createElement("Comp_NewRQ");
										node14.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_NewRQ")));
										bundleComp.appendChild(node14);

										Element node15 = doc.createElement("Comp_ConfigCheckIsPending");
										node15.appendChild(
												doc.createTextNode(dataCheck(bundleObj, "Comp_ConfigCheckIsPending")));
										bundleComp.appendChild(node15);

										Element node16 = doc.createElement("Comp_LineNumber");
										node16.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_LineNumber")));
										bundleComp.appendChild(node16);

										Element node17 = doc.createElement("Comp_EffectiveDatesFrom");
										node17.appendChild(
												doc.createTextNode(dataCheck(bundleObj, "Comp_EffectiveDatesFrom")));
										bundleComp.appendChild(node17);

										Element node18 = doc.createElement("Comp_EffectiveDatesTo");
										node18.appendChild(
												doc.createTextNode(dataCheck(bundleObj, "Comp_EffectiveDatesTo")));
										bundleComp.appendChild(node18);

										Element node19 = doc.createElement("Comp_BPrice");
										node19.appendChild(doc.createTextNode(dataCheck(bundleObj, "Comp_BPrice")));
										bundleComp.appendChild(node19);

										bundleCompList.appendChild(bundleComp);
									}
									product.appendChild(bundleCompList);
								} else if (!productkey.equals("ComponentID")) {

									Element node = doc.createElement(productkey);
									node.appendChild(doc.createTextNode(prodObj.get(productkey).toString()));

									product.appendChild(node);
									rootElement.appendChild(product);
								}
							} catch (Exception e) {
								e.printStackTrace();
							}

							deal.appendChild(product);
						}
					}
				}
			}

			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			StreamResult result = new StreamResult(new StringWriter());
			DOMSource source = new DOMSource(doc);
			transformer.transform(source, result);
			String xmlString = result.getWriter().toString();
			byte[] res = xmlString.getBytes(Charset.forName("UTF-8"));
			FileOutputStream fileOut = null;
			file = new File(KafkaSpecialPricingReportConstants.AllCommSpecialPriceName + "-DealSummary.xml");
			fileOut = new FileOutputStream(file);
			fileOut.write(res);
			FileDataSource fds = new FileDataSource(file);
			file = fds.getFile();
			fileOut.close();
			fileOut.flush();

		} catch (DOMException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}

		return file;
	}

	public File textFileDownloadService(JSONArray jsonArray) {

		PrintWriter printWriter = null;
		String fileName = KafkaSpecialPricingReportConstants.AllCommSpecialPriceName + "-DealSummary.txt";
		File file = new File(fileName);
		try {
			FileWriter fileWriter = new FileWriter(fileName);
			printWriter = new PrintWriter(fileWriter);
			JSONObject details1 = new JSONObject();
			JSONObject prodHeader = new JSONObject();
			int n = 0;
			for (int i = 0; i <= jsonArray.length(); i++) {
				if (n == 0) {
					JSONObject jsons = new JSONObject();
					jsons = jsonArray.getJSONObject(i);
					if (jsons.has("dealDetails") && jsons.has("productDetails") && jsons.has("resellerDetails")) {
						details1 = jsons;
						n++;
					}
				}
			}

			if (details1.has("productDetails") && details1.getJSONArray("productDetails").length() > 0) {
				prodHeader = details1.getJSONArray("productDetails").getJSONObject(0);
			}
			JSONObject detail = details1.getJSONObject("dealDetails");
			Map<String, String> dealObjHeader = pricingEmailServiceImpl.convertDealJsonObjectToLinkedHashMap(detail);

			String[] dealHeader = dealObjHeader.keySet().toArray(new String[dealObjHeader.size()]);
			for (String head : dealHeader) {
				printWriter.write(head + "|");
			}
			Map<String, String> productObjHeader = pricingEmailServiceImpl
					.convertProductJsonObjectToLinkedHashMap(prodHeader);
			String[] productHeader = productObjHeader.keySet().toArray(new String[productObjHeader.size()]);
			for (String head : productHeader) {
				if (!head.equalsIgnoreCase("bundle")) {
					printWriter.write(head + "|");
				}
			}
			printWriter.println();

			for (int h = 0; h < jsonArray.length(); h++) {

				JSONObject details = jsonArray.getJSONObject(h);
				JSONArray prodDetails = new JSONArray();
				if (details.has("productDetails")) {
					prodDetails = details.getJSONArray("productDetails");
				}
				JSONObject deal = details.getJSONObject("dealDetails");
				Map<String, String> dealObj = pricingEmailServiceImpl.convertDealJsonObjectToLinkedHashMap(deal);
				for (int rowIndex = 0; rowIndex < prodDetails.length(); rowIndex++) {
					JSONObject prodObject = prodDetails.getJSONObject(rowIndex);
					Map<String, String> productObj = pricingEmailServiceImpl
							.convertProductJsonObjectToLinkedHashMap(prodObject);

					Set<String> keySet = (Set<String>) productObj.keySet();
					Iterator<String> prodkeys = keySet.iterator();

					Set<String> dealKeySet = (Set<String>) dealObj.keySet();
					Iterator<String> dealKeys = dealKeySet.iterator();

					while (dealKeys.hasNext()) {
						String dealKey = dealKeys.next();
						printWriter.write(dealObj.get(dealKey) + "|");
					}
					System.out.println("---" + prodkeys);
					while (prodkeys.hasNext()) {
						String key = prodkeys.next();
						System.out.println(key);
						try {
							if (key.equalsIgnoreCase("Bundle")) {
								JSONArray bundleArray = new JSONArray(productObj.get(key));
								for (int bundleIndex = 0; bundleIndex < bundleArray.length(); bundleIndex++) {
									printWriter.println();
									JSONObject bundleObj = (JSONObject) bundleArray.getJSONObject(bundleIndex);
//									Iterator<String> bundlekeys = bundleObj.keys();

									Set<String> dealKeySet_bundle = (Set<String>) dealObj.keySet();
									Iterator<String> BundledealKeys = dealKeySet_bundle.iterator();

									Set<String> prodkeySet_bundle = (Set<String>) productObj.keySet();
									Iterator<String> prodBundlekey = prodkeySet_bundle.iterator();
									while (BundledealKeys.hasNext()) {
										String dealKey = BundledealKeys.next();
										printWriter.write(dealObj.get(dealKey) + "|");
									}
									printWriter.write(dataCheck(bundleObj, "Comp_LineType") + "|");
									printWriter.write("" + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_OptionCode") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_BundleID") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_ComponentID") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_ProductLine") + "|");
									printWriter.write("" + "|");
									printWriter.write("" + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_Quantity") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_ProductDescription") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_ListPrice") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_StdDiscPct") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_DiscPct") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_Offering") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_OfferType") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_Add_lDiscountPctOffListPrice") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_NewItem") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_NewRQ") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_ConfigCheckIsPending") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_LineNumber") + "|");
									printWriter.write("" + "|");
									printWriter.write("" + "|");
									printWriter.write("" + "|");
									printWriter.write("" + "|");
									printWriter.write("" + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_EffectiveDatesFrom") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_EffectiveDatesTo") + "|");
									printWriter.write(dataCheck(bundleObj, "Comp_BPrice") + "|");

								}

							} else {
								printWriter.write(productObj.get(key) + "|");
							}

						} catch (Exception e) {
							e.printStackTrace();
						}

					}

					printWriter.println();
				}
			}
			FileDataSource fds = new FileDataSource(file);
			file = fds.getFile();
			printWriter.close();
			printWriter.flush();

		} catch (Exception e) {
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		}
		return file;
	}
/* Method is used to validate the data and return the data as String
 * Parameter : JSONObject & Key as String */
	private String dataCheck(JSONObject jsonObject, String key) {
		String data = "";
		if (jsonObject.has(key)) {
			if (key.equalsIgnoreCase("Comp_ListPrice") || key.equalsIgnoreCase("Comp_StdDiscPct")) {
				long value = jsonObject.getLong(key);
				return data = Long.toString(value);
			} else {
				return data = jsonObject.getString(key);
			}
		} else {
			return data;
		}
	}

}