package com.allcomm.kafka.integration.entities;
public class CrossPlantMaterialStatus
{
    private String CrossPlantMaterialStatusCode;

    private String CrossPlantMaterialStatusDescription;

    private String SourceSystemCode;

    public String getCrossPlantMaterialStatusCode ()
    {
        return CrossPlantMaterialStatusCode;
    }

    public void setCrossPlantMaterialStatusCode (String CrossPlantMaterialStatusCode)
    {
        this.CrossPlantMaterialStatusCode = CrossPlantMaterialStatusCode;
    }

    public String getCrossPlantMaterialStatusDescription ()
    {
        return CrossPlantMaterialStatusDescription;
    }

    public void setCrossPlantMaterialStatusDescription (String CrossPlantMaterialStatusDescription)
    {
        this.CrossPlantMaterialStatusDescription = CrossPlantMaterialStatusDescription;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [CrossPlantMaterialStatusCode = "+CrossPlantMaterialStatusCode+", CrossPlantMaterialStatusDescription = "+CrossPlantMaterialStatusDescription+", SourceSystemCode = "+SourceSystemCode+"]";
    }
}