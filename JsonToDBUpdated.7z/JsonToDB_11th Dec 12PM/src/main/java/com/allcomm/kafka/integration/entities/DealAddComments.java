package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_DEAL_ADD_COMMENTS")
public class DealAddComments {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DEAL_COMMENTS_ID")
	private long id;

	@Column(name = "DEAL_ID")
	private long dealId;

	@Column(name = "SAP_DOCUMENT_NO")
	private long sapDocNo;

	@Column(name = "COMMENT_TYPE")
	private String cmntType;

	@Column(name = "COMMENTS_SETTING")
	private String cmntsSetting;

	@Column(name = "COMMENT_RECEPIENT")
	private String cmntRecepient;

	@Column(name = "STANDARD_T_C")
	private String standardTC;

	@Column(name = "T_C_COMMENT")
	private String tCComment;

	@Column(name = "COMMENT_BOX")
	private String cmntBox;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "DATE")
	private Date date;

	@Column(name = "TIME")
	private Date time;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getDealId() {
		return dealId;
	}

	public void setDealId(long dealId) {
		this.dealId = dealId;
	}

	public long getSapDocNo() {
		return sapDocNo;
	}

	public void setSapDocNo(long sapDocNo) {
		this.sapDocNo = sapDocNo;
	}

	public String getCmntType() {
		return cmntType;
	}

	public void setCmntType(String cmntType) {
		this.cmntType = cmntType;
	}

	public String getCmntsSetting() {
		return cmntsSetting;
	}

	public void setCmntsSetting(String cmntsSetting) {
		this.cmntsSetting = cmntsSetting;
	}

	public String getCmntRecepient() {
		return cmntRecepient;
	}

	public void setCmntRecepient(String cmntRecepient) {
		this.cmntRecepient = cmntRecepient;
	}

	public String getStandardTC() {
		return standardTC;
	}

	public void setStandardTC(String standardTC) {
		this.standardTC = standardTC;
	}

	public String gettCComment() {
		return tCComment;
	}

	public void settCComment(String tCComment) {
		this.tCComment = tCComment;
	}

	public String getCmntBox() {
		return cmntBox;
	}

	public void setCmntBox(String cmntBox) {
		this.cmntBox = cmntBox;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	
}
