package com.allcomm.kafka.integration.entities;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "PRICING_SPL_DEAL_ADD_CTRY_PRC_DESCRIPTORS")
public class DealAddCtryPrcDescriptors implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ADD_CTRY_PRC_DES_ID")
	private long addCtryPrcDescId;

	@Column(name = "DEAL_ID")
	private long dealId;

	@Column(name = "ADDITIONAL_COUNTRY")
	private String additionalCountry;

	@Column(name = "priceGeo")
	private String priceGEO;

	@Column(name = "PRICE_LIST")
	private String priceList;

	@Column(name = "INCOTERM")
	private String incoterm;

	@Column(name = "CURRENCY")
	private String currency;

	@Column(name = "SAP_DOCUMENT_NO")
	private long sapDocNo;

	@Column(name = "DEAL_VERSION")
	private long dealVersion;

	public long getAddCtryPrcDescId() {
		return addCtryPrcDescId;
	}

	public void setAddCtryPrcDescId(long addCtryPrcDescId) {
		this.addCtryPrcDescId = addCtryPrcDescId;
	}

	public long getDealId() {
		return dealId;
	}

	public void setDealId(long dealId) {
		this.dealId = dealId;
	}

	public String getAdditionalCountry() {
		return additionalCountry;
	}

	public void setAdditionalCountry(String additionalCountry) {
		this.additionalCountry = additionalCountry;
	}

	public String getPriceGEO() {
		return priceGEO;
	}

	public void setPriceGEO(String priceGEO) {
		this.priceGEO = priceGEO;
	}

	public String getPriceList() {
		return priceList;
	}

	public void setPriceList(String priceList) {
		this.priceList = priceList;
	}

	public String getIncoterm() {
		return incoterm;
	}

	public void setIncoterm(String incoterm) {
		this.incoterm = incoterm;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public long getSapDocNo() {
		return sapDocNo;
	}

	public void setSapDocNo(long sapDocNo) {
		this.sapDocNo = sapDocNo;
	}

	public long getDealVersion() {
		return dealVersion;
	}

	public void setDealVersion(long dealVersion) {
		this.dealVersion = dealVersion;
	}

	@Override
	public String toString() {
		return "DealAddCtryPrcDescriptors [addCtryPrcDescId=" + addCtryPrcDescId + ", dealId=" + dealId
				+ ", additionalCountry=" + additionalCountry + ", priceGEO=" + priceGEO + ", priceList=" + priceList
				+ ", incoterm=" + incoterm + ", currency=" + currency + ", sapDocNo=" + sapDocNo + ", dealVersion="
				+ dealVersion + "]";
	}
	
	

	}
