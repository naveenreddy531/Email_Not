package com.allcomm.kafka.integration.entities;

import javax.persistence.*;

@Entity
@Table(name = "PRICING_SPL")
public class DealAttachement {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DEAL_ATTACHMENT_ID")
	private long dealAttchId;

	@Column(name = "DEAL_ID")
	private long dealId;

	@Column(name = "EXT_DOC_FILENAME")
	private String extDocFileName;

	@Column(name = "EXT_DOC_SIZE")
	private String extDocSize;

	public long getDealAttchId() {
		return dealAttchId;
	}

	public void setDealAttchId(long dealAttchId) {
		this.dealAttchId = dealAttchId;
	}

	public long getDealId() {
		return dealId;
	}

	public void setDealId(long dealId) {
		this.dealId = dealId;
	}

	public String getExtDocFileName() {
		return extDocFileName;
	}

	public void setExtDocFileName(String extDocFileName) {
		this.extDocFileName = extDocFileName;
	}

	public String getExtDocSize() {
		return extDocSize;
	}

	public void setExtDocSize(String extDocSize) {
		this.extDocSize = extDocSize;
	}

}
