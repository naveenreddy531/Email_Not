package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_DEAL_BUNDLE_HEADER")
public class DealBundleHeader {

	@Id
	@Column(name = "BUNDLE_HEADER_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long bundleHeaderId;

	@Column(name = "BUNDLE_IDENTIFIER")
	private String bundleIdentifier;
	
	@Column(name = "DEAL_ID")
	private long dealId;

	@Column(name = "PRODUCT_NUMBER")
	private String prodNo;

	@Column(name = "PRODUCT_DESCRIPTION")
	private String prodDesc;

	@Column(name = "LINE_TYPE")
	private String lineType;

	@Column(name = "LINE_NUMBER")
	private long lineNo;

	@Column(name = "SOURCE_CONFIG_DESCRIPTION")
	private String srcConfiDesc;

	@Column(name = "CONFIG_ID")
	private long configId;

	@Column(name = "SPECIAL_CONFIG_FLAG")
	private String spcialConfiFlag;

	@Column(name = "DISPLAY_COMP_PRICE")
	private String dispCompPrice;

	@Column(name = "LAST_MODIFIED_Date")
	private Date lastModifiedDate;

	@Column(name = "COMPONENT_CHANGE_Date")
	private Date componentChangeDate;

	@Column(name = "SOURCE_CONFIG_ID")
	private String sourceConfigId;

	@Column(name = "CONFIGURATION_VALIDATION_CODE")
	private String configurationValidationCode;

	@Column(name = "CONFIGURATION_VALIDITY_Date")
	private Date configurationValidityDate;

	@Column(name = "FUTURE_PRODUCT_FLAG")
	private String futureProductFlag;

	@Column(name = "SAP_DOCUMENT_NO")
	private long sapDocumentNo;

	@Column(name = "DEAL_VERSION")
	private long dealVersion;
	
	public long getBundleHeaderId() {
		return bundleHeaderId;
	}

	public void setBundleHeaderId(long bundleHeaderId) {
		this.bundleHeaderId = bundleHeaderId;
	}

	public String getBundleIdentifier() {
		return bundleIdentifier;
	}

	public void setBundleIdentifier(String bundleIdentifier) {
		this.bundleIdentifier = bundleIdentifier;
	}

	public long getDealId() {
		return dealId;
	}

	public void setDealId(long dealId) {
		this.dealId = dealId;
	}

	public String getProdNo() {
		return prodNo;
	}

	public void setProdNo(String prodNo) {
		this.prodNo = prodNo;
	}

	public String getProdDesc() {
		return prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	public String getLineType() {
		return lineType;
	}

	public void setLineType(String lineType) {
		this.lineType = lineType;
	}

	public long getLineNo() {
		return lineNo;
	}

	public void setLineNo(long lineNo) {
		this.lineNo = lineNo;
	}

	public String getSrcConfiDesc() {
		return srcConfiDesc;
	}

	public void setSrcConfiDesc(String srcConfiDesc) {
		this.srcConfiDesc = srcConfiDesc;
	}

	public long getConfigId() {
		return configId;
	}

	public void setConfigId(long configId) {
		this.configId = configId;
	}

	public String getSpcialConfiFlag() {
		return spcialConfiFlag;
	}

	public void setSpcialConfiFlag(String spcialConfiFlag) {
		this.spcialConfiFlag = spcialConfiFlag;
	}

	public String getDispCompPrice() {
		return dispCompPrice;
	}

	public void setDispCompPrice(String dispCompPrice) {
		this.dispCompPrice = dispCompPrice;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Date getComponentChangeDate() {
		return componentChangeDate;
	}

	public void setComponentChangeDate(Date componentChangeDate) {
		this.componentChangeDate = componentChangeDate;
	}

	public String getSourceConfigId() {
		return sourceConfigId;
	}

	public void setSourceConfigId(String sourceConfigId) {
		this.sourceConfigId = sourceConfigId;
	}

	public String getConfigurationValidationCode() {
		return configurationValidationCode;
	}

	public void setConfigurationValidationCode(String configurationValidationCode) {
		this.configurationValidationCode = configurationValidationCode;
	}

	public Date getConfigurationValidityDate() {
		return configurationValidityDate;
	}

	public void setConfigurationValidityDate(Date configurationValidityDate) {
		this.configurationValidityDate = configurationValidityDate;
	}

	public String getFutureProductFlag() {
		return futureProductFlag;
	}

	public void setFutureProductFlag(String futureProductFlag) {
		this.futureProductFlag = futureProductFlag;
	}

	public long getSapDocumentNo() {
		return sapDocumentNo;
	}

	public void setSapDocumentNo(long sapDocumentNo) {
		this.sapDocumentNo = sapDocumentNo;
	}

	public long getDealVersion() {
		return dealVersion;
	}

	public void setDealVersion(long dealVersion) {
		this.dealVersion = dealVersion;
	}

}
