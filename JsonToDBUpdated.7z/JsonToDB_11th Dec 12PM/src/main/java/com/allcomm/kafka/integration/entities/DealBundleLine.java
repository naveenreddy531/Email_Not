package com.allcomm.kafka.integration.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "PRICING_SPL_DEAL_BUNDLE_LINE")
public class DealBundleLine implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BUNDLE_LINE_ID")
	private long bundleLineId;

	@Column(name = "DEAL_ID")
	private long dealId;

	@Column(name = "LINE_NR")
	private long lineNr;

	@Column(name = "SCALE_ID")
	private long scaleId;

	@Column(name = "BUNDLE_NO")
	private String bundleNo;

	@Column(name = "VERSION_CREATED")
	private long versionCreated;

	@Column(name = "ASSOCIATE_PLC")
	private String associatePLC;

	@Column(name = "AUTHORIZED_Date")
	private Date authorizedDate;

	@Column(name = "COMPONENET_LEVEL_CODE")
	private String componentLevelCode;

	@Column(name = "CREATION_Date")
	private Date creationDate;

	@Column(name = "UPDATION_Date")
	private Date updationDate;

	@Column(name = "REFERECE_PRICE_FLAG")
	private String refPriceFlag;

	@Column(name = "PRICE_LIST_CODE")
	private String priceListCode;

	@Column(name = "PRICE_TEAM_CODE")
	private String priceTeamCode;

	@Column(name = "BANDED_FLAG")
	private String bandedFlag;

	@Column(name = "SPECIAL_CONFIG_FLAG")
	private String spclConfiFlag;

	@Column(name = "VERIFIED_MULTICOUNTRY_FLAG")
	private String verifiedMulticountryFlag;

	@Column(name = "SP_STATUS")
	private String spStatus;

	@Column(name = "PRICE_MODELLING_FLAG")
	private String priceModellingFlag;

	@Column(name = "AUTHORIZATION_STATUS_DESC")
	private String authorizationStatusDesc;

	@Column(name = "LINE_AUTH_TYPE")
	private String lineAuthType;

	@Column(name = "AUTHORIZATION_STATUS")
	private String authorizationStatus;

	@Column(name = "PREV_PRICE_AMOUNT")
	private double prevPriceAmnt;

	@Column(name = "HAS_MCC")
	private String hasMcc;

	@Column(name = "INS_PRC_METHOD")
	private String insPrcMethod;

	@Column(name = "INS_PRC_AMT")
	private double insPrcAmt;

	@Column(name = "MEDALLION_NET_AMT")
	private double medallionNetAmt;

	@Column(name = "MEDALLION_LEVEL")
	private String medallionLevel;

	@Column(name = "ITEM_NUMBER")
	private String itemNo;

	@Column(name = "CLASS_CODE")
	private String classCode;

	@Column(name = "QUANTITY")
	private double qty;

	@Column(name = "STD_DISC")
	private double stdDisc;

	@Column(name = "LINE_TYPE")
	private String lineType;

	@Column(name = "LINE_ITEM_NO")
	private long lineItemNo;

	@Column(name = "OPT_CODE")
	private String optCode;

	@Column(name = "DESCRIPTION")
	private String discription;

	@Column(name = "PL")
	private String pl;

	@Column(name = "PRODUCT_CATEGORY")
	private String prodCat;

	@Column(name = "BUSINESS_GROUP")
	private String businessGroup;

	@Column(name = "BUSINESS_UNIT")
	private String businessUnit;

	@Column(name = "BUSINESS_UNIT_DESCRIPTION")
	private String businessUnitDescription;

	@Column(name = "LIST_PRICE")
	private double listPrice;

	@Column(name = "PRC_TYPE")
	private String prcType;

	@Column(name = "AUTH_BDNET")
	private double authBDNet;

	@Column(name = "AUTH_ADD")
	private double authAdd;

	@Column(name = "AUTH_TOTAL")
	private double authTotal;

	@Column(name = "CONFIG_ID")
	private String configId;

	@Column(name = "SAP_DOCUMENT_NO")
	private long sapDocumentNo;

	@Column(name = "DEAL_VERSION")
	private long dealVersion;

	@Column(name = "BUNDLE_IDENTIFIER")
	private String bundleIdentifier;
	@Column(name = "PRODUCT_COST_AMOUNT")
	private double productCostAmount;
	@Column(name = "PRODUCT_COST_DATE")
	private Date productCostDate;
	@Column(name = "REQUESTED_GROSS_MARGIN_AMOUNT")
	private double requestedGrossMarginAmount;
	@Column(name = "REQUESTED_GROSS_MARGIN_PERCENTAGE")
	private double requestedGrossMarginPercentage;
	@Column(name = "AUTHORIZED_GROSS_MARGIN_PERCENTAGE")
	private double authorizedGrossMarginPercentage;
	@Column(name = "EXTENDED_REQUESTED_BIG_DEAL_NET_AMOUNT")
	private double extendedRequestedBigDealNetAmount;
	@Column(name = "EXTENDED_AUTHORIZED_BIG_DEAL_NET_AMOUNT")
	private double extendedAuthorizedBigDealNetAmount;
	@Column(name = "EXTENDED_LIST_PRICE_AMOUNT")
	private double extendedListPriceAmount;
	@Column(name = "FIXED_DISCOUNT_REQUESTED_AMOUNT")
	private double fixedDiscountRequestedAmount;
	@Column(name = "FIXED_DISCOUNT_AUTHORIZED_AMOUNT")
	private double fixedDiscountAuthorizedAmount;
	@Column(name = "USER_EMAIL_IDENTIFIER")
	private String userEmailIdentifier;
	@Column(name = "AUTHORIZED_EMAIL_IDENTIFIER")
	private String authorizedEmailIdentifier;

	public long getBundleLineId() {
		return bundleLineId;
	}

	public void setBundleLineId(long bundleLineId) {
		this.bundleLineId = bundleLineId;
	}

	public long getDealId() {
		return dealId;
	}

	public void setDealId(long dealId) {
		this.dealId = dealId;
	}

	public long getLineNr() {
		return lineNr;
	}

	public void setLineNr(long lineNr) {
		this.lineNr = lineNr;
	}

	public long getScaleId() {
		return scaleId;
	}

	public void setScaleId(long scaleId) {
		this.scaleId = scaleId;
	}

	public String getBundleNo() {
		return bundleNo;
	}

	public void setBundleNo(String bundleNo) {
		this.bundleNo = bundleNo;
	}

	public long getVersionCreated() {
		return versionCreated;
	}

	public void setVersionCreated(long versionCreated) {
		this.versionCreated = versionCreated;
	}

	public String getAssociatePLC() {
		return associatePLC;
	}

	public void setAssociatePLC(String associatePLC) {
		this.associatePLC = associatePLC;
	}

	public Date getAuthorizedDate() {
		return authorizedDate;
	}

	public void setAuthorizedDate(Date authorizedDate) {
		this.authorizedDate = authorizedDate;
	}

	public String getComponentLevelCode() {
		return componentLevelCode;
	}

	public void setComponentLevelCode(String componentLevelCode) {
		this.componentLevelCode = componentLevelCode;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getUpdationDate() {
		return updationDate;
	}

	public void setUpdationDate(Date updationDate) {
		this.updationDate = updationDate;
	}

	public String getRefPriceFlag() {
		return refPriceFlag;
	}

	public void setRefPriceFlag(String refPriceFlag) {
		this.refPriceFlag = refPriceFlag;
	}

	public String getPriceListCode() {
		return priceListCode;
	}

	public void setPriceListCode(String priceListCode) {
		this.priceListCode = priceListCode;
	}

	public String getPriceTeamCode() {
		return priceTeamCode;
	}

	public void setPriceTeamCode(String priceTeamCode) {
		this.priceTeamCode = priceTeamCode;
	}

	public String getBandedFlag() {
		return bandedFlag;
	}

	public void setBandedFlag(String bandedFlag) {
		this.bandedFlag = bandedFlag;
	}

	public String getSpclConfiFlag() {
		return spclConfiFlag;
	}

	public void setSpclConfiFlag(String spclConfiFlag) {
		this.spclConfiFlag = spclConfiFlag;
	}

	public String getVerifiedMulticountryFlag() {
		return verifiedMulticountryFlag;
	}

	public void setVerifiedMulticountryFlag(String verifiedMulticountryFlag) {
		this.verifiedMulticountryFlag = verifiedMulticountryFlag;
	}

	public String getSpStatus() {
		return spStatus;
	}

	public void setSpStatus(String spStatus) {
		this.spStatus = spStatus;
	}

	public String getPriceModellingFlag() {
		return priceModellingFlag;
	}

	public void setPriceModellingFlag(String priceModellingFlag) {
		this.priceModellingFlag = priceModellingFlag;
	}

	public String getAuthorizationStatusDesc() {
		return authorizationStatusDesc;
	}

	public void setAuthorizationStatusDesc(String authorizationStatusDesc) {
		this.authorizationStatusDesc = authorizationStatusDesc;
	}

	public String getLineAuthType() {
		return lineAuthType;
	}

	public void setLineAuthType(String lineAuthType) {
		this.lineAuthType = lineAuthType;
	}

	public String getAuthorizationStatus() {
		return authorizationStatus;
	}

	public void setAuthorizationStatus(String authorizationStatus) {
		this.authorizationStatus = authorizationStatus;
	}

	public double getPrevPriceAmnt() {
		return prevPriceAmnt;
	}

	public void setPrevPriceAmnt(double prevPriceAmnt) {
		this.prevPriceAmnt = prevPriceAmnt;
	}

	public String getHasMcc() {
		return hasMcc;
	}

	public void setHasMcc(String hasMcc) {
		this.hasMcc = hasMcc;
	}

	public String getInsPrcMethod() {
		return insPrcMethod;
	}

	public void setInsPrcMethod(String insPrcMethod) {
		this.insPrcMethod = insPrcMethod;
	}

	public double getInsPrcAmt() {
		return insPrcAmt;
	}

	public void setInsPrcAmt(double insPrcAmt) {
		this.insPrcAmt = insPrcAmt;
	}

	public double getMedallionNetAmt() {
		return medallionNetAmt;
	}

	public void setMedallionNetAmt(double medallionNetAmt) {
		this.medallionNetAmt = medallionNetAmt;
	}

	public String getMedallionLevel() {
		return medallionLevel;
	}

	public void setMedallionLevel(String medallionLevel) {
		this.medallionLevel = medallionLevel;
	}

	public String getItemNo() {
		return itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	public double getQty() {
		return qty;
	}

	public void setQty(double qty) {
		this.qty = qty;
	}

	public double getStdDisc() {
		return stdDisc;
	}

	public void setStdDisc(double stdDisc) {
		this.stdDisc = stdDisc;
	}

	public String getLineType() {
		return lineType;
	}

	public void setLineType(String lineType) {
		this.lineType = lineType;
	}

	public long getLineItemNo() {
		return lineItemNo;
	}

	public void setLineItemNo(long lineItemNo) {
		this.lineItemNo = lineItemNo;
	}

	public String getOptCode() {
		return optCode;
	}

	public void setOptCode(String optCode) {
		this.optCode = optCode;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public String getPl() {
		return pl;
	}

	public void setPl(String pl) {
		this.pl = pl;
	}

	public String getProdCat() {
		return prodCat;
	}

	public void setProdCat(String prodCat) {
		this.prodCat = prodCat;
	}

	public String getBusinessGroup() {
		return businessGroup;
	}

	public void setBusinessGroup(String businessGroup) {
		this.businessGroup = businessGroup;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getBusinessUnitDescription() {
		return businessUnitDescription;
	}

	public void setBusinessUnitDescription(String businessUnitDescription) {
		this.businessUnitDescription = businessUnitDescription;
	}

	public double getListPrice() {
		return listPrice;
	}

	public void setListPrice(double listPrice) {
		this.listPrice = listPrice;
	}

	public String getPrcType() {
		return prcType;
	}

	public void setPrcType(String prcType) {
		this.prcType = prcType;
	}

	public double getAuthBDNet() {
		return authBDNet;
	}

	public void setAuthBDNet(double authBDNet) {
		this.authBDNet = authBDNet;
	}

	public double getAuthAdd() {
		return authAdd;
	}

	public void setAuthAdd(double authAdd) {
		this.authAdd = authAdd;
	}

	public double getAuthTotal() {
		return authTotal;
	}

	public void setAuthTotal(double authTotal) {
		this.authTotal = authTotal;
	}

	public String getConfigId() {
		return configId;
	}

	public void setConfigId(String configId) {
		this.configId = configId;
	}

	public long getSapDocumentNo() {
		return sapDocumentNo;
	}

	public void setSapDocumentNo(long sapDocumentNo) {
		this.sapDocumentNo = sapDocumentNo;
	}

	public long getDealVersion() {
		return dealVersion;
	}

	public void setDealVersion(long dealVersion) {
		this.dealVersion = dealVersion;
	}

	public String getBundleIdentifier() {
		return bundleIdentifier;
	}

	public void setBundleIdentifier(String bundleIdentifier) {
		this.bundleIdentifier = bundleIdentifier;
	}

	public double getProductCostAmount() {
		return productCostAmount;
	}

	public void setProductCostAmount(double productCostAmount) {
		this.productCostAmount = productCostAmount;
	}

	public Date getProductCostDate() {
		return productCostDate;
	}

	public void setProductCostDate(Date productCostDate) {
		this.productCostDate = productCostDate;
	}

	public double getRequestedGrossMarginAmount() {
		return requestedGrossMarginAmount;
	}

	public void setRequestedGrossMarginAmount(double requestedGrossMarginAmount) {
		this.requestedGrossMarginAmount = requestedGrossMarginAmount;
	}

	public double getRequestedGrossMarginPercentage() {
		return requestedGrossMarginPercentage;
	}

	public void setRequestedGrossMarginPercentage(double requestedGrossMarginPercentage) {
		this.requestedGrossMarginPercentage = requestedGrossMarginPercentage;
	}

	public double getAuthorizedGrossMarginPercentage() {
		return authorizedGrossMarginPercentage;
	}

	public void setAuthorizedGrossMarginPercentage(double authorizedGrossMarginPercentage) {
		this.authorizedGrossMarginPercentage = authorizedGrossMarginPercentage;
	}

	public double getExtendedRequestedBigDealNetAmount() {
		return extendedRequestedBigDealNetAmount;
	}

	public void setExtendedRequestedBigDealNetAmount(double extendedRequestedBigDealNetAmount) {
		this.extendedRequestedBigDealNetAmount = extendedRequestedBigDealNetAmount;
	}

	public double getExtendedAuthorizedBigDealNetAmount() {
		return extendedAuthorizedBigDealNetAmount;
	}

	public void setExtendedAuthorizedBigDealNetAmount(double extendedAuthorizedBigDealNetAmount) {
		this.extendedAuthorizedBigDealNetAmount = extendedAuthorizedBigDealNetAmount;
	}

	public double getExtendedListPriceAmount() {
		return extendedListPriceAmount;
	}

	public void setExtendedListPriceAmount(double extendedListPriceAmount) {
		this.extendedListPriceAmount = extendedListPriceAmount;
	}

	public double getFixedDiscountRequestedAmount() {
		return fixedDiscountRequestedAmount;
	}

	public void setFixedDiscountRequestedAmount(double fixedDiscountRequestedAmount) {
		this.fixedDiscountRequestedAmount = fixedDiscountRequestedAmount;
	}

	public double getFixedDiscountAuthorizedAmount() {
		return fixedDiscountAuthorizedAmount;
	}

	public void setFixedDiscountAuthorizedAmount(double fixedDiscountAuthorizedAmount) {
		this.fixedDiscountAuthorizedAmount = fixedDiscountAuthorizedAmount;
	}

	public String getUserEmailIdentifier() {
		return userEmailIdentifier;
	}

	public void setUserEmailIdentifier(String userEmailIdentifier) {
		this.userEmailIdentifier = userEmailIdentifier;
	}

	public String getAuthorizedEmailIdentifier() {
		return authorizedEmailIdentifier;
	}

	public void setAuthorizedEmailIdentifier(String authorizedEmailIdentifier) {
		this.authorizedEmailIdentifier = authorizedEmailIdentifier;
	}

}
