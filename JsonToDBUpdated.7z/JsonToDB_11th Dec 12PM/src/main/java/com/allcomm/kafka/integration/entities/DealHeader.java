package com.allcomm.kafka.integration.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_DEAL_HEADER")
public class DealHeader implements Serializable {

	private static long serialVersionUID = 6527885610392465677L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SAP_DOCUMENT_NO")
	private long sapDocumentNo;

	@Column(name = "DEAL_ID")
	private long dealID;

	@Column(name = "DEAL_TYPE")
	private String dealType;

	@Column(name = "DEAL_SUB_TYPE")
	private String dealSubType;

	@Column(name = "LEAD_BG")
	private String leadBG;

	@Column(name = "LEAD_BU")
	private String leadBU;

	@Column(name = "RTM_ROUTE_TO_MARKET")
	private String rtmRoutToMarket;

	@Column(name = "LEAD_COUNTRY")
	private String leadCountry;

	@Column(name = "PRICE_GEO")
	private String priceGEO;

	@Column(name = "PRICE_LIST_TYPE")
	private String priceListType;

	@Column(name = "CURRENCY")
	private String currency;

	@Column(name = "INCO_TERMS")
	private String incoTerms;

	@Column(name = "PRICE_TERM_CODE")
	private String priceTermCode;

	@Column(name = "GEOGRAPHIC_SCOPE")
	private String geographicScope;

	@Column(name = "REGION")
	private String region;

	@Column(name = "UPFRONT_REBATE_MIXED")
	private String upfrontRebateMixed;

	@Column(name = "LANGUAGE")
	private String language;

	@Column(name = "GLP_STATUS")
	private String glpStatus;

	@Column(name = "PAYMENT_TERMS")
	private String paymentTerms;

	@Column(name = "ECLIPSE_DEAL_NUMBER")
	private long eclipseDealNumber;

	@Column(name = "VERSION_NUMBER")
	private long versionNumber;

	@Column(name = "VERSION_DATE")
	private Date versionDate;

	@Column(name = "VERSION_TIME")
	private Date versionTime;

	@Column(name = "SOURCE_DEAL")
	private String sourceDeal;

	@Column(name = "TENANT_COMPANY")
	private String tenantCompany;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_BY_USER")
	private String createdByUser;

	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;

	@Column(name = "DEAL_VALIDITY_FROM_DATE")
	private Date dealValidityFromDate;
	@Column(name = "DEAL_VALIDITY_TO_DATE")
	private Date dealValidityToDate;
	@Column(name = "DEAL_VERSION_STATUS")
	private String dealVersionStatus;
	@Column(name = "OPPORTUNITY")
	private String opportunity;
	@Column(name = "CUSTOMER_NUMBER_PARTY_ID")
	private String custNoPartyId;
	@Column(name = "CUSTOMER_LATIN_NAME")
	private String custLatinName;
	@Column(name = "CUSTOMER_NON_LATIN_NAME")
	private String custNonLatinName;
	@Column(name = "ADDRESS")
	private String address;
	@Column(name = "CITY")
	private String city;
	@Column(name = "STATE")
	private String state;
	@Column(name = "POSTAL_ZIP_CODE")
	private String postalZipCode;
	@Column(name = "COUNTRY")
	private String country;
	@Column(name = "CUSTOMER_SEGMENT")
	private String custSegment;
	@Column(name = "INDUSTRY")
	private String industry;
	@Column(name = "ADDITIONAL_LOCATIONS")
	private String additionalLocations;
	@Column(name = "ACTIVE_STATUS")
	private String activeStatus;
	@Column(name = "CUSTOMER_LANGUAGE")
	private String custLanguage;
	@Column(name = "SERVICE_REQUEST_NUMBER_REQUEST_ID")
	private String serviceReqNoReqId;
	@Column(name = "OPPORTUNITY_ID")
	private String opportunityId;
	@Column(name = "DEAL_REG_ID")
	private String dealRegId;
	@Column(name = "DEAL_STATUS")
	private String dealStatus;
	@Column(name = "MC_CHARGE_CODE")
	private String mcChangeCode;
	@Column(name = "PROTECTION_CODE")
	private String protectionCode;
	@Column(name = "PROTECTION_DAYS")
	private long protectionDays;
	@Column(name = "CUSTOMER_ENGAGEMENT")
	private String custmerEngagement;
	@Column(name = "TOTAL_ADDITIONAL_DISCOUNT")
	private double totalAdditionalDiscount;
	@Column(name = "ASAP_INDICATOR")
	private String asapIndicatior;
	@Column(name = "ROUTING_INDICATOR")
	private String routingIndicator;
	@Column(name = "DEAL_SOURCE")
	private String dealSource;
	@Column(name = "DEAL_DESCRIPTION")
	private String dealDescription;
	@Column(name = "FREEZE_DEAL_FLAG")
	private String freezeDealFlag;
	@Column(name = "COMPLEX_DEAL_FLAG")
	private String complexDealFlag;
	@Column(name = "CORPORATE_RESELLER")
	private String corporateReseller;
	@Column(name = "SUPPRESS_IN_ALLCOMMS")
	private String supressInAllcomms;
	@Column(name = "HIGH_RISK_DEAL")
	private String highRiskDeal;
	@Column(name = "GLP_DEAL")
	private String glpDeal;
	@Column(name = "CATALOG_DEAL_FLAG")
	private String catalogDealFlag;
	@Column(name = "PROMO_EXCLUSION")
	private String promoExclusion;
	@Column(name = "GLOBAL_ACCOUNT_FLAG")
	private String globalAccFlag;
	@Column(name = "PROMOTION_FLAG")
	private String promotionFlag;
	@Column(name = "BUNDLE_ACCUMULATION_MODE")
	private String bundleAccmulationMode;
	@Column(name = "OEM_FLAG")
	private String oemFlag;
	@Column(name = "FRAMEWORK_DEAL")
	private String framworkDeal;
	@Column(name = "GLOBAL_DEAL_FLAG")
	private String globalDealFlag;
	@Column(name = "QUOTE_DISTRIBUTION_DATE")
	private Date qoteDistributionDate;
	@Column(name = "PRIMARY_RSL_FL")
	private String primaryRSLFL;
	@Column(name = "SOURCE_DEAL_VERSION_NUMBER")
	private long srcDealVrsnNo;
	@Column(name = "SOURCE_DEAL_TYPE")
	private String srcDealType;
	@Column(name = "LAST_MODIFIED_DATE")
	private Date lastModifiedDate;
	@Column(name = "EXTENDED_DEAL_DURATION_FLAG")
	private String extDealDurFlg;
	@Column(name = "EXTENDED_DEAL_DURATION_DAYS")
	private long extDealDurDays;
	@Column(name = "DB_ULTIMATE_ID")
	private String dbUltimateId;
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public static void setSerialVersionUID(long serialVersionUID) {
		DealHeader.serialVersionUID = serialVersionUID;
	}
	public long getSapDocumentNo() {
		return sapDocumentNo;
	}
	public void setSapDocumentNo(long sapDocumentNo) {
		this.sapDocumentNo = sapDocumentNo;
	}
	public long getDealID() {
		return dealID;
	}
	public void setDealID(long dealID) {
		this.dealID = dealID;
	}
	public String getDealType() {
		return dealType;
	}
	public void setDealType(String dealType) {
		this.dealType = dealType;
	}
	public String getDealSubType() {
		return dealSubType;
	}
	public void setDealSubType(String dealSubType) {
		this.dealSubType = dealSubType;
	}
	public String getLeadBG() {
		return leadBG;
	}
	public void setLeadBG(String leadBG) {
		this.leadBG = leadBG;
	}
	public String getLeadBU() {
		return leadBU;
	}
	public void setLeadBU(String leadBU) {
		this.leadBU = leadBU;
	}
	public String getRtmRoutToMarket() {
		return rtmRoutToMarket;
	}
	public void setRtmRoutToMarket(String rtmRoutToMarket) {
		this.rtmRoutToMarket = rtmRoutToMarket;
	}
	public String getLeadCountry() {
		return leadCountry;
	}
	public void setLeadCountry(String leadCountry) {
		this.leadCountry = leadCountry;
	}
	public String getPriceGEO() {
		return priceGEO;
	}
	public void setPriceGEO(String priceGEO) {
		this.priceGEO = priceGEO;
	}
	public String getPriceListType() {
		return priceListType;
	}
	public void setPriceListType(String priceListType) {
		this.priceListType = priceListType;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getIncoTerms() {
		return incoTerms;
	}
	public void setIncoTerms(String incoTerms) {
		this.incoTerms = incoTerms;
	}
	public String getPriceTermCode() {
		return priceTermCode;
	}
	public void setPriceTermCode(String priceTermCode) {
		this.priceTermCode = priceTermCode;
	}
	public String getGeographicScope() {
		return geographicScope;
	}
	public void setGeographicScope(String geographicScope) {
		this.geographicScope = geographicScope;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getUpfrontRebateMixed() {
		return upfrontRebateMixed;
	}
	public void setUpfrontRebateMixed(String upfrontRebateMixed) {
		this.upfrontRebateMixed = upfrontRebateMixed;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getGlpStatus() {
		return glpStatus;
	}
	public void setGlpStatus(String glpStatus) {
		this.glpStatus = glpStatus;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public long getEclipseDealNumber() {
		return eclipseDealNumber;
	}
	public void setEclipseDealNumber(long eclipseDealNumber) {
		this.eclipseDealNumber = eclipseDealNumber;
	}
	public long getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(long versionNumber) {
		this.versionNumber = versionNumber;
	}
	public Date getVersionDate() {
		return versionDate;
	}
	public void setVersionDate(Date versionDate) {
		this.versionDate = versionDate;
	}
	public Date getVersionTime() {
		return versionTime;
	}
	public void setVersionTime(Date versionTime) {
		this.versionTime = versionTime;
	}
	public String getSourceDeal() {
		return sourceDeal;
	}
	public void setSourceDeal(String sourceDeal) {
		this.sourceDeal = sourceDeal;
	}
	public String getTenantCompany() {
		return tenantCompany;
	}
	public void setTenantCompany(String tenantCompany) {
		this.tenantCompany = tenantCompany;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedByUser() {
		return createdByUser;
	}
	public void setCreatedByUser(String createdByUser) {
		this.createdByUser = createdByUser;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Date getDealValidityFromDate() {
		return dealValidityFromDate;
	}
	public void setDealValidityFromDate(Date dealValidityFromDate) {
		this.dealValidityFromDate = dealValidityFromDate;
	}
	public Date getDealValidityToDate() {
		return dealValidityToDate;
	}
	public void setDealValidityToDate(Date dealValidityToDate) {
		this.dealValidityToDate = dealValidityToDate;
	}
	public String getDealVersionStatus() {
		return dealVersionStatus;
	}
	public void setDealVersionStatus(String dealVersionStatus) {
		this.dealVersionStatus = dealVersionStatus;
	}
	public String getOpportunity() {
		return opportunity;
	}
	public void setOpportunity(String opportunity) {
		this.opportunity = opportunity;
	}
	public String getCustNoPartyId() {
		return custNoPartyId;
	}
	public void setCustNoPartyId(String custNoPartyId) {
		this.custNoPartyId = custNoPartyId;
	}
	public String getCustLatinName() {
		return custLatinName;
	}
	public void setCustLatinName(String custLatinName) {
		this.custLatinName = custLatinName;
	}
	public String getCustNonLatinName() {
		return custNonLatinName;
	}
	public void setCustNonLatinName(String custNonLatinName) {
		this.custNonLatinName = custNonLatinName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPostalZipCode() {
		return postalZipCode;
	}
	public void setPostalZipCode(String postalZipCode) {
		this.postalZipCode = postalZipCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCustSegment() {
		return custSegment;
	}
	public void setCustSegment(String custSegment) {
		this.custSegment = custSegment;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getAdditionalLocations() {
		return additionalLocations;
	}
	public void setAdditionalLocations(String additionalLocations) {
		this.additionalLocations = additionalLocations;
	}
	public String getActiveStatus() {
		return activeStatus;
	}
	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}
	public String getCustLanguage() {
		return custLanguage;
	}
	public void setCustLanguage(String custLanguage) {
		this.custLanguage = custLanguage;
	}
	public String getServiceReqNoReqId() {
		return serviceReqNoReqId;
	}
	public void setServiceReqNoReqId(String serviceReqNoReqId) {
		this.serviceReqNoReqId = serviceReqNoReqId;
	}
	public String getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}
	public String getDealRegId() {
		return dealRegId;
	}
	public void setDealRegId(String dealRegId) {
		this.dealRegId = dealRegId;
	}
	public String getDealStatus() {
		return dealStatus;
	}
	public void setDealStatus(String dealStatus) {
		this.dealStatus = dealStatus;
	}
	public String getMcChangeCode() {
		return mcChangeCode;
	}
	public void setMcChangeCode(String mcChangeCode) {
		this.mcChangeCode = mcChangeCode;
	}
	public String getProtectionCode() {
		return protectionCode;
	}
	public void setProtectionCode(String protectionCode) {
		this.protectionCode = protectionCode;
	}
	public long getProtectionDays() {
		return protectionDays;
	}
	public void setProtectionDays(long protectionDays) {
		this.protectionDays = protectionDays;
	}
	public String getCustmerEngagement() {
		return custmerEngagement;
	}
	public void setCustmerEngagement(String custmerEngagement) {
		this.custmerEngagement = custmerEngagement;
	}
	public double getTotalAdditionalDiscount() {
		return totalAdditionalDiscount;
	}
	public void setTotalAdditionalDiscount(double totalAdditionalDiscount) {
		this.totalAdditionalDiscount = totalAdditionalDiscount;
	}
	public String getAsapIndicatior() {
		return asapIndicatior;
	}
	public void setAsapIndicatior(String asapIndicatior) {
		this.asapIndicatior = asapIndicatior;
	}
	public String getRoutingIndicator() {
		return routingIndicator;
	}
	public void setRoutingIndicator(String routingIndicator) {
		this.routingIndicator = routingIndicator;
	}
	public String getDealSource() {
		return dealSource;
	}
	public void setDealSource(String dealSource) {
		this.dealSource = dealSource;
	}
	public String getDealDescription() {
		return dealDescription;
	}
	public void setDealDescription(String dealDescription) {
		this.dealDescription = dealDescription;
	}
	public String getFreezeDealFlag() {
		return freezeDealFlag;
	}
	public void setFreezeDealFlag(String freezeDealFlag) {
		this.freezeDealFlag = freezeDealFlag;
	}
	public String getComplexDealFlag() {
		return complexDealFlag;
	}
	public void setComplexDealFlag(String complexDealFlag) {
		this.complexDealFlag = complexDealFlag;
	}
	public String getCorporateReseller() {
		return corporateReseller;
	}
	public void setCorporateReseller(String corporateReseller) {
		this.corporateReseller = corporateReseller;
	}
	public String getSupressInAllcomms() {
		return supressInAllcomms;
	}
	public void setSupressInAllcomms(String supressInAllcomms) {
		this.supressInAllcomms = supressInAllcomms;
	}
	public String getHighRiskDeal() {
		return highRiskDeal;
	}
	public void setHighRiskDeal(String highRiskDeal) {
		this.highRiskDeal = highRiskDeal;
	}
	public String getGlpDeal() {
		return glpDeal;
	}
	public void setGlpDeal(String glpDeal) {
		this.glpDeal = glpDeal;
	}
	public String getCatalogDealFlag() {
		return catalogDealFlag;
	}
	public void setCatalogDealFlag(String catalogDealFlag) {
		this.catalogDealFlag = catalogDealFlag;
	}
	public String getPromoExclusion() {
		return promoExclusion;
	}
	public void setPromoExclusion(String promoExclusion) {
		this.promoExclusion = promoExclusion;
	}
	public String getGlobalAccFlag() {
		return globalAccFlag;
	}
	public void setGlobalAccFlag(String globalAccFlag) {
		this.globalAccFlag = globalAccFlag;
	}
	public String getPromotionFlag() {
		return promotionFlag;
	}
	public void setPromotionFlag(String promotionFlag) {
		this.promotionFlag = promotionFlag;
	}
	public String getBundleAccmulationMode() {
		return bundleAccmulationMode;
	}
	public void setBundleAccmulationMode(String bundleAccmulationMode) {
		this.bundleAccmulationMode = bundleAccmulationMode;
	}
	public String getOemFlag() {
		return oemFlag;
	}
	public void setOemFlag(String oemFlag) {
		this.oemFlag = oemFlag;
	}
	public String getFramworkDeal() {
		return framworkDeal;
	}
	public void setFramworkDeal(String framworkDeal) {
		this.framworkDeal = framworkDeal;
	}
	public String getGlobalDealFlag() {
		return globalDealFlag;
	}
	public void setGlobalDealFlag(String globalDealFlag) {
		this.globalDealFlag = globalDealFlag;
	}
	public Date getQoteDistributionDate() {
		return qoteDistributionDate;
	}
	public void setQoteDistributionDate(Date qoteDistributionDate) {
		this.qoteDistributionDate = qoteDistributionDate;
	}
	public String getPrimaryRSLFL() {
		return primaryRSLFL;
	}
	public void setPrimaryRSLFL(String primaryRSLFL) {
		this.primaryRSLFL = primaryRSLFL;
	}
	public long getSrcDealVrsnNo() {
		return srcDealVrsnNo;
	}
	public void setSrcDealVrsnNo(long srcDealVrsnNo) {
		this.srcDealVrsnNo = srcDealVrsnNo;
	}
	public String getSrcDealType() {
		return srcDealType;
	}
	public void setSrcDealType(String srcDealType) {
		this.srcDealType = srcDealType;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getExtDealDurFlg() {
		return extDealDurFlg;
	}
	public void setExtDealDurFlg(String extDealDurFlg) {
		this.extDealDurFlg = extDealDurFlg;
	}
	public long getExtDealDurDays() {
		return extDealDurDays;
	}
	public void setExtDealDurDays(long extDealDurDays) {
		this.extDealDurDays = extDealDurDays;
	}
	public String getDbUltimateId() {
		return dbUltimateId;
	}
	public void setDbUltimateId(String dbUltimateId) {
		this.dbUltimateId = dbUltimateId;
	}

	
	
	
}
