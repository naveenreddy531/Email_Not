package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_DEAL_LINE_DISC_SCALE")
public class DealLineDescScale {

	@Id
	@Column(name="sourceSystemCode")
	private String sourceSystemCode;
	private long dealIdentifier;
	private long dealVersionNumber;
	private long dealLineItemNumber;
	private long scaleIdentifier;
	private Date scaleStartDate;
	private String pricingTypeCode;
	private double listPriceAmount;
	private double requestedAmount;
	private double authorizedAmount;
	private double requestedIncrementalDiscountAmount;
	private double authorizedIncrementalDiscountAmount;
	private double requestedDiscountPercentage;
	private double authorizedDiscountPercentage;
	private double standardDiscountPercentage;
	private double additionalDiscountAmount;
	private double maximumBoundaryAmount;
	private double minimumBoundaryAmount;
	private Date scaleEndDate;
	private String lineItemAuthorizationIndicator;
	private double requestedListPriceDiscountPercentage;
	private Date sourceSystemCreateDate;
	private Date sourceSystemUpdateDate;
	private String authorizedStatusCode;
	private Date componentChangeDate;
	private double productCostAmount;
	private double requestedMarginPercentage;
	private double authorizedMarginPercentage;
	private String costAvailabilityIndicator;
	private String nonDiscountableIndicator;
	private String costStatusCode;
	private double previousAuthorizedQuantity;
	private long lastUpdatedByEmployeeIdentifier;
	private String authorizationStatusDescription;
	private double requestedFixedDiscountAmount;
	private double authorizedFixedDiscountAmount;
	private double targetAdditionalDiscountPercentage;
	private double minimumMarginalDiscountPercentage;
	private double targetMarginalDiscountPercentage;
	private Date guidanceRefreshDate;
	private double guidanceExpertPercentage;
	private double guidanceTypicalPercentage;
	private double guidanceFloorPercentage;
	private double previousGuidanceRequirementPercentage;
	private String guidanceAvailableIndicator;
	private String previousAuthorizationDescription;
	private double previousExternalApprovedProductAmount;
	private String guidanceDetailIdentifier;
	private String miscellaneousChargeIndicator;
	private double requestBackendContraAmount;
	private double authorizedBackendContraAmount;
	private double requestNetRevenueAmount;
	private double authorizedNetRevenueAmount;
	private double requestNetMarginAmount;
	private double authorizedNetMarginAmount;
	private double requestNetMarginPercentage;
	private double authorizedNetMarginPercentage;
	private String instantPriceMethodDescription;
	private double instantPricingAmount;
	private String lineAuthorizationTypeCode;
	private long authorizedByEmployeeNumber;
	private String lineProgressIndicator;
	private double medallionNetAmount;
	private String medallionDiscountLevelDescription;
	private String createdByUserId;
	private String updatedByUserId;
	private Date insertTimestamp;
	private Date updateTimestamp;
	private String logicalDeleteIndicator;

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public long getDealIdentifier() {
		return dealIdentifier;
	}

	public void setDealIdentifier(long dealIdentifier) {
		this.dealIdentifier = dealIdentifier;
	}

	public long getDealVersionNumber() {
		return dealVersionNumber;
	}

	public void setDealVersionNumber(long dealVersionNumber) {
		this.dealVersionNumber = dealVersionNumber;
	}

	public long getDealLineItemNumber() {
		return dealLineItemNumber;
	}

	public void setDealLineItemNumber(long dealLineItemNumber) {
		this.dealLineItemNumber = dealLineItemNumber;
	}

	public long getScaleIdentifier() {
		return scaleIdentifier;
	}

	public void setScaleIdentifier(long scaleIdentifier) {
		this.scaleIdentifier = scaleIdentifier;
	}

	public Date getScaleStartDate() {
		return scaleStartDate;
	}

	public void setScaleStartDate(Date scaleStartDate) {
		this.scaleStartDate = scaleStartDate;
	}

	public String getPricingTypeCode() {
		return pricingTypeCode;
	}

	public void setPricingTypeCode(String pricingTypeCode) {
		this.pricingTypeCode = pricingTypeCode;
	}

	public double getListPriceAmount() {
		return listPriceAmount;
	}

	public void setListPriceAmount(double listPriceAmount) {
		this.listPriceAmount = listPriceAmount;
	}

	public double getRequestedAmount() {
		return requestedAmount;
	}

	public void setRequestedAmount(double requestedAmount) {
		this.requestedAmount = requestedAmount;
	}

	public double getAuthorizedAmount() {
		return authorizedAmount;
	}

	public void setAuthorizedAmount(double authorizedAmount) {
		this.authorizedAmount = authorizedAmount;
	}

	public double getRequestedIncrementalDiscountAmount() {
		return requestedIncrementalDiscountAmount;
	}

	public void setRequestedIncrementalDiscountAmount(double requestedIncrementalDiscountAmount) {
		this.requestedIncrementalDiscountAmount = requestedIncrementalDiscountAmount;
	}

	public double getAuthorizedIncrementalDiscountAmount() {
		return authorizedIncrementalDiscountAmount;
	}

	public void setAuthorizedIncrementalDiscountAmount(double authorizedIncrementalDiscountAmount) {
		this.authorizedIncrementalDiscountAmount = authorizedIncrementalDiscountAmount;
	}

	public double getRequestedDiscountPercentage() {
		return requestedDiscountPercentage;
	}

	public void setRequestedDiscountPercentage(double requestedDiscountPercentage) {
		this.requestedDiscountPercentage = requestedDiscountPercentage;
	}

	public double getAuthorizedDiscountPercentage() {
		return authorizedDiscountPercentage;
	}

	public void setAuthorizedDiscountPercentage(double authorizedDiscountPercentage) {
		this.authorizedDiscountPercentage = authorizedDiscountPercentage;
	}

	public double getStandardDiscountPercentage() {
		return standardDiscountPercentage;
	}

	public void setStandardDiscountPercentage(double standardDiscountPercentage) {
		this.standardDiscountPercentage = standardDiscountPercentage;
	}

	public double getAdditionalDiscountAmount() {
		return additionalDiscountAmount;
	}

	public void setAdditionalDiscountAmount(double additionalDiscountAmount) {
		this.additionalDiscountAmount = additionalDiscountAmount;
	}

	public double getMaximumBoundaryAmount() {
		return maximumBoundaryAmount;
	}

	public void setMaximumBoundaryAmount(double maximumBoundaryAmount) {
		this.maximumBoundaryAmount = maximumBoundaryAmount;
	}

	public double getMinimumBoundaryAmount() {
		return minimumBoundaryAmount;
	}

	public void setMinimumBoundaryAmount(double minimumBoundaryAmount) {
		this.minimumBoundaryAmount = minimumBoundaryAmount;
	}

	public Date getScaleEndDate() {
		return scaleEndDate;
	}

	public void setScaleEndDate(Date scaleEndDate) {
		this.scaleEndDate = scaleEndDate;
	}

	public String getLineItemAuthorizationIndicator() {
		return lineItemAuthorizationIndicator;
	}

	public void setLineItemAuthorizationIndicator(String lineItemAuthorizationIndicator) {
		this.lineItemAuthorizationIndicator = lineItemAuthorizationIndicator;
	}

	public double getRequestedListPriceDiscountPercentage() {
		return requestedListPriceDiscountPercentage;
	}

	public void setRequestedListPriceDiscountPercentage(double requestedListPriceDiscountPercentage) {
		this.requestedListPriceDiscountPercentage = requestedListPriceDiscountPercentage;
	}

	public Date getSourceSystemCreateDate() {
		return sourceSystemCreateDate;
	}

	public void setSourceSystemCreateDate(Date sourceSystemCreateDate) {
		this.sourceSystemCreateDate = sourceSystemCreateDate;
	}

	public Date getSourceSystemUpdateDate() {
		return sourceSystemUpdateDate;
	}

	public void setSourceSystemUpdateDate(Date sourceSystemUpdateDate) {
		this.sourceSystemUpdateDate = sourceSystemUpdateDate;
	}

	public String getAuthorizedStatusCode() {
		return authorizedStatusCode;
	}

	public void setAuthorizedStatusCode(String authorizedStatusCode) {
		this.authorizedStatusCode = authorizedStatusCode;
	}

	public Date getComponentChangeDate() {
		return componentChangeDate;
	}

	public void setComponentChangeDate(Date componentChangeDate) {
		this.componentChangeDate = componentChangeDate;
	}

	public double getProductCostAmount() {
		return productCostAmount;
	}

	public void setProductCostAmount(double productCostAmount) {
		this.productCostAmount = productCostAmount;
	}

	public double getRequestedMarginPercentage() {
		return requestedMarginPercentage;
	}

	public void setRequestedMarginPercentage(double requestedMarginPercentage) {
		this.requestedMarginPercentage = requestedMarginPercentage;
	}

	public double getAuthorizedMarginPercentage() {
		return authorizedMarginPercentage;
	}

	public void setAuthorizedMarginPercentage(double authorizedMarginPercentage) {
		this.authorizedMarginPercentage = authorizedMarginPercentage;
	}

	public String getCostAvailabilityIndicator() {
		return costAvailabilityIndicator;
	}

	public void setCostAvailabilityIndicator(String costAvailabilityIndicator) {
		this.costAvailabilityIndicator = costAvailabilityIndicator;
	}

	public String getNonDiscountableIndicator() {
		return nonDiscountableIndicator;
	}

	public void setNonDiscountableIndicator(String nonDiscountableIndicator) {
		this.nonDiscountableIndicator = nonDiscountableIndicator;
	}

	public String getCostStatusCode() {
		return costStatusCode;
	}

	public void setCostStatusCode(String costStatusCode) {
		this.costStatusCode = costStatusCode;
	}

	public double getPreviousAuthorizedQuantity() {
		return previousAuthorizedQuantity;
	}

	public void setPreviousAuthorizedQuantity(double previousAuthorizedQuantity) {
		this.previousAuthorizedQuantity = previousAuthorizedQuantity;
	}

	public long getLastUpdatedByEmployeeIdentifier() {
		return lastUpdatedByEmployeeIdentifier;
	}

	public void setLastUpdatedByEmployeeIdentifier(long lastUpdatedByEmployeeIdentifier) {
		this.lastUpdatedByEmployeeIdentifier = lastUpdatedByEmployeeIdentifier;
	}

	public String getAuthorizationStatusDescription() {
		return authorizationStatusDescription;
	}

	public void setAuthorizationStatusDescription(String authorizationStatusDescription) {
		this.authorizationStatusDescription = authorizationStatusDescription;
	}

	public double getRequestedFixedDiscountAmount() {
		return requestedFixedDiscountAmount;
	}

	public void setRequestedFixedDiscountAmount(double requestedFixedDiscountAmount) {
		this.requestedFixedDiscountAmount = requestedFixedDiscountAmount;
	}

	public double getAuthorizedFixedDiscountAmount() {
		return authorizedFixedDiscountAmount;
	}

	public void setAuthorizedFixedDiscountAmount(double authorizedFixedDiscountAmount) {
		this.authorizedFixedDiscountAmount = authorizedFixedDiscountAmount;
	}

	public double getTargetAdditionalDiscountPercentage() {
		return targetAdditionalDiscountPercentage;
	}

	public void setTargetAdditionalDiscountPercentage(double targetAdditionalDiscountPercentage) {
		this.targetAdditionalDiscountPercentage = targetAdditionalDiscountPercentage;
	}

	public double getMinimumMarginalDiscountPercentage() {
		return minimumMarginalDiscountPercentage;
	}

	public void setMinimumMarginalDiscountPercentage(double minimumMarginalDiscountPercentage) {
		this.minimumMarginalDiscountPercentage = minimumMarginalDiscountPercentage;
	}

	public double getTargetMarginalDiscountPercentage() {
		return targetMarginalDiscountPercentage;
	}

	public void setTargetMarginalDiscountPercentage(double targetMarginalDiscountPercentage) {
		this.targetMarginalDiscountPercentage = targetMarginalDiscountPercentage;
	}

	public Date getGuidanceRefreshDate() {
		return guidanceRefreshDate;
	}

	public void setGuidanceRefreshDate(Date guidanceRefreshDate) {
		this.guidanceRefreshDate = guidanceRefreshDate;
	}

	public double getGuidanceExpertPercentage() {
		return guidanceExpertPercentage;
	}

	public void setGuidanceExpertPercentage(double guidanceExpertPercentage) {
		this.guidanceExpertPercentage = guidanceExpertPercentage;
	}

	public double getGuidanceTypicalPercentage() {
		return guidanceTypicalPercentage;
	}

	public void setGuidanceTypicalPercentage(double guidanceTypicalPercentage) {
		this.guidanceTypicalPercentage = guidanceTypicalPercentage;
	}

	public double getGuidanceFloorPercentage() {
		return guidanceFloorPercentage;
	}

	public void setGuidanceFloorPercentage(double guidanceFloorPercentage) {
		this.guidanceFloorPercentage = guidanceFloorPercentage;
	}

	public double getPreviousGuidanceRequirementPercentage() {
		return previousGuidanceRequirementPercentage;
	}

	public void setPreviousGuidanceRequirementPercentage(double previousGuidanceRequirementPercentage) {
		this.previousGuidanceRequirementPercentage = previousGuidanceRequirementPercentage;
	}

	public String getGuidanceAvailableIndicator() {
		return guidanceAvailableIndicator;
	}

	public void setGuidanceAvailableIndicator(String guidanceAvailableIndicator) {
		this.guidanceAvailableIndicator = guidanceAvailableIndicator;
	}

	public String getPreviousAuthorizationDescription() {
		return previousAuthorizationDescription;
	}

	public void setPreviousAuthorizationDescription(String previousAuthorizationDescription) {
		this.previousAuthorizationDescription = previousAuthorizationDescription;
	}

	public double getPreviousExternalApprovedProductAmount() {
		return previousExternalApprovedProductAmount;
	}

	public void setPreviousExternalApprovedProductAmount(double previousExternalApprovedProductAmount) {
		this.previousExternalApprovedProductAmount = previousExternalApprovedProductAmount;
	}

	public String getGuidanceDetailIdentifier() {
		return guidanceDetailIdentifier;
	}

	public void setGuidanceDetailIdentifier(String guidanceDetailIdentifier) {
		this.guidanceDetailIdentifier = guidanceDetailIdentifier;
	}

	public String getMiscellaneousChargeIndicator() {
		return miscellaneousChargeIndicator;
	}

	public void setMiscellaneousChargeIndicator(String miscellaneousChargeIndicator) {
		this.miscellaneousChargeIndicator = miscellaneousChargeIndicator;
	}

	public double getRequestBackendContraAmount() {
		return requestBackendContraAmount;
	}

	public void setRequestBackendContraAmount(double requestBackendContraAmount) {
		this.requestBackendContraAmount = requestBackendContraAmount;
	}

	public double getAuthorizedBackendContraAmount() {
		return authorizedBackendContraAmount;
	}

	public void setAuthorizedBackendContraAmount(double authorizedBackendContraAmount) {
		this.authorizedBackendContraAmount = authorizedBackendContraAmount;
	}

	public double getRequestNetRevenueAmount() {
		return requestNetRevenueAmount;
	}

	public void setRequestNetRevenueAmount(double requestNetRevenueAmount) {
		this.requestNetRevenueAmount = requestNetRevenueAmount;
	}

	public double getAuthorizedNetRevenueAmount() {
		return authorizedNetRevenueAmount;
	}

	public void setAuthorizedNetRevenueAmount(double authorizedNetRevenueAmount) {
		this.authorizedNetRevenueAmount = authorizedNetRevenueAmount;
	}

	public double getRequestNetMarginAmount() {
		return requestNetMarginAmount;
	}

	public void setRequestNetMarginAmount(double requestNetMarginAmount) {
		this.requestNetMarginAmount = requestNetMarginAmount;
	}

	public double getAuthorizedNetMarginAmount() {
		return authorizedNetMarginAmount;
	}

	public void setAuthorizedNetMarginAmount(double authorizedNetMarginAmount) {
		this.authorizedNetMarginAmount = authorizedNetMarginAmount;
	}

	public double getRequestNetMarginPercentage() {
		return requestNetMarginPercentage;
	}

	public void setRequestNetMarginPercentage(double requestNetMarginPercentage) {
		this.requestNetMarginPercentage = requestNetMarginPercentage;
	}

	public double getAuthorizedNetMarginPercentage() {
		return authorizedNetMarginPercentage;
	}

	public void setAuthorizedNetMarginPercentage(double authorizedNetMarginPercentage) {
		this.authorizedNetMarginPercentage = authorizedNetMarginPercentage;
	}

	public String getInstantPriceMethodDescription() {
		return instantPriceMethodDescription;
	}

	public void setInstantPriceMethodDescription(String instantPriceMethodDescription) {
		this.instantPriceMethodDescription = instantPriceMethodDescription;
	}

	public double getInstantPricingAmount() {
		return instantPricingAmount;
	}

	public void setInstantPricingAmount(double instantPricingAmount) {
		this.instantPricingAmount = instantPricingAmount;
	}

	public String getLineAuthorizationTypeCode() {
		return lineAuthorizationTypeCode;
	}

	public void setLineAuthorizationTypeCode(String lineAuthorizationTypeCode) {
		this.lineAuthorizationTypeCode = lineAuthorizationTypeCode;
	}

	public long getAuthorizedByEmployeeNumber() {
		return authorizedByEmployeeNumber;
	}

	public void setAuthorizedByEmployeeNumber(long authorizedByEmployeeNumber) {
		this.authorizedByEmployeeNumber = authorizedByEmployeeNumber;
	}

	public String getLineProgressIndicator() {
		return lineProgressIndicator;
	}

	public void setLineProgressIndicator(String lineProgressIndicator) {
		this.lineProgressIndicator = lineProgressIndicator;
	}

	public double getMedallionNetAmount() {
		return medallionNetAmount;
	}

	public void setMedallionNetAmount(double medallionNetAmount) {
		this.medallionNetAmount = medallionNetAmount;
	}

	public String getMedallionDiscountLevelDescription() {
		return medallionDiscountLevelDescription;
	}

	public void setMedallionDiscountLevelDescription(String medallionDiscountLevelDescription) {
		this.medallionDiscountLevelDescription = medallionDiscountLevelDescription;
	}

	public String getCreatedByUserId() {
		return createdByUserId;
	}

	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
	}

	public String getUpdatedByUserId() {
		return updatedByUserId;
	}

	public void setUpdatedByUserId(String updatedByUserId) {
		this.updatedByUserId = updatedByUserId;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}