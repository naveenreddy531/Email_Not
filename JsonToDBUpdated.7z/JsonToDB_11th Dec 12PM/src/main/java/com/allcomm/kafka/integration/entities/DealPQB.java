package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_DEAL_PQB")
public class DealPQB {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PQB_ID")
	private long pQBIdentifier;
	@Column(name = "DEAL_VERSION_NUMBER")
	private long dealVersionNumber;
	@Column(name = "DEAL_ID")
	private long dealIdentifier;
	@Column(name = "SOURCE_SYSTEM_CODE")
	private String sourceSystemCode;
	@Column(name = "CONSOLIDATED_NET_PRICE_AMOUNT")
	private double consolidatedNetPriceAmount;
	@Column(name = "CONSOLIDATE_DISCOUNT_PERCENTAGE")
	private double consolidateDiscountPercentage;
	@Column(name = "CONSOLIDATED_LIST_PRICE_AMOUNT")
	private double consolidatedListPriceAmount;
	@Column(name = "CURRENT_VERSION_CODE")
	private int currentVersionCode;
	@Column(name = "CURRENT_VERSION_STATUS_CODE")
	private String currentVersionStatusCode;
	@Column(name = "PREVIOUS_VERSION_CODE")
	private String previousVersionCode;
	@Column(name = "PREVIOUS_VERSION_STATUS_CODE")
	private String previousVersionStatusCode;
	@Column(name = "STRATEGIC_PQB_CODE")
	private String strategicPQBCode;
	@Column(name = "STRATEGIC_SEQUENCE_IDENTIFIER")
	private long strategicSequenceIdentifier;
	@Column(name = "STRATEGIC_PQB_MINIMUM_NUMBER")
	private double strategicPQBMinimumNumber;
	@Column(name = "STRATEGIC_PQB_MAXIMUM_NUMBER")
	private double strategicPQBMaximumNumber;
	@Column(name = "RAW_PQB_CODE")
	private String rawPQBCode;
	@Column(name = "RAW_PRICE_SEQUENCE_IDENTIFIER")
	private long rawPriceSequenceIdentifier;
	@Column(name = "RAW_PQB_MINIMUM_NUMBER")
	private double rawPQBMinimumNumber;
	@Column(name = "RAW_PQB_MAXIMUM_NUMBER")
	private double rawPQBMaximumNumber;
	@Column(name = "OPEN_LINE_PQB_CODE")
	private String openLinePQBCode;
	@Column(name = "OPEN_LINE_SEQUENCE_IDENTIFIER")
	private long openLineSequenceIdentifier;
	@Column(name = "OPEN_LINE_PQB_MINIMUM_NUMBER")
	private double openLinePQBMinimumNumber;
	@Column(name = "OPEN_LINEPQB_MAXIMUM_NUMBER")
	private double openLinePQBMaximumNumber;
	@Column(name = "STRATEGIC_COLOR_CODE")
	private String strategicColorCode;
	@Column(name = "RAW_COLOR_CODE")
	private String rawColorCode;
	@Column(name = "OPEN_LINE_COLOR_CODE")
	private String openLineColorCode;
	@Column(name = "INSERT_TIMESTAMP")
	private Date insertTimestamp;
	@Column(name = "UPDATE_TIMESTAMP")
	private Date updateTimestamp;
	@Column(name = "LOGICAL_DELETE_INDICATOR")
	private String logicalDeleteIndicator;

	public long getpQBIdentifier() {
		return pQBIdentifier;
	}

	public void setpQBIdentifier(long pQBIdentifier) {
		this.pQBIdentifier = pQBIdentifier;
	}

	public long getDealVersionNumber() {
		return dealVersionNumber;
	}

	public void setDealVersionNumber(long dealVersionNumber) {
		this.dealVersionNumber = dealVersionNumber;
	}

	public long getDealIdentifier() {
		return dealIdentifier;
	}

	public void setDealIdentifier(long dealIdentifier) {
		this.dealIdentifier = dealIdentifier;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public double getConsolidatedNetPriceAmount() {
		return consolidatedNetPriceAmount;
	}

	public void setConsolidatedNetPriceAmount(double consolidatedNetPriceAmount) {
		this.consolidatedNetPriceAmount = consolidatedNetPriceAmount;
	}

	public double getConsolidateDiscountPercentage() {
		return consolidateDiscountPercentage;
	}

	public void setConsolidateDiscountPercentage(double consolidateDiscountPercentage) {
		this.consolidateDiscountPercentage = consolidateDiscountPercentage;
	}

	public double getConsolidatedListPriceAmount() {
		return consolidatedListPriceAmount;
	}

	public void setConsolidatedListPriceAmount(double consolidatedListPriceAmount) {
		this.consolidatedListPriceAmount = consolidatedListPriceAmount;
	}

	public int getCurrentVersionCode() {
		return currentVersionCode;
	}

	public void setCurrentVersionCode(int currentVersionCode) {
		this.currentVersionCode = currentVersionCode;
	}

	public String getCurrentVersionStatusCode() {
		return currentVersionStatusCode;
	}

	public void setCurrentVersionStatusCode(String currentVersionStatusCode) {
		this.currentVersionStatusCode = currentVersionStatusCode;
	}

	public String getPreviousVersionCode() {
		return previousVersionCode;
	}

	public void setPreviousVersionCode(String previousVersionCode) {
		this.previousVersionCode = previousVersionCode;
	}

	public String getPreviousVersionStatusCode() {
		return previousVersionStatusCode;
	}

	public void setPreviousVersionStatusCode(String previousVersionStatusCode) {
		this.previousVersionStatusCode = previousVersionStatusCode;
	}

	public String getStrategicPQBCode() {
		return strategicPQBCode;
	}

	public void setStrategicPQBCode(String strategicPQBCode) {
		this.strategicPQBCode = strategicPQBCode;
	}

	public long getStrategicSequenceIdentifier() {
		return strategicSequenceIdentifier;
	}

	public void setStrategicSequenceIdentifier(long strategicSequenceIdentifier) {
		this.strategicSequenceIdentifier = strategicSequenceIdentifier;
	}

	public double getStrategicPQBMinimumNumber() {
		return strategicPQBMinimumNumber;
	}

	public void setStrategicPQBMinimumNumber(double strategicPQBMinimumNumber) {
		this.strategicPQBMinimumNumber = strategicPQBMinimumNumber;
	}

	public double getStrategicPQBMaximumNumber() {
		return strategicPQBMaximumNumber;
	}

	public void setStrategicPQBMaximumNumber(double strategicPQBMaximumNumber) {
		this.strategicPQBMaximumNumber = strategicPQBMaximumNumber;
	}

	public String getRawPQBCode() {
		return rawPQBCode;
	}

	public void setRawPQBCode(String rawPQBCode) {
		this.rawPQBCode = rawPQBCode;
	}

	public long getRawPriceSequenceIdentifier() {
		return rawPriceSequenceIdentifier;
	}

	public void setRawPriceSequenceIdentifier(long rawPriceSequenceIdentifier) {
		this.rawPriceSequenceIdentifier = rawPriceSequenceIdentifier;
	}

	public double getRawPQBMinimumNumber() {
		return rawPQBMinimumNumber;
	}

	public void setRawPQBMinimumNumber(double rawPQBMinimumNumber) {
		this.rawPQBMinimumNumber = rawPQBMinimumNumber;
	}

	public double getRawPQBMaximumNumber() {
		return rawPQBMaximumNumber;
	}

	public void setRawPQBMaximumNumber(double rawPQBMaximumNumber) {
		this.rawPQBMaximumNumber = rawPQBMaximumNumber;
	}

	public String getOpenLinePQBCode() {
		return openLinePQBCode;
	}

	public void setOpenLinePQBCode(String openLinePQBCode) {
		this.openLinePQBCode = openLinePQBCode;
	}

	public long getOpenLineSequenceIdentifier() {
		return openLineSequenceIdentifier;
	}

	public void setOpenLineSequenceIdentifier(long openLineSequenceIdentifier) {
		this.openLineSequenceIdentifier = openLineSequenceIdentifier;
	}

	public double getOpenLinePQBMinimumNumber() {
		return openLinePQBMinimumNumber;
	}

	public void setOpenLinePQBMinimumNumber(double openLinePQBMinimumNumber) {
		this.openLinePQBMinimumNumber = openLinePQBMinimumNumber;
	}

	public double getOpenLinePQBMaximumNumber() {
		return openLinePQBMaximumNumber;
	}

	public void setOpenLinePQBMaximumNumber(double openLinePQBMaximumNumber) {
		this.openLinePQBMaximumNumber = openLinePQBMaximumNumber;
	}

	public String getStrategicColorCode() {
		return strategicColorCode;
	}

	public void setStrategicColorCode(String strategicColorCode) {
		this.strategicColorCode = strategicColorCode;
	}

	public String getRawColorCode() {
		return rawColorCode;
	}

	public void setRawColorCode(String rawColorCode) {
		this.rawColorCode = rawColorCode;
	}

	public String getOpenLineColorCode() {
		return openLineColorCode;
	}

	public void setOpenLineColorCode(String openLineColorCode) {
		this.openLineColorCode = openLineColorCode;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}
