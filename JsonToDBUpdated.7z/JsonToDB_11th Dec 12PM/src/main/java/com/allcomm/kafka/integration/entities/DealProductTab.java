package com.allcomm.kafka.integration.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "PRICING_SPL_DEAL_PRODUCT_TAB")
public class DealProductTab implements Serializable {
	private static long serialVersionUID = -2653658680387086798L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "LINE_ITEM_NO")
	private Long lineItemNo;

	@Column(name = "INFO")
	private String info;

	@Column(name = "PRODUCT_NUMBER")
	private String prodNo;

	@Column(name = "OPT_CODE")
	private String optCode;

	@Column(name = "DESCRIPTION")
	private String desc;

	@Column(name = "PL")
	private String pL;

	@Column(name = "CLASSCODE")
	private String clsCode;

	@Column(name = "PRODUCT_CATEGORY")
	private String prodCat;

	@Column(name = "BUSINESS_GROUP")
	private String busGroup;

	@Column(name = "BUSINESS_UNIT")
	private String busUnit;

	@Column(name = "BUSINESS_UNIT_DESCRIPTION")
	private String busUnitDesc;

	@Column(name = "LIST_PRICE")
	private double listPrice;

	@Column(name = "STD_DISC")
	private double stdDisc;

	@Column(name = "PRC_TYPE")
	private String prcType;

	@Column(name = "REQUESTED_BDNET")
	private double requestedBDNet;

	@Column(name = "REQUESTED_ADD")
	private double reqestedAdd;

	@Column(name = "REQUESTED_TOTAL")
	private double requestedTotal;

	@Column(name = "PREV_REQUESTED_ADD")
	private String prevRequestedAdd;

	@Column(name = "AUTH_BDNET")
	private double authBDNet;

	@Column(name = "AUTH_ADDL")
	private double authAddl;

	@Column(name = "AUTH_TOTAL")
	private double authTotal;

	@Column(name = "REQUESTED_GM_AMT")
	private double requestedGMAMT;

	@Column(name = "REQUESTED_GM")
	private double requestedGM;

	@Column(name = "AUTHORIZED_GM_AMT")
	private double authorizedGMAMT;

	@Column(name = "AUTHORIZED_GM")
	private double AuthorizedGM;

	@Column(name = "EXTENDED_RQST_BDNET")
	private double extendedRqstDBNet;

	@Column(name = "EXTENDED_AUTH_BDNET")
	private double extendedAuthBDNet;

	@Column(name = "EST_K_AMOUNT")
	private double estKAmnt;

	@Column(name = "EXTENDED_EST_K_AMT")
	private double extendedESTKAmt;

	@Column(name = "CONSUMED_AMOUNT")
	private double consumedAmnt;

	@Column(name = "CONSUMED_QTY")
	private double consumedQty;

	@Column(name = "LINE_ITEM_CONSUMED")
	private String lineItemConsumed;

	@Column(name = "REMAINING_AMOUNT")
	private double remAmnt;

	@Column(name = "R_THRESHOLD_QTY")
	private double rThresholdQty;

	@Column(name = "DEAL_VALUE_DISCOUNT")
	private double dealValueDiscount;

	@Column(name = "HAS_MCC")
	private String hasMcc;

	@Column(name = "REMAINING_QUANTITY")
	private double remQty;

	@Column(name = "AUTHORIZED_STATUS")
	private String authrizedStatus;

	@Column(name = "PRODUCT_LINE")
	private String prodLine;

	@Column(name = "QUANTITY")
	private double qty;

	@Column(name = "PRODUCT_FAMILY")
	private String prodFamily;

	@Column(name = "LONG_DESCRIPTION__FLAG")
	private String longDescFlg;

	@Column(name = "NON_DISCOUNTABLE_FLAG")
	private String nonDiscountableFlg;

	@Column(name = "BEGIN_DATE")
	private Date beginDate;

	@Column(name = "END_DATE")
	private Date endDate;

	@Column(name = "AUTH_DATE")
	private Date authDate;

	@Column(name = "AUTHORIZER")
	private Long authorizer;

	@Column(name = "LINE_AUTH_TYPE")
	private String lineAuthType;

	@Column(name = "CONFIG_ID")
	private String congigID;

	@Column(name = "SOURCE_CONFIG_ID")
	private String srcConfiID;

	@Column(name = "ORD_MIN_QUANTITY")
	private double ordMinQty;

	@Column(name = "LN_MAX_QTY")
	private double lnMaxQty;

	@Column(name = "LINE_TYPE")
	private String lineType;

	@Column(name = "DEAL_ID")
	private Long dealId;

	@Column(name = "SAP_DOCUMENT_NO")
	private Long sapDocNo;

	@Column(name = "DEAL_VERSION")
	private Long dealVersion;

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public static void setSerialVersionUID(long serialVersionUID) {
		DealProductTab.serialVersionUID = serialVersionUID;
	}

	public Long getLineItemNo() {
		return lineItemNo;
	}

	public void setLineItemNo(Long lineItemNo) {
		this.lineItemNo = lineItemNo;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getProdNo() {
		return prodNo;
	}

	public void setProdNo(String prodNo) {
		this.prodNo = prodNo;
	}

	public String getOptCode() {
		return optCode;
	}

	public void setOptCode(String optCode) {
		this.optCode = optCode;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getpL() {
		return pL;
	}

	public void setpL(String pL) {
		this.pL = pL;
	}

	public String getClsCode() {
		return clsCode;
	}

	public void setClsCode(String clsCode) {
		this.clsCode = clsCode;
	}

	public String getProdCat() {
		return prodCat;
	}

	public void setProdCat(String prodCat) {
		this.prodCat = prodCat;
	}

	public String getBusGroup() {
		return busGroup;
	}

	public void setBusGroup(String busGroup) {
		this.busGroup = busGroup;
	}

	public String getBusUnit() {
		return busUnit;
	}

	public void setBusUnit(String busUnit) {
		this.busUnit = busUnit;
	}

	public String getBusUnitDesc() {
		return busUnitDesc;
	}

	public void setBusUnitDesc(String busUnitDesc) {
		this.busUnitDesc = busUnitDesc;
	}

	public double getListPrice() {
		return listPrice;
	}

	public void setListPrice(double listPrice) {
		this.listPrice = listPrice;
	}

	public double getStdDisc() {
		return stdDisc;
	}

	public void setStdDisc(double stdDisc) {
		this.stdDisc = stdDisc;
	}

	public String getPrcType() {
		return prcType;
	}

	public void setPrcType(String prcType) {
		this.prcType = prcType;
	}

	public double getRequestedBDNet() {
		return requestedBDNet;
	}

	public void setRequestedBDNet(double requestedBDNet) {
		this.requestedBDNet = requestedBDNet;
	}

	public double getReqestedAdd() {
		return reqestedAdd;
	}

	public void setReqestedAdd(double reqestedAdd) {
		this.reqestedAdd = reqestedAdd;
	}

	public double getRequestedTotal() {
		return requestedTotal;
	}

	public void setRequestedTotal(double requestedTotal) {
		this.requestedTotal = requestedTotal;
	}

	public String getPrevRequestedAdd() {
		return prevRequestedAdd;
	}

	public void setPrevRequestedAdd(String prevRequestedAdd) {
		this.prevRequestedAdd = prevRequestedAdd;
	}

	public double getAuthBDNet() {
		return authBDNet;
	}

	public void setAuthBDNet(double authBDNet) {
		this.authBDNet = authBDNet;
	}

	public double getAuthAddl() {
		return authAddl;
	}

	public void setAuthAddl(double authAddl) {
		this.authAddl = authAddl;
	}

	public double getAuthTotal() {
		return authTotal;
	}

	public void setAuthTotal(double authTotal) {
		this.authTotal = authTotal;
	}

	public double getRequestedGMAMT() {
		return requestedGMAMT;
	}

	public void setRequestedGMAMT(double requestedGMAMT) {
		this.requestedGMAMT = requestedGMAMT;
	}

	public double getRequestedGM() {
		return requestedGM;
	}

	public void setRequestedGM(double requestedGM) {
		this.requestedGM = requestedGM;
	}

	public double getAuthorizedGMAMT() {
		return authorizedGMAMT;
	}

	public void setAuthorizedGMAMT(double authorizedGMAMT) {
		this.authorizedGMAMT = authorizedGMAMT;
	}

	public double getAuthorizedGM() {
		return AuthorizedGM;
	}

	public void setAuthorizedGM(double authorizedGM) {
		AuthorizedGM = authorizedGM;
	}

	public double getExtendedRqstDBNet() {
		return extendedRqstDBNet;
	}

	public void setExtendedRqstDBNet(double extendedRqstDBNet) {
		this.extendedRqstDBNet = extendedRqstDBNet;
	}

	public double getExtendedAuthBDNet() {
		return extendedAuthBDNet;
	}

	public void setExtendedAuthBDNet(double extendedAuthBDNet) {
		this.extendedAuthBDNet = extendedAuthBDNet;
	}

	public double getEstKAmnt() {
		return estKAmnt;
	}

	public void setEstKAmnt(double estKAmnt) {
		this.estKAmnt = estKAmnt;
	}

	public double getExtendedESTKAmt() {
		return extendedESTKAmt;
	}

	public void setExtendedESTKAmt(double extendedESTKAmt) {
		this.extendedESTKAmt = extendedESTKAmt;
	}

	public double getConsumedAmnt() {
		return consumedAmnt;
	}

	public void setConsumedAmnt(double consumedAmnt) {
		this.consumedAmnt = consumedAmnt;
	}

	public double getConsumedQty() {
		return consumedQty;
	}

	public void setConsumedQty(double consumedQty) {
		this.consumedQty = consumedQty;
	}

	public String getLineItemConsumed() {
		return lineItemConsumed;
	}

	public void setLineItemConsumed(String lineItemConsumed) {
		this.lineItemConsumed = lineItemConsumed;
	}

	public double getRemAmnt() {
		return remAmnt;
	}

	public void setRemAmnt(double remAmnt) {
		this.remAmnt = remAmnt;
	}

	public double getrThresholdQty() {
		return rThresholdQty;
	}

	public void setrThresholdQty(double rThresholdQty) {
		this.rThresholdQty = rThresholdQty;
	}

	public double getDealValueDiscount() {
		return dealValueDiscount;
	}

	public void setDealValueDiscount(double dealValueDiscount) {
		this.dealValueDiscount = dealValueDiscount;
	}

	public String getHasMcc() {
		return hasMcc;
	}

	public void setHasMcc(String hasMcc) {
		this.hasMcc = hasMcc;
	}

	public double getRemQty() {
		return remQty;
	}

	public void setRemQty(double remQty) {
		this.remQty = remQty;
	}

	public String getAuthrizedStatus() {
		return authrizedStatus;
	}

	public void setAuthrizedStatus(String authrizedStatus) {
		this.authrizedStatus = authrizedStatus;
	}

	public String getProdLine() {
		return prodLine;
	}

	public void setProdLine(String prodLine) {
		this.prodLine = prodLine;
	}

	public double getQty() {
		return qty;
	}

	public void setQty(double qty) {
		this.qty = qty;
	}

	public String getProdFamily() {
		return prodFamily;
	}

	public void setProdFamily(String prodFamily) {
		this.prodFamily = prodFamily;
	}

	public String getLongDescFlg() {
		return longDescFlg;
	}

	public void setLongDescFlg(String longDescFlg) {
		this.longDescFlg = longDescFlg;
	}

	public String getNonDiscountableFlg() {
		return nonDiscountableFlg;
	}

	public void setNonDiscountableFlg(String nonDiscountableFlg) {
		this.nonDiscountableFlg = nonDiscountableFlg;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getAuthDate() {
		return authDate;
	}

	public void setAuthDate(Date authDate) {
		this.authDate = authDate;
	}

	public Long getAuthorizer() {
		return authorizer;
	}

	public void setAuthorizer(Long authorizer) {
		this.authorizer = authorizer;
	}

	public String getLineAuthType() {
		return lineAuthType;
	}

	public void setLineAuthType(String lineAuthType) {
		this.lineAuthType = lineAuthType;
	}

	public String getCongigID() {
		return congigID;
	}

	public void setCongigID(String congigID) {
		this.congigID = congigID;
	}

	public String getSrcConfiID() {
		return srcConfiID;
	}

	public void setSrcConfiID(String srcConfiID) {
		this.srcConfiID = srcConfiID;
	}

	public double getOrdMinQty() {
		return ordMinQty;
	}

	public void setOrdMinQty(double ordMinQty) {
		this.ordMinQty = ordMinQty;
	}

	public double getLnMaxQty() {
		return lnMaxQty;
	}

	public void setLnMaxQty(double lnMaxQty) {
		this.lnMaxQty = lnMaxQty;
	}

	public String getLineType() {
		return lineType;
	}

	public void setLineType(String lineType) {
		this.lineType = lineType;
	}

	public Long getDealId() {
		return dealId;
	}

	public void setDealId(Long dealId) {
		this.dealId = dealId;
	}

	public Long getSapDocNo() {
		return sapDocNo;
	}

	public void setSapDocNo(Long sapDocNo) {
		this.sapDocNo = sapDocNo;
	}

	public Long getDealVersion() {
		return dealVersion;
	}

	public void setDealVersion(Long dealVersion) {
		this.dealVersion = dealVersion;
	}

}
