package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_DEAL_RESELLER_A")
public class DealResellerA {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RESELLER_A_ID")
	private long resellerAId;
	@Column(name = "DEAL_ID")
	private long dealId;
	@Column(name = "RESELLER_A_SOLD_TO")
	private String resellerASoldTo;
	@Column(name = "RESELLER_A_NAME")
	private String resellerAName;
	@Column(name = "CONTRACT_NO")
	private String contractNo;
	@Column(name = "CITY")
	private String city;
	@Column(name = "ADDRESS")
	private String address;
	@Column(name = "STATE_PROVINCE")
	private String stateProvince;
	@Column(name = "COUNTRY")
	private String country;
	@Column(name = "ZIP")
	private long zip;
	@Column(name = "SPECIAL_ELIGIBILITY_FLAG")
	private String splEligibilityFlg;
	@Column(name = "PRM_LOCATION_ID")
	private String prmLocationID;
	@Column(name = "PPRO_ID")
	private String pproId;
	@Column(name = "SAP_DOCUMENT_NO")
	private long sapDocNo;
	@Column(name = "DEAL_VERSION")
	private long dealVersion;
	@Column(name = "CONTACT_FIRST_NAME")
	private String contactFirstName;
	@Column(name = "CONTACT_LAST_NAME")
	private String contactLastName;
	@Column(name = "CONTACT_NUMBER")
	private String contactNumber;
	@Column(name = "CONTACT_EMAIL_ADDRESS")
	private String contactEmailAddress;
	@Column(name = "RESELLER_TYPE_CODE")
	private String resellerTypeCode;
	@Column(name = "RESELLER_TYPE_DESCRIPTION")
	private String resellerTypeDescription;
	@Column(name = "CREATED_BY_EMPLOYEE_NUMBER")
	private long createdByEmployeeNumber;
	@Column(name = "CONTRACT_END_DATE")
	private Date contractEndDate;
	@Column(name = "DUNS_IDENTIFIER")
	private String dUNSIdentifier;
	@Column(name = "VALUE_ADDED_TAX_NUMBER")
	private String valueAddedTaxNumber;
	@Column(name = "CONTRACT_COUNTRY_CODE")
	private String contractCountryCode;
	@Column(name = "PURCHASE_AGREEMENT_TYPE_CODE")
	private String purchaseAgreementTypeCode;
	@Column(name = "BUYER_TYPE_CODE")
	private String buyerTypeCode;
	@Column(name = "PARTNER_STATUS_INDICATOR")
	private String partnerStatusIndicator;
	@Column(name = "ISO_COUNTRY_CODE")
	private String iSOCountryCode;
	@Column(name = "HIGH_RISK_INDICATOR")
	private String highRiskIndicator;
	@Column(name = "ADDED_BY_EMPLOYEE_NUMBER")
	private long addedByEmployeeNumber;
	@Column(name = "CONTRACT_GLOBAL_LIST_PRICE_INDICATOR")
	private String contractGlobalListPriceIndicator;
	@Column(name = "PRIMARY_RELEASE_INDICATOR")
	private String primaryReleaseIndicator;
	@Column(name = "RECEIVE_INDICATOR")
	private String receiveIndicator;
	@Column(name = "DEFAULT_STANDARD_PERCENTAGE")
	private double defaultStandardPercentage;

	public long getResellerAId() {
		return resellerAId;
	}

	public void setResellerAId(long resellerAId) {
		this.resellerAId = resellerAId;
	}

	public long getDealId() {
		return dealId;
	}

	public void setDealId(long dealId) {
		this.dealId = dealId;
	}

	public String getResellerASoldTo() {
		return resellerASoldTo;
	}

	public void setResellerASoldTo(String resellerASoldTo) {
		this.resellerASoldTo = resellerASoldTo;
	}

	public String getResellerAName() {
		return resellerAName;
	}

	public void setResellerAName(String resellerAName) {
		this.resellerAName = resellerAName;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStateProvince() {
		return stateProvince;
	}

	public void setStateProvince(String stateProvince) {
		this.stateProvince = stateProvince;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public long getZip() {
		return zip;
	}

	public void setZip(long zip) {
		this.zip = zip;
	}

	public String getSplEligibilityFlg() {
		return splEligibilityFlg;
	}

	public void setSplEligibilityFlg(String splEligibilityFlg) {
		this.splEligibilityFlg = splEligibilityFlg;
	}

	public String getPrmLocationID() {
		return prmLocationID;
	}

	public void setPrmLocationID(String prmLocationID) {
		this.prmLocationID = prmLocationID;
	}

	public String getPproId() {
		return pproId;
	}

	public void setPproId(String pproId) {
		this.pproId = pproId;
	}

	public long getSapDocNo() {
		return sapDocNo;
	}

	public void setSapDocNo(long sapDocNo) {
		this.sapDocNo = sapDocNo;
	}

	public long getDealVersion() {
		return dealVersion;
	}

	public void setDealVersion(long dealVersion) {
		this.dealVersion = dealVersion;
	}

	public String getContactFirstName() {
		return contactFirstName;
	}

	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}

	public String getContactLastName() {
		return contactLastName;
	}

	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getContactEmailAddress() {
		return contactEmailAddress;
	}

	public void setContactEmailAddress(String contactEmailAddress) {
		this.contactEmailAddress = contactEmailAddress;
	}

	public String getResellerTypeCode() {
		return resellerTypeCode;
	}

	public void setResellerTypeCode(String resellerTypeCode) {
		this.resellerTypeCode = resellerTypeCode;
	}

	public String getResellerTypeDescription() {
		return resellerTypeDescription;
	}

	public void setResellerTypeDescription(String resellerTypeDescription) {
		this.resellerTypeDescription = resellerTypeDescription;
	}

	public long getCreatedByEmployeeNumber() {
		return createdByEmployeeNumber;
	}

	public void setCreatedByEmployeeNumber(long createdByEmployeeNumber) {
		this.createdByEmployeeNumber = createdByEmployeeNumber;
	}

	public Date getContractEndDate() {
		return contractEndDate;
	}

	public void setContractEndDate(Date contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	public String getdUNSIdentifier() {
		return dUNSIdentifier;
	}

	public void setdUNSIdentifier(String dUNSIdentifier) {
		this.dUNSIdentifier = dUNSIdentifier;
	}

	public String getValueAddedTaxNumber() {
		return valueAddedTaxNumber;
	}

	public void setValueAddedTaxNumber(String valueAddedTaxNumber) {
		this.valueAddedTaxNumber = valueAddedTaxNumber;
	}

	public String getContractCountryCode() {
		return contractCountryCode;
	}

	public void setContractCountryCode(String contractCountryCode) {
		this.contractCountryCode = contractCountryCode;
	}

	public String getPurchaseAgreementTypeCode() {
		return purchaseAgreementTypeCode;
	}

	public void setPurchaseAgreementTypeCode(String purchaseAgreementTypeCode) {
		this.purchaseAgreementTypeCode = purchaseAgreementTypeCode;
	}

	public String getBuyerTypeCode() {
		return buyerTypeCode;
	}

	public void setBuyerTypeCode(String buyerTypeCode) {
		this.buyerTypeCode = buyerTypeCode;
	}

	public String getPartnerStatusIndicator() {
		return partnerStatusIndicator;
	}

	public void setPartnerStatusIndicator(String partnerStatusIndicator) {
		this.partnerStatusIndicator = partnerStatusIndicator;
	}

	public String getiSOCountryCode() {
		return iSOCountryCode;
	}

	public void setiSOCountryCode(String iSOCountryCode) {
		this.iSOCountryCode = iSOCountryCode;
	}

	public String getHighRiskIndicator() {
		return highRiskIndicator;
	}

	public void setHighRiskIndicator(String highRiskIndicator) {
		this.highRiskIndicator = highRiskIndicator;
	}

	public long getAddedByEmployeeNumber() {
		return addedByEmployeeNumber;
	}

	public void setAddedByEmployeeNumber(long addedByEmployeeNumber) {
		this.addedByEmployeeNumber = addedByEmployeeNumber;
	}

	public String getContractGlobalListPriceIndicator() {
		return contractGlobalListPriceIndicator;
	}

	public void setContractGlobalListPriceIndicator(String contractGlobalListPriceIndicator) {
		this.contractGlobalListPriceIndicator = contractGlobalListPriceIndicator;
	}

	public String getPrimaryReleaseIndicator() {
		return primaryReleaseIndicator;
	}

	public void setPrimaryReleaseIndicator(String primaryReleaseIndicator) {
		this.primaryReleaseIndicator = primaryReleaseIndicator;
	}

	public String getReceiveIndicator() {
		return receiveIndicator;
	}

	public void setReceiveIndicator(String receiveIndicator) {
		this.receiveIndicator = receiveIndicator;
	}

	public double getDefaultStandardPercentage() {
		return defaultStandardPercentage;
	}

	public void setDefaultStandardPercentage(double defaultStandardPercentage) {
		this.defaultStandardPercentage = defaultStandardPercentage;
	}

}
