package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "PRICING_SPL_DEAL_RESELLER_B")
public class DealResellerB {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RESELLER_B_ID")
	private long resellerBId;
	@Column(name = "DEAL_ID")
	private long dealId;
	@Column(name = "RESELLER_B_SOLD_TO")
	private String resellerBSoldTo;
	@Column(name = "RESELLER_B_NAME")
	private String resellerBName;
	@Column(name = "CONTRACT_NO")
	private String contractNo;
	@Column(name = "CITY")
	private String city;
	@Column(name = "ADDRESS")
	private String address;
	@Column(name = "STATE_PROVINCE")
	private String stateProvince;
	@Column(name = "COUNTRY")
	private String country;
	@Column(name = "ZIP")
	private long zip;
	@Column(name = "SPECIAL_ELIGIBILITY_FLAG")
	private String specialEligibilityFlag;
	@Column(name = "PRM_LOCATION_ID")
	private String prmLocationId;
	@Column(name = "PPRO_ID")
	private String pproId;
	@Column(name = "SAP_DOCUMENT_NO")
	private long sapDocumentNo;
	@Column(name = "DEAL_VERSION")
	private long dealVersion;
	@Column(name = "CONTACT_FIRST_NAME")
	private String ContactFirstName;
	@Column(name = "CONTACT_LAST_NAME")
	private String ContactLastName;
	@Column(name = "CONTACT_NUMBER")
	private String ContactNumber;
	@Column(name = "CONTACT_EMAIL_ADDRESS")
	private String ContactEmailAddress;
	@Column(name = "RESELLER_TYPE_CODE")
	private String ResellerTypeCode;
	@Column(name = "RESELLER_TYPE_DESCRIPTION")
	private String ResellerTypeDescription;
	@Column(name = "CREATED_BY_EMPLOYEE_NUMBER")
	private long createdByEmployeeNumber;
	@Column(name = "CONTRACT_END_DATE")
	private Date contractEndDate;
	@Column(name = "DUNS_IDENTIFIER")
	private String dUNSIdentifier;
	@Column(name = "VALUE_ADDED_TAX_NUMBER")
	private String valueAddedTaxNumber;
	@Column(name = "CONTRACT_COUNTRY_CODE")
	private String contractCountryCode;
	@Column(name = "PURCHASE_AGREEMENT_TYPE_CODE")
	private String purchaseAgreementTypeCode;
	@Column(name = "BUYER_TYPE_CODE")
	private String buyerTypeCode;
	@Column(name = "PARTNER_STATUS_INDICATOR")
	private String partnerStatusIndicator;
	@Column(name = "ISO_COUNTRY_CODE")
	private String iSOCountryCode;
	@Column(name = "HIGH_RISK_INDICATOR")
	private String highRiskIndicator;
	@Column(name = "ADDED_BY_EMPLOYEE_NUMBER")
	private long addedByEmployeeNumber;
	@Column(name = "CONTRACT_GLOBAL_LIST_PRICE_INDICATOR")
	private String contractGlobalListPriceIndicator;
	@Column(name = "DEFAULT_VALUE_PERCENTAGE")
	private double defaultValuePercentage;
	public long getResellerBId() {
		return resellerBId;
	}
	public void setResellerBId(long resellerBId) {
		this.resellerBId = resellerBId;
	}
	public long getDealId() {
		return dealId;
	}
	public void setDealId(long dealId) {
		this.dealId = dealId;
	}
	public String getResellerBSoldTo() {
		return resellerBSoldTo;
	}
	public void setResellerBSoldTo(String resellerBSoldTo) {
		this.resellerBSoldTo = resellerBSoldTo;
	}
	public String getResellerBName() {
		return resellerBName;
	}
	public void setResellerBName(String resellerBName) {
		this.resellerBName = resellerBName;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStateProvince() {
		return stateProvince;
	}
	public void setStateProvince(String stateProvince) {
		this.stateProvince = stateProvince;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public long getZip() {
		return zip;
	}
	public void setZip(long zip) {
		this.zip = zip;
	}
	public String getSpecialEligibilityFlag() {
		return specialEligibilityFlag;
	}
	public void setSpecialEligibilityFlag(String specialEligibilityFlag) {
		this.specialEligibilityFlag = specialEligibilityFlag;
	}
	public String getPrmLocationId() {
		return prmLocationId;
	}
	public void setPrmLocationId(String prmLocationId) {
		this.prmLocationId = prmLocationId;
	}
	public String getPproId() {
		return pproId;
	}
	public void setPproId(String pproId) {
		this.pproId = pproId;
	}
	public long getSapDocumentNo() {
		return sapDocumentNo;
	}
	public void setSapDocumentNo(long sapDocumentNo) {
		this.sapDocumentNo = sapDocumentNo;
	}
	public long getDealVersion() {
		return dealVersion;
	}
	public void setDealVersion(long dealVersion) {
		this.dealVersion = dealVersion;
	}
	public String getContactFirstName() {
		return ContactFirstName;
	}
	public void setContactFirstName(String contactFirstName) {
		ContactFirstName = contactFirstName;
	}
	public String getContactLastName() {
		return ContactLastName;
	}
	public void setContactLastName(String contactLastName) {
		ContactLastName = contactLastName;
	}
	public String getContactNumber() {
		return ContactNumber;
	}
	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}
	public String getContactEmailAddress() {
		return ContactEmailAddress;
	}
	public void setContactEmailAddress(String contactEmailAddress) {
		ContactEmailAddress = contactEmailAddress;
	}
	public String getResellerTypeCode() {
		return ResellerTypeCode;
	}
	public void setResellerTypeCode(String resellerTypeCode) {
		ResellerTypeCode = resellerTypeCode;
	}
	public String getResellerTypeDescription() {
		return ResellerTypeDescription;
	}
	public void setResellerTypeDescription(String resellerTypeDescription) {
		ResellerTypeDescription = resellerTypeDescription;
	}
	public long getCreatedByEmployeeNumber() {
		return createdByEmployeeNumber;
	}
	public void setCreatedByEmployeeNumber(long createdByEmployeeNumber) {
		this.createdByEmployeeNumber = createdByEmployeeNumber;
	}
	public Date getContractEndDate() {
		return contractEndDate;
	}
	public void setContractEndDate(Date contractEndDate) {
		this.contractEndDate = contractEndDate;
	}
	public String getdUNSIdentifier() {
		return dUNSIdentifier;
	}
	public void setdUNSIdentifier(String dUNSIdentifier) {
		this.dUNSIdentifier = dUNSIdentifier;
	}
	public String getValueAddedTaxNumber() {
		return valueAddedTaxNumber;
	}
	public void setValueAddedTaxNumber(String valueAddedTaxNumber) {
		this.valueAddedTaxNumber = valueAddedTaxNumber;
	}
	public String getContractCountryCode() {
		return contractCountryCode;
	}
	public void setContractCountryCode(String contractCountryCode) {
		this.contractCountryCode = contractCountryCode;
	}
	public String getPurchaseAgreementTypeCode() {
		return purchaseAgreementTypeCode;
	}
	public void setPurchaseAgreementTypeCode(String purchaseAgreementTypeCode) {
		this.purchaseAgreementTypeCode = purchaseAgreementTypeCode;
	}
	public String getBuyerTypeCode() {
		return buyerTypeCode;
	}
	public void setBuyerTypeCode(String buyerTypeCode) {
		this.buyerTypeCode = buyerTypeCode;
	}
	public String getPartnerStatusIndicator() {
		return partnerStatusIndicator;
	}
	public void setPartnerStatusIndicator(String partnerStatusIndicator) {
		this.partnerStatusIndicator = partnerStatusIndicator;
	}
	public String getiSOCountryCode() {
		return iSOCountryCode;
	}
	public void setiSOCountryCode(String iSOCountryCode) {
		this.iSOCountryCode = iSOCountryCode;
	}
	public String getHighRiskIndicator() {
		return highRiskIndicator;
	}
	public void setHighRiskIndicator(String highRiskIndicator) {
		this.highRiskIndicator = highRiskIndicator;
	}
	public long getAddedByEmployeeNumber() {
		return addedByEmployeeNumber;
	}
	public void setAddedByEmployeeNumber(long addedByEmployeeNumber) {
		this.addedByEmployeeNumber = addedByEmployeeNumber;
	}
	public String getContractGlobalListPriceIndicator() {
		return contractGlobalListPriceIndicator;
	}
	public void setContractGlobalListPriceIndicator(String contractGlobalListPriceIndicator) {
		this.contractGlobalListPriceIndicator = contractGlobalListPriceIndicator;
	}
	public double getDefaultValuePercentage() {
		return defaultValuePercentage;
	}
	public void setDefaultValuePercentage(double defaultValuePercentage) {
		this.defaultValuePercentage = defaultValuePercentage;
	}
	
	
}