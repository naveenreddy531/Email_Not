package com.allcomm.kafka.integration.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_DEAL_SALES_REP")
public class DealSalesRep {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SALES_REP_ID")
	private long salesRepID;

	@Column(name = "HP_EMPLOYEE_NUMBER")
	private long hpEmpNo;

	@Column(name = "DEAL_ID")
	private long dealId;

	@Column(name = "SAP_DOCUMENT_NO")
	private long sapDocNo;

	@Column(name = "DEAL_VERSION")
	private long dealVersion;

	public long getSalesRepID() {
		return salesRepID;
	}

	public void setSalesRepID(long salesRepID) {
		this.salesRepID = salesRepID;
	}

	public long getHpEmpNo() {
		return hpEmpNo;
	}

	public void setHpEmpNo(long hpEmpNo) {
		this.hpEmpNo = hpEmpNo;
	}

	public long getSapDocNo() {
		return sapDocNo;
	}

	public void setSapDocNo(long sapDocNo) {
		this.sapDocNo = sapDocNo;
	}

	public long getDealVersion() {
		return dealVersion;
	}

	public void setDealVersion(long dealVersion) {
		this.dealVersion = dealVersion;
	}

	public long getDealId() {
		return dealId;
	}

	public void setDealId(long dealId) {
		this.dealId = dealId;
	}

	@Override
	public String toString() {
		return "DealSalesRep [salesRepID=" + salesRepID + ", hpEmpNo=" + hpEmpNo + ", dealId=" + dealId + ", sapDocNo="
				+ sapDocNo + ", dealVersion=" + dealVersion + "]";
	}

}
