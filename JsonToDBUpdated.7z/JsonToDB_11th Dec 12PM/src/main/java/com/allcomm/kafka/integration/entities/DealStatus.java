package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_PRICE_COMM_DEAL_STATUS")
public class DealStatus {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PRICE_COMM_DEAL_STATUS_ID")
	private long id;

	@Column(name = "STATUS_TYPE_CD")
	private String statusTypeCD;

	@Column(name = "STATUS_TYPE_DESC")
	private String statusTypeDesc;

	@Column(name = "ACTIVE_FL")
	private String activeFL;

	@Column(name = "CREATION_DTS")
	private Date creationDTS;

	@Column(name = "UPDATE_DTS")
	private Date updtDTS;

	@Column(name = "LAST_CHANGE_EMP_NR")
	private long lastChngEmpNr;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStatusTypeCD() {
		return statusTypeCD;
	}

	public void setStatusTypeCD(String statusTypeCD) {
		this.statusTypeCD = statusTypeCD;
	}

	public String getStatusTypeDesc() {
		return statusTypeDesc;
	}

	public void setStatusTypeDesc(String statusTypeDesc) {
		this.statusTypeDesc = statusTypeDesc;
	}

	public String getActiveFL() {
		return activeFL;
	}

	public void setActiveFL(String activeFL) {
		this.activeFL = activeFL;
	}

	public Date getCreationDTS() {
		return creationDTS;
	}

	public void setCreationDTS(Date creationDTS) {
		this.creationDTS = creationDTS;
	}

	public Date getUpdtDTS() {
		return updtDTS;
	}

	public void setUpdtDTS(Date updtDTS) {
		this.updtDTS = updtDTS;
	}

	public long getLastChngEmpNr() {
		return lastChngEmpNr;
	}

	public void setLastChngEmpNr(long lastChngEmpNr) {
		this.lastChngEmpNr = lastChngEmpNr;
	}

}
