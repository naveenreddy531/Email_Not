package com.allcomm.kafka.integration.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "PRICING_SPL_DEAL_USERS")
public class DealUsers implements Serializable {
	private static long serialVersionUID = -44180022249782423L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DEAL_USERS_ID")
	private long dealUsersId;
	@Column(name = "DEAL_ID")
	private long dealId;
	@Column(name = "HPE_USER_ID")
	private String hpeUserId;
	@Column(name = "DEAL_USER_DESCRIPTION")
	private String dealUserDesc;
	@Column(name = "DEAL_USER_TYPE_CD")
	private String dealUserTypeCD;
	@Column(name = "CAN_RECEIVE_QUOTE_FI")
	private String canRecieveQoteFI;
	@Column(name = "HPE_EMPLOYEE_NUMBER")
	private long hpeEmpNo;
	@Column(name = "HPE_EMPLOYEE_MAIL")
	private String hpeEmpMail;
	@Column(name = "SAP_DOCUMENT_NO")
	private long sapDocNo;
	@Column(name = "DEAL_VERSION")
	private long dealVrsn;

	public long getDealUsersId() {
		return dealUsersId;
	}

	public void setDealUsersId(long dealUsersId) {
		this.dealUsersId = dealUsersId;
	}

	public long getDealId() {
		return dealId;
	}

	public void setDealId(long dealId) {
		this.dealId = dealId;
	}

	public String getHpeUserId() {
		return hpeUserId;
	}

	public void setHpeUserId(String hpeUserId) {
		this.hpeUserId = hpeUserId;
	}

	public String getDealUserDesc() {
		return dealUserDesc;
	}

	public void setDealUserDesc(String dealUserDesc) {
		this.dealUserDesc = dealUserDesc;
	}

	public String getDealUserTypeCD() {
		return dealUserTypeCD;
	}

	public void setDealUserTypeCD(String dealUserTypeCD) {
		this.dealUserTypeCD = dealUserTypeCD;
	}

	public String getCanRecieveQoteFI() {
		return canRecieveQoteFI;
	}

	public void setCanRecieveQoteFI(String canRecieveQoteFI) {
		this.canRecieveQoteFI = canRecieveQoteFI;
	}

	public long getHpeEmpNo() {
		return hpeEmpNo;
	}

	public void setHpeEmpNo(long hpeEmpNo) {
		this.hpeEmpNo = hpeEmpNo;
	}

	public String getHpeEmpMail() {
		return hpeEmpMail;
	}

	public void setHpeEmpMail(String hpeEmpMail) {
		this.hpeEmpMail = hpeEmpMail;
	}

	public long getSapDocNo() {
		return sapDocNo;
	}

	public void setSapDocNo(long sapDocNo) {
		this.sapDocNo = sapDocNo;
	}

	public long getDealVrsn() {
		return dealVrsn;
	}

	public void setDealVrsn(long dealVrsn) {
		this.dealVrsn = dealVrsn;
	}

	@Override
	public String toString() {
		return "DealUsers [DEAL_USERS_ID=" + dealUsersId + ", dealId=" + dealId + ", hpeUserId=" + hpeUserId
				+ ", dealUserDesc=" + dealUserDesc + ", dealUserTypeCD=" + dealUserTypeCD + ", canRecieveQoteFI="
				+ canRecieveQoteFI + ", hpeEmpNo=" + hpeEmpNo + ", hpeEmpMail=" + hpeEmpMail + ", sapDocNo=" + sapDocNo
				+ ", dealVrsn=" + dealVrsn + "]";
	}

}
