package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "PRICING_SPL_PRICE_COMM_DISCOUNT_TYPE")
public class DiscountType {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PRICE_COMM_DEAL_DISCOUNT_ID")
	private long id;

	@Column(name = "DISCOUNT_TYPE_CD")
	private String discTypeCD;

	@Column(name = "DISCOUNT_TYPE_DESC")
	private String discTypeDesc;

	@Column(name = "ACTIVE_FL")
	private String activeFL;

	@Column(name = "CREATION_DTS")
	private Date creationDate;

	@Column(name = "UPDATE_DTS")
	private Date updateDate;

	@Column(name = "LAST_CHANGE_EMP_NR")
	private long lastChangeEmpNo;

	public  long getId() {
		return id;
	}

	public  void setId(long id) {
		this.id = id;
	}

	public  String getDiscTypeCD() {
		return discTypeCD;
	}

	public  void setDiscTypeCD(String discTypeCD) {
		this.discTypeCD = discTypeCD;
	}

	public  String getDiscTypeDesc() {
		return discTypeDesc;
	}

	public  void setDiscTypeDesc(String discTypeDesc) {
		this.discTypeDesc = discTypeDesc;
	}

	public  String getActiveFL() {
		return activeFL;
	}

	public  void setActiveFL(String activeFL) {
		this.activeFL = activeFL;
	}

	public  Date getCreationDate() {
		return creationDate;
	}

	public  void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public  Date getUpdateDate() {
		return updateDate;
	}

	public  void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public  long getLastChangeEmpNo() {
		return lastChangeEmpNo;
	}

	public  void setLastChangeEmpNo(long lastChangeEmpNo) {
		this.lastChangeEmpNo = lastChangeEmpNo;
	}

}
