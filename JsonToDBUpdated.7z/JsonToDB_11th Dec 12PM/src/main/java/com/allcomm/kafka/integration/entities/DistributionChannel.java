package com.allcomm.kafka.integration.entities;
public class DistributionChannel
{
    private String DistributionChannelDescription;

    private String DistributionChannelCode;

    private String SourceSystemCode;

    public String getDistributionChannelDescription ()
    {
        return DistributionChannelDescription;
    }

    public void setDistributionChannelDescription (String DistributionChannelDescription)
    {
        this.DistributionChannelDescription = DistributionChannelDescription;
    }

    public String getDistributionChannelCode ()
    {
        return DistributionChannelCode;
    }

    public void setDistributionChannelCode (String DistributionChannelCode)
    {
        this.DistributionChannelCode = DistributionChannelCode;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [DistributionChannelDescription = "+DistributionChannelDescription+", DistributionChannelCode = "+DistributionChannelCode+", SourceSystemCode = "+SourceSystemCode+"]";
    }
}