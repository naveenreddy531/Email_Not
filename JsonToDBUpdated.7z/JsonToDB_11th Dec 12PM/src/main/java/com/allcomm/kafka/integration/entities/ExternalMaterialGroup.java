package com.allcomm.kafka.integration.entities;
public class ExternalMaterialGroup
{
    private String SourceSystemCode;

    private String ExternalMaterialGroupCode;

    private String ExternalMaterialGroupDescription;

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getExternalMaterialGroupCode ()
    {
        return ExternalMaterialGroupCode;
    }

    public void setExternalMaterialGroupCode (String ExternalMaterialGroupCode)
    {
        this.ExternalMaterialGroupCode = ExternalMaterialGroupCode;
    }

    public String getExternalMaterialGroupDescription ()
    {
        return ExternalMaterialGroupDescription;
    }

    public void setExternalMaterialGroupDescription (String ExternalMaterialGroupDescription)
    {
        this.ExternalMaterialGroupDescription = ExternalMaterialGroupDescription;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [SourceSystemCode = "+SourceSystemCode+", ExternalMaterialGroupCode = "+ExternalMaterialGroupCode+", ExternalMaterialGroupDescription = "+ExternalMaterialGroupDescription+"]";
    }
}