package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_IBP_LOOKUP")
public class IBPLookup {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long ibp_Id;
	private String dealType;

	private String routeToMarket;

	private String countryCode;

	private String countryName;

	private String region;

	private String productLineCode;

	private String productLineDescription;

	private String priceTypeCode;

	private String priceTypeDescription;

	private String upliftBdnet;

	private String upliftDiscount;

	private Date startDate;

	private Date endDate;

	private String displayText;

	private String showVpaIbp;

	private String dealScenario;

	private String medalType;

	private String cert;

	private String dealReg;

	public long getIbp_Id() {
		return ibp_Id;
	}

	public void setIbp_Id(long ibp_Id) {
		this.ibp_Id = ibp_Id;
	}

	public String getDealType() {
		return dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	public String getRouteToMarket() {
		return routeToMarket;
	}

	public void setRouteToMarket(String routeToMarket) {
		this.routeToMarket = routeToMarket;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getProductLineCode() {
		return productLineCode;
	}

	public void setProductLineCode(String productLineCode) {
		this.productLineCode = productLineCode;
	}

	public String getProductLineDescription() {
		return productLineDescription;
	}

	public void setProductLineDescription(String productLineDescription) {
		this.productLineDescription = productLineDescription;
	}

	public String getPriceTypeCode() {
		return priceTypeCode;
	}

	public void setPriceTypeCode(String priceTypeCode) {
		this.priceTypeCode = priceTypeCode;
	}

	public String getPriceTypeDescription() {
		return priceTypeDescription;
	}

	public void setPriceTypeDescription(String priceTypeDescription) {
		this.priceTypeDescription = priceTypeDescription;
	}

	public String getUpliftBdnet() {
		return upliftBdnet;
	}

	public void setUpliftBdnet(String upliftBdnet) {
		this.upliftBdnet = upliftBdnet;
	}

	public String getUpliftDiscount() {
		return upliftDiscount;
	}

	public void setUpliftDiscount(String upliftDiscount) {
		this.upliftDiscount = upliftDiscount;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

	public String getShowVpaIbp() {
		return showVpaIbp;
	}

	public void setShowVpaIbp(String showVpaIbp) {
		this.showVpaIbp = showVpaIbp;
	}

	public String getDealScenario() {
		return dealScenario;
	}

	public void setDealScenario(String dealScenario) {
		this.dealScenario = dealScenario;
	}

	public String getMedalType() {
		return medalType;
	}

	public void setMedalType(String medalType) {
		this.medalType = medalType;
	}

	public String getCert() {
		return cert;
	}

	public void setCert(String cert) {
		this.cert = cert;
	}

	public String getDealReg() {
		return dealReg;
	}

	public void setDealReg(String dealReg) {
		this.dealReg = dealReg;
	}

	@Override
	public String toString() {
		return "IBPLookup [ibp_Id=" + ibp_Id + ", dealType=" + dealType + ", routeToMarket=" + routeToMarket
				+ ", countryCode=" + countryCode + ", countryName=" + countryName + ", region=" + region
				+ ", productLineCode=" + productLineCode + ", productLineDescription=" + productLineDescription
				+ ", priceTypeCode=" + priceTypeCode + ", priceTypeDescription=" + priceTypeDescription
				+ ", upliftBdnet=" + upliftBdnet + ", upliftDiscount=" + upliftDiscount + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", displayText=" + displayText + ", showVpaIbp=" + showVpaIbp
				+ ", dealScenario=" + dealScenario + ", medalType=" + medalType + ", cert=" + cert + ", dealReg="
				+ dealReg + "]";
	}

}
