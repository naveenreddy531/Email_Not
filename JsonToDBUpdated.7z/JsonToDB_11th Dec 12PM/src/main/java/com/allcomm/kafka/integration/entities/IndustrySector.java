package com.allcomm.kafka.integration.entities;
public class IndustrySector
{
    private String IndustrySectorCode;

    private String IndustrySectorDescription;

    private String SourceSystemCode;

    public String getIndustrySectorCode ()
    {
        return IndustrySectorCode;
    }

    public void setIndustrySectorCode (String IndustrySectorCode)
    {
        this.IndustrySectorCode = IndustrySectorCode;
    }

    public String getIndustrySectorDescription ()
    {
        return IndustrySectorDescription;
    }

    public void setIndustrySectorDescription (String IndustrySectorDescription)
    {
        this.IndustrySectorDescription = IndustrySectorDescription;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [IndustrySectorCode = "+IndustrySectorCode+", IndustrySectorDescription = "+IndustrySectorDescription+", SourceSystemCode = "+SourceSystemCode+"]";
    }
}