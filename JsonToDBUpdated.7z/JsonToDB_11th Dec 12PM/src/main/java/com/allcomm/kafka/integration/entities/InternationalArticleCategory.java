package com.allcomm.kafka.integration.entities;
public class InternationalArticleCategory
{
    private String SourceSystemCode;

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [SourceSystemCode = "+SourceSystemCode+"]";
    }
}