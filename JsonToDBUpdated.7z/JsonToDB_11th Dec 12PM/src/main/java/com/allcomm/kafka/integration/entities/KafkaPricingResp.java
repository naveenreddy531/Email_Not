package com.allcomm.kafka.integration.entities;

import java.io.Serializable;

public class KafkaPricingResp implements Serializable {
	private Long KafkaPricingRespId;
	private String IndustrySectorCode;

	private DangerousGoods DangerousGoods;

	public final Long getKafkaPricingRespId() {
		return KafkaPricingRespId;
	}

	public final void setKafkaPricingRespId(Long kafkaPricingRespId) {
		KafkaPricingRespId = kafkaPricingRespId;
	}

	private ExternalMaterialGroup ExternalMaterialGroup;

	private CrossPlantMaterialStatus CrossPlantMaterialStatus;

	private MaterialSales[] MaterialSales;

	private MaterialTax[] MaterialTax;

	private String CrossPlantMaterialStatusEffectiveDate;

	private MaterialGroup MaterialGroup;

	private IndustrySector IndustrySector;

	private CrossSalesMaterialStatus CrossSalesMaterialStatus;

	private UnitOfMeasure[] UnitOfMeasure;

	private String SalesDivisionCode;

	private SalesDivision SalesDivision;

	private String BaseUnitofMeasureCode;

	private String GeneralMaterialItemCategoryGroupCode;

	private PackagingMaterialGroup PackagingMaterialGroup;

	private String CreatedByUserID;

	private String TransportationGroupCode;

	private String SourceSystemCreateTimestamp;

	private String DangerousGoodsCode;

	private String MaterialIdentifier;

	private String UpdatedByUserID;

	private String LaboratoryDesignCode;

	private MaterialType MaterialType;

	private MaterialWarehouse[] MaterialWarehouse;

	private LaboratoryDesign LaboratoryDesign;

	private String SourceSystemUpdateTimestamp;

	private String WeightUnitofMeasureCode;

	private String GrossWeight;

	private MaterialLanguage[] MaterialLanguage;

	private String NetWeight;

	private MaterialUnitOfMeasure[] MaterialUnitOfMeasure;

	private String SourceSystemCode;

	private String OldMaterialIdentifier;

	private String ExternalMaterialGroupCode;

	private String MaterialTypeCode;

	private String CrossPlantMaterialStatusCode;

	private String MaterialGroupCode;

	public String getCrossPlantMaterialStatusCode() {
		return CrossPlantMaterialStatusCode;
	}

	public void setCrossPlantMaterialStatusCode(String CrossPlantMaterialStatusCode) {
		this.CrossPlantMaterialStatusCode = CrossPlantMaterialStatusCode;
	}

	public String getMaterialGroupCode() {
		return MaterialGroupCode;
	}

	public void setMaterialGroupCode(String MaterialGroupCode) {
		this.MaterialGroupCode = MaterialGroupCode;
	}

	public String getIndustrySectorCode() {
		return IndustrySectorCode;
	}

	public void setIndustrySectorCode(String IndustrySectorCode) {
		this.IndustrySectorCode = IndustrySectorCode;
	}

	public DangerousGoods getDangerousGoods() {
		return DangerousGoods;
	}

	public void setDangerousGoods(DangerousGoods DangerousGoods) {
		this.DangerousGoods = DangerousGoods;
	}

	public ExternalMaterialGroup getExternalMaterialGroup() {
		return ExternalMaterialGroup;
	}

	public void setExternalMaterialGroup(ExternalMaterialGroup ExternalMaterialGroup) {
		this.ExternalMaterialGroup = ExternalMaterialGroup;
	}

	public CrossPlantMaterialStatus getCrossPlantMaterialStatus() {
		return CrossPlantMaterialStatus;
	}

	public void setCrossPlantMaterialStatus(CrossPlantMaterialStatus CrossPlantMaterialStatus) {
		this.CrossPlantMaterialStatus = CrossPlantMaterialStatus;
	}

	public MaterialSales[] getMaterialSales() {
		return MaterialSales;
	}

	public void setMaterialSales(MaterialSales[] MaterialSales) {
		this.MaterialSales = MaterialSales;
	}

	public MaterialTax[] getMaterialTax() {
		return MaterialTax;
	}

	public void setMaterialTax(MaterialTax[] MaterialTax) {
		this.MaterialTax = MaterialTax;
	}

	public String getCrossPlantMaterialStatusEffectiveDate() {
		return CrossPlantMaterialStatusEffectiveDate;
	}

	public void setCrossPlantMaterialStatusEffectiveDate(String CrossPlantMaterialStatusEffectiveDate) {
		this.CrossPlantMaterialStatusEffectiveDate = CrossPlantMaterialStatusEffectiveDate;
	}

	public MaterialGroup getMaterialGroup() {
		return MaterialGroup;
	}

	public void setMaterialGroup(MaterialGroup MaterialGroup) {
		this.MaterialGroup = MaterialGroup;
	}

	public IndustrySector getIndustrySector() {
		return IndustrySector;
	}

	public void setIndustrySector(IndustrySector IndustrySector) {
		this.IndustrySector = IndustrySector;
	}

	public CrossSalesMaterialStatus getCrossSalesMaterialStatus() {
		return CrossSalesMaterialStatus;
	}

	public void setCrossSalesMaterialStatus(CrossSalesMaterialStatus CrossSalesMaterialStatus) {
		this.CrossSalesMaterialStatus = CrossSalesMaterialStatus;
	}

	public UnitOfMeasure[] getUnitOfMeasure() {
		return UnitOfMeasure;
	}

	public void setUnitOfMeasure(UnitOfMeasure[] UnitOfMeasure) {
		this.UnitOfMeasure = UnitOfMeasure;
	}

	public String getSalesDivisionCode() {
		return SalesDivisionCode;
	}

	public void setSalesDivisionCode(String SalesDivisionCode) {
		this.SalesDivisionCode = SalesDivisionCode;
	}

	public SalesDivision getSalesDivision() {
		return SalesDivision;
	}

	public void setSalesDivision(SalesDivision SalesDivision) {
		this.SalesDivision = SalesDivision;
	}

	public String getBaseUnitofMeasureCode() {
		return BaseUnitofMeasureCode;
	}

	public void setBaseUnitofMeasureCode(String BaseUnitofMeasureCode) {
		this.BaseUnitofMeasureCode = BaseUnitofMeasureCode;
	}

	public String getGeneralMaterialItemCategoryGroupCode() {
		return GeneralMaterialItemCategoryGroupCode;
	}

	public void setGeneralMaterialItemCategoryGroupCode(String GeneralMaterialItemCategoryGroupCode) {
		this.GeneralMaterialItemCategoryGroupCode = GeneralMaterialItemCategoryGroupCode;
	}

	public PackagingMaterialGroup getPackagingMaterialGroup() {
		return PackagingMaterialGroup;
	}

	public void setPackagingMaterialGroup(PackagingMaterialGroup PackagingMaterialGroup) {
		this.PackagingMaterialGroup = PackagingMaterialGroup;
	}

	public String getCreatedByUserID() {
		return CreatedByUserID;
	}

	public void setCreatedByUserID(String CreatedByUserID) {
		this.CreatedByUserID = CreatedByUserID;
	}

	public String getTransportationGroupCode() {
		return TransportationGroupCode;
	}

	public void setTransportationGroupCode(String TransportationGroupCode) {
		this.TransportationGroupCode = TransportationGroupCode;
	}

	public String getSourceSystemCreateTimestamp() {
		return SourceSystemCreateTimestamp;
	}

	public void setSourceSystemCreateTimestamp(String SourceSystemCreateTimestamp) {
		this.SourceSystemCreateTimestamp = SourceSystemCreateTimestamp;
	}

	public String getDangerousGoodsCode() {
		return DangerousGoodsCode;
	}

	public void setDangerousGoodsCode(String DangerousGoodsCode) {
		this.DangerousGoodsCode = DangerousGoodsCode;
	}

	public String getMaterialIdentifier() {
		return MaterialIdentifier;
	}

	public void setMaterialIdentifier(String MaterialIdentifier) {
		this.MaterialIdentifier = MaterialIdentifier;
	}

	public String getUpdatedByUserID() {
		return UpdatedByUserID;
	}

	public void setUpdatedByUserID(String UpdatedByUserID) {
		this.UpdatedByUserID = UpdatedByUserID;
	}

	public String getLaboratoryDesignCode() {
		return LaboratoryDesignCode;
	}

	public void setLaboratoryDesignCode(String LaboratoryDesignCode) {
		this.LaboratoryDesignCode = LaboratoryDesignCode;
	}

	public MaterialType getMaterialType() {
		return MaterialType;
	}

	public void setMaterialType(MaterialType MaterialType) {
		this.MaterialType = MaterialType;
	}

	public MaterialWarehouse[] getMaterialWarehouse() {
		return MaterialWarehouse;
	}

	public void setMaterialWarehouse(MaterialWarehouse[] MaterialWarehouse) {
		this.MaterialWarehouse = MaterialWarehouse;
	}

	public LaboratoryDesign getLaboratoryDesign() {
		return LaboratoryDesign;
	}

	public void setLaboratoryDesign(LaboratoryDesign LaboratoryDesign) {
		this.LaboratoryDesign = LaboratoryDesign;
	}

	public String getSourceSystemUpdateTimestamp() {
		return SourceSystemUpdateTimestamp;
	}

	public void setSourceSystemUpdateTimestamp(String SourceSystemUpdateTimestamp) {
		this.SourceSystemUpdateTimestamp = SourceSystemUpdateTimestamp;
	}

	public String getWeightUnitofMeasureCode() {
		return WeightUnitofMeasureCode;
	}

	public void setWeightUnitofMeasureCode(String WeightUnitofMeasureCode) {
		this.WeightUnitofMeasureCode = WeightUnitofMeasureCode;
	}

	public String getGrossWeight() {
		return GrossWeight;
	}

	public void setGrossWeight(String GrossWeight) {
		this.GrossWeight = GrossWeight;
	}

	public MaterialLanguage[] getMaterialLanguage() {
		return MaterialLanguage;
	}

	public void setMaterialLanguage(MaterialLanguage[] MaterialLanguage) {
		this.MaterialLanguage = MaterialLanguage;
	}

	public String getNetWeight() {
		return NetWeight;
	}

	public void setNetWeight(String NetWeight) {
		this.NetWeight = NetWeight;
	}

	public MaterialUnitOfMeasure[] getMaterialUnitOfMeasure() {
		return MaterialUnitOfMeasure;
	}

	public void setMaterialUnitOfMeasure(MaterialUnitOfMeasure[] MaterialUnitOfMeasure) {
		this.MaterialUnitOfMeasure = MaterialUnitOfMeasure;
	}

	public String getSourceSystemCode() {
		return SourceSystemCode;
	}

	public void setSourceSystemCode(String SourceSystemCode) {
		this.SourceSystemCode = SourceSystemCode;
	}

	public String getOldMaterialIdentifier() {
		return OldMaterialIdentifier;
	}

	public void setOldMaterialIdentifier(String OldMaterialIdentifier) {
		this.OldMaterialIdentifier = OldMaterialIdentifier;
	}

	public String getExternalMaterialGroupCode() {
		return ExternalMaterialGroupCode;
	}

	public void setExternalMaterialGroupCode(String ExternalMaterialGroupCode) {
		this.ExternalMaterialGroupCode = ExternalMaterialGroupCode;
	}

	public String getMaterialTypeCode() {
		return MaterialTypeCode;
	}

	public void setMaterialTypeCode(String MaterialTypeCode) {
		this.MaterialTypeCode = MaterialTypeCode;
	}

	@Override
	public String toString() {
		return "ClassPojo [CrossPlantMaterialStatusCode = " + CrossPlantMaterialStatusCode + ", MaterialGroupCode = "
				+ MaterialGroupCode + ", IndustrySectorCode = " + IndustrySectorCode + ", DangerousGoods = "
				+ DangerousGoods + ", ExternalMaterialGroup = " + ExternalMaterialGroup
				+ ", CrossPlantMaterialStatus = " + CrossPlantMaterialStatus + ", MaterialSales = " + MaterialSales
				+ ", MaterialTax = " + MaterialTax + ", CrossPlantMaterialStatusEffectiveDate = "
				+ CrossPlantMaterialStatusEffectiveDate + ", MaterialGroup = " + MaterialGroup + ", IndustrySector = "
				+ IndustrySector + ", CrossSalesMaterialStatus = " + CrossSalesMaterialStatus + ", UnitOfMeasure = "
				+ UnitOfMeasure + ", SalesDivisionCode = " + SalesDivisionCode + ", SalesDivision = " + SalesDivision
				+ ", BaseUnitofMeasureCode = " + BaseUnitofMeasureCode + ", GeneralMaterialItemCategoryGroupCode = "
				+ GeneralMaterialItemCategoryGroupCode + ", PackagingMaterialGroup = " + PackagingMaterialGroup
				+ ", CreatedByUserID = " + CreatedByUserID + ", TransportationGroupCode = " + TransportationGroupCode
				+ ", SourceSystemCreateTimestamp = " + SourceSystemCreateTimestamp + ", DangerousGoodsCode = "
				+ DangerousGoodsCode + ", MaterialIdentifier = " + MaterialIdentifier + ", UpdatedByUserID = "
				+ UpdatedByUserID + ", LaboratoryDesignCode = " + LaboratoryDesignCode + ", MaterialType = "
				+ MaterialType + ", MaterialWarehouse = " + MaterialWarehouse + ", LaboratoryDesign = "
				+ LaboratoryDesign + ", SourceSystemUpdateTimestamp = " + SourceSystemUpdateTimestamp
				+ ", WeightUnitofMeasureCode = " + WeightUnitofMeasureCode + ", GrossWeight = " + GrossWeight
				+ ", MaterialLanguage = " + MaterialLanguage + ", NetWeight = " + NetWeight
				+ ", MaterialUnitOfMeasure = " + MaterialUnitOfMeasure + ", SourceSystemCode = " + SourceSystemCode
				+ ", OldMaterialIdentifier = " + OldMaterialIdentifier + ", ExternalMaterialGroupCode = "
				+ ExternalMaterialGroupCode + ", MaterialTypeCode = " + MaterialTypeCode + "]";
	}
}
