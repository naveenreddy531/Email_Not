package com.allcomm.kafka.integration.entities;
public class LaboratoryDesign
{
    private String SourceSystemCode;

    private String LaboratoryDesignDescription;

    private String LaboratoryDesignCode;

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getLaboratoryDesignDescription ()
    {
        return LaboratoryDesignDescription;
    }

    public void setLaboratoryDesignDescription (String LaboratoryDesignDescription)
    {
        this.LaboratoryDesignDescription = LaboratoryDesignDescription;
    }

    public String getLaboratoryDesignCode ()
    {
        return LaboratoryDesignCode;
    }

    public void setLaboratoryDesignCode (String LaboratoryDesignCode)
    {
        this.LaboratoryDesignCode = LaboratoryDesignCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [SourceSystemCode = "+SourceSystemCode+", LaboratoryDesignDescription = "+LaboratoryDesignDescription+", LaboratoryDesignCode = "+LaboratoryDesignCode+"]";
    }
}