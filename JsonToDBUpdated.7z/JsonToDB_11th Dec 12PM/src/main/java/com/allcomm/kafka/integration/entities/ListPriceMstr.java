package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "PRICE_COMMS_LIST_PRICE_MSTR")
public class ListPriceMstr {
	@Id
	private long Id;
	private String orderableProduct;
	private String countryCode;
	private String priceGeo;
	private String currency;
	private String incoterm;
	private long QBF;
	private long QBT;
	private String UOM;
	private double LP;
	private double prevLP;
	private Date LPEffectiveDate;
	private Date endEffectivity;
	private String priceSource;
	private Date eTransmittedDate;
	private String correction;
	private String sourceOfData;
	private String conditionTypeCode;
	private String scaleTypeCode;
	private String calculationTypeCode;
	private String optionID;
	public long getId() {
		return Id;
	}
	public void setId(long id) {
		Id = id;
	}
	public String getOrderableProduct() {
		return orderableProduct;
	}
	public void setOrderableProduct(String orderableProduct) {
		this.orderableProduct = orderableProduct;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getPriceGeo() {
		return priceGeo;
	}
	public void setPriceGeo(String priceGeo) {
		this.priceGeo = priceGeo;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getIncoterm() {
		return incoterm;
	}
	public void setIncoterm(String incoterm) {
		this.incoterm = incoterm;
	}
	public long getQBF() {
		return QBF;
	}
	public void setQBF(long qBF) {
		QBF = qBF;
	}
	public long getQBT() {
		return QBT;
	}
	public void setQBT(long qBT) {
		QBT = qBT;
	}
	public String getUOM() {
		return UOM;
	}
	public void setUOM(String uOM) {
		UOM = uOM;
	}
	public double getLP() {
		return LP;
	}
	public void setLP(double lP) {
		LP = lP;
	}
	public double getPrevLP() {
		return prevLP;
	}
	public void setPrevLP(double prevLP) {
		this.prevLP = prevLP;
	}
	public Date getLPEffectiveDate() {
		return LPEffectiveDate;
	}
	public void setLPEffectiveDate(Date lPEffectiveDate) {
		LPEffectiveDate = lPEffectiveDate;
	}
	public Date getEndEffectivity() {
		return endEffectivity;
	}
	public void setEndEffectivity(Date endEffectivity) {
		this.endEffectivity = endEffectivity;
	}
	public String getPriceSource() {
		return priceSource;
	}
	public void setPriceSource(String priceSource) {
		this.priceSource = priceSource;
	}
	public Date geteTransmittedDate() {
		return eTransmittedDate;
	}
	public void seteTransmittedDate(Date eTransmittedDate) {
		this.eTransmittedDate = eTransmittedDate;
	}
	public String getCorrection() {
		return correction;
	}
	public void setCorrection(String correction) {
		this.correction = correction;
	}
	public String getSourceOfData() {
		return sourceOfData;
	}
	public void setSourceOfData(String sourceOfData) {
		this.sourceOfData = sourceOfData;
	}
	public String getConditionTypeCode() {
		return conditionTypeCode;
	}
	public void setConditionTypeCode(String conditionTypeCode) {
		this.conditionTypeCode = conditionTypeCode;
	}
	public String getScaleTypeCode() {
		return scaleTypeCode;
	}
	public void setScaleTypeCode(String scaleTypeCode) {
		this.scaleTypeCode = scaleTypeCode;
	}
	public String getCalculationTypeCode() {
		return calculationTypeCode;
	}
	public void setCalculationTypeCode(String calculationTypeCode) {
		this.calculationTypeCode = calculationTypeCode;
	}
	public String getOptionID() {
		return optionID;
	}
	public void setOptionID(String optionID) {
		this.optionID = optionID;
	}
	
	

	}
