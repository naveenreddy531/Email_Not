package com.allcomm.kafka.integration.entities;
public class MaterialAccountAssignmentGroup
{
    private String MaterialAccountAssignmentGroupCode;

    private String MaterialAccountAssignmentDescription;

    private String SourceSystemCode;

    public String getMaterialAccountAssignmentGroupCode ()
    {
        return MaterialAccountAssignmentGroupCode;
    }

    public void setMaterialAccountAssignmentGroupCode (String MaterialAccountAssignmentGroupCode)
    {
        this.MaterialAccountAssignmentGroupCode = MaterialAccountAssignmentGroupCode;
    }

    public String getMaterialAccountAssignmentDescription ()
    {
        return MaterialAccountAssignmentDescription;
    }

    public void setMaterialAccountAssignmentDescription (String MaterialAccountAssignmentDescription)
    {
        this.MaterialAccountAssignmentDescription = MaterialAccountAssignmentDescription;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [MaterialAccountAssignmentGroupCode = "+MaterialAccountAssignmentGroupCode+", MaterialAccountAssignmentDescription = "+MaterialAccountAssignmentDescription+", SourceSystemCode = "+SourceSystemCode+"]";
    }
}
