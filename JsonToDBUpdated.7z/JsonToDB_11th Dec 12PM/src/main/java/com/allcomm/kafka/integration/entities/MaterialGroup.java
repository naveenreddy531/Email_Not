package com.allcomm.kafka.integration.entities;
public class MaterialGroup
{
    private String MaterialGroupCode;

    private String SourceSystemCode;

    private String MaterialGroupDescription;

    private String MaterialGroupLongDescription;

    public String getMaterialGroupCode ()
    {
        return MaterialGroupCode;
    }

    public void setMaterialGroupCode (String MaterialGroupCode)
    {
        this.MaterialGroupCode = MaterialGroupCode;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getMaterialGroupDescription ()
    {
        return MaterialGroupDescription;
    }

    public void setMaterialGroupDescription (String MaterialGroupDescription)
    {
        this.MaterialGroupDescription = MaterialGroupDescription;
    }

    public String getMaterialGroupLongDescription ()
    {
        return MaterialGroupLongDescription;
    }

    public void setMaterialGroupLongDescription (String MaterialGroupLongDescription)
    {
        this.MaterialGroupLongDescription = MaterialGroupLongDescription;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [MaterialGroupCode = "+MaterialGroupCode+", SourceSystemCode = "+SourceSystemCode+", MaterialGroupDescription = "+MaterialGroupDescription+", MaterialGroupLongDescription = "+MaterialGroupLongDescription+"]";
    }
}