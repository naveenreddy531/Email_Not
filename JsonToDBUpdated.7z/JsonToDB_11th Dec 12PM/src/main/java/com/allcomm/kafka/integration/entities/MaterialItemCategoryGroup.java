package com.allcomm.kafka.integration.entities;
public class MaterialItemCategoryGroup
{
    private String SourceSystemCode;

    private String MaterialItemCategoryGroupDescription;

    private String MaterialItemCategoryGroupCode;

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getMaterialItemCategoryGroupDescription ()
    {
        return MaterialItemCategoryGroupDescription;
    }

    public void setMaterialItemCategoryGroupDescription (String MaterialItemCategoryGroupDescription)
    {
        this.MaterialItemCategoryGroupDescription = MaterialItemCategoryGroupDescription;
    }

    public String getMaterialItemCategoryGroupCode ()
    {
        return MaterialItemCategoryGroupCode;
    }

    public void setMaterialItemCategoryGroupCode (String MaterialItemCategoryGroupCode)
    {
        this.MaterialItemCategoryGroupCode = MaterialItemCategoryGroupCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [SourceSystemCode = "+SourceSystemCode+", MaterialItemCategoryGroupDescription = "+MaterialItemCategoryGroupDescription+", MaterialItemCategoryGroupCode = "+MaterialItemCategoryGroupCode+"]";
    }
}