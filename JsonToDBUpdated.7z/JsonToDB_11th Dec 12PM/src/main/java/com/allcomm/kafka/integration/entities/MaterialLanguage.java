package com.allcomm.kafka.integration.entities;

public class MaterialLanguage {
	private String MaterialDescription;

	private String ISOLanguageCode;

	private String MaterialIdentifier;

	private String SourceSystemCode;

	public String getMaterialDescription() {
		return MaterialDescription;
	}

	public void setMaterialDescription(String MaterialDescription) {
		this.MaterialDescription = MaterialDescription;
	}

	public String getISOLanguageCode() {
		return ISOLanguageCode;
	}

	public void setISOLanguageCode(String ISOLanguageCode) {
		this.ISOLanguageCode = ISOLanguageCode;
	}

	public String getMaterialIdentifier() {
		return MaterialIdentifier;
	}

	public void setMaterialIdentifier(String MaterialIdentifier) {
		this.MaterialIdentifier = MaterialIdentifier;
	}

	public String getSourceSystemCode() {
		return SourceSystemCode;
	}

	public void setSourceSystemCode(String SourceSystemCode) {
		this.SourceSystemCode = SourceSystemCode;
	}

	@Override
	public String toString() {
		return "ClassPojo [MaterialDescription = " + MaterialDescription + ", ISOLanguageCode = " + ISOLanguageCode
				+ ", MaterialIdentifier = " + MaterialIdentifier + ", SourceSystemCode = " + SourceSystemCode + "]";
	}
}
