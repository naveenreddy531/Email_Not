package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pricing_MaterialLanguage")
public class MaterialLanguageEntity {
	@Id
	@Column(name = "MATERIAL_LANGUAGE_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String sourceSystemCode;
	private String materialIdentifier;
	@Column(name ="isoLanguageCode")
	private String iSOLanguageCode;
	private String materialDescription;
	private String basicDataText;
	private String internalcommentText;
	private String inspectionText;
	private Date insertTimestamp;
	private Date updateTimestamp;
	private String logicalDeleteIndicator;

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getMaterialIdentifier() {
		return materialIdentifier;
	}

	public void setMaterialIdentifier(String materialIdentifier) {
		this.materialIdentifier = materialIdentifier;
	}

	public String getiSOLanguageCode() {
		return iSOLanguageCode;
	}

	public void setiSOLanguageCode(String iSOLanguageCode) {
		this.iSOLanguageCode = iSOLanguageCode;
	}

	public String getMaterialDescription() {
		return materialDescription;
	}

	public void setMaterialDescription(String materialDescription) {
		this.materialDescription = materialDescription;
	}

	public String getBasicDataText() {
		return basicDataText;
	}

	public void setBasicDataText(String basicDataText) {
		this.basicDataText = basicDataText;
	}

	public String getInternalcommentText() {
		return internalcommentText;
	}

	public void setInternalcommentText(String internalcommentText) {
		this.internalcommentText = internalcommentText;
	}

	public String getInspectionText() {
		return inspectionText;
	}

	public void setInspectionText(String inspectionText) {
		this.inspectionText = inspectionText;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}
