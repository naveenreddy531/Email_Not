package com.allcomm.kafka.integration.entities;
public class MaterialSales
{
    private MaterialTaxCondition MaterialTaxCondition;

    private MaterialItemCategoryGroup MaterialItemCategoryGroup;

    private String MaterialIdentifier;

    private MaterialTaxSalesOrganization MaterialTaxSalesOrganization;

    private SalesOrganization SalesOrganization;

    private String SalesOrganizationCode;

    private String DistributionChannelCode;

    private String PlantCode;

    private String AccountAssignmentGroupCode;

    private DistributionChannel DistributionChannel;

    private String SourceSystemCode;

    private MaterialAccountAssignmentGroup MaterialAccountAssignmentGroup;

    private String MaterialItemCategoryGroupCode;

    private MaterialDistributionStatus MaterialDistributionStatus;

    public MaterialTaxCondition getMaterialTaxCondition ()
    {
        return MaterialTaxCondition;
    }

    public void setMaterialTaxCondition (MaterialTaxCondition MaterialTaxCondition)
    {
        this.MaterialTaxCondition = MaterialTaxCondition;
    }

    public MaterialItemCategoryGroup getMaterialItemCategoryGroup ()
    {
        return MaterialItemCategoryGroup;
    }

    public void setMaterialItemCategoryGroup (MaterialItemCategoryGroup MaterialItemCategoryGroup)
    {
        this.MaterialItemCategoryGroup = MaterialItemCategoryGroup;
    }

    public String getMaterialIdentifier ()
    {
        return MaterialIdentifier;
    }

    public void setMaterialIdentifier (String MaterialIdentifier)
    {
        this.MaterialIdentifier = MaterialIdentifier;
    }

    public MaterialTaxSalesOrganization getMaterialTaxSalesOrganization ()
    {
        return MaterialTaxSalesOrganization;
    }

    public void setMaterialTaxSalesOrganization (MaterialTaxSalesOrganization MaterialTaxSalesOrganization)
    {
        this.MaterialTaxSalesOrganization = MaterialTaxSalesOrganization;
    }

    public SalesOrganization getSalesOrganization ()
    {
        return SalesOrganization;
    }

    public void setSalesOrganization (SalesOrganization SalesOrganization)
    {
        this.SalesOrganization = SalesOrganization;
    }

    public String getSalesOrganizationCode ()
    {
        return SalesOrganizationCode;
    }

    public void setSalesOrganizationCode (String SalesOrganizationCode)
    {
        this.SalesOrganizationCode = SalesOrganizationCode;
    }

    public String getDistributionChannelCode ()
    {
        return DistributionChannelCode;
    }

    public void setDistributionChannelCode (String DistributionChannelCode)
    {
        this.DistributionChannelCode = DistributionChannelCode;
    }

    public String getPlantCode ()
    {
        return PlantCode;
    }

    public void setPlantCode (String PlantCode)
    {
        this.PlantCode = PlantCode;
    }

    public String getAccountAssignmentGroupCode ()
    {
        return AccountAssignmentGroupCode;
    }

    public void setAccountAssignmentGroupCode (String AccountAssignmentGroupCode)
    {
        this.AccountAssignmentGroupCode = AccountAssignmentGroupCode;
    }

    public DistributionChannel getDistributionChannel ()
    {
        return DistributionChannel;
    }

    public void setDistributionChannel (DistributionChannel DistributionChannel)
    {
        this.DistributionChannel = DistributionChannel;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public MaterialAccountAssignmentGroup getMaterialAccountAssignmentGroup ()
    {
        return MaterialAccountAssignmentGroup;
    }

    public void setMaterialAccountAssignmentGroup (MaterialAccountAssignmentGroup MaterialAccountAssignmentGroup)
    {
        this.MaterialAccountAssignmentGroup = MaterialAccountAssignmentGroup;
    }

    public String getMaterialItemCategoryGroupCode ()
    {
        return MaterialItemCategoryGroupCode;
    }

    public void setMaterialItemCategoryGroupCode (String MaterialItemCategoryGroupCode)
    {
        this.MaterialItemCategoryGroupCode = MaterialItemCategoryGroupCode;
    }

    public MaterialDistributionStatus getMaterialDistributionStatus ()
    {
        return MaterialDistributionStatus;
    }

    public void setMaterialDistributionStatus (MaterialDistributionStatus MaterialDistributionStatus)
    {
        this.MaterialDistributionStatus = MaterialDistributionStatus;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [MaterialTaxCondition = "+MaterialTaxCondition+", MaterialItemCategoryGroup = "+MaterialItemCategoryGroup+", MaterialIdentifier = "+MaterialIdentifier+", MaterialTaxSalesOrganization = "+MaterialTaxSalesOrganization+", SalesOrganization = "+SalesOrganization+", SalesOrganizationCode = "+SalesOrganizationCode+", DistributionChannelCode = "+DistributionChannelCode+", PlantCode = "+PlantCode+", AccountAssignmentGroupCode = "+AccountAssignmentGroupCode+", DistributionChannel = "+DistributionChannel+", SourceSystemCode = "+SourceSystemCode+", MaterialAccountAssignmentGroup = "+MaterialAccountAssignmentGroup+", MaterialItemCategoryGroupCode = "+MaterialItemCategoryGroupCode+", MaterialDistributionStatus = "+MaterialDistributionStatus+"]";
    }
}