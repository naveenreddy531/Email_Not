package com.allcomm.kafka.integration.entities;
public class MaterialTax
{
    private MaterialTaxPurchasing MaterialTaxPurchasing;

    private String MaterialIdentifier;

    private String DestinationCountryCode;

    private String SourceSystemCode;

    private String MaterialTaxClassification1Code;

    public MaterialTaxPurchasing getMaterialTaxPurchasing ()
    {
        return MaterialTaxPurchasing;
    }

    public void setMaterialTaxPurchasing (MaterialTaxPurchasing MaterialTaxPurchasing)
    {
        this.MaterialTaxPurchasing = MaterialTaxPurchasing;
    }

    public String getMaterialIdentifier ()
    {
        return MaterialIdentifier;
    }

    public void setMaterialIdentifier (String MaterialIdentifier)
    {
        this.MaterialIdentifier = MaterialIdentifier;
    }

    public String getDestinationCountryCode ()
    {
        return DestinationCountryCode;
    }

    public void setDestinationCountryCode (String DestinationCountryCode)
    {
        this.DestinationCountryCode = DestinationCountryCode;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getMaterialTaxClassification1Code ()
    {
        return MaterialTaxClassification1Code;
    }

    public void setMaterialTaxClassification1Code (String MaterialTaxClassification1Code)
    {
        this.MaterialTaxClassification1Code = MaterialTaxClassification1Code;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [MaterialTaxPurchasing = "+MaterialTaxPurchasing+", MaterialIdentifier = "+MaterialIdentifier+", DestinationCountryCode = "+DestinationCountryCode+", SourceSystemCode = "+SourceSystemCode+", MaterialTaxClassification1Code = "+MaterialTaxClassification1Code+"]";
    }
}