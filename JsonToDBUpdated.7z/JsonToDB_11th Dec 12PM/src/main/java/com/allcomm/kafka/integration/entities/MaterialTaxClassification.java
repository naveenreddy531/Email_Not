package com.allcomm.kafka.integration.entities;
public class MaterialTaxClassification
{
    private String MaterialTaxClassificationDescription;

    private String SourceSystemCode;

    private String MaterialTaxClassificationCode;

    private String MaterialTaxCategoryCode;

    public String getMaterialTaxClassificationDescription ()
    {
        return MaterialTaxClassificationDescription;
    }

    public void setMaterialTaxClassificationDescription (String MaterialTaxClassificationDescription)
    {
        this.MaterialTaxClassificationDescription = MaterialTaxClassificationDescription;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getMaterialTaxClassificationCode ()
    {
        return MaterialTaxClassificationCode;
    }

    public void setMaterialTaxClassificationCode (String MaterialTaxClassificationCode)
    {
        this.MaterialTaxClassificationCode = MaterialTaxClassificationCode;
    }

    public String getMaterialTaxCategoryCode ()
    {
        return MaterialTaxCategoryCode;
    }

    public void setMaterialTaxCategoryCode (String MaterialTaxCategoryCode)
    {
        this.MaterialTaxCategoryCode = MaterialTaxCategoryCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [MaterialTaxClassificationDescription = "+MaterialTaxClassificationDescription+", SourceSystemCode = "+SourceSystemCode+", MaterialTaxClassificationCode = "+MaterialTaxClassificationCode+", MaterialTaxCategoryCode = "+MaterialTaxCategoryCode+"]";
    }
}