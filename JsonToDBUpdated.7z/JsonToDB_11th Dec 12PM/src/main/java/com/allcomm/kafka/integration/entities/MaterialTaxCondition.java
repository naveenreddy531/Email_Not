package com.allcomm.kafka.integration.entities;
public class MaterialTaxCondition
{
    private String SourceSystemCode;

    private String MaterialTaxConditionTypeCode;

    private String MaterialTaxConditionUsageCode;

    private String MaterialTaxConditionName;

    private String MaterialTaxConditionApplicationCode;

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getMaterialTaxConditionTypeCode ()
    {
        return MaterialTaxConditionTypeCode;
    }

    public void setMaterialTaxConditionTypeCode (String MaterialTaxConditionTypeCode)
    {
        this.MaterialTaxConditionTypeCode = MaterialTaxConditionTypeCode;
    }

    public String getMaterialTaxConditionUsageCode ()
    {
        return MaterialTaxConditionUsageCode;
    }

    public void setMaterialTaxConditionUsageCode (String MaterialTaxConditionUsageCode)
    {
        this.MaterialTaxConditionUsageCode = MaterialTaxConditionUsageCode;
    }

    public String getMaterialTaxConditionName ()
    {
        return MaterialTaxConditionName;
    }

    public void setMaterialTaxConditionName (String MaterialTaxConditionName)
    {
        this.MaterialTaxConditionName = MaterialTaxConditionName;
    }

    public String getMaterialTaxConditionApplicationCode ()
    {
        return MaterialTaxConditionApplicationCode;
    }

    public void setMaterialTaxConditionApplicationCode (String MaterialTaxConditionApplicationCode)
    {
        this.MaterialTaxConditionApplicationCode = MaterialTaxConditionApplicationCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [SourceSystemCode = "+SourceSystemCode+", MaterialTaxConditionTypeCode = "+MaterialTaxConditionTypeCode+", MaterialTaxConditionUsageCode = "+MaterialTaxConditionUsageCode+", MaterialTaxConditionName = "+MaterialTaxConditionName+", MaterialTaxConditionApplicationCode = "+MaterialTaxConditionApplicationCode+"]";
    }
}