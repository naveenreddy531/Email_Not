package com.allcomm.kafka.integration.entities;
public class MaterialTaxPurchasing
{
    private String DestinationCountryCode;

    private String SourceSystemCode;

    public String getDestinationCountryCode ()
    {
        return DestinationCountryCode;
    }

    public void setDestinationCountryCode (String DestinationCountryCode)
    {
        this.DestinationCountryCode = DestinationCountryCode;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [DestinationCountryCode = "+DestinationCountryCode+", SourceSystemCode = "+SourceSystemCode+"]";
    }
}