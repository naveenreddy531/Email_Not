package com.allcomm.kafka.integration.entities;
public class MaterialTaxSalesOrganization
{
    private MaterialTaxClassification MaterialTaxClassification;

    private String MaterialIdentifier;

    private String SalesOrganizationCode;

    private String DistributionChannelCode;

    private String SourceSystemCode;

    private String DepartureCountryCode;

    private String MaterialTaxClassificationCode;

    private String MaterialTaxCategoryCode;

    public MaterialTaxClassification getMaterialTaxClassification ()
    {
        return MaterialTaxClassification;
    }

    public void setMaterialTaxClassification (MaterialTaxClassification MaterialTaxClassification)
    {
        this.MaterialTaxClassification = MaterialTaxClassification;
    }

    public String getMaterialIdentifier ()
    {
        return MaterialIdentifier;
    }

    public void setMaterialIdentifier (String MaterialIdentifier)
    {
        this.MaterialIdentifier = MaterialIdentifier;
    }

    public String getSalesOrganizationCode ()
    {
        return SalesOrganizationCode;
    }

    public void setSalesOrganizationCode (String SalesOrganizationCode)
    {
        this.SalesOrganizationCode = SalesOrganizationCode;
    }

    public String getDistributionChannelCode ()
    {
        return DistributionChannelCode;
    }

    public void setDistributionChannelCode (String DistributionChannelCode)
    {
        this.DistributionChannelCode = DistributionChannelCode;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getDepartureCountryCode ()
    {
        return DepartureCountryCode;
    }

    public void setDepartureCountryCode (String DepartureCountryCode)
    {
        this.DepartureCountryCode = DepartureCountryCode;
    }

    public String getMaterialTaxClassificationCode ()
    {
        return MaterialTaxClassificationCode;
    }

    public void setMaterialTaxClassificationCode (String MaterialTaxClassificationCode)
    {
        this.MaterialTaxClassificationCode = MaterialTaxClassificationCode;
    }

    public String getMaterialTaxCategoryCode ()
    {
        return MaterialTaxCategoryCode;
    }

    public void setMaterialTaxCategoryCode (String MaterialTaxCategoryCode)
    {
        this.MaterialTaxCategoryCode = MaterialTaxCategoryCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [MaterialTaxClassification = "+MaterialTaxClassification+", MaterialIdentifier = "+MaterialIdentifier+", SalesOrganizationCode = "+SalesOrganizationCode+", DistributionChannelCode = "+DistributionChannelCode+", SourceSystemCode = "+SourceSystemCode+", DepartureCountryCode = "+DepartureCountryCode+", MaterialTaxClassificationCode = "+MaterialTaxClassificationCode+", MaterialTaxCategoryCode = "+MaterialTaxCategoryCode+"]";
    }
}