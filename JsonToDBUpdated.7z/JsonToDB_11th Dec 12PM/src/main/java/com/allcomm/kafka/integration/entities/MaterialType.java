package com.allcomm.kafka.integration.entities;
public class MaterialType
{
    private String MaterialTypeDescription;

    private String SourceSystemCode;

    private String MaterialTypeCode;

    public String getMaterialTypeDescription ()
    {
        return MaterialTypeDescription;
    }

    public void setMaterialTypeDescription (String MaterialTypeDescription)
    {
        this.MaterialTypeDescription = MaterialTypeDescription;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getMaterialTypeCode ()
    {
        return MaterialTypeCode;
    }

    public void setMaterialTypeCode (String MaterialTypeCode)
    {
        this.MaterialTypeCode = MaterialTypeCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [MaterialTypeDescription = "+MaterialTypeDescription+", SourceSystemCode = "+SourceSystemCode+", MaterialTypeCode = "+MaterialTypeCode+"]";
    }
}
