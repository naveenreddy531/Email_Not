package com.allcomm.kafka.integration.entities;
public class MaterialUnitOfMeasure
{
    private String DonominatorConversionNumber;

    private InternationalArticleCategory InternationalArticleCategory;

    private String NumeratorConversionNumber;

    private String MaterialIdentifier;

    private String UnitOfMeasureCode;

    private UnitOfMeasure[] UnitOfMeasure;

    private String SourceSystemCode;

    private String WeightUnitofMeasureCode;

    private String GrossWeight;

    public String getDonominatorConversionNumber ()
    {
        return DonominatorConversionNumber;
    }

    public void setDonominatorConversionNumber (String DonominatorConversionNumber)
    {
        this.DonominatorConversionNumber = DonominatorConversionNumber;
    }

    public InternationalArticleCategory getInternationalArticleCategory ()
    {
        return InternationalArticleCategory;
    }

    public void setInternationalArticleCategory (InternationalArticleCategory InternationalArticleCategory)
    {
        this.InternationalArticleCategory = InternationalArticleCategory;
    }

    public String getNumeratorConversionNumber ()
    {
        return NumeratorConversionNumber;
    }

    public void setNumeratorConversionNumber (String NumeratorConversionNumber)
    {
        this.NumeratorConversionNumber = NumeratorConversionNumber;
    }

    public String getMaterialIdentifier ()
    {
        return MaterialIdentifier;
    }

    public void setMaterialIdentifier (String MaterialIdentifier)
    {
        this.MaterialIdentifier = MaterialIdentifier;
    }

    public String getUnitOfMeasureCode ()
    {
        return UnitOfMeasureCode;
    }

    public void setUnitOfMeasureCode (String UnitOfMeasureCode)
    {
        this.UnitOfMeasureCode = UnitOfMeasureCode;
    }

    public UnitOfMeasure[] getUnitOfMeasure ()
    {
        return UnitOfMeasure;
    }

    public void setUnitOfMeasure (UnitOfMeasure[] UnitOfMeasure)
    {
        this.UnitOfMeasure = UnitOfMeasure;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getWeightUnitofMeasureCode ()
    {
        return WeightUnitofMeasureCode;
    }

    public void setWeightUnitofMeasureCode (String WeightUnitofMeasureCode)
    {
        this.WeightUnitofMeasureCode = WeightUnitofMeasureCode;
    }

    public String getGrossWeight ()
    {
        return GrossWeight;
    }

    public void setGrossWeight (String GrossWeight)
    {
        this.GrossWeight = GrossWeight;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [DonominatorConversionNumber = "+DonominatorConversionNumber+", InternationalArticleCategory = "+InternationalArticleCategory+", NumeratorConversionNumber = "+NumeratorConversionNumber+", MaterialIdentifier = "+MaterialIdentifier+", UnitOfMeasureCode = "+UnitOfMeasureCode+", UnitOfMeasure = "+UnitOfMeasure+", SourceSystemCode = "+SourceSystemCode+", WeightUnitofMeasureCode = "+WeightUnitofMeasureCode+", GrossWeight = "+GrossWeight+"]";
    }
}