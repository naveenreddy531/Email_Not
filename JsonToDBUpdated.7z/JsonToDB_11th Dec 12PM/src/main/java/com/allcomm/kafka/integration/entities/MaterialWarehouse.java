package com.allcomm.kafka.integration.entities;
public class MaterialWarehouse
{
    private String StockRemovalStorateTypeCode;

    private String WarehouseComplexCode;

    private String StockPlacecementStorageTypeCode;

    private String MaterialIdentifier;

    private String SourceSystemCode;

    private MaterialWarehouseStorage[] MaterialWarehouseStorage;

    public String getStockRemovalStorateTypeCode ()
    {
        return StockRemovalStorateTypeCode;
    }

    public void setStockRemovalStorateTypeCode (String StockRemovalStorateTypeCode)
    {
        this.StockRemovalStorateTypeCode = StockRemovalStorateTypeCode;
    }

    public String getWarehouseComplexCode ()
    {
        return WarehouseComplexCode;
    }

    public void setWarehouseComplexCode (String WarehouseComplexCode)
    {
        this.WarehouseComplexCode = WarehouseComplexCode;
    }

    public String getStockPlacecementStorageTypeCode ()
    {
        return StockPlacecementStorageTypeCode;
    }

    public void setStockPlacecementStorageTypeCode (String StockPlacecementStorageTypeCode)
    {
        this.StockPlacecementStorageTypeCode = StockPlacecementStorageTypeCode;
    }

    public String getMaterialIdentifier ()
    {
        return MaterialIdentifier;
    }

    public void setMaterialIdentifier (String MaterialIdentifier)
    {
        this.MaterialIdentifier = MaterialIdentifier;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public MaterialWarehouseStorage[] getMaterialWarehouseStorage ()
    {
        return MaterialWarehouseStorage;
    }

    public void setMaterialWarehouseStorage (MaterialWarehouseStorage[] MaterialWarehouseStorage)
    {
        this.MaterialWarehouseStorage = MaterialWarehouseStorage;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [StockRemovalStorateTypeCode = "+StockRemovalStorateTypeCode+", WarehouseComplexCode = "+WarehouseComplexCode+", StockPlacecementStorageTypeCode = "+StockPlacecementStorageTypeCode+", MaterialIdentifier = "+MaterialIdentifier+", SourceSystemCode = "+SourceSystemCode+", MaterialWarehouseStorage = "+MaterialWarehouseStorage+"]";
    }
}