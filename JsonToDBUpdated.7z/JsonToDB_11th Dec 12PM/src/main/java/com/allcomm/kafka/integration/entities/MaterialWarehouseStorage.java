package com.allcomm.kafka.integration.entities;
public class MaterialWarehouseStorage
{
    private String MaterialIdentifier;

    private String SourceSystemCode;

    private String WarehouseTypeCode;

    public String getMaterialIdentifier ()
    {
        return MaterialIdentifier;
    }

    public void setMaterialIdentifier (String MaterialIdentifier)
    {
        this.MaterialIdentifier = MaterialIdentifier;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getWarehouseTypeCode ()
    {
        return WarehouseTypeCode;
    }

    public void setWarehouseTypeCode (String WarehouseTypeCode)
    {
        this.WarehouseTypeCode = WarehouseTypeCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [MaterialIdentifier = "+MaterialIdentifier+", SourceSystemCode = "+SourceSystemCode+", WarehouseTypeCode = "+WarehouseTypeCode+"]";
    }
}
