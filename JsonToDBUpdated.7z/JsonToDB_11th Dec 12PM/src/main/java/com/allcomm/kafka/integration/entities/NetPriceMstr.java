package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_PRICE_COMMS_NET_PRICE_MSTR")
public class NetPriceMstr {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String PANum;
	private String ordereableProduct;
	private String countryCode;
	private long QBF;
	private long QBT;
	private String UOM;
	private String priceGeo;
	private String currency;
	private String incoterm;
	private String custPriceGroup;
	private double NP;
	private double LP;
	private double prevLP;
	private double prevNP;
	private double PP;
	private Date LPEffectiveDate;
	private Date NPEffectiveDate;
	private Date NPEndEffectiveDate;
	private Date endEffectivity;
	private Date eTransmittedDate;
	private String correction;
	private String sourceOfData;
	private String comments;
	private String offerID;
	private long dealID;
	private int PADiscPct;
	private Date PADiscStartDate;
	private Date PADiscEndDate;
	private String exhibitNumber;
	private String priceSource;
	private String QBFlag;
	private String PL;
	private String PriceChangeCode;
	private Date PriceChangeDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPANum() {
		return PANum;
	}

	public void setPANum(String pANum) {
		PANum = pANum;
	}

	public String getOrdereableProduct() {
		return ordereableProduct;
	}

	public void setOrdereableProduct(String ordereableProduct) {
		this.ordereableProduct = ordereableProduct;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public long getQBF() {
		return QBF;
	}

	public void setQBF(long qBF) {
		QBF = qBF;
	}

	public long getQBT() {
		return QBT;
	}

	public void setQBT(long qBT) {
		QBT = qBT;
	}

	public String getUOM() {
		return UOM;
	}

	public void setUOM(String uOM) {
		UOM = uOM;
	}

	public String getPriceGeo() {
		return priceGeo;
	}

	public void setPriceGeo(String priceGeo) {
		this.priceGeo = priceGeo;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getIncoterm() {
		return incoterm;
	}

	public void setIncoterm(String incoterm) {
		this.incoterm = incoterm;
	}

	public String getCustPriceGroup() {
		return custPriceGroup;
	}

	public void setCustPriceGroup(String custPriceGroup) {
		this.custPriceGroup = custPriceGroup;
	}

	public double getNP() {
		return NP;
	}

	public void setNP(double nP) {
		NP = nP;
	}

	public double getLP() {
		return LP;
	}

	public void setLP(double lP) {
		LP = lP;
	}

	public double getPrevLP() {
		return prevLP;
	}

	public void setPrevLP(double prevLP) {
		this.prevLP = prevLP;
	}

	public double getPrevNP() {
		return prevNP;
	}

	public void setPrevNP(double prevNP) {
		this.prevNP = prevNP;
	}

	public double getPP() {
		return PP;
	}

	public void setPP(double pP) {
		PP = pP;
	}

	public Date getLPEffectiveDate() {
		return LPEffectiveDate;
	}

	public void setLPEffectiveDate(Date lPEffectiveDate) {
		LPEffectiveDate = lPEffectiveDate;
	}

	public Date getNPEffectiveDate() {
		return NPEffectiveDate;
	}

	public void setNPEffectiveDate(Date nPEffectiveDate) {
		NPEffectiveDate = nPEffectiveDate;
	}

	public Date getNPEndEffectiveDate() {
		return NPEndEffectiveDate;
	}

	public void setNPEndEffectiveDate(Date nPEndEffectiveDate) {
		NPEndEffectiveDate = nPEndEffectiveDate;
	}

	public Date getEndEffectivity() {
		return endEffectivity;
	}

	public void setEndEffectivity(Date endEffectivity) {
		this.endEffectivity = endEffectivity;
	}

	public Date geteTransmittedDate() {
		return eTransmittedDate;
	}

	public void seteTransmittedDate(Date eTransmittedDate) {
		this.eTransmittedDate = eTransmittedDate;
	}

	public String getCorrection() {
		return correction;
	}

	public void setCorrection(String correction) {
		this.correction = correction;
	}

	public String getSourceOfData() {
		return sourceOfData;
	}

	public void setSourceOfData(String sourceOfData) {
		this.sourceOfData = sourceOfData;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getOfferID() {
		return offerID;
	}

	public void setOfferID(String offerID) {
		this.offerID = offerID;
	}

	public long getDealID() {
		return dealID;
	}

	public void setDealID(long dealID) {
		this.dealID = dealID;
	}

	public int getPADiscPct() {
		return PADiscPct;
	}

	public void setPADiscPct(int pADiscPct) {
		PADiscPct = pADiscPct;
	}

	public Date getPADiscStartDate() {
		return PADiscStartDate;
	}

	public void setPADiscStartDate(Date pADiscStartDate) {
		PADiscStartDate = pADiscStartDate;
	}

	public Date getPADiscEndDate() {
		return PADiscEndDate;
	}

	public void setPADiscEndDate(Date pADiscEndDate) {
		PADiscEndDate = pADiscEndDate;
	}

	public String getExhibitNumber() {
		return exhibitNumber;
	}

	public void setExhibitNumber(String exhibitNumber) {
		this.exhibitNumber = exhibitNumber;
	}

	public String getPriceSource() {
		return priceSource;
	}

	public void setPriceSource(String priceSource) {
		this.priceSource = priceSource;
	}

	public String getQBFlag() {
		return QBFlag;
	}

	public void setQBFlag(String qBFlag) {
		QBFlag = qBFlag;
	}

	public String getPL() {
		return PL;
	}

	public void setPL(String pL) {
		PL = pL;
	}

	public String getPriceChangeCode() {
		return PriceChangeCode;
	}

	public void setPriceChangeCode(String priceChangeCode) {
		PriceChangeCode = priceChangeCode;
	}

	public Date getPriceChangeDate() {
		return PriceChangeDate;
	}

	public void setPriceChangeDate(Date priceChangeDate) {
		PriceChangeDate = priceChangeDate;
	}

	@Override
	public String toString() {
		return "NetPriceMstr [id=" + id + ", PANum=" + PANum + ", ordereableProduct=" + ordereableProduct
				+ ", countryCode=" + countryCode + ", QBF=" + QBF + ", QBT=" + QBT + ", UOM=" + UOM + ", priceGeo="
				+ priceGeo + ", currency=" + currency + ", incoterm=" + incoterm + ", custPriceGroup=" + custPriceGroup
				+ ", NP=" + NP + ", LP=" + LP + ", prevLP=" + prevLP + ", prevNP=" + prevNP + ", PP=" + PP
				+ ", LPEffectiveDate=" + LPEffectiveDate + ", NPEffectiveDate=" + NPEffectiveDate
				+ ", NPEndEffectiveDate=" + NPEndEffectiveDate + ", endEffectivity=" + endEffectivity
				+ ", eTransmittedDate=" + eTransmittedDate + ", correction=" + correction + ", sourceOfData="
				+ sourceOfData + ", comments=" + comments + ", offerID=" + offerID + ", dealID=" + dealID
				+ ", PADiscPct=" + PADiscPct + ", PADiscStartDate=" + PADiscStartDate + ", PADiscEndDate="
				+ PADiscEndDate + ", exhibitNumber=" + exhibitNumber + ", priceSource=" + priceSource + ", QBFlag="
				+ QBFlag + ", PL=" + PL + ", PriceChangeCode=" + PriceChangeCode + ", PriceChangeDate="
				+ PriceChangeDate + "]";
	}

}
