package com.allcomm.kafka.integration.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_PRICE_COMM_DEAL_STATUS")
public class PriceCommDealStatus implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PRICE_COMM_DEAL_STATUS_ID")
	private long priceCommDealStatusId;
	
	@Column(name = "STATUS_TYPE_CD")
	private String statusTypeCd;
	
	@Column(name = "STATUS_TYPE_DESC")
	private String statusTypeDesc;
	
	@Column(name = "ACTIVE_FL")
	private String activeFL;
	
	@Column(name = "CREATION_DTS")
	private Date creationDTS;
	
	@Column(name = "UPDATE_DTS")
	private Date updateDTS;
	
	@Column(name = "LAST_CHANGE_EMP_NR")
	private long lastChangeEmpNr;

	public long getPriceCommDealStatusId() {
		return priceCommDealStatusId;
	}

	public void setPriceCommDealStatusId(long priceCommDealStatusId) {
		this.priceCommDealStatusId = priceCommDealStatusId;
	}

	public String getStatusTypeCd() {
		return statusTypeCd;
	}

	public void setStatusTypeCd(String statusTypeCd) {
		this.statusTypeCd = statusTypeCd;
	}

	public String getStatusTypeDesc() {
		return statusTypeDesc;
	}

	public void setStatusTypeDesc(String statusTypeDesc) {
		this.statusTypeDesc = statusTypeDesc;
	}

	public String getActiveFL() {
		return activeFL;
	}

	public void setActiveFL(String activeFL) {
		this.activeFL = activeFL;
	}

	public Date getCreationDTS() {
		return creationDTS;
	}

	public void setCreationDTS(Date creationDTS) {
		this.creationDTS = creationDTS;
	}

	public Date getUpdateDTS() {
		return updateDTS;
	}

	public void setUpdateDTS(Date updateDTS) {
		this.updateDTS = updateDTS;
	}

	public long getLastChangeEmpNr() {
		return lastChangeEmpNr;
	}

	public void setLastChangeEmpNr(long lastChangeEmpNr) {
		this.lastChangeEmpNr = lastChangeEmpNr;
	}

	@Override
	public String toString() {
		return "PriceCommDealStatus [priceCommDealStatusId=" + priceCommDealStatusId + ", statusTypeCd=" + statusTypeCd
				+ ", statusTypeDesc=" + statusTypeDesc + ", activeFL=" + activeFL + ", creationDTS=" + creationDTS
				+ ", updateDTS=" + updateDTS + ", lastChangeEmpNr=" + lastChangeEmpNr + "]";
	}	
	
	

}
