package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_SPL_PRICE_COMM_DEAL_SUBTYPE")
public class PriceCommDealSubtype {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PRICE_COMM_DEAL_SUBTYPE_ID")
	private long id;

	@Column(name = "PROMO_TYPE_CD")
	private String promoTypeCD;

	@Column(name = "PROMO_TYPE_DESC")
	private String promoTypeDesc;

	@Column(name = "ACTIVE_FL")
	private String activeFL;

	@Column(name = "CREATION_DTS")
	private Date creationDTS;

	@Column(name = "UPDATE_DTS")
	private Date updtDTS;

	@Column(name = "LAST_CHANGE_EMP_NR")
	private long lastChangeEmpNr;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPromoTypeCD() {
		return promoTypeCD;
	}

	public void setPromoTypeCD(String promoTypeCD) {
		this.promoTypeCD = promoTypeCD;
	}

	public String getPromoTypeDesc() {
		return promoTypeDesc;
	}

	public void setPromoTypeDesc(String promoTypeDesc) {
		this.promoTypeDesc = promoTypeDesc;
	}

	public String getActiveFL() {
		return activeFL;
	}

	public void setActiveFL(String activeFL) {
		this.activeFL = activeFL;
	}

	public Date getCreationDTS() {
		return creationDTS;
	}

	public void setCreationDTS(Date creationDTS) {
		this.creationDTS = creationDTS;
	}

	public Date getUpdtDTS() {
		return updtDTS;
	}

	public void setUpdtDTS(Date updtDTS) {
		this.updtDTS = updtDTS;
	}

	public long getLastChangeEmpNr() {
		return lastChangeEmpNr;
	}

	public void setLastChangeEmpNr(long lastChangeEmpNr) {
		this.lastChangeEmpNr = lastChangeEmpNr;
	}

}
