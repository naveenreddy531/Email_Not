package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "PRICING_SPL_PRICE_COMM_DEAL_TYPE")
public class PriceCommDealType {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PRICE_COMM_DEAL_TYPE_ID")
	private long priceCommDealTypeId;

	@Column(name = "DEAL_TYPE_CD")
	private long dealTypeCD;

	@Column(name = "DEAL_TYPE_DESC")
	private String dealTypeDesc;

	@Column(name = "BUS_JUSTIFY_RQD")
	private String busJustifyRQD;

	@Column(name = "ACTIVE_FL")
	private String activeFL;

	@Column(name = "CREATION_DTS")
	private Date creationDTS;

	@Column(name = "UPDate_DTS")
	private Date updtDTS;

	@Column(name = "LAST_CHANGE_EMP_NR")
	private long lastChangeEmpNr;

	@Column(name = "RISK_ASSESS_REQD_FL")
	private String riskAcessessReqdFL;

	@Column(name = "ALLOW_BD_LINE_TYPE_FL")
	private String allowBdLineTypeFL;

	public long getPriceCommDealTypeId() {
		return priceCommDealTypeId;
	}

	public void setPriceCommDealTypeId(long priceCommDealTypeId) {
		this.priceCommDealTypeId = priceCommDealTypeId;
	}

	public long getDealTypeCD() {
		return dealTypeCD;
	}

	public void setDealTypeCD(long dealTypeCD) {
		this.dealTypeCD = dealTypeCD;
	}

	public String getDealTypeDesc() {
		return dealTypeDesc;
	}

	public void setDealTypeDesc(String dealTypeDesc) {
		this.dealTypeDesc = dealTypeDesc;
	}

	public String getBusJustifyRQD() {
		return busJustifyRQD;
	}

	public void setBusJustifyRQD(String busJustifyRQD) {
		this.busJustifyRQD = busJustifyRQD;
	}

	public String getActiveFL() {
		return activeFL;
	}

	public void setActiveFL(String activeFL) {
		this.activeFL = activeFL;
	}

	public Date getCreationDTS() {
		return creationDTS;
	}

	public void setCreationDTS(Date creationDTS) {
		this.creationDTS = creationDTS;
	}

	public Date getUpdtDTS() {
		return updtDTS;
	}

	public void setUpdtDTS(Date updtDTS) {
		this.updtDTS = updtDTS;
	}

	public long getLastChangeEmpNr() {
		return lastChangeEmpNr;
	}

	public void setLastChangeEmpNr(long lastChangeEmpNr) {
		this.lastChangeEmpNr = lastChangeEmpNr;
	}

	public String getRiskAcessessReqdFL() {
		return riskAcessessReqdFL;
	}

	public void setRiskAcessessReqdFL(String riskAcessessReqdFL) {
		this.riskAcessessReqdFL = riskAcessessReqdFL;
	}

	public String getAllowBdLineTypeFL() {
		return allowBdLineTypeFL;
	}

	public void setAllowBdLineTypeFL(String allowBdLineTypeFL) {
		this.allowBdLineTypeFL = allowBdLineTypeFL;
	}

}
