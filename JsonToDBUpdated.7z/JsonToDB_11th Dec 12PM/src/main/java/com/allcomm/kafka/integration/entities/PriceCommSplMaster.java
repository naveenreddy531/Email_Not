package com.allcomm.kafka.integration.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_PRICE_COMMS_SPL_MASTER")
public class PriceCommSplMaster implements Serializable {
	private static final long serialVersionUID = 1577930854565076037L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SPEC_B2B_MASTER_ID")
	private long specB2BMasterId;
		
	@Column(name = "COMPANYNAME")
	private String companyName;
	
	@Column(name = "REGION_CODE")
	private String regionCode;
	
	@Column(name = "COUNTRY_CODE")
	private String countryCode;
	
	@Column(name = "PARTYID")
	private String partyId;
	
	@Column(name = "PARTNERPROID")
	private String partnerProdId;
	
	@Column(name = "FREQUENCY")
	private String frequency;
	
	@Column(name = "CONTENTTYPE")
	private String contentType;
	
	@Column(name = "FILEFORMAT")
	private String fileFormat;
	
	@Column(name = "PUSHMECHANISM")
	private String pushMechanism;
	
	@Column(name = "RECEIVERID")
	private String receiverId;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "EMAILADDRESS")
	private String emailAddress;
	
	@Column(name = "DEALID")
	private String dealId;
	
	@Column(name = "CREATEDDATE")
	private Date createDate;
	
	@Column(name = "UPDATEDDATE")
	private Date updatedDate;
	
	@Column(name = "LAUNCHTIME")
	private String launchTime;
	
	@Column(name = "DATERANGE")
	private String DateRange;
	
	@Column(name = "CURRENCY_")
	private String currency;
	
	@Column(name = "PRICETERM")
	private String priceTerm;
	
	@Column(name = "HOSTNAME")
	private String hostName;
	
	@Column(name = "USERNAME")
	private String userName;
	
	@Column(name = "USERPASS")
	private String userPass;
	
	@Column(name = "HOST_DIR")
	private String hostDir;
	
	@Column(name = "EMAILFAILED")
	private String emailFailed;
	
	@Column(name = "EMAILALT")
	private String emailAlt;
	
	@Column(name = "CREATEDBY")
	private String createdBy;
	
	@Column(name = "UPDATEDBY")
	private String updatedBy;
	
	@Column(name = "LAST_SUCCESS_DT")
	private Date lastSuccessDate;
	
	@Column(name = "LAST_FAILURE_DT")
	private Date lastFailureDate;
	
	@Column(name = "NUM_FAILURES")
	private long numFailures;
	
	@Column(name = "SINGLE_FILE_DEAL_FLAG")
	private String singleFileDealFlag;
	
	@Column(name = "SEND_ZIP_FILE_FLAG")
	private String sendZipFileFlag;
	
	@Column(name = "ONE_TIME_FILE_FLAG")
	private String oneTimeFileFlag;
	
	@Column(name = "FULL_FILE_SUCCESS_DT")
	private String fullFileSuccessDate;
	
	@Column(name = "STDOUT_VERSION_NR")
	private long stdoutVersionNR;
	
	@Column(name = "LOCALE_CD")
	private String localeCD;
	
	@Column(name = "USE_SSH_KEY_FLAG")
	private String useSshKeyFlag;
	
	@Column(name = "TRANSFER_TYPE")
	private String transferType;
	
	@Column(name = "GATEWAY_ID")
	private String gatewayId;
	
	@Column(name = "CONTACT_NAME")
	private String contactName;
	
	@Column(name = "CONTACT_PHONE")
	private String contactPhone;
	
	@Column(name = "MISC")
	private String misc;
	
	@Column(name = "EDI_RECIEVER_ID")
	private String ediReceiverId;
	
	@Column(name = "SPLITR_FLAG")
	private String splitrFlag;

	public long getSpecB2BMasterId() {
		return specB2BMasterId;
	}

	public void setSpecB2BMasterId(long specB2BMasterId) {
		this.specB2BMasterId = specB2BMasterId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getPartnerProdId() {
		return partnerProdId;
	}

	public void setPartnerProdId(String partnerProdId) {
		this.partnerProdId = partnerProdId;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public String getPushMechanism() {
		return pushMechanism;
	}

	public void setPushMechanism(String pushMechanism) {
		this.pushMechanism = pushMechanism;
	}

	public String getReceiverId() {
		return receiverId;
	}

	public void setReceiverId(String receiverId) {
		this.receiverId = receiverId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getLaunchTime() {
		return launchTime;
	}

	public void setLaunchTime(String launchTime) {
		this.launchTime = launchTime;
	}

	public String getDateRange() {
		return DateRange;
	}

	public void setDateRange(String dateRange) {
		DateRange = dateRange;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getPriceTerm() {
		return priceTerm;
	}

	public void setPriceTerm(String priceTerm) {
		this.priceTerm = priceTerm;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	public String getHostDir() {
		return hostDir;
	}

	public void setHostDir(String hostDir) {
		this.hostDir = hostDir;
	}

	public String getEmailFailed() {
		return emailFailed;
	}

	public void setEmailFailed(String emailFailed) {
		this.emailFailed = emailFailed;
	}

	public String getEmailAlt() {
		return emailAlt;
	}

	public void setEmailAlt(String emailAlt) {
		this.emailAlt = emailAlt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getLastSuccessDate() {
		return lastSuccessDate;
	}

	public void setLastSuccessDate(Date lastSuccessDate) {
		this.lastSuccessDate = lastSuccessDate;
	}

	public Date getLastFailureDate() {
		return lastFailureDate;
	}

	public void setLastFailureDate(Date lastFailureDate) {
		this.lastFailureDate = lastFailureDate;
	}

	public long getNumFailures() {
		return numFailures;
	}

	public void setNumFailures(long numFailures) {
		this.numFailures = numFailures;
	}

	public String getSingleFileDealFlag() {
		return singleFileDealFlag;
	}

	public void setSingleFileDealFlag(String singleFileDealFlag) {
		this.singleFileDealFlag = singleFileDealFlag;
	}

	public String getSendZipFileFlag() {
		return sendZipFileFlag;
	}

	public void setSendZipFileFlag(String sendZipFileFlag) {
		this.sendZipFileFlag = sendZipFileFlag;
	}

	public String getOneTimeFileFlag() {
		return oneTimeFileFlag;
	}

	public void setOneTimeFileFlag(String oneTimeFileFlag) {
		this.oneTimeFileFlag = oneTimeFileFlag;
	}

	public String getFullFileSuccessDate() {
		return fullFileSuccessDate;
	}

	public void setFullFileSuccessDate(String fullFileSuccessDate) {
		this.fullFileSuccessDate = fullFileSuccessDate;
	}

	public long getStdoutVersionNR() {
		return stdoutVersionNR;
	}

	public void setStdoutVersionNR(long stdoutVersionNR) {
		this.stdoutVersionNR = stdoutVersionNR;
	}

	public String getLocaleCD() {
		return localeCD;
	}

	public void setLocaleCD(String localeCD) {
		this.localeCD = localeCD;
	}

	public String getUseSshKeyFlag() {
		return useSshKeyFlag;
	}

	public void setUseSshKeyFlag(String useSshKeyFlag) {
		this.useSshKeyFlag = useSshKeyFlag;
	}

	public String getTransferType() {
		return transferType;
	}

	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	public String getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getMisc() {
		return misc;
	}

	public void setMisc(String misc) {
		this.misc = misc;
	}

	public String getEdiReceiverId() {
		return ediReceiverId;
	}

	public void setEdiReceiverId(String ediReceiverId) {
		this.ediReceiverId = ediReceiverId;
	}

	public String getSplitrFlag() {
		return splitrFlag;
	}

	public void setSplitrFlag(String splitrFlag) {
		this.splitrFlag = splitrFlag;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "PriceCommSplMaster [specB2BMasterId=" + specB2BMasterId + ", companyName=" + companyName
				+ ", regionCode=" + regionCode + ", countryCode=" + countryCode + ", partyId=" + partyId
				+ ", partnerProdId=" + partnerProdId + ", frequency=" + frequency + ", contentType=" + contentType
				+ ", fileFormat=" + fileFormat + ", pushMechanism=" + pushMechanism + ", receiverId=" + receiverId
				+ ", status=" + status + ", emailAddress=" + emailAddress + ", dealId=" + dealId + ", createDate="
				+ createDate + ", updatedDate=" + updatedDate + ", launchTime=" + launchTime + ", DateRange="
				+ DateRange + ", currency=" + currency + ", priceTerm=" + priceTerm + ", hostName=" + hostName
				+ ", userName=" + userName + ", userPass=" + userPass + ", hostDir=" + hostDir + ", emailFailed="
				+ emailFailed + ", emailAlt=" + emailAlt + ", createdBy=" + createdBy + ", updatedBy=" + updatedBy
				+ ", lastSuccessDate=" + lastSuccessDate + ", lastFailureDate=" + lastFailureDate + ", numFailures="
				+ numFailures + ", singleFileDealFlag=" + singleFileDealFlag + ", sendZipFileFlag=" + sendZipFileFlag
				+ ", oneTimeFileFlag=" + oneTimeFileFlag + ", fullFileSuccessDate=" + fullFileSuccessDate
				+ ", stdoutVersionNR=" + stdoutVersionNR + ", localeCD=" + localeCD + ", useSshKeyFlag=" + useSshKeyFlag
				+ ", transferType=" + transferType + ", gatewayId=" + gatewayId + ", contactName=" + contactName
				+ ", contactPhone=" + contactPhone + ", misc=" + misc + ", ediReceiverId=" + ediReceiverId
				+ ", splitrFlag=" + splitrFlag + "]";
	}

	
}
