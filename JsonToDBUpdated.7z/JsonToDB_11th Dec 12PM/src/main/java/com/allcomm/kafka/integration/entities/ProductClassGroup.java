package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_PRODUCTCLASSGROUP")
public class ProductClassGroup {
	@Id
	@Column(name = "PRODUCT_CLASSGROUP_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long productClassGroupId;
	@Column(name = "ORDERABLE_PRODUCT")
	private String materialIdentifier;
	private String sourceSystemCode;
	private String classGroupCode;
	private String classGroupDescription;
	private Date insertTimestamp;
	private Date updateTimestamp;
	private String logicalDeleteIndicator;

	public String getMaterialIdentifier() {
		return materialIdentifier;
	}

	public void setMaterialIdentifier(String materialIdentifier) {
		this.materialIdentifier = materialIdentifier;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getClassGroupCode() {
		return classGroupCode;
	}

	public void setClassGroupCode(String classGroupCode) {
		this.classGroupCode = classGroupCode;
	}

	public String getClassGroupDescription() {
		return classGroupDescription;
	}

	public void setClassGroupDescription(String classGroupDescription) {
		this.classGroupDescription = classGroupDescription;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}
