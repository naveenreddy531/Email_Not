package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pricing_ProductClassHeader")
public class ProductClassHeader {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="PRODUCT_CLASS_HEADER_ID")
	private long id;
	@Column(name = "ORDERABLE_PRODUCT")
	private String materialIdentifier;
	private String sourceSystemCode;
	private double internalClassNumber;
	private String classTypeCode;
	private String classIdentifier;
	private String classStatusCode;
	private String classGroupCode;
	private Date validStartDate;
	private Date validEndDate;
	private String organizationalAreaCode;
	private String billofMaterialUsedIndicator;
	private String taskCodeUsedIndicator;
	private String createdByUserID;
	private Date sourceSystemCreateTimestamp;
	private String updatedByUserID;
	private Date sourceSystemUpdateTimestamp;
	private Date insertTimestamp;
	private Date updateTimestamp;
	private String logicalDeleteIndicator;

	public String getMaterialIdentifier() {
		return materialIdentifier;
	}

	public void setMaterialIdentifier(String materialIdentifier) {
		this.materialIdentifier = materialIdentifier;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public double getInternalClassNumber() {
		return internalClassNumber;
	}

	public void setInternalClassNumber(double internalClassNumber) {
		this.internalClassNumber = internalClassNumber;
	}

	public String getClassTypeCode() {
		return classTypeCode;
	}

	public void setClassTypeCode(String classTypeCode) {
		this.classTypeCode = classTypeCode;
	}

	public String getClassIdentifier() {
		return classIdentifier;
	}

	public void setClassIdentifier(String classIdentifier) {
		this.classIdentifier = classIdentifier;
	}

	public String getClassStatusCode() {
		return classStatusCode;
	}

	public void setClassStatusCode(String classStatusCode) {
		this.classStatusCode = classStatusCode;
	}

	public String getClassGroupCode() {
		return classGroupCode;
	}

	public void setClassGroupCode(String classGroupCode) {
		this.classGroupCode = classGroupCode;
	}

	public Date getValidStartDate() {
		return validStartDate;
	}

	public void setValidStartDate(Date validStartDate) {
		this.validStartDate = validStartDate;
	}

	public Date getValidEndDate() {
		return validEndDate;
	}

	public void setValidEndDate(Date validEndDate) {
		this.validEndDate = validEndDate;
	}

	public String getOrganizationalAreaCode() {
		return organizationalAreaCode;
	}

	public void setOrganizationalAreaCode(String organizationalAreaCode) {
		this.organizationalAreaCode = organizationalAreaCode;
	}

	public String getBillofMaterialUsedIndicator() {
		return billofMaterialUsedIndicator;
	}

	public void setBillofMaterialUsedIndicator(String billofMaterialUsedIndicator) {
		this.billofMaterialUsedIndicator = billofMaterialUsedIndicator;
	}

	public String getTaskCodeUsedIndicator() {
		return taskCodeUsedIndicator;
	}

	public void setTaskCodeUsedIndicator(String taskCodeUsedIndicator) {
		this.taskCodeUsedIndicator = taskCodeUsedIndicator;
	}

	public String getCreatedByUserID() {
		return createdByUserID;
	}

	public void setCreatedByUserID(String createdByUserID) {
		this.createdByUserID = createdByUserID;
	}

	public Date getSourceSystemCreateTimestamp() {
		return sourceSystemCreateTimestamp;
	}

	public void setSourceSystemCreateTimestamp(Date sourceSystemCreateTimestamp) {
		this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
	}

	public String getUpdatedByUserID() {
		return updatedByUserID;
	}

	public void setUpdatedByUserID(String updatedByUserID) {
		this.updatedByUserID = updatedByUserID;
	}

	public Date getSourceSystemUpdateTimestamp() {
		return sourceSystemUpdateTimestamp;
	}

	public void setSourceSystemUpdateTimestamp(Date sourceSystemUpdateTimestamp) {
		this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}
