package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pricing_ProductClassType")
public class ProductClassType {
	@Id
	@Column(name = "PRODUCT_CLASS_TYPE_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "ORDERABLE_PRODUCT")
	private String materialIdentifier;
	private String sourceSystemCode;
	private String classTypeCode;
	private String classTypeDescription;
	private Date insertTimestamp;
	private Date updateTimestamp;
	private String logicalDeleteIndicator;

	public String getMaterialIdentifier() {
		return materialIdentifier;
	}

	public void setMaterialIdentifier(String materialIdentifier) {
		this.materialIdentifier = materialIdentifier;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getClassTypeCode() {
		return classTypeCode;
	}

	public void setClassTypeCode(String classTypeCode) {
		this.classTypeCode = classTypeCode;
	}

	public String getClassTypeDescription() {
		return classTypeDescription;
	}

	public void setClassTypeDescription(String classTypeDescription) {
		this.classTypeDescription = classTypeDescription;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}
