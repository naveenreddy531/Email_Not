package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pricing_ProductClassificationValue")
public class ProductClassificationValue {
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	@Column(name ="PRICING_PRODUCT_CLASSIFICATION_VALUE_ID")
	private long id;
	@Column(name = "ORDERABLE_PRODUCT")
	private String materialIdentifier;
	private String sourceSystemCode;
	private String objectIdentifier;
	private long internalCharacteristicCode;
	private long sequenceNumber;
	private String classTypeCode;
	private long changeManagementVersionIdentifier;
	private String objectClassCode;
	private String classStatusCode;
	private String characteristicValueText;
	private String characteristicName;
	private String engineeringChangeIdentifier;
	private Date validStartDate;
	private Date validEndDate;
	private Date insertTimestamp;
	private Date updateTimestamp;
	private Date logicalDeleteIndicator;

	public String getMaterialIdentifier() {
		return materialIdentifier;
	}

	public void setMaterialIdentifier(String materialIdentifier) {
		this.materialIdentifier = materialIdentifier;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getObjectIdentifier() {
		return objectIdentifier;
	}

	public void setObjectIdentifier(String objectIdentifier) {
		this.objectIdentifier = objectIdentifier;
	}

	public long getInternalCharacteristicCode() {
		return internalCharacteristicCode;
	}

	public void setInternalCharacteristicCode(long internalCharacteristicCode) {
		this.internalCharacteristicCode = internalCharacteristicCode;
	}

	public long getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(long sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getClassTypeCode() {
		return classTypeCode;
	}

	public void setClassTypeCode(String classTypeCode) {
		this.classTypeCode = classTypeCode;
	}

	public long getChangeManagementVersionIdentifier() {
		return changeManagementVersionIdentifier;
	}

	public void setChangeManagementVersionIdentifier(long changeManagementVersionIdentifier) {
		this.changeManagementVersionIdentifier = changeManagementVersionIdentifier;
	}

	public String getObjectClassCode() {
		return objectClassCode;
	}

	public void setObjectClassCode(String objectClassCode) {
		this.objectClassCode = objectClassCode;
	}

	public String getClassStatusCode() {
		return classStatusCode;
	}

	public void setClassStatusCode(String classStatusCode) {
		this.classStatusCode = classStatusCode;
	}

	public String getCharacteristicValueText() {
		return characteristicValueText;
	}

	public void setCharacteristicValueText(String characteristicValueText) {
		this.characteristicValueText = characteristicValueText;
	}

	public String getCharacteristicName() {
		return characteristicName;
	}

	public void setCharacteristicName(String characteristicName) {
		this.characteristicName = characteristicName;
	}

	public String getEngineeringChangeIdentifier() {
		return engineeringChangeIdentifier;
	}

	public void setEngineeringChangeIdentifier(String engineeringChangeIdentifier) {
		this.engineeringChangeIdentifier = engineeringChangeIdentifier;
	}

	public Date getValidStartDate() {
		return validStartDate;
	}

	public void setValidStartDate(Date validStartDate) {
		this.validStartDate = validStartDate;
	}

	public Date getValidEndDate() {
		return validEndDate;
	}

	public void setValidEndDate(Date validEndDate) {
		this.validEndDate = validEndDate;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public Date getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(Date logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}
