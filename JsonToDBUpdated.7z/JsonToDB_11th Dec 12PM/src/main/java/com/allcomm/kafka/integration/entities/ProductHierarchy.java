package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pricing_ProductHierarchy")
public class ProductHierarchy {
	@Id
	@Column(name = "PRODUCT_HIERARCHY_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "ORDERABLE_PRODUCT")
	private String materialIdentifier;
	private String sourceSystemCode;
	private String productHierarchyCode;
	private String productHierarchyDescription;
	private long productHierarchyLevelNumber;
	private String productTypeCode;
	private String productTypeDescription;
	private String productCategoryCode;
	private String productCategoryDescription;
	private String productSubCategoryCode;
	private String productSubCategoryDescription;
	private String productFamilyCode;
	private String productFamilyDescription;
	private String productSeriesCode;
	private String productSeriesDescription;
	private String productModelCode;
	private String productModelDescription;
	private Date insertTimestamp;
	private Date updateTimestamp;
	private String logicalDeleteIndicator;

	public String getMaterialIdentifier() {
		return materialIdentifier;
	}

	public void setMaterialIdentifier(String materialIdentifier) {
		this.materialIdentifier = materialIdentifier;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getProductHierarchyCode() {
		return productHierarchyCode;
	}

	public void setProductHierarchyCode(String productHierarchyCode) {
		this.productHierarchyCode = productHierarchyCode;
	}

	public String getProductHierarchyDescription() {
		return productHierarchyDescription;
	}

	public void setProductHierarchyDescription(String productHierarchyDescription) {
		this.productHierarchyDescription = productHierarchyDescription;
	}

	public long getProductHierarchyLevelNumber() {
		return productHierarchyLevelNumber;
	}

	public void setProductHierarchyLevelNumber(long productHierarchyLevelNumber) {
		this.productHierarchyLevelNumber = productHierarchyLevelNumber;
	}

	public String getProductTypeCode() {
		return productTypeCode;
	}

	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}

	public String getProductTypeDescription() {
		return productTypeDescription;
	}

	public void setProductTypeDescription(String productTypeDescription) {
		this.productTypeDescription = productTypeDescription;
	}

	public String getProductCategoryCode() {
		return productCategoryCode;
	}

	public void setProductCategoryCode(String productCategoryCode) {
		this.productCategoryCode = productCategoryCode;
	}

	public String getProductCategoryDescription() {
		return productCategoryDescription;
	}

	public void setProductCategoryDescription(String productCategoryDescription) {
		this.productCategoryDescription = productCategoryDescription;
	}

	public String getProductSubCategoryCode() {
		return productSubCategoryCode;
	}

	public void setProductSubCategoryCode(String productSubCategoryCode) {
		this.productSubCategoryCode = productSubCategoryCode;
	}

	public String getProductSubCategoryDescription() {
		return productSubCategoryDescription;
	}

	public void setProductSubCategoryDescription(String productSubCategoryDescription) {
		this.productSubCategoryDescription = productSubCategoryDescription;
	}

	public String getProductFamilyCode() {
		return productFamilyCode;
	}

	public void setProductFamilyCode(String productFamilyCode) {
		this.productFamilyCode = productFamilyCode;
	}

	public String getProductFamilyDescription() {
		return productFamilyDescription;
	}

	public void setProductFamilyDescription(String productFamilyDescription) {
		this.productFamilyDescription = productFamilyDescription;
	}

	public String getProductSeriesCode() {
		return productSeriesCode;
	}

	public void setProductSeriesCode(String productSeriesCode) {
		this.productSeriesCode = productSeriesCode;
	}

	public String getProductSeriesDescription() {
		return productSeriesDescription;
	}

	public void setProductSeriesDescription(String productSeriesDescription) {
		this.productSeriesDescription = productSeriesDescription;
	}

	public String getProductModelCode() {
		return productModelCode;
	}

	public void setProductModelCode(String productModelCode) {
		this.productModelCode = productModelCode;
	}

	public String getProductModelDescription() {
		return productModelDescription;
	}

	public void setProductModelDescription(String productModelDescription) {
		this.productModelDescription = productModelDescription;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}
