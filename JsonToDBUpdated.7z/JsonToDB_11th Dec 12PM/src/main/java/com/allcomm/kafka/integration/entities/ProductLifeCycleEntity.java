package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pricing_ProductLifeCycle")
public class ProductLifeCycleEntity {

	@Id
	@Column(name ="PRODUCT_LIFE_CYCLE_ENTITY_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String sourceSystemCode;
	private String productLifeCycleEventCode;
	private String materialIdentifier;
	private Date plannedDate;
	private String generalIndicator;
	private String createdByUserID;
	private String updatedByUserID;
	private Date sourceSystemCreateTimestamp;
	private Date sourceSystemUpdateTimestamp;
	private Date insertTimestamp;
	private Date updateTimestamp;
	private String logicalDeleteIndicator;

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getProductLifeCycleEventCode() {
		return productLifeCycleEventCode;
	}

	public void setProductLifeCycleEventCode(String productLifeCycleEventCode) {
		this.productLifeCycleEventCode = productLifeCycleEventCode;
	}

	public String getMaterialIdentifier() {
		return materialIdentifier;
	}

	public void setMaterialIdentifier(String materialIdentifier) {
		this.materialIdentifier = materialIdentifier;
	}

	public Date getPlannedDate() {
		return plannedDate;
	}

	public void setPlannedDate(Date plannedDate) {
		this.plannedDate = plannedDate;
	}

	public String getGeneralIndicator() {
		return generalIndicator;
	}

	public void setGeneralIndicator(String generalIndicator) {
		this.generalIndicator = generalIndicator;
	}

	public String getCreatedByUserID() {
		return createdByUserID;
	}

	public void setCreatedByUserID(String createdByUserID) {
		this.createdByUserID = createdByUserID;
	}

	public String getUpdatedByUserID() {
		return updatedByUserID;
	}

	public void setUpdatedByUserID(String updatedByUserID) {
		this.updatedByUserID = updatedByUserID;
	}

	public Date getSourceSystemCreateTimestamp() {
		return sourceSystemCreateTimestamp;
	}

	public void setSourceSystemCreateTimestamp(Date sourceSystemCreateTimestamp) {
		this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
	}

	public Date getSourceSystemUpdateTimestamp() {
		return sourceSystemUpdateTimestamp;
	}

	public void setSourceSystemUpdateTimestamp(Date sourceSystemUpdateTimestamp) {
		this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}
