package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pricing_ProductLifeCycleEvent")
public class ProductLifeCycleEventEntity {
	@Id
	@Column(name = "PRODUCT_LIFE_CYCLE_EVENT_ENTITY_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String sourceSystemCode;
	private String productLifeCycleEventCode;
	private String productLifeCycleEventDescription;
	private Date insertTimestamp;
	private Date updateTimestamp;
	private String logicalDeleteIndicator;

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getProductLifeCycleEventCode() {
		return productLifeCycleEventCode;
	}

	public void setProductLifeCycleEventCode(String productLifeCycleEventCode) {
		this.productLifeCycleEventCode = productLifeCycleEventCode;
	}

	public String getProductLifeCycleEventDescription() {
		return productLifeCycleEventDescription;
	}

	public void setProductLifeCycleEventDescription(String productLifeCycleEventDescription) {
		this.productLifeCycleEventDescription = productLifeCycleEventDescription;
	}

	public Date getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public Date getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

}
