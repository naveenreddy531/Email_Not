package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRODUCT_MSTR")
public class ProductMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String productNumber;
	private String productQtyBreak;
	private String PL;
	private String PLDescription;
	private String longDescription;
	private String shortDescription;
	private String replacementProduct;
	private String productClassID;
	private String productClassDescription;
	private String model;
	private String modelDescription;
	private String family;
	private String familyDescription;
	private String series;
	private String seriesDescription;
	private String productChangeCode;
	private Date productChangeDate;
	private String PLCStatus;
	private Date PLCEffectiveDate;
	private String UOM;
	private String UPCCode;
	private String productDimensions;
	private String dimensionsUnit;
	private String productGrossWeight;
	private String serializationFlag;
	private String volume;
	private String volumeUnit;
	private String warrantyCode;
	private String weight;
	private String weightUnit;
	private String catalogID;
	private String duration;
	private String objectofService;
	private String EANCode;
	private String ESD;
	private String publish;
	private String category;
	private String oldMaterialIdentifier;
	private String sourceSystemCode;
	private String uNSPSCExternalMaterialGroupCode;
	private String productHierarchyCode;
	private String materialStatusCode;
	private String packagingMaterialGroupCode;
	private String materialTypeCode;
	private String materialDocumentTypeCode;
	private String crossSalesMaterialStatusCode;
	private String industryStandardCode;
	private String materialDocumentNumber;
	private String configurableMaterialIndicator;
	private String manufacturerPartIdentifier;
	private String manufacturerVendorPartyIdentifier;
	private String logicalDeleteIndicator;
	private String generalMaterialItemCategoryGroupCode;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	public String getProductQtyBreak() {
		return productQtyBreak;
	}

	public void setProductQtyBreak(String productQtyBreak) {
		this.productQtyBreak = productQtyBreak;
	}

	public String getPL() {
		return PL;
	}

	public void setPL(String pL) {
		PL = pL;
	}

	public String getPLDescription() {
		return PLDescription;
	}

	public void setPLDescription(String pLDescription) {
		PLDescription = pLDescription;
	}

	public String getLongDescription() {
		return longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getReplacementProduct() {
		return replacementProduct;
	}

	public void setReplacementProduct(String replacementProduct) {
		this.replacementProduct = replacementProduct;
	}

	public String getProductClassID() {
		return productClassID;
	}

	public void setProductClassID(String productClassID) {
		this.productClassID = productClassID;
	}

	public String getProductClassDescription() {
		return productClassDescription;
	}

	public void setProductClassDescription(String productClassDescription) {
		this.productClassDescription = productClassDescription;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getModelDescription() {
		return modelDescription;
	}

	public void setModelDescription(String modelDescription) {
		this.modelDescription = modelDescription;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public String getFamilyDescription() {
		return familyDescription;
	}

	public void setFamilyDescription(String familyDescription) {
		this.familyDescription = familyDescription;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getSeriesDescription() {
		return seriesDescription;
	}

	public void setSeriesDescription(String seriesDescription) {
		this.seriesDescription = seriesDescription;
	}

	public String getProductChangeCode() {
		return productChangeCode;
	}

	public void setProductChangeCode(String productChangeCode) {
		this.productChangeCode = productChangeCode;
	}

	public Date getProductChangeDate() {
		return productChangeDate;
	}

	public void setProductChangeDate(Date productChangeDate) {
		this.productChangeDate = productChangeDate;
	}

	public String getPLCStatus() {
		return PLCStatus;
	}

	public void setPLCStatus(String pLCStatus) {
		PLCStatus = pLCStatus;
	}

	public Date getPLCEffectiveDate() {
		return PLCEffectiveDate;
	}

	public void setPLCEffectiveDate(Date pLCEffectiveDate) {
		PLCEffectiveDate = pLCEffectiveDate;
	}

	public String getUOM() {
		return UOM;
	}

	public void setUOM(String uOM) {
		UOM = uOM;
	}

	public String getUPCCode() {
		return UPCCode;
	}

	public void setUPCCode(String uPCCode) {
		UPCCode = uPCCode;
	}

	public String getProductDimensions() {
		return productDimensions;
	}

	public void setProductDimensions(String productDimensions) {
		this.productDimensions = productDimensions;
	}

	public String getDimensionsUnit() {
		return dimensionsUnit;
	}

	public void setDimensionsUnit(String dimensionsUnit) {
		this.dimensionsUnit = dimensionsUnit;
	}

	public String getProductGrossWeight() {
		return productGrossWeight;
	}

	public void setProductGrossWeight(String productGrossWeight) {
		this.productGrossWeight = productGrossWeight;
	}

	public String getSerializationFlag() {
		return serializationFlag;
	}

	public void setSerializationFlag(String serializationFlag) {
		this.serializationFlag = serializationFlag;
	}

	public String getVolume() {
		return volume;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}

	public String getVolumeUnit() {
		return volumeUnit;
	}

	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}

	public String getWarrantyCode() {
		return warrantyCode;
	}

	public void setWarrantyCode(String warrantyCode) {
		this.warrantyCode = warrantyCode;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getWeightUnit() {
		return weightUnit;
	}

	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}

	public String getCatalogID() {
		return catalogID;
	}

	public void setCatalogID(String catalogID) {
		this.catalogID = catalogID;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getObjectofService() {
		return objectofService;
	}

	public void setObjectofService(String objectofService) {
		this.objectofService = objectofService;
	}

	public String getEANCode() {
		return EANCode;
	}

	public void setEANCode(String eANCode) {
		EANCode = eANCode;
	}

	public String getESD() {
		return ESD;
	}

	public void setESD(String eSD) {
		ESD = eSD;
	}

	public String getPublish() {
		return publish;
	}

	public void setPublish(String publish) {
		this.publish = publish;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getOldMaterialIdentifier() {
		return oldMaterialIdentifier;
	}

	public void setOldMaterialIdentifier(String oldMaterialIdentifier) {
		this.oldMaterialIdentifier = oldMaterialIdentifier;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getuNSPSCExternalMaterialGroupCode() {
		return uNSPSCExternalMaterialGroupCode;
	}

	public void setuNSPSCExternalMaterialGroupCode(String uNSPSCExternalMaterialGroupCode) {
		this.uNSPSCExternalMaterialGroupCode = uNSPSCExternalMaterialGroupCode;
	}

	public String getProductHierarchyCode() {
		return productHierarchyCode;
	}

	public void setProductHierarchyCode(String productHierarchyCode) {
		this.productHierarchyCode = productHierarchyCode;
	}

	public String getMaterialStatusCode() {
		return materialStatusCode;
	}

	public void setMaterialStatusCode(String materialStatusCode) {
		this.materialStatusCode = materialStatusCode;
	}

	public String getPackagingMaterialGroupCode() {
		return packagingMaterialGroupCode;
	}

	public void setPackagingMaterialGroupCode(String packagingMaterialGroupCode) {
		this.packagingMaterialGroupCode = packagingMaterialGroupCode;
	}

	public String getMaterialTypeCode() {
		return materialTypeCode;
	}

	public void setMaterialTypeCode(String materialTypeCode) {
		this.materialTypeCode = materialTypeCode;
	}

	public String getMaterialDocumentTypeCode() {
		return materialDocumentTypeCode;
	}

	public void setMaterialDocumentTypeCode(String materialDocumentTypeCode) {
		this.materialDocumentTypeCode = materialDocumentTypeCode;
	}

	public String getCrossSalesMaterialStatusCode() {
		return crossSalesMaterialStatusCode;
	}

	public void setCrossSalesMaterialStatusCode(String crossSalesMaterialStatusCode) {
		this.crossSalesMaterialStatusCode = crossSalesMaterialStatusCode;
	}

	public String getIndustryStandardCode() {
		return industryStandardCode;
	}

	public void setIndustryStandardCode(String industryStandardCode) {
		this.industryStandardCode = industryStandardCode;
	}

	public String getMaterialDocumentNumber() {
		return materialDocumentNumber;
	}

	public void setMaterialDocumentNumber(String materialDocumentNumber) {
		this.materialDocumentNumber = materialDocumentNumber;
	}

	public String getConfigurableMaterialIndicator() {
		return configurableMaterialIndicator;
	}

	public void setConfigurableMaterialIndicator(String configurableMaterialIndicator) {
		this.configurableMaterialIndicator = configurableMaterialIndicator;
	}

	public String getManufacturerPartIdentifier() {
		return manufacturerPartIdentifier;
	}

	public void setManufacturerPartIdentifier(String manufacturerPartIdentifier) {
		this.manufacturerPartIdentifier = manufacturerPartIdentifier;
	}

	public String getManufacturerVendorPartyIdentifier() {
		return manufacturerVendorPartyIdentifier;
	}

	public void setManufacturerVendorPartyIdentifier(String manufacturerVendorPartyIdentifier) {
		this.manufacturerVendorPartyIdentifier = manufacturerVendorPartyIdentifier;
	}

	public String getLogicalDeleteIndicator() {
		return logicalDeleteIndicator;
	}

	public void setLogicalDeleteIndicator(String logicalDeleteIndicator) {
		this.logicalDeleteIndicator = logicalDeleteIndicator;
	}

	public String getGeneralMaterialItemCategoryGroupCode() {
		return generalMaterialItemCategoryGroupCode;
	}

	public void setGeneralMaterialItemCategoryGroupCode(String generalMaterialItemCategoryGroupCode) {
		this.generalMaterialItemCategoryGroupCode = generalMaterialItemCategoryGroupCode;
	}

}
