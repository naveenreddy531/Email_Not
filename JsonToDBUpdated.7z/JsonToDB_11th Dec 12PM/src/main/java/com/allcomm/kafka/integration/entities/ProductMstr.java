package com.allcomm.kafka.integration.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICING_PRODUCT_MSTR")
public class ProductMstr {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String productNumberlong;
	private String productQtyBreak;
	private String PL;
	private String PLDescription;
	private String longDescription;
	private String shortDescription;
	private String replacementProduct;
	private String productClassID;
	private String productClassDescription;
	private String model;
	private String modelDescription;
	private String family;
	private String familyDescription;
	private String series;
	private String seriesDescription;
	private String productChangeCode;
	private Date productChangeDate;
	private String PLCStatus;
	private Date PLCEffectiveDate;
	private String UOM;
	private String UPCCode;
	private String productDimensions;
	private String dimensionsUnit;
	private String productGrossWeight;
	private String serializationFlag;
	private String volume;
	private String volumeUnit;
	private String warrantyCode;
	private String weight;
	private String weightUnit;
	private String catalogID;
	private String duration;
	private String objectofService;
	private String EANCode;
	private String ESD;
	private String publish;
	private String category;
}
