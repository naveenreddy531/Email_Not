package com.allcomm.kafka.integration.entities;
public class SalesDivision
{
    private String SourceSystemCode;

    private String SalesDivisionCode;

    private String SalesDivisionDescription;

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getSalesDivisionCode ()
    {
        return SalesDivisionCode;
    }

    public void setSalesDivisionCode (String SalesDivisionCode)
    {
        this.SalesDivisionCode = SalesDivisionCode;
    }

    public String getSalesDivisionDescription ()
    {
        return SalesDivisionDescription;
    }

    public void setSalesDivisionDescription (String SalesDivisionDescription)
    {
        this.SalesDivisionDescription = SalesDivisionDescription;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [SourceSystemCode = "+SourceSystemCode+", SalesDivisionCode = "+SalesDivisionCode+", SalesDivisionDescription = "+SalesDivisionDescription+"]";
    }
}