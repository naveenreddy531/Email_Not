package com.allcomm.kafka.integration.entities;
public class SalesOrganization
{
    private String SalesOrganizationCode;

    private String SourceSystemCode;

    private String SalesOrganizationDescription;

    public String getSalesOrganizationCode ()
    {
        return SalesOrganizationCode;
    }

    public void setSalesOrganizationCode (String SalesOrganizationCode)
    {
        this.SalesOrganizationCode = SalesOrganizationCode;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getSalesOrganizationDescription ()
    {
        return SalesOrganizationDescription;
    }

    public void setSalesOrganizationDescription (String SalesOrganizationDescription)
    {
        this.SalesOrganizationDescription = SalesOrganizationDescription;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [SalesOrganizationCode = "+SalesOrganizationCode+", SourceSystemCode = "+SourceSystemCode+", SalesOrganizationDescription = "+SalesOrganizationDescription+"]";
    }
}