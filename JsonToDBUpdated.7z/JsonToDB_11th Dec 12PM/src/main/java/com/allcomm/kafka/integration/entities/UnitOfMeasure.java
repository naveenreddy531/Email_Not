package com.allcomm.kafka.integration.entities;
public class UnitOfMeasure
{
    private String UnitOfMeasureDescription;

    private String UnitOfMeasureCode;

    private String SourceSystemCode;

    private String CommericalFormatUnitOfMeasureCode;

    private String TechnicalFormatUnitOfMeasureCode;

    private String UnitOfMeasureLongDescription;

    public String getUnitOfMeasureDescription ()
    {
        return UnitOfMeasureDescription;
    }

    public void setUnitOfMeasureDescription (String UnitOfMeasureDescription)
    {
        this.UnitOfMeasureDescription = UnitOfMeasureDescription;
    }

    public String getUnitOfMeasureCode ()
    {
        return UnitOfMeasureCode;
    }

    public void setUnitOfMeasureCode (String UnitOfMeasureCode)
    {
        this.UnitOfMeasureCode = UnitOfMeasureCode;
    }

    public String getSourceSystemCode ()
    {
        return SourceSystemCode;
    }

    public void setSourceSystemCode (String SourceSystemCode)
    {
        this.SourceSystemCode = SourceSystemCode;
    }

    public String getCommericalFormatUnitOfMeasureCode ()
    {
        return CommericalFormatUnitOfMeasureCode;
    }

    public void setCommericalFormatUnitOfMeasureCode (String CommericalFormatUnitOfMeasureCode)
    {
        this.CommericalFormatUnitOfMeasureCode = CommericalFormatUnitOfMeasureCode;
    }

    public String getTechnicalFormatUnitOfMeasureCode ()
    {
        return TechnicalFormatUnitOfMeasureCode;
    }

    public void setTechnicalFormatUnitOfMeasureCode (String TechnicalFormatUnitOfMeasureCode)
    {
        this.TechnicalFormatUnitOfMeasureCode = TechnicalFormatUnitOfMeasureCode;
    }

    public String getUnitOfMeasureLongDescription ()
    {
        return UnitOfMeasureLongDescription;
    }

    public void setUnitOfMeasureLongDescription (String UnitOfMeasureLongDescription)
    {
        this.UnitOfMeasureLongDescription = UnitOfMeasureLongDescription;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [UnitOfMeasureDescription = "+UnitOfMeasureDescription+", UnitOfMeasureCode = "+UnitOfMeasureCode+", SourceSystemCode = "+SourceSystemCode+", CommericalFormatUnitOfMeasureCode = "+CommericalFormatUnitOfMeasureCode+", TechnicalFormatUnitOfMeasureCode = "+TechnicalFormatUnitOfMeasureCode+", UnitOfMeasureLongDescription = "+UnitOfMeasureLongDescription+"]";
    }
}