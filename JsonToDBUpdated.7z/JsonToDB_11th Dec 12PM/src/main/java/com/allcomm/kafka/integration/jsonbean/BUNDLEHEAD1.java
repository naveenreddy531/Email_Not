
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SAPDocumentIdentifier",
    "LineTypeCode",
    "BundleHeaderDescription",
    "ConfigurationIdentifier",
    "SPECIAL_CONFIGURATION_IND",
    "ComponentChangeDate",
    "FixedDiscountRequestAmount",
    "FIXED_DISCOUNT_AUTHORIZED_AMNT",
    "AddToCatalogueIndicator",
    "SourceSystemCreateTimestamp",
    "SourceSystemUpdateTimestamp",
    "GuidanceRefreshDate",
    "AuthorizedBigDealNetAmount",
    "AuthorizationBasisText",
    "CurrentBenefitProgramAmount",
    "SourceSystemQuantity",
    "GuidanceDetailIdentifier",
    "InstantPricingAmount",
    "ListPriceAmount",
    "RequestedTotalPercentage",
    "InstantPricingMethodAmount",
    "StandardDiscountPercentage"
})
public class BUNDLEHEAD1 {

    @JsonProperty("SAPDocumentIdentifier")
    private String sAPDocumentIdentifier;
    @JsonProperty("LineTypeCode")
    private String lineTypeCode;
    @JsonProperty("BundleHeaderDescription")
    private String bundleHeaderDescription;
    @JsonProperty("ConfigurationIdentifier")
    private String configurationIdentifier;
    @JsonProperty("SPECIAL_CONFIGURATION_IND")
    private String sPECIALCONFIGURATIONIND;
    @JsonProperty("ComponentChangeDate")
    private String componentChangeDate;
    @JsonProperty("FixedDiscountRequestAmount")
    private String fixedDiscountRequestAmount;
    @JsonProperty("FIXED_DISCOUNT_AUTHORIZED_AMNT")
    private String fIXEDDISCOUNTAUTHORIZEDAMNT;
    @JsonProperty("AddToCatalogueIndicator")
    private String addToCatalogueIndicator;
    @JsonProperty("SourceSystemCreateTimestamp")
    private String sourceSystemCreateTimestamp;
    @JsonProperty("SourceSystemUpdateTimestamp")
    private String sourceSystemUpdateTimestamp;
    @JsonProperty("GuidanceRefreshDate")
    private String guidanceRefreshDate;
    @JsonProperty("AuthorizedBigDealNetAmount")
    private String authorizedBigDealNetAmount;
    @JsonProperty("AuthorizationBasisText")
    private String authorizationBasisText;
    @JsonProperty("CurrentBenefitProgramAmount")
    private String currentBenefitProgramAmount;
    @JsonProperty("SourceSystemQuantity")
    private String sourceSystemQuantity;
    @JsonProperty("GuidanceDetailIdentifier")
    private String guidanceDetailIdentifier;
    @JsonProperty("InstantPricingAmount")
    private String instantPricingAmount;
    @JsonProperty("ListPriceAmount")
    private String listPriceAmount;
    @JsonProperty("RequestedTotalPercentage")
    private String requestedTotalPercentage;
    @JsonProperty("InstantPricingMethodAmount")
    private String instantPricingMethodAmount;
    @JsonProperty("StandardDiscountPercentage")
    private String standardDiscountPercentage;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SAPDocumentIdentifier")
    public String getSAPDocumentIdentifier() {
        return sAPDocumentIdentifier;
    }

    @JsonProperty("SAPDocumentIdentifier")
    public void setSAPDocumentIdentifier(String sAPDocumentIdentifier) {
        this.sAPDocumentIdentifier = sAPDocumentIdentifier;
    }

    public BUNDLEHEAD1 withSAPDocumentIdentifier(String sAPDocumentIdentifier) {
        this.sAPDocumentIdentifier = sAPDocumentIdentifier;
        return this;
    }

    @JsonProperty("LineTypeCode")
    public String getLineTypeCode() {
        return lineTypeCode;
    }

    @JsonProperty("LineTypeCode")
    public void setLineTypeCode(String lineTypeCode) {
        this.lineTypeCode = lineTypeCode;
    }

    public BUNDLEHEAD1 withLineTypeCode(String lineTypeCode) {
        this.lineTypeCode = lineTypeCode;
        return this;
    }

    @JsonProperty("BundleHeaderDescription")
    public String getBundleHeaderDescription() {
        return bundleHeaderDescription;
    }

    @JsonProperty("BundleHeaderDescription")
    public void setBundleHeaderDescription(String bundleHeaderDescription) {
        this.bundleHeaderDescription = bundleHeaderDescription;
    }

    public BUNDLEHEAD1 withBundleHeaderDescription(String bundleHeaderDescription) {
        this.bundleHeaderDescription = bundleHeaderDescription;
        return this;
    }

    @JsonProperty("ConfigurationIdentifier")
    public String getConfigurationIdentifier() {
        return configurationIdentifier;
    }

    @JsonProperty("ConfigurationIdentifier")
    public void setConfigurationIdentifier(String configurationIdentifier) {
        this.configurationIdentifier = configurationIdentifier;
    }

    public BUNDLEHEAD1 withConfigurationIdentifier(String configurationIdentifier) {
        this.configurationIdentifier = configurationIdentifier;
        return this;
    }

    @JsonProperty("SPECIAL_CONFIGURATION_IND")
    public String getSPECIALCONFIGURATIONIND() {
        return sPECIALCONFIGURATIONIND;
    }

    @JsonProperty("SPECIAL_CONFIGURATION_IND")
    public void setSPECIALCONFIGURATIONIND(String sPECIALCONFIGURATIONIND) {
        this.sPECIALCONFIGURATIONIND = sPECIALCONFIGURATIONIND;
    }

    public BUNDLEHEAD1 withSPECIALCONFIGURATIONIND(String sPECIALCONFIGURATIONIND) {
        this.sPECIALCONFIGURATIONIND = sPECIALCONFIGURATIONIND;
        return this;
    }

    @JsonProperty("ComponentChangeDate")
    public String getComponentChangeDate() {
        return componentChangeDate;
    }

    @JsonProperty("ComponentChangeDate")
    public void setComponentChangeDate(String componentChangeDate) {
        this.componentChangeDate = componentChangeDate;
    }

    public BUNDLEHEAD1 withComponentChangeDate(String componentChangeDate) {
        this.componentChangeDate = componentChangeDate;
        return this;
    }

    @JsonProperty("FixedDiscountRequestAmount")
    public String getFixedDiscountRequestAmount() {
        return fixedDiscountRequestAmount;
    }

    @JsonProperty("FixedDiscountRequestAmount")
    public void setFixedDiscountRequestAmount(String fixedDiscountRequestAmount) {
        this.fixedDiscountRequestAmount = fixedDiscountRequestAmount;
    }

    public BUNDLEHEAD1 withFixedDiscountRequestAmount(String fixedDiscountRequestAmount) {
        this.fixedDiscountRequestAmount = fixedDiscountRequestAmount;
        return this;
    }

    @JsonProperty("FIXED_DISCOUNT_AUTHORIZED_AMNT")
    public String getFIXEDDISCOUNTAUTHORIZEDAMNT() {
        return fIXEDDISCOUNTAUTHORIZEDAMNT;
    }

    @JsonProperty("FIXED_DISCOUNT_AUTHORIZED_AMNT")
    public void setFIXEDDISCOUNTAUTHORIZEDAMNT(String fIXEDDISCOUNTAUTHORIZEDAMNT) {
        this.fIXEDDISCOUNTAUTHORIZEDAMNT = fIXEDDISCOUNTAUTHORIZEDAMNT;
    }

    public BUNDLEHEAD1 withFIXEDDISCOUNTAUTHORIZEDAMNT(String fIXEDDISCOUNTAUTHORIZEDAMNT) {
        this.fIXEDDISCOUNTAUTHORIZEDAMNT = fIXEDDISCOUNTAUTHORIZEDAMNT;
        return this;
    }

    @JsonProperty("AddToCatalogueIndicator")
    public String getAddToCatalogueIndicator() {
        return addToCatalogueIndicator;
    }

    @JsonProperty("AddToCatalogueIndicator")
    public void setAddToCatalogueIndicator(String addToCatalogueIndicator) {
        this.addToCatalogueIndicator = addToCatalogueIndicator;
    }

    public BUNDLEHEAD1 withAddToCatalogueIndicator(String addToCatalogueIndicator) {
        this.addToCatalogueIndicator = addToCatalogueIndicator;
        return this;
    }

    @JsonProperty("SourceSystemCreateTimestamp")
    public String getSourceSystemCreateTimestamp() {
        return sourceSystemCreateTimestamp;
    }

    @JsonProperty("SourceSystemCreateTimestamp")
    public void setSourceSystemCreateTimestamp(String sourceSystemCreateTimestamp) {
        this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
    }

    public BUNDLEHEAD1 withSourceSystemCreateTimestamp(String sourceSystemCreateTimestamp) {
        this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
        return this;
    }

    @JsonProperty("SourceSystemUpdateTimestamp")
    public String getSourceSystemUpdateTimestamp() {
        return sourceSystemUpdateTimestamp;
    }

    @JsonProperty("SourceSystemUpdateTimestamp")
    public void setSourceSystemUpdateTimestamp(String sourceSystemUpdateTimestamp) {
        this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
    }

    public BUNDLEHEAD1 withSourceSystemUpdateTimestamp(String sourceSystemUpdateTimestamp) {
        this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
        return this;
    }

    @JsonProperty("GuidanceRefreshDate")
    public String getGuidanceRefreshDate() {
        return guidanceRefreshDate;
    }

    @JsonProperty("GuidanceRefreshDate")
    public void setGuidanceRefreshDate(String guidanceRefreshDate) {
        this.guidanceRefreshDate = guidanceRefreshDate;
    }

    public BUNDLEHEAD1 withGuidanceRefreshDate(String guidanceRefreshDate) {
        this.guidanceRefreshDate = guidanceRefreshDate;
        return this;
    }

    @JsonProperty("AuthorizedBigDealNetAmount")
    public String getAuthorizedBigDealNetAmount() {
        return authorizedBigDealNetAmount;
    }

    @JsonProperty("AuthorizedBigDealNetAmount")
    public void setAuthorizedBigDealNetAmount(String authorizedBigDealNetAmount) {
        this.authorizedBigDealNetAmount = authorizedBigDealNetAmount;
    }

    public BUNDLEHEAD1 withAuthorizedBigDealNetAmount(String authorizedBigDealNetAmount) {
        this.authorizedBigDealNetAmount = authorizedBigDealNetAmount;
        return this;
    }

    @JsonProperty("AuthorizationBasisText")
    public String getAuthorizationBasisText() {
        return authorizationBasisText;
    }

    @JsonProperty("AuthorizationBasisText")
    public void setAuthorizationBasisText(String authorizationBasisText) {
        this.authorizationBasisText = authorizationBasisText;
    }

    public BUNDLEHEAD1 withAuthorizationBasisText(String authorizationBasisText) {
        this.authorizationBasisText = authorizationBasisText;
        return this;
    }

    @JsonProperty("CurrentBenefitProgramAmount")
    public String getCurrentBenefitProgramAmount() {
        return currentBenefitProgramAmount;
    }

    @JsonProperty("CurrentBenefitProgramAmount")
    public void setCurrentBenefitProgramAmount(String currentBenefitProgramAmount) {
        this.currentBenefitProgramAmount = currentBenefitProgramAmount;
    }

    public BUNDLEHEAD1 withCurrentBenefitProgramAmount(String currentBenefitProgramAmount) {
        this.currentBenefitProgramAmount = currentBenefitProgramAmount;
        return this;
    }

    @JsonProperty("SourceSystemQuantity")
    public String getSourceSystemQuantity() {
        return sourceSystemQuantity;
    }

    @JsonProperty("SourceSystemQuantity")
    public void setSourceSystemQuantity(String sourceSystemQuantity) {
        this.sourceSystemQuantity = sourceSystemQuantity;
    }

    public BUNDLEHEAD1 withSourceSystemQuantity(String sourceSystemQuantity) {
        this.sourceSystemQuantity = sourceSystemQuantity;
        return this;
    }

    @JsonProperty("GuidanceDetailIdentifier")
    public String getGuidanceDetailIdentifier() {
        return guidanceDetailIdentifier;
    }

    @JsonProperty("GuidanceDetailIdentifier")
    public void setGuidanceDetailIdentifier(String guidanceDetailIdentifier) {
        this.guidanceDetailIdentifier = guidanceDetailIdentifier;
    }

    public BUNDLEHEAD1 withGuidanceDetailIdentifier(String guidanceDetailIdentifier) {
        this.guidanceDetailIdentifier = guidanceDetailIdentifier;
        return this;
    }

    @JsonProperty("InstantPricingAmount")
    public String getInstantPricingAmount() {
        return instantPricingAmount;
    }

    @JsonProperty("InstantPricingAmount")
    public void setInstantPricingAmount(String instantPricingAmount) {
        this.instantPricingAmount = instantPricingAmount;
    }

    public BUNDLEHEAD1 withInstantPricingAmount(String instantPricingAmount) {
        this.instantPricingAmount = instantPricingAmount;
        return this;
    }

    @JsonProperty("ListPriceAmount")
    public String getListPriceAmount() {
        return listPriceAmount;
    }

    @JsonProperty("ListPriceAmount")
    public void setListPriceAmount(String listPriceAmount) {
        this.listPriceAmount = listPriceAmount;
    }

    public BUNDLEHEAD1 withListPriceAmount(String listPriceAmount) {
        this.listPriceAmount = listPriceAmount;
        return this;
    }

    @JsonProperty("RequestedTotalPercentage")
    public String getRequestedTotalPercentage() {
        return requestedTotalPercentage;
    }

    @JsonProperty("RequestedTotalPercentage")
    public void setRequestedTotalPercentage(String requestedTotalPercentage) {
        this.requestedTotalPercentage = requestedTotalPercentage;
    }

    public BUNDLEHEAD1 withRequestedTotalPercentage(String requestedTotalPercentage) {
        this.requestedTotalPercentage = requestedTotalPercentage;
        return this;
    }

    @JsonProperty("InstantPricingMethodAmount")
    public String getInstantPricingMethodAmount() {
        return instantPricingMethodAmount;
    }

    @JsonProperty("InstantPricingMethodAmount")
    public void setInstantPricingMethodAmount(String instantPricingMethodAmount) {
        this.instantPricingMethodAmount = instantPricingMethodAmount;
    }

    public BUNDLEHEAD1 withInstantPricingMethodAmount(String instantPricingMethodAmount) {
        this.instantPricingMethodAmount = instantPricingMethodAmount;
        return this;
    }

    @JsonProperty("StandardDiscountPercentage")
    public String getStandardDiscountPercentage() {
        return standardDiscountPercentage;
    }

    @JsonProperty("StandardDiscountPercentage")
    public void setStandardDiscountPercentage(String standardDiscountPercentage) {
        this.standardDiscountPercentage = standardDiscountPercentage;
    }

    public BUNDLEHEAD1 withStandardDiscountPercentage(String standardDiscountPercentage) {
        this.standardDiscountPercentage = standardDiscountPercentage;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public BUNDLEHEAD1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sAPDocumentIdentifier).append(lineTypeCode).append(bundleHeaderDescription).append(configurationIdentifier).append(sPECIALCONFIGURATIONIND).append(componentChangeDate).append(fixedDiscountRequestAmount).append(fIXEDDISCOUNTAUTHORIZEDAMNT).append(addToCatalogueIndicator).append(sourceSystemCreateTimestamp).append(sourceSystemUpdateTimestamp).append(guidanceRefreshDate).append(authorizedBigDealNetAmount).append(authorizationBasisText).append(currentBenefitProgramAmount).append(sourceSystemQuantity).append(guidanceDetailIdentifier).append(instantPricingAmount).append(listPriceAmount).append(requestedTotalPercentage).append(instantPricingMethodAmount).append(standardDiscountPercentage).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BUNDLEHEAD1) == false) {
            return false;
        }
        BUNDLEHEAD1 rhs = ((BUNDLEHEAD1) other);
        return new EqualsBuilder().append(sAPDocumentIdentifier, rhs.sAPDocumentIdentifier).append(lineTypeCode, rhs.lineTypeCode).append(bundleHeaderDescription, rhs.bundleHeaderDescription).append(configurationIdentifier, rhs.configurationIdentifier).append(sPECIALCONFIGURATIONIND, rhs.sPECIALCONFIGURATIONIND).append(componentChangeDate, rhs.componentChangeDate).append(fixedDiscountRequestAmount, rhs.fixedDiscountRequestAmount).append(fIXEDDISCOUNTAUTHORIZEDAMNT, rhs.fIXEDDISCOUNTAUTHORIZEDAMNT).append(addToCatalogueIndicator, rhs.addToCatalogueIndicator).append(sourceSystemCreateTimestamp, rhs.sourceSystemCreateTimestamp).append(sourceSystemUpdateTimestamp, rhs.sourceSystemUpdateTimestamp).append(guidanceRefreshDate, rhs.guidanceRefreshDate).append(authorizedBigDealNetAmount, rhs.authorizedBigDealNetAmount).append(authorizationBasisText, rhs.authorizationBasisText).append(currentBenefitProgramAmount, rhs.currentBenefitProgramAmount).append(sourceSystemQuantity, rhs.sourceSystemQuantity).append(guidanceDetailIdentifier, rhs.guidanceDetailIdentifier).append(instantPricingAmount, rhs.instantPricingAmount).append(listPriceAmount, rhs.listPriceAmount).append(requestedTotalPercentage, rhs.requestedTotalPercentage).append(instantPricingMethodAmount, rhs.instantPricingMethodAmount).append(standardDiscountPercentage, rhs.standardDiscountPercentage).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
