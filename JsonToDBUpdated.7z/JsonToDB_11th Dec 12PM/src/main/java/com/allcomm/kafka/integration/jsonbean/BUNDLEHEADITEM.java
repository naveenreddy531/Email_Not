
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "BUNDLE_HEAD1",
    "BUNDLE_ITEM1",
    "BUNDLE_ITEM2"
})
public class BUNDLEHEADITEM {

    @JsonProperty("BUNDLE_HEAD1")
    private BUNDLEHEAD1 bUNDLEHEAD1;
    @JsonProperty("BUNDLE_ITEM1")
    private List<BUNDLEITEM1> bUNDLEITEM1 = new ArrayList<BUNDLEITEM1>();
    @JsonProperty("BUNDLE_ITEM2")
    private List<BUNDLEITEM2> bUNDLEITEM2 = new ArrayList<BUNDLEITEM2>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("BUNDLE_HEAD1")
    public BUNDLEHEAD1 getBUNDLEHEAD1() {
        return bUNDLEHEAD1;
    }

    @JsonProperty("BUNDLE_HEAD1")
    public void setBUNDLEHEAD1(BUNDLEHEAD1 bUNDLEHEAD1) {
        this.bUNDLEHEAD1 = bUNDLEHEAD1;
    }

    public BUNDLEHEADITEM withBUNDLEHEAD1(BUNDLEHEAD1 bUNDLEHEAD1) {
        this.bUNDLEHEAD1 = bUNDLEHEAD1;
        return this;
    }

    @JsonProperty("BUNDLE_ITEM1")
    public List<BUNDLEITEM1> getBUNDLEITEM1() {
        return bUNDLEITEM1;
    }

    @JsonProperty("BUNDLE_ITEM1")
    public void setBUNDLEITEM1(List<BUNDLEITEM1> bUNDLEITEM1) {
        this.bUNDLEITEM1 = bUNDLEITEM1;
    }

    public BUNDLEHEADITEM withBUNDLEITEM1(List<BUNDLEITEM1> bUNDLEITEM1) {
        this.bUNDLEITEM1 = bUNDLEITEM1;
        return this;
    }

    @JsonProperty("BUNDLE_ITEM2")
    public List<BUNDLEITEM2> getBUNDLEITEM2() {
        return bUNDLEITEM2;
    }

    @JsonProperty("BUNDLE_ITEM2")
    public void setBUNDLEITEM2(List<BUNDLEITEM2> bUNDLEITEM2) {
        this.bUNDLEITEM2 = bUNDLEITEM2;
    }

    public BUNDLEHEADITEM withBUNDLEITEM2(List<BUNDLEITEM2> bUNDLEITEM2) {
        this.bUNDLEITEM2 = bUNDLEITEM2;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public BUNDLEHEADITEM withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(bUNDLEHEAD1).append(bUNDLEITEM1).append(bUNDLEITEM2).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BUNDLEHEADITEM) == false) {
            return false;
        }
        BUNDLEHEADITEM rhs = ((BUNDLEHEADITEM) other);
        return new EqualsBuilder().append(bUNDLEHEAD1, rhs.bUNDLEHEAD1).append(bUNDLEITEM1, rhs.bUNDLEITEM1).append(bUNDLEITEM2, rhs.bUNDLEITEM2).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
