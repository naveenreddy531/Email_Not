
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "DealVersionNumber",
    "BundleIdentifier",
    "SAPDocumentNumber",
    "MaterialLifeCycleIndicator",
    "AuthorizedDate",
    "AuthorizerByUserId",
    "PriceListCode",
    "PriceTermCode",
    "BandedIndicator",
    "ProductCostPriceAmount",
    "ProductCostDate",
    "PreviousRequestedGuidancePercentage",
    "AuthorizerLineTypeCode",
    "PreviousAuthorizationStatusIndicator",
    "PreviousApprovedPriceAmount",
    "RequestBackEndContraAmount",
    "AuthorizationBackEndContraAmount",
    "RequestNetRevenueAmount",
    "AuthorizedNetRevenueAmount",
    "ExternalContraAmount",
    "RequestNetMarginAmount",
    "AuthorizedNetMarginAmount",
    "RequestNetMarginPercentage",
    "AuthorizedNetMarginPercentage",
    "InstantPricingAmount",
    "MedallionNetAmount",
    "ItemSequenceNumber",
    "BundleLineQuantity",
    "StandardDiscountPercentage",
    "RequestedBigDealNetAmount",
    "AuthorizedGrossMarginAmount",
    "BundleDescription",
    "DivisionCode",
    "BusinessGroupCode",
    "BusinessUnitCode",
    "ListPriceValueAmount",
    "RequestedAdditionalDiscountPercentage",
    "RequestedTotalPercentage",
    "ExpertAdditionalPercentage",
    "FloorAdditionalPercentage",
    "TypicalAdditionalPercentage",
    "PreviousRequestedAdditionalPercentage",
    "AuthorizedBigDealNetAmount",
    "AuthorizedAdditionalPercentage",
    "AuthorizedTotalPercentage",
    "CostAvailabilityIndicator",
    "ShipChargeIndicator",
    "GuidanceAvailablityIndicator",
    "AuthorizationStatusCode",
    "InstantPricingMethodCode",
    "MedallionLevelCode"
})
public class BUNDLEITEM1 {

    @JsonProperty("DealVersionNumber")
    private String dealVersionNumber;
    @JsonProperty("BundleIdentifier")
    private String bundleIdentifier;
    @JsonProperty("SAPDocumentNumber")
    private String sAPDocumentNumber;
    @JsonProperty("MaterialLifeCycleIndicator")
    private String materialLifeCycleIndicator;
    @JsonProperty("AuthorizedDate")
    private String authorizedDate;
    @JsonProperty("AuthorizerByUserId")
    private String authorizerByUserId;
    @JsonProperty("PriceListCode")
    private String priceListCode;
    @JsonProperty("PriceTermCode")
    private String priceTermCode;
    @JsonProperty("BandedIndicator")
    private String bandedIndicator;
    @JsonProperty("ProductCostPriceAmount")
    private String productCostPriceAmount;
    @JsonProperty("ProductCostDate")
    private String productCostDate;
    @JsonProperty("PreviousRequestedGuidancePercentage")
    private String previousRequestedGuidancePercentage;
    @JsonProperty("AuthorizerLineTypeCode")
    private String authorizerLineTypeCode;
    @JsonProperty("PreviousAuthorizationStatusIndicator")
    private String previousAuthorizationStatusIndicator;
    @JsonProperty("PreviousApprovedPriceAmount")
    private String previousApprovedPriceAmount;
    @JsonProperty("RequestBackEndContraAmount")
    private String requestBackEndContraAmount;
    @JsonProperty("AuthorizationBackEndContraAmount")
    private String authorizationBackEndContraAmount;
    @JsonProperty("RequestNetRevenueAmount")
    private String requestNetRevenueAmount;
    @JsonProperty("AuthorizedNetRevenueAmount")
    private String authorizedNetRevenueAmount;
    @JsonProperty("ExternalContraAmount")
    private String externalContraAmount;
    @JsonProperty("RequestNetMarginAmount")
    private String requestNetMarginAmount;
    @JsonProperty("AuthorizedNetMarginAmount")
    private String authorizedNetMarginAmount;
    @JsonProperty("RequestNetMarginPercentage")
    private String requestNetMarginPercentage;
    @JsonProperty("AuthorizedNetMarginPercentage")
    private String authorizedNetMarginPercentage;
    @JsonProperty("InstantPricingAmount")
    private String instantPricingAmount;
    @JsonProperty("MedallionNetAmount")
    private String medallionNetAmount;
    @JsonProperty("ItemSequenceNumber")
    private String itemSequenceNumber;
    @JsonProperty("BundleLineQuantity")
    private String bundleLineQuantity;
    @JsonProperty("StandardDiscountPercentage")
    private String standardDiscountPercentage;
    @JsonProperty("RequestedBigDealNetAmount")
    private String requestedBigDealNetAmount;
    @JsonProperty("AuthorizedGrossMarginAmount")
    private String authorizedGrossMarginAmount;
    @JsonProperty("BundleDescription")
    private String bundleDescription;
    @JsonProperty("DivisionCode")
    private String divisionCode;
    @JsonProperty("BusinessGroupCode")
    private String businessGroupCode;
    @JsonProperty("BusinessUnitCode")
    private String businessUnitCode;
    @JsonProperty("ListPriceValueAmount")
    private String listPriceValueAmount;
    @JsonProperty("RequestedAdditionalDiscountPercentage")
    private String requestedAdditionalDiscountPercentage;
    @JsonProperty("RequestedTotalPercentage")
    private String requestedTotalPercentage;
    @JsonProperty("ExpertAdditionalPercentage")
    private String expertAdditionalPercentage;
    @JsonProperty("FloorAdditionalPercentage")
    private String floorAdditionalPercentage;
    @JsonProperty("TypicalAdditionalPercentage")
    private String typicalAdditionalPercentage;
    @JsonProperty("PreviousRequestedAdditionalPercentage")
    private String previousRequestedAdditionalPercentage;
    @JsonProperty("AuthorizedBigDealNetAmount")
    private String authorizedBigDealNetAmount;
    @JsonProperty("AuthorizedAdditionalPercentage")
    private String authorizedAdditionalPercentage;
    @JsonProperty("AuthorizedTotalPercentage")
    private String authorizedTotalPercentage;
    @JsonProperty("CostAvailabilityIndicator")
    private String costAvailabilityIndicator;
    @JsonProperty("ShipChargeIndicator")
    private String shipChargeIndicator;
    @JsonProperty("GuidanceAvailablityIndicator")
    private String guidanceAvailablityIndicator;
    @JsonProperty("AuthorizationStatusCode")
    private String authorizationStatusCode;
    @JsonProperty("InstantPricingMethodCode")
    private String instantPricingMethodCode;
    @JsonProperty("MedallionLevelCode")
    private String medallionLevelCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("DealVersionNumber")
    public String getDealVersionNumber() {
        return dealVersionNumber;
    }

    @JsonProperty("DealVersionNumber")
    public void setDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
    }

    public BUNDLEITEM1 withDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
        return this;
    }

    @JsonProperty("BundleIdentifier")
    public String getBundleIdentifier() {
        return bundleIdentifier;
    }

    @JsonProperty("BundleIdentifier")
    public void setBundleIdentifier(String bundleIdentifier) {
        this.bundleIdentifier = bundleIdentifier;
    }

    public BUNDLEITEM1 withBundleIdentifier(String bundleIdentifier) {
        this.bundleIdentifier = bundleIdentifier;
        return this;
    }

    @JsonProperty("SAPDocumentNumber")
    public String getSAPDocumentNumber() {
        return sAPDocumentNumber;
    }

    @JsonProperty("SAPDocumentNumber")
    public void setSAPDocumentNumber(String sAPDocumentNumber) {
        this.sAPDocumentNumber = sAPDocumentNumber;
    }

    public BUNDLEITEM1 withSAPDocumentNumber(String sAPDocumentNumber) {
        this.sAPDocumentNumber = sAPDocumentNumber;
        return this;
    }

    @JsonProperty("MaterialLifeCycleIndicator")
    public String getMaterialLifeCycleIndicator() {
        return materialLifeCycleIndicator;
    }

    @JsonProperty("MaterialLifeCycleIndicator")
    public void setMaterialLifeCycleIndicator(String materialLifeCycleIndicator) {
        this.materialLifeCycleIndicator = materialLifeCycleIndicator;
    }

    public BUNDLEITEM1 withMaterialLifeCycleIndicator(String materialLifeCycleIndicator) {
        this.materialLifeCycleIndicator = materialLifeCycleIndicator;
        return this;
    }

    @JsonProperty("AuthorizedDate")
    public String getAuthorizedDate() {
        return authorizedDate;
    }

    @JsonProperty("AuthorizedDate")
    public void setAuthorizedDate(String authorizedDate) {
        this.authorizedDate = authorizedDate;
    }

    public BUNDLEITEM1 withAuthorizedDate(String authorizedDate) {
        this.authorizedDate = authorizedDate;
        return this;
    }

    @JsonProperty("AuthorizerByUserId")
    public String getAuthorizerByUserId() {
        return authorizerByUserId;
    }

    @JsonProperty("AuthorizerByUserId")
    public void setAuthorizerByUserId(String authorizerByUserId) {
        this.authorizerByUserId = authorizerByUserId;
    }

    public BUNDLEITEM1 withAuthorizerByUserId(String authorizerByUserId) {
        this.authorizerByUserId = authorizerByUserId;
        return this;
    }

    @JsonProperty("PriceListCode")
    public String getPriceListCode() {
        return priceListCode;
    }

    @JsonProperty("PriceListCode")
    public void setPriceListCode(String priceListCode) {
        this.priceListCode = priceListCode;
    }

    public BUNDLEITEM1 withPriceListCode(String priceListCode) {
        this.priceListCode = priceListCode;
        return this;
    }

    @JsonProperty("PriceTermCode")
    public String getPriceTermCode() {
        return priceTermCode;
    }

    @JsonProperty("PriceTermCode")
    public void setPriceTermCode(String priceTermCode) {
        this.priceTermCode = priceTermCode;
    }

    public BUNDLEITEM1 withPriceTermCode(String priceTermCode) {
        this.priceTermCode = priceTermCode;
        return this;
    }

    @JsonProperty("BandedIndicator")
    public String getBandedIndicator() {
        return bandedIndicator;
    }

    @JsonProperty("BandedIndicator")
    public void setBandedIndicator(String bandedIndicator) {
        this.bandedIndicator = bandedIndicator;
    }

    public BUNDLEITEM1 withBandedIndicator(String bandedIndicator) {
        this.bandedIndicator = bandedIndicator;
        return this;
    }

    @JsonProperty("ProductCostPriceAmount")
    public String getProductCostPriceAmount() {
        return productCostPriceAmount;
    }

    @JsonProperty("ProductCostPriceAmount")
    public void setProductCostPriceAmount(String productCostPriceAmount) {
        this.productCostPriceAmount = productCostPriceAmount;
    }

    public BUNDLEITEM1 withProductCostPriceAmount(String productCostPriceAmount) {
        this.productCostPriceAmount = productCostPriceAmount;
        return this;
    }

    @JsonProperty("ProductCostDate")
    public String getProductCostDate() {
        return productCostDate;
    }

    @JsonProperty("ProductCostDate")
    public void setProductCostDate(String productCostDate) {
        this.productCostDate = productCostDate;
    }

    public BUNDLEITEM1 withProductCostDate(String productCostDate) {
        this.productCostDate = productCostDate;
        return this;
    }

    @JsonProperty("PreviousRequestedGuidancePercentage")
    public String getPreviousRequestedGuidancePercentage() {
        return previousRequestedGuidancePercentage;
    }

    @JsonProperty("PreviousRequestedGuidancePercentage")
    public void setPreviousRequestedGuidancePercentage(String previousRequestedGuidancePercentage) {
        this.previousRequestedGuidancePercentage = previousRequestedGuidancePercentage;
    }

    public BUNDLEITEM1 withPreviousRequestedGuidancePercentage(String previousRequestedGuidancePercentage) {
        this.previousRequestedGuidancePercentage = previousRequestedGuidancePercentage;
        return this;
    }

    @JsonProperty("AuthorizerLineTypeCode")
    public String getAuthorizerLineTypeCode() {
        return authorizerLineTypeCode;
    }

    @JsonProperty("AuthorizerLineTypeCode")
    public void setAuthorizerLineTypeCode(String authorizerLineTypeCode) {
        this.authorizerLineTypeCode = authorizerLineTypeCode;
    }

    public BUNDLEITEM1 withAuthorizerLineTypeCode(String authorizerLineTypeCode) {
        this.authorizerLineTypeCode = authorizerLineTypeCode;
        return this;
    }

    @JsonProperty("PreviousAuthorizationStatusIndicator")
    public String getPreviousAuthorizationStatusIndicator() {
        return previousAuthorizationStatusIndicator;
    }

    @JsonProperty("PreviousAuthorizationStatusIndicator")
    public void setPreviousAuthorizationStatusIndicator(String previousAuthorizationStatusIndicator) {
        this.previousAuthorizationStatusIndicator = previousAuthorizationStatusIndicator;
    }

    public BUNDLEITEM1 withPreviousAuthorizationStatusIndicator(String previousAuthorizationStatusIndicator) {
        this.previousAuthorizationStatusIndicator = previousAuthorizationStatusIndicator;
        return this;
    }

    @JsonProperty("PreviousApprovedPriceAmount")
    public String getPreviousApprovedPriceAmount() {
        return previousApprovedPriceAmount;
    }

    @JsonProperty("PreviousApprovedPriceAmount")
    public void setPreviousApprovedPriceAmount(String previousApprovedPriceAmount) {
        this.previousApprovedPriceAmount = previousApprovedPriceAmount;
    }

    public BUNDLEITEM1 withPreviousApprovedPriceAmount(String previousApprovedPriceAmount) {
        this.previousApprovedPriceAmount = previousApprovedPriceAmount;
        return this;
    }

    @JsonProperty("RequestBackEndContraAmount")
    public String getRequestBackEndContraAmount() {
        return requestBackEndContraAmount;
    }

    @JsonProperty("RequestBackEndContraAmount")
    public void setRequestBackEndContraAmount(String requestBackEndContraAmount) {
        this.requestBackEndContraAmount = requestBackEndContraAmount;
    }

    public BUNDLEITEM1 withRequestBackEndContraAmount(String requestBackEndContraAmount) {
        this.requestBackEndContraAmount = requestBackEndContraAmount;
        return this;
    }

    @JsonProperty("AuthorizationBackEndContraAmount")
    public String getAuthorizationBackEndContraAmount() {
        return authorizationBackEndContraAmount;
    }

    @JsonProperty("AuthorizationBackEndContraAmount")
    public void setAuthorizationBackEndContraAmount(String authorizationBackEndContraAmount) {
        this.authorizationBackEndContraAmount = authorizationBackEndContraAmount;
    }

    public BUNDLEITEM1 withAuthorizationBackEndContraAmount(String authorizationBackEndContraAmount) {
        this.authorizationBackEndContraAmount = authorizationBackEndContraAmount;
        return this;
    }

    @JsonProperty("RequestNetRevenueAmount")
    public String getRequestNetRevenueAmount() {
        return requestNetRevenueAmount;
    }

    @JsonProperty("RequestNetRevenueAmount")
    public void setRequestNetRevenueAmount(String requestNetRevenueAmount) {
        this.requestNetRevenueAmount = requestNetRevenueAmount;
    }

    public BUNDLEITEM1 withRequestNetRevenueAmount(String requestNetRevenueAmount) {
        this.requestNetRevenueAmount = requestNetRevenueAmount;
        return this;
    }

    @JsonProperty("AuthorizedNetRevenueAmount")
    public String getAuthorizedNetRevenueAmount() {
        return authorizedNetRevenueAmount;
    }

    @JsonProperty("AuthorizedNetRevenueAmount")
    public void setAuthorizedNetRevenueAmount(String authorizedNetRevenueAmount) {
        this.authorizedNetRevenueAmount = authorizedNetRevenueAmount;
    }

    public BUNDLEITEM1 withAuthorizedNetRevenueAmount(String authorizedNetRevenueAmount) {
        this.authorizedNetRevenueAmount = authorizedNetRevenueAmount;
        return this;
    }

    @JsonProperty("ExternalContraAmount")
    public String getExternalContraAmount() {
        return externalContraAmount;
    }

    @JsonProperty("ExternalContraAmount")
    public void setExternalContraAmount(String externalContraAmount) {
        this.externalContraAmount = externalContraAmount;
    }

    public BUNDLEITEM1 withExternalContraAmount(String externalContraAmount) {
        this.externalContraAmount = externalContraAmount;
        return this;
    }

    @JsonProperty("RequestNetMarginAmount")
    public String getRequestNetMarginAmount() {
        return requestNetMarginAmount;
    }

    @JsonProperty("RequestNetMarginAmount")
    public void setRequestNetMarginAmount(String requestNetMarginAmount) {
        this.requestNetMarginAmount = requestNetMarginAmount;
    }

    public BUNDLEITEM1 withRequestNetMarginAmount(String requestNetMarginAmount) {
        this.requestNetMarginAmount = requestNetMarginAmount;
        return this;
    }

    @JsonProperty("AuthorizedNetMarginAmount")
    public String getAuthorizedNetMarginAmount() {
        return authorizedNetMarginAmount;
    }

    @JsonProperty("AuthorizedNetMarginAmount")
    public void setAuthorizedNetMarginAmount(String authorizedNetMarginAmount) {
        this.authorizedNetMarginAmount = authorizedNetMarginAmount;
    }

    public BUNDLEITEM1 withAuthorizedNetMarginAmount(String authorizedNetMarginAmount) {
        this.authorizedNetMarginAmount = authorizedNetMarginAmount;
        return this;
    }

    @JsonProperty("RequestNetMarginPercentage")
    public String getRequestNetMarginPercentage() {
        return requestNetMarginPercentage;
    }

    @JsonProperty("RequestNetMarginPercentage")
    public void setRequestNetMarginPercentage(String requestNetMarginPercentage) {
        this.requestNetMarginPercentage = requestNetMarginPercentage;
    }

    public BUNDLEITEM1 withRequestNetMarginPercentage(String requestNetMarginPercentage) {
        this.requestNetMarginPercentage = requestNetMarginPercentage;
        return this;
    }

    @JsonProperty("AuthorizedNetMarginPercentage")
    public String getAuthorizedNetMarginPercentage() {
        return authorizedNetMarginPercentage;
    }

    @JsonProperty("AuthorizedNetMarginPercentage")
    public void setAuthorizedNetMarginPercentage(String authorizedNetMarginPercentage) {
        this.authorizedNetMarginPercentage = authorizedNetMarginPercentage;
    }

    public BUNDLEITEM1 withAuthorizedNetMarginPercentage(String authorizedNetMarginPercentage) {
        this.authorizedNetMarginPercentage = authorizedNetMarginPercentage;
        return this;
    }

    @JsonProperty("InstantPricingAmount")
    public String getInstantPricingAmount() {
        return instantPricingAmount;
    }

    @JsonProperty("InstantPricingAmount")
    public void setInstantPricingAmount(String instantPricingAmount) {
        this.instantPricingAmount = instantPricingAmount;
    }

    public BUNDLEITEM1 withInstantPricingAmount(String instantPricingAmount) {
        this.instantPricingAmount = instantPricingAmount;
        return this;
    }

    @JsonProperty("MedallionNetAmount")
    public String getMedallionNetAmount() {
        return medallionNetAmount;
    }

    @JsonProperty("MedallionNetAmount")
    public void setMedallionNetAmount(String medallionNetAmount) {
        this.medallionNetAmount = medallionNetAmount;
    }

    public BUNDLEITEM1 withMedallionNetAmount(String medallionNetAmount) {
        this.medallionNetAmount = medallionNetAmount;
        return this;
    }

    @JsonProperty("ItemSequenceNumber")
    public String getItemSequenceNumber() {
        return itemSequenceNumber;
    }

    @JsonProperty("ItemSequenceNumber")
    public void setItemSequenceNumber(String itemSequenceNumber) {
        this.itemSequenceNumber = itemSequenceNumber;
    }

    public BUNDLEITEM1 withItemSequenceNumber(String itemSequenceNumber) {
        this.itemSequenceNumber = itemSequenceNumber;
        return this;
    }

    @JsonProperty("BundleLineQuantity")
    public String getBundleLineQuantity() {
        return bundleLineQuantity;
    }

    @JsonProperty("BundleLineQuantity")
    public void setBundleLineQuantity(String bundleLineQuantity) {
        this.bundleLineQuantity = bundleLineQuantity;
    }

    public BUNDLEITEM1 withBundleLineQuantity(String bundleLineQuantity) {
        this.bundleLineQuantity = bundleLineQuantity;
        return this;
    }

    @JsonProperty("StandardDiscountPercentage")
    public String getStandardDiscountPercentage() {
        return standardDiscountPercentage;
    }

    @JsonProperty("StandardDiscountPercentage")
    public void setStandardDiscountPercentage(String standardDiscountPercentage) {
        this.standardDiscountPercentage = standardDiscountPercentage;
    }

    public BUNDLEITEM1 withStandardDiscountPercentage(String standardDiscountPercentage) {
        this.standardDiscountPercentage = standardDiscountPercentage;
        return this;
    }

    @JsonProperty("RequestedBigDealNetAmount")
    public String getRequestedBigDealNetAmount() {
        return requestedBigDealNetAmount;
    }

    @JsonProperty("RequestedBigDealNetAmount")
    public void setRequestedBigDealNetAmount(String requestedBigDealNetAmount) {
        this.requestedBigDealNetAmount = requestedBigDealNetAmount;
    }

    public BUNDLEITEM1 withRequestedBigDealNetAmount(String requestedBigDealNetAmount) {
        this.requestedBigDealNetAmount = requestedBigDealNetAmount;
        return this;
    }

    @JsonProperty("AuthorizedGrossMarginAmount")
    public String getAuthorizedGrossMarginAmount() {
        return authorizedGrossMarginAmount;
    }

    @JsonProperty("AuthorizedGrossMarginAmount")
    public void setAuthorizedGrossMarginAmount(String authorizedGrossMarginAmount) {
        this.authorizedGrossMarginAmount = authorizedGrossMarginAmount;
    }

    public BUNDLEITEM1 withAuthorizedGrossMarginAmount(String authorizedGrossMarginAmount) {
        this.authorizedGrossMarginAmount = authorizedGrossMarginAmount;
        return this;
    }

    @JsonProperty("BundleDescription")
    public String getBundleDescription() {
        return bundleDescription;
    }

    @JsonProperty("BundleDescription")
    public void setBundleDescription(String bundleDescription) {
        this.bundleDescription = bundleDescription;
    }

    public BUNDLEITEM1 withBundleDescription(String bundleDescription) {
        this.bundleDescription = bundleDescription;
        return this;
    }

    @JsonProperty("DivisionCode")
    public String getDivisionCode() {
        return divisionCode;
    }

    @JsonProperty("DivisionCode")
    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public BUNDLEITEM1 withDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
        return this;
    }

    @JsonProperty("BusinessGroupCode")
    public String getBusinessGroupCode() {
        return businessGroupCode;
    }

    @JsonProperty("BusinessGroupCode")
    public void setBusinessGroupCode(String businessGroupCode) {
        this.businessGroupCode = businessGroupCode;
    }

    public BUNDLEITEM1 withBusinessGroupCode(String businessGroupCode) {
        this.businessGroupCode = businessGroupCode;
        return this;
    }

    @JsonProperty("BusinessUnitCode")
    public String getBusinessUnitCode() {
        return businessUnitCode;
    }

    @JsonProperty("BusinessUnitCode")
    public void setBusinessUnitCode(String businessUnitCode) {
        this.businessUnitCode = businessUnitCode;
    }

    public BUNDLEITEM1 withBusinessUnitCode(String businessUnitCode) {
        this.businessUnitCode = businessUnitCode;
        return this;
    }

    @JsonProperty("ListPriceValueAmount")
    public String getListPriceValueAmount() {
        return listPriceValueAmount;
    }

    @JsonProperty("ListPriceValueAmount")
    public void setListPriceValueAmount(String listPriceValueAmount) {
        this.listPriceValueAmount = listPriceValueAmount;
    }

    public BUNDLEITEM1 withListPriceValueAmount(String listPriceValueAmount) {
        this.listPriceValueAmount = listPriceValueAmount;
        return this;
    }

    @JsonProperty("RequestedAdditionalDiscountPercentage")
    public String getRequestedAdditionalDiscountPercentage() {
        return requestedAdditionalDiscountPercentage;
    }

    @JsonProperty("RequestedAdditionalDiscountPercentage")
    public void setRequestedAdditionalDiscountPercentage(String requestedAdditionalDiscountPercentage) {
        this.requestedAdditionalDiscountPercentage = requestedAdditionalDiscountPercentage;
    }

    public BUNDLEITEM1 withRequestedAdditionalDiscountPercentage(String requestedAdditionalDiscountPercentage) {
        this.requestedAdditionalDiscountPercentage = requestedAdditionalDiscountPercentage;
        return this;
    }

    @JsonProperty("RequestedTotalPercentage")
    public String getRequestedTotalPercentage() {
        return requestedTotalPercentage;
    }

    @JsonProperty("RequestedTotalPercentage")
    public void setRequestedTotalPercentage(String requestedTotalPercentage) {
        this.requestedTotalPercentage = requestedTotalPercentage;
    }

    public BUNDLEITEM1 withRequestedTotalPercentage(String requestedTotalPercentage) {
        this.requestedTotalPercentage = requestedTotalPercentage;
        return this;
    }

    @JsonProperty("ExpertAdditionalPercentage")
    public String getExpertAdditionalPercentage() {
        return expertAdditionalPercentage;
    }

    @JsonProperty("ExpertAdditionalPercentage")
    public void setExpertAdditionalPercentage(String expertAdditionalPercentage) {
        this.expertAdditionalPercentage = expertAdditionalPercentage;
    }

    public BUNDLEITEM1 withExpertAdditionalPercentage(String expertAdditionalPercentage) {
        this.expertAdditionalPercentage = expertAdditionalPercentage;
        return this;
    }

    @JsonProperty("FloorAdditionalPercentage")
    public String getFloorAdditionalPercentage() {
        return floorAdditionalPercentage;
    }

    @JsonProperty("FloorAdditionalPercentage")
    public void setFloorAdditionalPercentage(String floorAdditionalPercentage) {
        this.floorAdditionalPercentage = floorAdditionalPercentage;
    }

    public BUNDLEITEM1 withFloorAdditionalPercentage(String floorAdditionalPercentage) {
        this.floorAdditionalPercentage = floorAdditionalPercentage;
        return this;
    }

    @JsonProperty("TypicalAdditionalPercentage")
    public String getTypicalAdditionalPercentage() {
        return typicalAdditionalPercentage;
    }

    @JsonProperty("TypicalAdditionalPercentage")
    public void setTypicalAdditionalPercentage(String typicalAdditionalPercentage) {
        this.typicalAdditionalPercentage = typicalAdditionalPercentage;
    }

    public BUNDLEITEM1 withTypicalAdditionalPercentage(String typicalAdditionalPercentage) {
        this.typicalAdditionalPercentage = typicalAdditionalPercentage;
        return this;
    }

    @JsonProperty("PreviousRequestedAdditionalPercentage")
    public String getPreviousRequestedAdditionalPercentage() {
        return previousRequestedAdditionalPercentage;
    }

    @JsonProperty("PreviousRequestedAdditionalPercentage")
    public void setPreviousRequestedAdditionalPercentage(String previousRequestedAdditionalPercentage) {
        this.previousRequestedAdditionalPercentage = previousRequestedAdditionalPercentage;
    }

    public BUNDLEITEM1 withPreviousRequestedAdditionalPercentage(String previousRequestedAdditionalPercentage) {
        this.previousRequestedAdditionalPercentage = previousRequestedAdditionalPercentage;
        return this;
    }

    @JsonProperty("AuthorizedBigDealNetAmount")
    public String getAuthorizedBigDealNetAmount() {
        return authorizedBigDealNetAmount;
    }

    @JsonProperty("AuthorizedBigDealNetAmount")
    public void setAuthorizedBigDealNetAmount(String authorizedBigDealNetAmount) {
        this.authorizedBigDealNetAmount = authorizedBigDealNetAmount;
    }

    public BUNDLEITEM1 withAuthorizedBigDealNetAmount(String authorizedBigDealNetAmount) {
        this.authorizedBigDealNetAmount = authorizedBigDealNetAmount;
        return this;
    }

    @JsonProperty("AuthorizedAdditionalPercentage")
    public String getAuthorizedAdditionalPercentage() {
        return authorizedAdditionalPercentage;
    }

    @JsonProperty("AuthorizedAdditionalPercentage")
    public void setAuthorizedAdditionalPercentage(String authorizedAdditionalPercentage) {
        this.authorizedAdditionalPercentage = authorizedAdditionalPercentage;
    }

    public BUNDLEITEM1 withAuthorizedAdditionalPercentage(String authorizedAdditionalPercentage) {
        this.authorizedAdditionalPercentage = authorizedAdditionalPercentage;
        return this;
    }

    @JsonProperty("AuthorizedTotalPercentage")
    public String getAuthorizedTotalPercentage() {
        return authorizedTotalPercentage;
    }

    @JsonProperty("AuthorizedTotalPercentage")
    public void setAuthorizedTotalPercentage(String authorizedTotalPercentage) {
        this.authorizedTotalPercentage = authorizedTotalPercentage;
    }

    public BUNDLEITEM1 withAuthorizedTotalPercentage(String authorizedTotalPercentage) {
        this.authorizedTotalPercentage = authorizedTotalPercentage;
        return this;
    }

    @JsonProperty("CostAvailabilityIndicator")
    public String getCostAvailabilityIndicator() {
        return costAvailabilityIndicator;
    }

    @JsonProperty("CostAvailabilityIndicator")
    public void setCostAvailabilityIndicator(String costAvailabilityIndicator) {
        this.costAvailabilityIndicator = costAvailabilityIndicator;
    }

    public BUNDLEITEM1 withCostAvailabilityIndicator(String costAvailabilityIndicator) {
        this.costAvailabilityIndicator = costAvailabilityIndicator;
        return this;
    }

    @JsonProperty("ShipChargeIndicator")
    public String getShipChargeIndicator() {
        return shipChargeIndicator;
    }

    @JsonProperty("ShipChargeIndicator")
    public void setShipChargeIndicator(String shipChargeIndicator) {
        this.shipChargeIndicator = shipChargeIndicator;
    }

    public BUNDLEITEM1 withShipChargeIndicator(String shipChargeIndicator) {
        this.shipChargeIndicator = shipChargeIndicator;
        return this;
    }

    @JsonProperty("GuidanceAvailablityIndicator")
    public String getGuidanceAvailablityIndicator() {
        return guidanceAvailablityIndicator;
    }

    @JsonProperty("GuidanceAvailablityIndicator")
    public void setGuidanceAvailablityIndicator(String guidanceAvailablityIndicator) {
        this.guidanceAvailablityIndicator = guidanceAvailablityIndicator;
    }

    public BUNDLEITEM1 withGuidanceAvailablityIndicator(String guidanceAvailablityIndicator) {
        this.guidanceAvailablityIndicator = guidanceAvailablityIndicator;
        return this;
    }

    @JsonProperty("AuthorizationStatusCode")
    public String getAuthorizationStatusCode() {
        return authorizationStatusCode;
    }

    @JsonProperty("AuthorizationStatusCode")
    public void setAuthorizationStatusCode(String authorizationStatusCode) {
        this.authorizationStatusCode = authorizationStatusCode;
    }

    public BUNDLEITEM1 withAuthorizationStatusCode(String authorizationStatusCode) {
        this.authorizationStatusCode = authorizationStatusCode;
        return this;
    }

    @JsonProperty("InstantPricingMethodCode")
    public String getInstantPricingMethodCode() {
        return instantPricingMethodCode;
    }

    @JsonProperty("InstantPricingMethodCode")
    public void setInstantPricingMethodCode(String instantPricingMethodCode) {
        this.instantPricingMethodCode = instantPricingMethodCode;
    }

    public BUNDLEITEM1 withInstantPricingMethodCode(String instantPricingMethodCode) {
        this.instantPricingMethodCode = instantPricingMethodCode;
        return this;
    }

    @JsonProperty("MedallionLevelCode")
    public String getMedallionLevelCode() {
        return medallionLevelCode;
    }

    @JsonProperty("MedallionLevelCode")
    public void setMedallionLevelCode(String medallionLevelCode) {
        this.medallionLevelCode = medallionLevelCode;
    }

    public BUNDLEITEM1 withMedallionLevelCode(String medallionLevelCode) {
        this.medallionLevelCode = medallionLevelCode;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public BUNDLEITEM1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dealVersionNumber).append(bundleIdentifier).append(sAPDocumentNumber).append(materialLifeCycleIndicator).append(authorizedDate).append(authorizerByUserId).append(priceListCode).append(priceTermCode).append(bandedIndicator).append(productCostPriceAmount).append(productCostDate).append(previousRequestedGuidancePercentage).append(authorizerLineTypeCode).append(previousAuthorizationStatusIndicator).append(previousApprovedPriceAmount).append(requestBackEndContraAmount).append(authorizationBackEndContraAmount).append(requestNetRevenueAmount).append(authorizedNetRevenueAmount).append(externalContraAmount).append(requestNetMarginAmount).append(authorizedNetMarginAmount).append(requestNetMarginPercentage).append(authorizedNetMarginPercentage).append(instantPricingAmount).append(medallionNetAmount).append(itemSequenceNumber).append(bundleLineQuantity).append(standardDiscountPercentage).append(requestedBigDealNetAmount).append(authorizedGrossMarginAmount).append(bundleDescription).append(divisionCode).append(businessGroupCode).append(businessUnitCode).append(listPriceValueAmount).append(requestedAdditionalDiscountPercentage).append(requestedTotalPercentage).append(expertAdditionalPercentage).append(floorAdditionalPercentage).append(typicalAdditionalPercentage).append(previousRequestedAdditionalPercentage).append(authorizedBigDealNetAmount).append(authorizedAdditionalPercentage).append(authorizedTotalPercentage).append(costAvailabilityIndicator).append(shipChargeIndicator).append(guidanceAvailablityIndicator).append(authorizationStatusCode).append(instantPricingMethodCode).append(medallionLevelCode).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BUNDLEITEM1) == false) {
            return false;
        }
        BUNDLEITEM1 rhs = ((BUNDLEITEM1) other);
        return new EqualsBuilder().append(dealVersionNumber, rhs.dealVersionNumber).append(bundleIdentifier, rhs.bundleIdentifier).append(sAPDocumentNumber, rhs.sAPDocumentNumber).append(materialLifeCycleIndicator, rhs.materialLifeCycleIndicator).append(authorizedDate, rhs.authorizedDate).append(authorizerByUserId, rhs.authorizerByUserId).append(priceListCode, rhs.priceListCode).append(priceTermCode, rhs.priceTermCode).append(bandedIndicator, rhs.bandedIndicator).append(productCostPriceAmount, rhs.productCostPriceAmount).append(productCostDate, rhs.productCostDate).append(previousRequestedGuidancePercentage, rhs.previousRequestedGuidancePercentage).append(authorizerLineTypeCode, rhs.authorizerLineTypeCode).append(previousAuthorizationStatusIndicator, rhs.previousAuthorizationStatusIndicator).append(previousApprovedPriceAmount, rhs.previousApprovedPriceAmount).append(requestBackEndContraAmount, rhs.requestBackEndContraAmount).append(authorizationBackEndContraAmount, rhs.authorizationBackEndContraAmount).append(requestNetRevenueAmount, rhs.requestNetRevenueAmount).append(authorizedNetRevenueAmount, rhs.authorizedNetRevenueAmount).append(externalContraAmount, rhs.externalContraAmount).append(requestNetMarginAmount, rhs.requestNetMarginAmount).append(authorizedNetMarginAmount, rhs.authorizedNetMarginAmount).append(requestNetMarginPercentage, rhs.requestNetMarginPercentage).append(authorizedNetMarginPercentage, rhs.authorizedNetMarginPercentage).append(instantPricingAmount, rhs.instantPricingAmount).append(medallionNetAmount, rhs.medallionNetAmount).append(itemSequenceNumber, rhs.itemSequenceNumber).append(bundleLineQuantity, rhs.bundleLineQuantity).append(standardDiscountPercentage, rhs.standardDiscountPercentage).append(requestedBigDealNetAmount, rhs.requestedBigDealNetAmount).append(authorizedGrossMarginAmount, rhs.authorizedGrossMarginAmount).append(bundleDescription, rhs.bundleDescription).append(divisionCode, rhs.divisionCode).append(businessGroupCode, rhs.businessGroupCode).append(businessUnitCode, rhs.businessUnitCode).append(listPriceValueAmount, rhs.listPriceValueAmount).append(requestedAdditionalDiscountPercentage, rhs.requestedAdditionalDiscountPercentage).append(requestedTotalPercentage, rhs.requestedTotalPercentage).append(expertAdditionalPercentage, rhs.expertAdditionalPercentage).append(floorAdditionalPercentage, rhs.floorAdditionalPercentage).append(typicalAdditionalPercentage, rhs.typicalAdditionalPercentage).append(previousRequestedAdditionalPercentage, rhs.previousRequestedAdditionalPercentage).append(authorizedBigDealNetAmount, rhs.authorizedBigDealNetAmount).append(authorizedAdditionalPercentage, rhs.authorizedAdditionalPercentage).append(authorizedTotalPercentage, rhs.authorizedTotalPercentage).append(costAvailabilityIndicator, rhs.costAvailabilityIndicator).append(shipChargeIndicator, rhs.shipChargeIndicator).append(guidanceAvailablityIndicator, rhs.guidanceAvailablityIndicator).append(authorizationStatusCode, rhs.authorizationStatusCode).append(instantPricingMethodCode, rhs.instantPricingMethodCode).append(medallionLevelCode, rhs.medallionLevelCode).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
