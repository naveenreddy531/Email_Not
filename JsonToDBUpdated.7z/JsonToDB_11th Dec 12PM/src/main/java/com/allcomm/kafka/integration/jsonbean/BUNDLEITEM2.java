
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ExternalLineItemNumber",
    "AuthorizedPercentage",
    "RequestedGrossMarginAmount",
    "RequestedGrossMarginPer",
    "AuthorizedGrossMarginPercentage",
    "ExtendedRequestBigDealNetAmount",
    "ExtendedAuthorizedBigDealNetAmount",
    "ExtendedListPriceAmount",
    "AuthorizationStatusDescription",
    "MaterialIdentifier"
})
public class BUNDLEITEM2 {

    @JsonProperty("ExternalLineItemNumber")
    private String externalLineItemNumber;
    @JsonProperty("AuthorizedPercentage")
    private String authorizedPercentage;
    @JsonProperty("RequestedGrossMarginAmount")
    private String requestedGrossMarginAmount;
    @JsonProperty("RequestedGrossMarginPer")
    private String requestedGrossMarginPer;
    @JsonProperty("AuthorizedGrossMarginPercentage")
    private String authorizedGrossMarginPercentage;
    @JsonProperty("ExtendedRequestBigDealNetAmount")
    private String extendedRequestBigDealNetAmount;
    @JsonProperty("ExtendedAuthorizedBigDealNetAmount")
    private String extendedAuthorizedBigDealNetAmount;
    @JsonProperty("ExtendedListPriceAmount")
    private String extendedListPriceAmount;
    @JsonProperty("AuthorizationStatusDescription")
    private String authorizationStatusDescription;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ExternalLineItemNumber")
    public String getExternalLineItemNumber() {
        return externalLineItemNumber;
    }

    @JsonProperty("ExternalLineItemNumber")
    public void setExternalLineItemNumber(String externalLineItemNumber) {
        this.externalLineItemNumber = externalLineItemNumber;
    }

    public BUNDLEITEM2 withExternalLineItemNumber(String externalLineItemNumber) {
        this.externalLineItemNumber = externalLineItemNumber;
        return this;
    }

    @JsonProperty("AuthorizedPercentage")
    public String getAuthorizedPercentage() {
        return authorizedPercentage;
    }

    @JsonProperty("AuthorizedPercentage")
    public void setAuthorizedPercentage(String authorizedPercentage) {
        this.authorizedPercentage = authorizedPercentage;
    }

    public BUNDLEITEM2 withAuthorizedPercentage(String authorizedPercentage) {
        this.authorizedPercentage = authorizedPercentage;
        return this;
    }

    @JsonProperty("RequestedGrossMarginAmount")
    public String getRequestedGrossMarginAmount() {
        return requestedGrossMarginAmount;
    }

    @JsonProperty("RequestedGrossMarginAmount")
    public void setRequestedGrossMarginAmount(String requestedGrossMarginAmount) {
        this.requestedGrossMarginAmount = requestedGrossMarginAmount;
    }

    public BUNDLEITEM2 withRequestedGrossMarginAmount(String requestedGrossMarginAmount) {
        this.requestedGrossMarginAmount = requestedGrossMarginAmount;
        return this;
    }

    @JsonProperty("RequestedGrossMarginPer")
    public String getRequestedGrossMarginPer() {
        return requestedGrossMarginPer;
    }

    @JsonProperty("RequestedGrossMarginPer")
    public void setRequestedGrossMarginPer(String requestedGrossMarginPer) {
        this.requestedGrossMarginPer = requestedGrossMarginPer;
    }

    public BUNDLEITEM2 withRequestedGrossMarginPer(String requestedGrossMarginPer) {
        this.requestedGrossMarginPer = requestedGrossMarginPer;
        return this;
    }

    @JsonProperty("AuthorizedGrossMarginPercentage")
    public String getAuthorizedGrossMarginPercentage() {
        return authorizedGrossMarginPercentage;
    }

    @JsonProperty("AuthorizedGrossMarginPercentage")
    public void setAuthorizedGrossMarginPercentage(String authorizedGrossMarginPercentage) {
        this.authorizedGrossMarginPercentage = authorizedGrossMarginPercentage;
    }

    public BUNDLEITEM2 withAuthorizedGrossMarginPercentage(String authorizedGrossMarginPercentage) {
        this.authorizedGrossMarginPercentage = authorizedGrossMarginPercentage;
        return this;
    }

    @JsonProperty("ExtendedRequestBigDealNetAmount")
    public String getExtendedRequestBigDealNetAmount() {
        return extendedRequestBigDealNetAmount;
    }

    @JsonProperty("ExtendedRequestBigDealNetAmount")
    public void setExtendedRequestBigDealNetAmount(String extendedRequestBigDealNetAmount) {
        this.extendedRequestBigDealNetAmount = extendedRequestBigDealNetAmount;
    }

    public BUNDLEITEM2 withExtendedRequestBigDealNetAmount(String extendedRequestBigDealNetAmount) {
        this.extendedRequestBigDealNetAmount = extendedRequestBigDealNetAmount;
        return this;
    }

    @JsonProperty("ExtendedAuthorizedBigDealNetAmount")
    public String getExtendedAuthorizedBigDealNetAmount() {
        return extendedAuthorizedBigDealNetAmount;
    }

    @JsonProperty("ExtendedAuthorizedBigDealNetAmount")
    public void setExtendedAuthorizedBigDealNetAmount(String extendedAuthorizedBigDealNetAmount) {
        this.extendedAuthorizedBigDealNetAmount = extendedAuthorizedBigDealNetAmount;
    }

    public BUNDLEITEM2 withExtendedAuthorizedBigDealNetAmount(String extendedAuthorizedBigDealNetAmount) {
        this.extendedAuthorizedBigDealNetAmount = extendedAuthorizedBigDealNetAmount;
        return this;
    }

    @JsonProperty("ExtendedListPriceAmount")
    public String getExtendedListPriceAmount() {
        return extendedListPriceAmount;
    }

    @JsonProperty("ExtendedListPriceAmount")
    public void setExtendedListPriceAmount(String extendedListPriceAmount) {
        this.extendedListPriceAmount = extendedListPriceAmount;
    }

    public BUNDLEITEM2 withExtendedListPriceAmount(String extendedListPriceAmount) {
        this.extendedListPriceAmount = extendedListPriceAmount;
        return this;
    }

    @JsonProperty("AuthorizationStatusDescription")
    public String getAuthorizationStatusDescription() {
        return authorizationStatusDescription;
    }

    @JsonProperty("AuthorizationStatusDescription")
    public void setAuthorizationStatusDescription(String authorizationStatusDescription) {
        this.authorizationStatusDescription = authorizationStatusDescription;
    }

    public BUNDLEITEM2 withAuthorizationStatusDescription(String authorizationStatusDescription) {
        this.authorizationStatusDescription = authorizationStatusDescription;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public BUNDLEITEM2 withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public BUNDLEITEM2 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(externalLineItemNumber).append(authorizedPercentage).append(requestedGrossMarginAmount).append(requestedGrossMarginPer).append(authorizedGrossMarginPercentage).append(extendedRequestBigDealNetAmount).append(extendedAuthorizedBigDealNetAmount).append(extendedListPriceAmount).append(authorizationStatusDescription).append(materialIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BUNDLEITEM2) == false) {
            return false;
        }
        BUNDLEITEM2 rhs = ((BUNDLEITEM2) other);
        return new EqualsBuilder().append(externalLineItemNumber, rhs.externalLineItemNumber).append(authorizedPercentage, rhs.authorizedPercentage).append(requestedGrossMarginAmount, rhs.requestedGrossMarginAmount).append(requestedGrossMarginPer, rhs.requestedGrossMarginPer).append(authorizedGrossMarginPercentage, rhs.authorizedGrossMarginPercentage).append(extendedRequestBigDealNetAmount, rhs.extendedRequestBigDealNetAmount).append(extendedAuthorizedBigDealNetAmount, rhs.extendedAuthorizedBigDealNetAmount).append(extendedListPriceAmount, rhs.extendedListPriceAmount).append(authorizationStatusDescription, rhs.authorizationStatusDescription).append(materialIdentifier, rhs.materialIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
