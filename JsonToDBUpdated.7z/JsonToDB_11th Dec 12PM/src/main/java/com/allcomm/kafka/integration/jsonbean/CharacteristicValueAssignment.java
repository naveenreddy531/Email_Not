
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "ObjectIdentifier",
    "InternalCharacteristicCode",
    "SequenceNumber",
    "ClassTypeCode",
    "ObjectClassCode",
    "ClassStatusCode",
    "CharacteristicValueText",
    "CharacteristicName",
    "ValidEndDate"
})
public class CharacteristicValueAssignment {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("ObjectIdentifier")
    private String objectIdentifier;
    @JsonProperty("InternalCharacteristicCode")
    private Integer internalCharacteristicCode;
    @JsonProperty("SequenceNumber")
    private Integer sequenceNumber;
    @JsonProperty("ClassTypeCode")
    private String classTypeCode;
    @JsonProperty("ObjectClassCode")
    private String objectClassCode;
    @JsonProperty("ClassStatusCode")
    private String classStatusCode;
    @JsonProperty("CharacteristicValueText")
    private String characteristicValueText;
    @JsonProperty("CharacteristicName")
    private String characteristicName;
    @JsonProperty("ValidEndDate")
    private String validEndDate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public CharacteristicValueAssignment withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("ObjectIdentifier")
    public String getObjectIdentifier() {
        return objectIdentifier;
    }

    @JsonProperty("ObjectIdentifier")
    public void setObjectIdentifier(String objectIdentifier) {
        this.objectIdentifier = objectIdentifier;
    }

    public CharacteristicValueAssignment withObjectIdentifier(String objectIdentifier) {
        this.objectIdentifier = objectIdentifier;
        return this;
    }

    @JsonProperty("InternalCharacteristicCode")
    public Integer getInternalCharacteristicCode() {
        return internalCharacteristicCode;
    }

    @JsonProperty("InternalCharacteristicCode")
    public void setInternalCharacteristicCode(Integer internalCharacteristicCode) {
        this.internalCharacteristicCode = internalCharacteristicCode;
    }

    public CharacteristicValueAssignment withInternalCharacteristicCode(Integer internalCharacteristicCode) {
        this.internalCharacteristicCode = internalCharacteristicCode;
        return this;
    }

    @JsonProperty("SequenceNumber")
    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    @JsonProperty("SequenceNumber")
    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public CharacteristicValueAssignment withSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
        return this;
    }

    @JsonProperty("ClassTypeCode")
    public String getClassTypeCode() {
        return classTypeCode;
    }

    @JsonProperty("ClassTypeCode")
    public void setClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
    }

    public CharacteristicValueAssignment withClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
        return this;
    }

    @JsonProperty("ObjectClassCode")
    public String getObjectClassCode() {
        return objectClassCode;
    }

    @JsonProperty("ObjectClassCode")
    public void setObjectClassCode(String objectClassCode) {
        this.objectClassCode = objectClassCode;
    }

    public CharacteristicValueAssignment withObjectClassCode(String objectClassCode) {
        this.objectClassCode = objectClassCode;
        return this;
    }

    @JsonProperty("ClassStatusCode")
    public String getClassStatusCode() {
        return classStatusCode;
    }

    @JsonProperty("ClassStatusCode")
    public void setClassStatusCode(String classStatusCode) {
        this.classStatusCode = classStatusCode;
    }

    public CharacteristicValueAssignment withClassStatusCode(String classStatusCode) {
        this.classStatusCode = classStatusCode;
        return this;
    }

    @JsonProperty("CharacteristicValueText")
    public String getCharacteristicValueText() {
        return characteristicValueText;
    }

    @JsonProperty("CharacteristicValueText")
    public void setCharacteristicValueText(String characteristicValueText) {
        this.characteristicValueText = characteristicValueText;
    }

    public CharacteristicValueAssignment withCharacteristicValueText(String characteristicValueText) {
        this.characteristicValueText = characteristicValueText;
        return this;
    }

    @JsonProperty("CharacteristicName")
    public String getCharacteristicName() {
        return characteristicName;
    }

    @JsonProperty("CharacteristicName")
    public void setCharacteristicName(String characteristicName) {
        this.characteristicName = characteristicName;
    }

    public CharacteristicValueAssignment withCharacteristicName(String characteristicName) {
        this.characteristicName = characteristicName;
        return this;
    }

    @JsonProperty("ValidEndDate")
    public String getValidEndDate() {
        return validEndDate;
    }

    @JsonProperty("ValidEndDate")
    public void setValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
    }

    public CharacteristicValueAssignment withValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CharacteristicValueAssignment withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(objectIdentifier).append(internalCharacteristicCode).append(sequenceNumber).append(classTypeCode).append(objectClassCode).append(classStatusCode).append(characteristicValueText).append(characteristicName).append(validEndDate).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CharacteristicValueAssignment) == false) {
            return false;
        }
        CharacteristicValueAssignment rhs = ((CharacteristicValueAssignment) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(objectIdentifier, rhs.objectIdentifier).append(internalCharacteristicCode, rhs.internalCharacteristicCode).append(sequenceNumber, rhs.sequenceNumber).append(classTypeCode, rhs.classTypeCode).append(objectClassCode, rhs.objectClassCode).append(classStatusCode, rhs.classStatusCode).append(characteristicValueText, rhs.characteristicValueText).append(characteristicName, rhs.characteristicName).append(validEndDate, rhs.validEndDate).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
