
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "InternalClassNumber",
    "ClassTypeCode",
    "ClassIdentifier",
    "ClassStatusCode",
    "ClassGroupCode",
    "ValidStartDate",
    "ValidEndDate",
    "CreatedByUserID",
    "SourceSystemCreateTimestamp",
    "SourceSystemUpdateTimestamp",
    "ClassTypeStatus",
    "ClassGroup",
    "UpdatedByUserID"
})
public class ClassHeader {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("InternalClassNumber")
    private Integer internalClassNumber;
    @JsonProperty("ClassTypeCode")
    private String classTypeCode;
    @JsonProperty("ClassIdentifier")
    private String classIdentifier;
    @JsonProperty("ClassStatusCode")
    private String classStatusCode;
    @JsonProperty("ClassGroupCode")
    private String classGroupCode;
    @JsonProperty("ValidStartDate")
    private String validStartDate;
    @JsonProperty("ValidEndDate")
    private String validEndDate;
    @JsonProperty("CreatedByUserID")
    private String createdByUserID;
    @JsonProperty("SourceSystemCreateTimestamp")
    private String sourceSystemCreateTimestamp;
    @JsonProperty("SourceSystemUpdateTimestamp")
    private String sourceSystemUpdateTimestamp;
    @JsonProperty("ClassTypeStatus")
    private ClassTypeStatus_ classTypeStatus;
    @JsonProperty("ClassGroup")
    private ClassGroup classGroup;
    @JsonProperty("UpdatedByUserID")
    private String updatedByUserID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public ClassHeader withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("InternalClassNumber")
    public Integer getInternalClassNumber() {
        return internalClassNumber;
    }

    @JsonProperty("InternalClassNumber")
    public void setInternalClassNumber(Integer internalClassNumber) {
        this.internalClassNumber = internalClassNumber;
    }

    public ClassHeader withInternalClassNumber(Integer internalClassNumber) {
        this.internalClassNumber = internalClassNumber;
        return this;
    }

    @JsonProperty("ClassTypeCode")
    public String getClassTypeCode() {
        return classTypeCode;
    }

    @JsonProperty("ClassTypeCode")
    public void setClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
    }

    public ClassHeader withClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
        return this;
    }

    @JsonProperty("ClassIdentifier")
    public String getClassIdentifier() {
        return classIdentifier;
    }

    @JsonProperty("ClassIdentifier")
    public void setClassIdentifier(String classIdentifier) {
        this.classIdentifier = classIdentifier;
    }

    public ClassHeader withClassIdentifier(String classIdentifier) {
        this.classIdentifier = classIdentifier;
        return this;
    }

    @JsonProperty("ClassStatusCode")
    public String getClassStatusCode() {
        return classStatusCode;
    }

    @JsonProperty("ClassStatusCode")
    public void setClassStatusCode(String classStatusCode) {
        this.classStatusCode = classStatusCode;
    }

    public ClassHeader withClassStatusCode(String classStatusCode) {
        this.classStatusCode = classStatusCode;
        return this;
    }

    @JsonProperty("ClassGroupCode")
    public String getClassGroupCode() {
        return classGroupCode;
    }

    @JsonProperty("ClassGroupCode")
    public void setClassGroupCode(String classGroupCode) {
        this.classGroupCode = classGroupCode;
    }

    public ClassHeader withClassGroupCode(String classGroupCode) {
        this.classGroupCode = classGroupCode;
        return this;
    }

    @JsonProperty("ValidStartDate")
    public String getValidStartDate() {
        return validStartDate;
    }

    @JsonProperty("ValidStartDate")
    public void setValidStartDate(String validStartDate) {
        this.validStartDate = validStartDate;
    }

    public ClassHeader withValidStartDate(String validStartDate) {
        this.validStartDate = validStartDate;
        return this;
    }

    @JsonProperty("ValidEndDate")
    public String getValidEndDate() {
        return validEndDate;
    }

    @JsonProperty("ValidEndDate")
    public void setValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
    }

    public ClassHeader withValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
        return this;
    }

    @JsonProperty("CreatedByUserID")
    public String getCreatedByUserID() {
        return createdByUserID;
    }

    @JsonProperty("CreatedByUserID")
    public void setCreatedByUserID(String createdByUserID) {
        this.createdByUserID = createdByUserID;
    }

    public ClassHeader withCreatedByUserID(String createdByUserID) {
        this.createdByUserID = createdByUserID;
        return this;
    }

    @JsonProperty("SourceSystemCreateTimestamp")
    public String getSourceSystemCreateTimestamp() {
        return sourceSystemCreateTimestamp;
    }

    @JsonProperty("SourceSystemCreateTimestamp")
    public void setSourceSystemCreateTimestamp(String sourceSystemCreateTimestamp) {
        this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
    }

    public ClassHeader withSourceSystemCreateTimestamp(String sourceSystemCreateTimestamp) {
        this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
        return this;
    }

    @JsonProperty("SourceSystemUpdateTimestamp")
    public String getSourceSystemUpdateTimestamp() {
        return sourceSystemUpdateTimestamp;
    }

    @JsonProperty("SourceSystemUpdateTimestamp")
    public void setSourceSystemUpdateTimestamp(String sourceSystemUpdateTimestamp) {
        this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
    }

    public ClassHeader withSourceSystemUpdateTimestamp(String sourceSystemUpdateTimestamp) {
        this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
        return this;
    }

    @JsonProperty("ClassTypeStatus")
    public ClassTypeStatus_ getClassTypeStatus() {
        return classTypeStatus;
    }

    @JsonProperty("ClassTypeStatus")
    public void setClassTypeStatus(ClassTypeStatus_ classTypeStatus) {
        this.classTypeStatus = classTypeStatus;
    }

    public ClassHeader withClassTypeStatus(ClassTypeStatus_ classTypeStatus) {
        this.classTypeStatus = classTypeStatus;
        return this;
    }

    @JsonProperty("ClassGroup")
    public ClassGroup getClassGroup() {
        return classGroup;
    }

    @JsonProperty("ClassGroup")
    public void setClassGroup(ClassGroup classGroup) {
        this.classGroup = classGroup;
    }

    public ClassHeader withClassGroup(ClassGroup classGroup) {
        this.classGroup = classGroup;
        return this;
    }

    @JsonProperty("UpdatedByUserID")
    public String getUpdatedByUserID() {
        return updatedByUserID;
    }

    @JsonProperty("UpdatedByUserID")
    public void setUpdatedByUserID(String updatedByUserID) {
        this.updatedByUserID = updatedByUserID;
    }

    public ClassHeader withUpdatedByUserID(String updatedByUserID) {
        this.updatedByUserID = updatedByUserID;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ClassHeader withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(internalClassNumber).append(classTypeCode).append(classIdentifier).append(classStatusCode).append(classGroupCode).append(validStartDate).append(validEndDate).append(createdByUserID).append(sourceSystemCreateTimestamp).append(sourceSystemUpdateTimestamp).append(classTypeStatus).append(classGroup).append(updatedByUserID).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ClassHeader) == false) {
            return false;
        }
        ClassHeader rhs = ((ClassHeader) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(internalClassNumber, rhs.internalClassNumber).append(classTypeCode, rhs.classTypeCode).append(classIdentifier, rhs.classIdentifier).append(classStatusCode, rhs.classStatusCode).append(classGroupCode, rhs.classGroupCode).append(validStartDate, rhs.validStartDate).append(validEndDate, rhs.validEndDate).append(createdByUserID, rhs.createdByUserID).append(sourceSystemCreateTimestamp, rhs.sourceSystemCreateTimestamp).append(sourceSystemUpdateTimestamp, rhs.sourceSystemUpdateTimestamp).append(classTypeStatus, rhs.classTypeStatus).append(classGroup, rhs.classGroup).append(updatedByUserID, rhs.updatedByUserID).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
