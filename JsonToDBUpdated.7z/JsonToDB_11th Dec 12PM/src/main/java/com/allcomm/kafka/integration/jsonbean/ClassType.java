
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "ClassTypeCode",
    "ClassTypeDescription",
    "ClassTypeStatus"
})
public class ClassType {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("ClassTypeCode")
    private String classTypeCode;
    @JsonProperty("ClassTypeDescription")
    private String classTypeDescription;
    @JsonProperty("ClassTypeStatus")
    private ClassTypeStatus classTypeStatus;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public ClassType withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("ClassTypeCode")
    public String getClassTypeCode() {
        return classTypeCode;
    }

    @JsonProperty("ClassTypeCode")
    public void setClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
    }

    public ClassType withClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
        return this;
    }

    @JsonProperty("ClassTypeDescription")
    public String getClassTypeDescription() {
        return classTypeDescription;
    }

    @JsonProperty("ClassTypeDescription")
    public void setClassTypeDescription(String classTypeDescription) {
        this.classTypeDescription = classTypeDescription;
    }

    public ClassType withClassTypeDescription(String classTypeDescription) {
        this.classTypeDescription = classTypeDescription;
        return this;
    }

    @JsonProperty("ClassTypeStatus")
    public ClassTypeStatus getClassTypeStatus() {
        return classTypeStatus;
    }

    @JsonProperty("ClassTypeStatus")
    public void setClassTypeStatus(ClassTypeStatus classTypeStatus) {
        this.classTypeStatus = classTypeStatus;
    }

    public ClassType withClassTypeStatus(ClassTypeStatus classTypeStatus) {
        this.classTypeStatus = classTypeStatus;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ClassType withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(classTypeCode).append(classTypeDescription).append(classTypeStatus).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ClassType) == false) {
            return false;
        }
        ClassType rhs = ((ClassType) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(classTypeCode, rhs.classTypeCode).append(classTypeDescription, rhs.classTypeDescription).append(classTypeStatus, rhs.classTypeStatus).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
