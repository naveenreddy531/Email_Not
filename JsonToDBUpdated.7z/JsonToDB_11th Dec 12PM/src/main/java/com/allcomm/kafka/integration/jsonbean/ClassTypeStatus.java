
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "ClassTypeCode",
    "ClassStatusCode",
    "ClassStatusDescription",
    "CharacteristicValueAssignment"
})
public class ClassTypeStatus {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("ClassTypeCode")
    private String classTypeCode;
    @JsonProperty("ClassStatusCode")
    private String classStatusCode;
    @JsonProperty("ClassStatusDescription")
    private String classStatusDescription;
    @JsonProperty("CharacteristicValueAssignment")
    private List<CharacteristicValueAssignment> characteristicValueAssignment = new ArrayList<CharacteristicValueAssignment>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public ClassTypeStatus withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("ClassTypeCode")
    public String getClassTypeCode() {
        return classTypeCode;
    }

    @JsonProperty("ClassTypeCode")
    public void setClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
    }

    public ClassTypeStatus withClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
        return this;
    }

    @JsonProperty("ClassStatusCode")
    public String getClassStatusCode() {
        return classStatusCode;
    }

    @JsonProperty("ClassStatusCode")
    public void setClassStatusCode(String classStatusCode) {
        this.classStatusCode = classStatusCode;
    }

    public ClassTypeStatus withClassStatusCode(String classStatusCode) {
        this.classStatusCode = classStatusCode;
        return this;
    }

    @JsonProperty("ClassStatusDescription")
    public String getClassStatusDescription() {
        return classStatusDescription;
    }

    @JsonProperty("ClassStatusDescription")
    public void setClassStatusDescription(String classStatusDescription) {
        this.classStatusDescription = classStatusDescription;
    }

    public ClassTypeStatus withClassStatusDescription(String classStatusDescription) {
        this.classStatusDescription = classStatusDescription;
        return this;
    }

    @JsonProperty("CharacteristicValueAssignment")
    public List<CharacteristicValueAssignment> getCharacteristicValueAssignment() {
        return characteristicValueAssignment;
    }

    @JsonProperty("CharacteristicValueAssignment")
    public void setCharacteristicValueAssignment(List<CharacteristicValueAssignment> characteristicValueAssignment) {
        this.characteristicValueAssignment = characteristicValueAssignment;
    }

    public ClassTypeStatus withCharacteristicValueAssignment(List<CharacteristicValueAssignment> characteristicValueAssignment) {
        this.characteristicValueAssignment = characteristicValueAssignment;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ClassTypeStatus withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(classTypeCode).append(classStatusCode).append(classStatusDescription).append(characteristicValueAssignment).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ClassTypeStatus) == false) {
            return false;
        }
        ClassTypeStatus rhs = ((ClassTypeStatus) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(classTypeCode, rhs.classTypeCode).append(classStatusCode, rhs.classStatusCode).append(classStatusDescription, rhs.classStatusDescription).append(characteristicValueAssignment, rhs.characteristicValueAssignment).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
