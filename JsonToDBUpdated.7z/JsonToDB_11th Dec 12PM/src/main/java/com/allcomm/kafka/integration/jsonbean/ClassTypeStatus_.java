
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "ClassTypeCode",
    "ClassStatusCode",
    "ClassStatusDescription",
    "CharacteristicValueAssignment"
})
public class ClassTypeStatus_ {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("ClassTypeCode")
    private String classTypeCode;
    @JsonProperty("ClassStatusCode")
    private String classStatusCode;
    @JsonProperty("ClassStatusDescription")
    private String classStatusDescription;
    @JsonProperty("CharacteristicValueAssignment")
    private List<CharacteristicValueAssignment_> characteristicValueAssignment = new ArrayList<CharacteristicValueAssignment_>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public ClassTypeStatus_ withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("ClassTypeCode")
    public String getClassTypeCode() {
        return classTypeCode;
    }

    @JsonProperty("ClassTypeCode")
    public void setClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
    }

    public ClassTypeStatus_ withClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
        return this;
    }

    @JsonProperty("ClassStatusCode")
    public String getClassStatusCode() {
        return classStatusCode;
    }

    @JsonProperty("ClassStatusCode")
    public void setClassStatusCode(String classStatusCode) {
        this.classStatusCode = classStatusCode;
    }

    public ClassTypeStatus_ withClassStatusCode(String classStatusCode) {
        this.classStatusCode = classStatusCode;
        return this;
    }

    @JsonProperty("ClassStatusDescription")
    public String getClassStatusDescription() {
        return classStatusDescription;
    }

    @JsonProperty("ClassStatusDescription")
    public void setClassStatusDescription(String classStatusDescription) {
        this.classStatusDescription = classStatusDescription;
    }

    public ClassTypeStatus_ withClassStatusDescription(String classStatusDescription) {
        this.classStatusDescription = classStatusDescription;
        return this;
    }

    @JsonProperty("CharacteristicValueAssignment")
    public List<CharacteristicValueAssignment_> getCharacteristicValueAssignment() {
        return characteristicValueAssignment;
    }

    @JsonProperty("CharacteristicValueAssignment")
    public void setCharacteristicValueAssignment(List<CharacteristicValueAssignment_> characteristicValueAssignment) {
        this.characteristicValueAssignment = characteristicValueAssignment;
    }

    public ClassTypeStatus_ withCharacteristicValueAssignment(List<CharacteristicValueAssignment_> characteristicValueAssignment) {
        this.characteristicValueAssignment = characteristicValueAssignment;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ClassTypeStatus_ withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(classTypeCode).append(classStatusCode).append(classStatusDescription).append(characteristicValueAssignment).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ClassTypeStatus_) == false) {
            return false;
        }
        ClassTypeStatus_ rhs = ((ClassTypeStatus_) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(classTypeCode, rhs.classTypeCode).append(classStatusCode, rhs.classStatusCode).append(classStatusDescription, rhs.classStatusDescription).append(characteristicValueAssignment, rhs.characteristicValueAssignment).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
