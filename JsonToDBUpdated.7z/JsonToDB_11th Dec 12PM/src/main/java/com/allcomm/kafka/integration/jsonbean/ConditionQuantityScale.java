
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "PricingConditionIdentifier",
    "PricingConditionItemNumber",
    "ScaleLineSequenceNumber",
    "UnitListPriceAmount",
    "ScaleLineQuantity"
})
public class ConditionQuantityScale {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("PricingConditionIdentifier")
    private String pricingConditionIdentifier;
    @JsonProperty("PricingConditionItemNumber")
    private Integer pricingConditionItemNumber;
    @JsonProperty("ScaleLineSequenceNumber")
    private Integer scaleLineSequenceNumber;
    @JsonProperty("UnitListPriceAmount")
    private Integer unitListPriceAmount;
    @JsonProperty("ScaleLineQuantity")
    private Integer scaleLineQuantity;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public ConditionQuantityScale withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("PricingConditionIdentifier")
    public String getPricingConditionIdentifier() {
        return pricingConditionIdentifier;
    }

    @JsonProperty("PricingConditionIdentifier")
    public void setPricingConditionIdentifier(String pricingConditionIdentifier) {
        this.pricingConditionIdentifier = pricingConditionIdentifier;
    }

    public ConditionQuantityScale withPricingConditionIdentifier(String pricingConditionIdentifier) {
        this.pricingConditionIdentifier = pricingConditionIdentifier;
        return this;
    }

    @JsonProperty("PricingConditionItemNumber")
    public Integer getPricingConditionItemNumber() {
        return pricingConditionItemNumber;
    }

    @JsonProperty("PricingConditionItemNumber")
    public void setPricingConditionItemNumber(Integer pricingConditionItemNumber) {
        this.pricingConditionItemNumber = pricingConditionItemNumber;
    }

    public ConditionQuantityScale withPricingConditionItemNumber(Integer pricingConditionItemNumber) {
        this.pricingConditionItemNumber = pricingConditionItemNumber;
        return this;
    }

    @JsonProperty("ScaleLineSequenceNumber")
    public Integer getScaleLineSequenceNumber() {
        return scaleLineSequenceNumber;
    }

    @JsonProperty("ScaleLineSequenceNumber")
    public void setScaleLineSequenceNumber(Integer scaleLineSequenceNumber) {
        this.scaleLineSequenceNumber = scaleLineSequenceNumber;
    }

    public ConditionQuantityScale withScaleLineSequenceNumber(Integer scaleLineSequenceNumber) {
        this.scaleLineSequenceNumber = scaleLineSequenceNumber;
        return this;
    }

    @JsonProperty("UnitListPriceAmount")
    public Integer getUnitListPriceAmount() {
        return unitListPriceAmount;
    }

    @JsonProperty("UnitListPriceAmount")
    public void setUnitListPriceAmount(Integer unitListPriceAmount) {
        this.unitListPriceAmount = unitListPriceAmount;
    }

    public ConditionQuantityScale withUnitListPriceAmount(Integer unitListPriceAmount) {
        this.unitListPriceAmount = unitListPriceAmount;
        return this;
    }

    @JsonProperty("ScaleLineQuantity")
    public Integer getScaleLineQuantity() {
        return scaleLineQuantity;
    }

    @JsonProperty("ScaleLineQuantity")
    public void setScaleLineQuantity(Integer scaleLineQuantity) {
        this.scaleLineQuantity = scaleLineQuantity;
    }

    public ConditionQuantityScale withScaleLineQuantity(Integer scaleLineQuantity) {
        this.scaleLineQuantity = scaleLineQuantity;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ConditionQuantityScale withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(pricingConditionIdentifier).append(pricingConditionItemNumber).append(scaleLineSequenceNumber).append(unitListPriceAmount).append(scaleLineQuantity).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ConditionQuantityScale) == false) {
            return false;
        }
        ConditionQuantityScale rhs = ((ConditionQuantityScale) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(pricingConditionIdentifier, rhs.pricingConditionIdentifier).append(pricingConditionItemNumber, rhs.pricingConditionItemNumber).append(scaleLineSequenceNumber, rhs.scaleLineSequenceNumber).append(unitListPriceAmount, rhs.unitListPriceAmount).append(scaleLineQuantity, rhs.scaleLineQuantity).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
