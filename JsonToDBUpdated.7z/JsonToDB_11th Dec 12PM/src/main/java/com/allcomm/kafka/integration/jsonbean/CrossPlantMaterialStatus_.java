
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "CrossPlantMaterialStatusCode",
    "CrossPlantMaterialStatusDescription"
})
public class CrossPlantMaterialStatus_ {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("CrossPlantMaterialStatusCode")
    private String crossPlantMaterialStatusCode;
    @JsonProperty("CrossPlantMaterialStatusDescription")
    private String crossPlantMaterialStatusDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public CrossPlantMaterialStatus_ withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("CrossPlantMaterialStatusCode")
    public String getCrossPlantMaterialStatusCode() {
        return crossPlantMaterialStatusCode;
    }

    @JsonProperty("CrossPlantMaterialStatusCode")
    public void setCrossPlantMaterialStatusCode(String crossPlantMaterialStatusCode) {
        this.crossPlantMaterialStatusCode = crossPlantMaterialStatusCode;
    }

    public CrossPlantMaterialStatus_ withCrossPlantMaterialStatusCode(String crossPlantMaterialStatusCode) {
        this.crossPlantMaterialStatusCode = crossPlantMaterialStatusCode;
        return this;
    }

    @JsonProperty("CrossPlantMaterialStatusDescription")
    public String getCrossPlantMaterialStatusDescription() {
        return crossPlantMaterialStatusDescription;
    }

    @JsonProperty("CrossPlantMaterialStatusDescription")
    public void setCrossPlantMaterialStatusDescription(String crossPlantMaterialStatusDescription) {
        this.crossPlantMaterialStatusDescription = crossPlantMaterialStatusDescription;
    }

    public CrossPlantMaterialStatus_ withCrossPlantMaterialStatusDescription(String crossPlantMaterialStatusDescription) {
        this.crossPlantMaterialStatusDescription = crossPlantMaterialStatusDescription;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CrossPlantMaterialStatus_ withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(crossPlantMaterialStatusCode).append(crossPlantMaterialStatusDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CrossPlantMaterialStatus_) == false) {
            return false;
        }
        CrossPlantMaterialStatus_ rhs = ((CrossPlantMaterialStatus_) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(crossPlantMaterialStatusCode, rhs.crossPlantMaterialStatusCode).append(crossPlantMaterialStatusDescription, rhs.crossPlantMaterialStatusDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
