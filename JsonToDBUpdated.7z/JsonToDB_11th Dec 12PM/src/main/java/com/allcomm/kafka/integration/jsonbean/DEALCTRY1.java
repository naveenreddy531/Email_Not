
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CountryCode",
    "PriceGeographyCode",
    "PriceListTypeCode",
    "CurrencyCode",
    "InsertTimestamp",
    "UpdateTimestamp"
})
public class DEALCTRY1 {

    @JsonProperty("CountryCode")
    private String countryCode;
    @JsonProperty("PriceGeographyCode")
    private String priceGeographyCode;
    @JsonProperty("PriceListTypeCode")
    private String priceListTypeCode;
    @JsonProperty("CurrencyCode")
    private String currencyCode;
    @JsonProperty("InsertTimestamp")
    private String insertTimestamp;
    @JsonProperty("UpdateTimestamp")
    private String updateTimestamp;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CountryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("CountryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public DEALCTRY1 withCountryCode(String countryCode) {
        this.countryCode = countryCode;
        return this;
    }

    @JsonProperty("PriceGeographyCode")
    public String getPriceGeographyCode() {
        return priceGeographyCode;
    }

    @JsonProperty("PriceGeographyCode")
    public void setPriceGeographyCode(String priceGeographyCode) {
        this.priceGeographyCode = priceGeographyCode;
    }

    public DEALCTRY1 withPriceGeographyCode(String priceGeographyCode) {
        this.priceGeographyCode = priceGeographyCode;
        return this;
    }

    @JsonProperty("PriceListTypeCode")
    public String getPriceListTypeCode() {
        return priceListTypeCode;
    }

    @JsonProperty("PriceListTypeCode")
    public void setPriceListTypeCode(String priceListTypeCode) {
        this.priceListTypeCode = priceListTypeCode;
    }

    public DEALCTRY1 withPriceListTypeCode(String priceListTypeCode) {
        this.priceListTypeCode = priceListTypeCode;
        return this;
    }

    @JsonProperty("CurrencyCode")
    public String getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("CurrencyCode")
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public DEALCTRY1 withCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
        return this;
    }

    @JsonProperty("InsertTimestamp")
    public String getInsertTimestamp() {
        return insertTimestamp;
    }

    @JsonProperty("InsertTimestamp")
    public void setInsertTimestamp(String insertTimestamp) {
        this.insertTimestamp = insertTimestamp;
    }

    public DEALCTRY1 withInsertTimestamp(String insertTimestamp) {
        this.insertTimestamp = insertTimestamp;
        return this;
    }

    @JsonProperty("UpdateTimestamp")
    public String getUpdateTimestamp() {
        return updateTimestamp;
    }

    @JsonProperty("UpdateTimestamp")
    public void setUpdateTimestamp(String updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    public DEALCTRY1 withUpdateTimestamp(String updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DEALCTRY1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(countryCode).append(priceGeographyCode).append(priceListTypeCode).append(currencyCode).append(insertTimestamp).append(updateTimestamp).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DEALCTRY1) == false) {
            return false;
        }
        DEALCTRY1 rhs = ((DEALCTRY1) other);
        return new EqualsBuilder().append(countryCode, rhs.countryCode).append(priceGeographyCode, rhs.priceGeographyCode).append(priceListTypeCode, rhs.priceListTypeCode).append(currencyCode, rhs.currencyCode).append(insertTimestamp, rhs.insertTimestamp).append(updateTimestamp, rhs.updateTimestamp).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
