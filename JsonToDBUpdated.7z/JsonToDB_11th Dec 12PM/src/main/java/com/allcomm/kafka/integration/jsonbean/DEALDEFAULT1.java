
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ClientName",
    "ClientPassword",
    "RequestType",
    "HasCTOConfigFl",
    "PIUFL",
    "SingleBUFl",
    "DealApprFl",
    "DealQuoteFl",
    "DealRouteFl",
    "IgnoreDealEndDateValidations",
    "IgnoreDealHeaderUpdates",
    "IgnoreDuplicateExtQuoteNrCheck",
    "IgnoreHighRiskValidations",
    "IgnoreV0toV1Validations",
    "PerformDealRegAdjustmentsFl",
    "CanRecvQuoteFl",
    "DistActingOnBehalfPartnerFl",
    "PrimaryRslFl",
    "CurrencyProgramBenefit",
    "UseExternalListPriceFl",
    "EccBundle",
    "MDCPOrgID",
    "MDCPOtherPartyInstanceID",
    "MDCPOtherPartySiteID"
})
public class DEALDEFAULT1 {

    @JsonProperty("ClientName")
    private String clientName;
    @JsonProperty("ClientPassword")
    private String clientPassword;
    @JsonProperty("RequestType")
    private String requestType;
    @JsonProperty("HasCTOConfigFl")
    private String hasCTOConfigFl;
    @JsonProperty("PIUFL")
    private String pIUFL;
    @JsonProperty("SingleBUFl")
    private String singleBUFl;
    @JsonProperty("DealApprFl")
    private String dealApprFl;
    @JsonProperty("DealQuoteFl")
    private String dealQuoteFl;
    @JsonProperty("DealRouteFl")
    private String dealRouteFl;
    @JsonProperty("IgnoreDealEndDateValidations")
    private String ignoreDealEndDateValidations;
    @JsonProperty("IgnoreDealHeaderUpdates")
    private String ignoreDealHeaderUpdates;
    @JsonProperty("IgnoreDuplicateExtQuoteNrCheck")
    private String ignoreDuplicateExtQuoteNrCheck;
    @JsonProperty("IgnoreHighRiskValidations")
    private String ignoreHighRiskValidations;
    @JsonProperty("IgnoreV0toV1Validations")
    private String ignoreV0toV1Validations;
    @JsonProperty("PerformDealRegAdjustmentsFl")
    private String performDealRegAdjustmentsFl;
    @JsonProperty("CanRecvQuoteFl")
    private String canRecvQuoteFl;
    @JsonProperty("DistActingOnBehalfPartnerFl")
    private String distActingOnBehalfPartnerFl;
    @JsonProperty("PrimaryRslFl")
    private String primaryRslFl;
    @JsonProperty("CurrencyProgramBenefit")
    private String currencyProgramBenefit;
    @JsonProperty("UseExternalListPriceFl")
    private String useExternalListPriceFl;
    @JsonProperty("EccBundle")
    private String eccBundle;
    @JsonProperty("MDCPOrgID")
    private String mDCPOrgID;
    @JsonProperty("MDCPOtherPartyInstanceID")
    private String mDCPOtherPartyInstanceID;
    @JsonProperty("MDCPOtherPartySiteID")
    private String mDCPOtherPartySiteID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ClientName")
    public String getClientName() {
        return clientName;
    }

    @JsonProperty("ClientName")
    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public DEALDEFAULT1 withClientName(String clientName) {
        this.clientName = clientName;
        return this;
    }

    @JsonProperty("ClientPassword")
    public String getClientPassword() {
        return clientPassword;
    }

    @JsonProperty("ClientPassword")
    public void setClientPassword(String clientPassword) {
        this.clientPassword = clientPassword;
    }

    public DEALDEFAULT1 withClientPassword(String clientPassword) {
        this.clientPassword = clientPassword;
        return this;
    }

    @JsonProperty("RequestType")
    public String getRequestType() {
        return requestType;
    }

    @JsonProperty("RequestType")
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public DEALDEFAULT1 withRequestType(String requestType) {
        this.requestType = requestType;
        return this;
    }

    @JsonProperty("HasCTOConfigFl")
    public String getHasCTOConfigFl() {
        return hasCTOConfigFl;
    }

    @JsonProperty("HasCTOConfigFl")
    public void setHasCTOConfigFl(String hasCTOConfigFl) {
        this.hasCTOConfigFl = hasCTOConfigFl;
    }

    public DEALDEFAULT1 withHasCTOConfigFl(String hasCTOConfigFl) {
        this.hasCTOConfigFl = hasCTOConfigFl;
        return this;
    }

    @JsonProperty("PIUFL")
    public String getPIUFL() {
        return pIUFL;
    }

    @JsonProperty("PIUFL")
    public void setPIUFL(String pIUFL) {
        this.pIUFL = pIUFL;
    }

    public DEALDEFAULT1 withPIUFL(String pIUFL) {
        this.pIUFL = pIUFL;
        return this;
    }

    @JsonProperty("SingleBUFl")
    public String getSingleBUFl() {
        return singleBUFl;
    }

    @JsonProperty("SingleBUFl")
    public void setSingleBUFl(String singleBUFl) {
        this.singleBUFl = singleBUFl;
    }

    public DEALDEFAULT1 withSingleBUFl(String singleBUFl) {
        this.singleBUFl = singleBUFl;
        return this;
    }

    @JsonProperty("DealApprFl")
    public String getDealApprFl() {
        return dealApprFl;
    }

    @JsonProperty("DealApprFl")
    public void setDealApprFl(String dealApprFl) {
        this.dealApprFl = dealApprFl;
    }

    public DEALDEFAULT1 withDealApprFl(String dealApprFl) {
        this.dealApprFl = dealApprFl;
        return this;
    }

    @JsonProperty("DealQuoteFl")
    public String getDealQuoteFl() {
        return dealQuoteFl;
    }

    @JsonProperty("DealQuoteFl")
    public void setDealQuoteFl(String dealQuoteFl) {
        this.dealQuoteFl = dealQuoteFl;
    }

    public DEALDEFAULT1 withDealQuoteFl(String dealQuoteFl) {
        this.dealQuoteFl = dealQuoteFl;
        return this;
    }

    @JsonProperty("DealRouteFl")
    public String getDealRouteFl() {
        return dealRouteFl;
    }

    @JsonProperty("DealRouteFl")
    public void setDealRouteFl(String dealRouteFl) {
        this.dealRouteFl = dealRouteFl;
    }

    public DEALDEFAULT1 withDealRouteFl(String dealRouteFl) {
        this.dealRouteFl = dealRouteFl;
        return this;
    }

    @JsonProperty("IgnoreDealEndDateValidations")
    public String getIgnoreDealEndDateValidations() {
        return ignoreDealEndDateValidations;
    }

    @JsonProperty("IgnoreDealEndDateValidations")
    public void setIgnoreDealEndDateValidations(String ignoreDealEndDateValidations) {
        this.ignoreDealEndDateValidations = ignoreDealEndDateValidations;
    }

    public DEALDEFAULT1 withIgnoreDealEndDateValidations(String ignoreDealEndDateValidations) {
        this.ignoreDealEndDateValidations = ignoreDealEndDateValidations;
        return this;
    }

    @JsonProperty("IgnoreDealHeaderUpdates")
    public String getIgnoreDealHeaderUpdates() {
        return ignoreDealHeaderUpdates;
    }

    @JsonProperty("IgnoreDealHeaderUpdates")
    public void setIgnoreDealHeaderUpdates(String ignoreDealHeaderUpdates) {
        this.ignoreDealHeaderUpdates = ignoreDealHeaderUpdates;
    }

    public DEALDEFAULT1 withIgnoreDealHeaderUpdates(String ignoreDealHeaderUpdates) {
        this.ignoreDealHeaderUpdates = ignoreDealHeaderUpdates;
        return this;
    }

    @JsonProperty("IgnoreDuplicateExtQuoteNrCheck")
    public String getIgnoreDuplicateExtQuoteNrCheck() {
        return ignoreDuplicateExtQuoteNrCheck;
    }

    @JsonProperty("IgnoreDuplicateExtQuoteNrCheck")
    public void setIgnoreDuplicateExtQuoteNrCheck(String ignoreDuplicateExtQuoteNrCheck) {
        this.ignoreDuplicateExtQuoteNrCheck = ignoreDuplicateExtQuoteNrCheck;
    }

    public DEALDEFAULT1 withIgnoreDuplicateExtQuoteNrCheck(String ignoreDuplicateExtQuoteNrCheck) {
        this.ignoreDuplicateExtQuoteNrCheck = ignoreDuplicateExtQuoteNrCheck;
        return this;
    }

    @JsonProperty("IgnoreHighRiskValidations")
    public String getIgnoreHighRiskValidations() {
        return ignoreHighRiskValidations;
    }

    @JsonProperty("IgnoreHighRiskValidations")
    public void setIgnoreHighRiskValidations(String ignoreHighRiskValidations) {
        this.ignoreHighRiskValidations = ignoreHighRiskValidations;
    }

    public DEALDEFAULT1 withIgnoreHighRiskValidations(String ignoreHighRiskValidations) {
        this.ignoreHighRiskValidations = ignoreHighRiskValidations;
        return this;
    }

    @JsonProperty("IgnoreV0toV1Validations")
    public String getIgnoreV0toV1Validations() {
        return ignoreV0toV1Validations;
    }

    @JsonProperty("IgnoreV0toV1Validations")
    public void setIgnoreV0toV1Validations(String ignoreV0toV1Validations) {
        this.ignoreV0toV1Validations = ignoreV0toV1Validations;
    }

    public DEALDEFAULT1 withIgnoreV0toV1Validations(String ignoreV0toV1Validations) {
        this.ignoreV0toV1Validations = ignoreV0toV1Validations;
        return this;
    }

    @JsonProperty("PerformDealRegAdjustmentsFl")
    public String getPerformDealRegAdjustmentsFl() {
        return performDealRegAdjustmentsFl;
    }

    @JsonProperty("PerformDealRegAdjustmentsFl")
    public void setPerformDealRegAdjustmentsFl(String performDealRegAdjustmentsFl) {
        this.performDealRegAdjustmentsFl = performDealRegAdjustmentsFl;
    }

    public DEALDEFAULT1 withPerformDealRegAdjustmentsFl(String performDealRegAdjustmentsFl) {
        this.performDealRegAdjustmentsFl = performDealRegAdjustmentsFl;
        return this;
    }

    @JsonProperty("CanRecvQuoteFl")
    public String getCanRecvQuoteFl() {
        return canRecvQuoteFl;
    }

    @JsonProperty("CanRecvQuoteFl")
    public void setCanRecvQuoteFl(String canRecvQuoteFl) {
        this.canRecvQuoteFl = canRecvQuoteFl;
    }

    public DEALDEFAULT1 withCanRecvQuoteFl(String canRecvQuoteFl) {
        this.canRecvQuoteFl = canRecvQuoteFl;
        return this;
    }

    @JsonProperty("DistActingOnBehalfPartnerFl")
    public String getDistActingOnBehalfPartnerFl() {
        return distActingOnBehalfPartnerFl;
    }

    @JsonProperty("DistActingOnBehalfPartnerFl")
    public void setDistActingOnBehalfPartnerFl(String distActingOnBehalfPartnerFl) {
        this.distActingOnBehalfPartnerFl = distActingOnBehalfPartnerFl;
    }

    public DEALDEFAULT1 withDistActingOnBehalfPartnerFl(String distActingOnBehalfPartnerFl) {
        this.distActingOnBehalfPartnerFl = distActingOnBehalfPartnerFl;
        return this;
    }

    @JsonProperty("PrimaryRslFl")
    public String getPrimaryRslFl() {
        return primaryRslFl;
    }

    @JsonProperty("PrimaryRslFl")
    public void setPrimaryRslFl(String primaryRslFl) {
        this.primaryRslFl = primaryRslFl;
    }

    public DEALDEFAULT1 withPrimaryRslFl(String primaryRslFl) {
        this.primaryRslFl = primaryRslFl;
        return this;
    }

    @JsonProperty("CurrencyProgramBenefit")
    public String getCurrencyProgramBenefit() {
        return currencyProgramBenefit;
    }

    @JsonProperty("CurrencyProgramBenefit")
    public void setCurrencyProgramBenefit(String currencyProgramBenefit) {
        this.currencyProgramBenefit = currencyProgramBenefit;
    }

    public DEALDEFAULT1 withCurrencyProgramBenefit(String currencyProgramBenefit) {
        this.currencyProgramBenefit = currencyProgramBenefit;
        return this;
    }

    @JsonProperty("UseExternalListPriceFl")
    public String getUseExternalListPriceFl() {
        return useExternalListPriceFl;
    }

    @JsonProperty("UseExternalListPriceFl")
    public void setUseExternalListPriceFl(String useExternalListPriceFl) {
        this.useExternalListPriceFl = useExternalListPriceFl;
    }

    public DEALDEFAULT1 withUseExternalListPriceFl(String useExternalListPriceFl) {
        this.useExternalListPriceFl = useExternalListPriceFl;
        return this;
    }

    @JsonProperty("EccBundle")
    public String getEccBundle() {
        return eccBundle;
    }

    @JsonProperty("EccBundle")
    public void setEccBundle(String eccBundle) {
        this.eccBundle = eccBundle;
    }

    public DEALDEFAULT1 withEccBundle(String eccBundle) {
        this.eccBundle = eccBundle;
        return this;
    }

    @JsonProperty("MDCPOrgID")
    public String getMDCPOrgID() {
        return mDCPOrgID;
    }

    @JsonProperty("MDCPOrgID")
    public void setMDCPOrgID(String mDCPOrgID) {
        this.mDCPOrgID = mDCPOrgID;
    }

    public DEALDEFAULT1 withMDCPOrgID(String mDCPOrgID) {
        this.mDCPOrgID = mDCPOrgID;
        return this;
    }

    @JsonProperty("MDCPOtherPartyInstanceID")
    public String getMDCPOtherPartyInstanceID() {
        return mDCPOtherPartyInstanceID;
    }

    @JsonProperty("MDCPOtherPartyInstanceID")
    public void setMDCPOtherPartyInstanceID(String mDCPOtherPartyInstanceID) {
        this.mDCPOtherPartyInstanceID = mDCPOtherPartyInstanceID;
    }

    public DEALDEFAULT1 withMDCPOtherPartyInstanceID(String mDCPOtherPartyInstanceID) {
        this.mDCPOtherPartyInstanceID = mDCPOtherPartyInstanceID;
        return this;
    }

    @JsonProperty("MDCPOtherPartySiteID")
    public String getMDCPOtherPartySiteID() {
        return mDCPOtherPartySiteID;
    }

    @JsonProperty("MDCPOtherPartySiteID")
    public void setMDCPOtherPartySiteID(String mDCPOtherPartySiteID) {
        this.mDCPOtherPartySiteID = mDCPOtherPartySiteID;
    }

    public DEALDEFAULT1 withMDCPOtherPartySiteID(String mDCPOtherPartySiteID) {
        this.mDCPOtherPartySiteID = mDCPOtherPartySiteID;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DEALDEFAULT1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(clientName).append(clientPassword).append(requestType).append(hasCTOConfigFl).append(pIUFL).append(singleBUFl).append(dealApprFl).append(dealQuoteFl).append(dealRouteFl).append(ignoreDealEndDateValidations).append(ignoreDealHeaderUpdates).append(ignoreDuplicateExtQuoteNrCheck).append(ignoreHighRiskValidations).append(ignoreV0toV1Validations).append(performDealRegAdjustmentsFl).append(canRecvQuoteFl).append(distActingOnBehalfPartnerFl).append(primaryRslFl).append(currencyProgramBenefit).append(useExternalListPriceFl).append(eccBundle).append(mDCPOrgID).append(mDCPOtherPartyInstanceID).append(mDCPOtherPartySiteID).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DEALDEFAULT1) == false) {
            return false;
        }
        DEALDEFAULT1 rhs = ((DEALDEFAULT1) other);
        return new EqualsBuilder().append(clientName, rhs.clientName).append(clientPassword, rhs.clientPassword).append(requestType, rhs.requestType).append(hasCTOConfigFl, rhs.hasCTOConfigFl).append(pIUFL, rhs.pIUFL).append(singleBUFl, rhs.singleBUFl).append(dealApprFl, rhs.dealApprFl).append(dealQuoteFl, rhs.dealQuoteFl).append(dealRouteFl, rhs.dealRouteFl).append(ignoreDealEndDateValidations, rhs.ignoreDealEndDateValidations).append(ignoreDealHeaderUpdates, rhs.ignoreDealHeaderUpdates).append(ignoreDuplicateExtQuoteNrCheck, rhs.ignoreDuplicateExtQuoteNrCheck).append(ignoreHighRiskValidations, rhs.ignoreHighRiskValidations).append(ignoreV0toV1Validations, rhs.ignoreV0toV1Validations).append(performDealRegAdjustmentsFl, rhs.performDealRegAdjustmentsFl).append(canRecvQuoteFl, rhs.canRecvQuoteFl).append(distActingOnBehalfPartnerFl, rhs.distActingOnBehalfPartnerFl).append(primaryRslFl, rhs.primaryRslFl).append(currencyProgramBenefit, rhs.currencyProgramBenefit).append(useExternalListPriceFl, rhs.useExternalListPriceFl).append(eccBundle, rhs.eccBundle).append(mDCPOrgID, rhs.mDCPOrgID).append(mDCPOtherPartyInstanceID, rhs.mDCPOtherPartyInstanceID).append(mDCPOtherPartySiteID, rhs.mDCPOtherPartySiteID).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
