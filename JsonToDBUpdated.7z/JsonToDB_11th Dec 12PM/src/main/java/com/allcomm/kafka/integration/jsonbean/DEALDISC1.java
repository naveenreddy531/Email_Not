
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ScaleIdentifier",
    "ScaleStartDate",
    "DealLineItemNumber",
    "DealVersionNumber",
    "DealIdentifier",
    "SourceSystemCode",
    "RequestedIncrementalDiscountAmount",
    "AuthorizedIncrementalDiscountAmount",
    "StandardDiscountPercentage",
    "DiscountPercentage",
    "MaximumBoundaryAmount",
    "MinimumBoundaryAmount",
    "ScaleEndDate",
    "RequestedDiscountPercentage",
    "SourceSystemCreateDate",
    "SourceSystemUpdateDate",
    "AuthorizedStatusCode",
    "ProductCostAmount",
    "CostStatusCode",
    "RequestedFixedDiscountAmount",
    "AuthorizedFixedDiscountAmount",
    "TargetAdditionalDiscountPercentage",
    "MinimumMarginalDiscountPercentage",
    "TargetMarginalDiscountPercentage",
    "LineProgressIndiator",
    "MedallionNetAmount",
    "InsertTimestamp",
    "UpdateTimestamp"
})
public class DEALDISC1 {

    @JsonProperty("ScaleIdentifier")
    private String scaleIdentifier;
    @JsonProperty("ScaleStartDate")
    private String scaleStartDate;
    @JsonProperty("DealLineItemNumber")
    private String dealLineItemNumber;
    @JsonProperty("DealVersionNumber")
    private String dealVersionNumber;
    @JsonProperty("DealIdentifier")
    private String dealIdentifier;
    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("RequestedIncrementalDiscountAmount")
    private String requestedIncrementalDiscountAmount;
    @JsonProperty("AuthorizedIncrementalDiscountAmount")
    private String authorizedIncrementalDiscountAmount;
    @JsonProperty("StandardDiscountPercentage")
    private String standardDiscountPercentage;
    @JsonProperty("DiscountPercentage")
    private String discountPercentage;
    @JsonProperty("MaximumBoundaryAmount")
    private String maximumBoundaryAmount;
    @JsonProperty("MinimumBoundaryAmount")
    private String minimumBoundaryAmount;
    @JsonProperty("ScaleEndDate")
    private String scaleEndDate;
    @JsonProperty("RequestedDiscountPercentage")
    private String requestedDiscountPercentage;
    @JsonProperty("SourceSystemCreateDate")
    private String sourceSystemCreateDate;
    @JsonProperty("SourceSystemUpdateDate")
    private String sourceSystemUpdateDate;
    @JsonProperty("AuthorizedStatusCode")
    private String authorizedStatusCode;
    @JsonProperty("ProductCostAmount")
    private String productCostAmount;
    @JsonProperty("CostStatusCode")
    private String costStatusCode;
    @JsonProperty("RequestedFixedDiscountAmount")
    private String requestedFixedDiscountAmount;
    @JsonProperty("AuthorizedFixedDiscountAmount")
    private String authorizedFixedDiscountAmount;
    @JsonProperty("TargetAdditionalDiscountPercentage")
    private String targetAdditionalDiscountPercentage;
    @JsonProperty("MinimumMarginalDiscountPercentage")
    private String minimumMarginalDiscountPercentage;
    @JsonProperty("TargetMarginalDiscountPercentage")
    private String targetMarginalDiscountPercentage;
    @JsonProperty("LineProgressIndiator")
    private String lineProgressIndiator;
    @JsonProperty("MedallionNetAmount")
    private String medallionNetAmount;
    @JsonProperty("InsertTimestamp")
    private String insertTimestamp;
    @JsonProperty("UpdateTimestamp")
    private String updateTimestamp;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ScaleIdentifier")
    public String getScaleIdentifier() {
        return scaleIdentifier;
    }

    @JsonProperty("ScaleIdentifier")
    public void setScaleIdentifier(String scaleIdentifier) {
        this.scaleIdentifier = scaleIdentifier;
    }

    public DEALDISC1 withScaleIdentifier(String scaleIdentifier) {
        this.scaleIdentifier = scaleIdentifier;
        return this;
    }

    @JsonProperty("ScaleStartDate")
    public String getScaleStartDate() {
        return scaleStartDate;
    }

    @JsonProperty("ScaleStartDate")
    public void setScaleStartDate(String scaleStartDate) {
        this.scaleStartDate = scaleStartDate;
    }

    public DEALDISC1 withScaleStartDate(String scaleStartDate) {
        this.scaleStartDate = scaleStartDate;
        return this;
    }

    @JsonProperty("DealLineItemNumber")
    public String getDealLineItemNumber() {
        return dealLineItemNumber;
    }

    @JsonProperty("DealLineItemNumber")
    public void setDealLineItemNumber(String dealLineItemNumber) {
        this.dealLineItemNumber = dealLineItemNumber;
    }

    public DEALDISC1 withDealLineItemNumber(String dealLineItemNumber) {
        this.dealLineItemNumber = dealLineItemNumber;
        return this;
    }

    @JsonProperty("DealVersionNumber")
    public String getDealVersionNumber() {
        return dealVersionNumber;
    }

    @JsonProperty("DealVersionNumber")
    public void setDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
    }

    public DEALDISC1 withDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
        return this;
    }

    @JsonProperty("DealIdentifier")
    public String getDealIdentifier() {
        return dealIdentifier;
    }

    @JsonProperty("DealIdentifier")
    public void setDealIdentifier(String dealIdentifier) {
        this.dealIdentifier = dealIdentifier;
    }

    public DEALDISC1 withDealIdentifier(String dealIdentifier) {
        this.dealIdentifier = dealIdentifier;
        return this;
    }

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public DEALDISC1 withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("RequestedIncrementalDiscountAmount")
    public String getRequestedIncrementalDiscountAmount() {
        return requestedIncrementalDiscountAmount;
    }

    @JsonProperty("RequestedIncrementalDiscountAmount")
    public void setRequestedIncrementalDiscountAmount(String requestedIncrementalDiscountAmount) {
        this.requestedIncrementalDiscountAmount = requestedIncrementalDiscountAmount;
    }

    public DEALDISC1 withRequestedIncrementalDiscountAmount(String requestedIncrementalDiscountAmount) {
        this.requestedIncrementalDiscountAmount = requestedIncrementalDiscountAmount;
        return this;
    }

    @JsonProperty("AuthorizedIncrementalDiscountAmount")
    public String getAuthorizedIncrementalDiscountAmount() {
        return authorizedIncrementalDiscountAmount;
    }

    @JsonProperty("AuthorizedIncrementalDiscountAmount")
    public void setAuthorizedIncrementalDiscountAmount(String authorizedIncrementalDiscountAmount) {
        this.authorizedIncrementalDiscountAmount = authorizedIncrementalDiscountAmount;
    }

    public DEALDISC1 withAuthorizedIncrementalDiscountAmount(String authorizedIncrementalDiscountAmount) {
        this.authorizedIncrementalDiscountAmount = authorizedIncrementalDiscountAmount;
        return this;
    }

    @JsonProperty("StandardDiscountPercentage")
    public String getStandardDiscountPercentage() {
        return standardDiscountPercentage;
    }

    @JsonProperty("StandardDiscountPercentage")
    public void setStandardDiscountPercentage(String standardDiscountPercentage) {
        this.standardDiscountPercentage = standardDiscountPercentage;
    }

    public DEALDISC1 withStandardDiscountPercentage(String standardDiscountPercentage) {
        this.standardDiscountPercentage = standardDiscountPercentage;
        return this;
    }

    @JsonProperty("DiscountPercentage")
    public String getDiscountPercentage() {
        return discountPercentage;
    }

    @JsonProperty("DiscountPercentage")
    public void setDiscountPercentage(String discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public DEALDISC1 withDiscountPercentage(String discountPercentage) {
        this.discountPercentage = discountPercentage;
        return this;
    }

    @JsonProperty("MaximumBoundaryAmount")
    public String getMaximumBoundaryAmount() {
        return maximumBoundaryAmount;
    }

    @JsonProperty("MaximumBoundaryAmount")
    public void setMaximumBoundaryAmount(String maximumBoundaryAmount) {
        this.maximumBoundaryAmount = maximumBoundaryAmount;
    }

    public DEALDISC1 withMaximumBoundaryAmount(String maximumBoundaryAmount) {
        this.maximumBoundaryAmount = maximumBoundaryAmount;
        return this;
    }

    @JsonProperty("MinimumBoundaryAmount")
    public String getMinimumBoundaryAmount() {
        return minimumBoundaryAmount;
    }

    @JsonProperty("MinimumBoundaryAmount")
    public void setMinimumBoundaryAmount(String minimumBoundaryAmount) {
        this.minimumBoundaryAmount = minimumBoundaryAmount;
    }

    public DEALDISC1 withMinimumBoundaryAmount(String minimumBoundaryAmount) {
        this.minimumBoundaryAmount = minimumBoundaryAmount;
        return this;
    }

    @JsonProperty("ScaleEndDate")
    public String getScaleEndDate() {
        return scaleEndDate;
    }

    @JsonProperty("ScaleEndDate")
    public void setScaleEndDate(String scaleEndDate) {
        this.scaleEndDate = scaleEndDate;
    }

    public DEALDISC1 withScaleEndDate(String scaleEndDate) {
        this.scaleEndDate = scaleEndDate;
        return this;
    }

    @JsonProperty("RequestedDiscountPercentage")
    public String getRequestedDiscountPercentage() {
        return requestedDiscountPercentage;
    }

    @JsonProperty("RequestedDiscountPercentage")
    public void setRequestedDiscountPercentage(String requestedDiscountPercentage) {
        this.requestedDiscountPercentage = requestedDiscountPercentage;
    }

    public DEALDISC1 withRequestedDiscountPercentage(String requestedDiscountPercentage) {
        this.requestedDiscountPercentage = requestedDiscountPercentage;
        return this;
    }

    @JsonProperty("SourceSystemCreateDate")
    public String getSourceSystemCreateDate() {
        return sourceSystemCreateDate;
    }

    @JsonProperty("SourceSystemCreateDate")
    public void setSourceSystemCreateDate(String sourceSystemCreateDate) {
        this.sourceSystemCreateDate = sourceSystemCreateDate;
    }

    public DEALDISC1 withSourceSystemCreateDate(String sourceSystemCreateDate) {
        this.sourceSystemCreateDate = sourceSystemCreateDate;
        return this;
    }

    @JsonProperty("SourceSystemUpdateDate")
    public String getSourceSystemUpdateDate() {
        return sourceSystemUpdateDate;
    }

    @JsonProperty("SourceSystemUpdateDate")
    public void setSourceSystemUpdateDate(String sourceSystemUpdateDate) {
        this.sourceSystemUpdateDate = sourceSystemUpdateDate;
    }

    public DEALDISC1 withSourceSystemUpdateDate(String sourceSystemUpdateDate) {
        this.sourceSystemUpdateDate = sourceSystemUpdateDate;
        return this;
    }

    @JsonProperty("AuthorizedStatusCode")
    public String getAuthorizedStatusCode() {
        return authorizedStatusCode;
    }

    @JsonProperty("AuthorizedStatusCode")
    public void setAuthorizedStatusCode(String authorizedStatusCode) {
        this.authorizedStatusCode = authorizedStatusCode;
    }

    public DEALDISC1 withAuthorizedStatusCode(String authorizedStatusCode) {
        this.authorizedStatusCode = authorizedStatusCode;
        return this;
    }

    @JsonProperty("ProductCostAmount")
    public String getProductCostAmount() {
        return productCostAmount;
    }

    @JsonProperty("ProductCostAmount")
    public void setProductCostAmount(String productCostAmount) {
        this.productCostAmount = productCostAmount;
    }

    public DEALDISC1 withProductCostAmount(String productCostAmount) {
        this.productCostAmount = productCostAmount;
        return this;
    }

    @JsonProperty("CostStatusCode")
    public String getCostStatusCode() {
        return costStatusCode;
    }

    @JsonProperty("CostStatusCode")
    public void setCostStatusCode(String costStatusCode) {
        this.costStatusCode = costStatusCode;
    }

    public DEALDISC1 withCostStatusCode(String costStatusCode) {
        this.costStatusCode = costStatusCode;
        return this;
    }

    @JsonProperty("RequestedFixedDiscountAmount")
    public String getRequestedFixedDiscountAmount() {
        return requestedFixedDiscountAmount;
    }

    @JsonProperty("RequestedFixedDiscountAmount")
    public void setRequestedFixedDiscountAmount(String requestedFixedDiscountAmount) {
        this.requestedFixedDiscountAmount = requestedFixedDiscountAmount;
    }

    public DEALDISC1 withRequestedFixedDiscountAmount(String requestedFixedDiscountAmount) {
        this.requestedFixedDiscountAmount = requestedFixedDiscountAmount;
        return this;
    }

    @JsonProperty("AuthorizedFixedDiscountAmount")
    public String getAuthorizedFixedDiscountAmount() {
        return authorizedFixedDiscountAmount;
    }

    @JsonProperty("AuthorizedFixedDiscountAmount")
    public void setAuthorizedFixedDiscountAmount(String authorizedFixedDiscountAmount) {
        this.authorizedFixedDiscountAmount = authorizedFixedDiscountAmount;
    }

    public DEALDISC1 withAuthorizedFixedDiscountAmount(String authorizedFixedDiscountAmount) {
        this.authorizedFixedDiscountAmount = authorizedFixedDiscountAmount;
        return this;
    }

    @JsonProperty("TargetAdditionalDiscountPercentage")
    public String getTargetAdditionalDiscountPercentage() {
        return targetAdditionalDiscountPercentage;
    }

    @JsonProperty("TargetAdditionalDiscountPercentage")
    public void setTargetAdditionalDiscountPercentage(String targetAdditionalDiscountPercentage) {
        this.targetAdditionalDiscountPercentage = targetAdditionalDiscountPercentage;
    }

    public DEALDISC1 withTargetAdditionalDiscountPercentage(String targetAdditionalDiscountPercentage) {
        this.targetAdditionalDiscountPercentage = targetAdditionalDiscountPercentage;
        return this;
    }

    @JsonProperty("MinimumMarginalDiscountPercentage")
    public String getMinimumMarginalDiscountPercentage() {
        return minimumMarginalDiscountPercentage;
    }

    @JsonProperty("MinimumMarginalDiscountPercentage")
    public void setMinimumMarginalDiscountPercentage(String minimumMarginalDiscountPercentage) {
        this.minimumMarginalDiscountPercentage = minimumMarginalDiscountPercentage;
    }

    public DEALDISC1 withMinimumMarginalDiscountPercentage(String minimumMarginalDiscountPercentage) {
        this.minimumMarginalDiscountPercentage = minimumMarginalDiscountPercentage;
        return this;
    }

    @JsonProperty("TargetMarginalDiscountPercentage")
    public String getTargetMarginalDiscountPercentage() {
        return targetMarginalDiscountPercentage;
    }

    @JsonProperty("TargetMarginalDiscountPercentage")
    public void setTargetMarginalDiscountPercentage(String targetMarginalDiscountPercentage) {
        this.targetMarginalDiscountPercentage = targetMarginalDiscountPercentage;
    }

    public DEALDISC1 withTargetMarginalDiscountPercentage(String targetMarginalDiscountPercentage) {
        this.targetMarginalDiscountPercentage = targetMarginalDiscountPercentage;
        return this;
    }

    @JsonProperty("LineProgressIndiator")
    public String getLineProgressIndiator() {
        return lineProgressIndiator;
    }

    @JsonProperty("LineProgressIndiator")
    public void setLineProgressIndiator(String lineProgressIndiator) {
        this.lineProgressIndiator = lineProgressIndiator;
    }

    public DEALDISC1 withLineProgressIndiator(String lineProgressIndiator) {
        this.lineProgressIndiator = lineProgressIndiator;
        return this;
    }

    @JsonProperty("MedallionNetAmount")
    public String getMedallionNetAmount() {
        return medallionNetAmount;
    }

    @JsonProperty("MedallionNetAmount")
    public void setMedallionNetAmount(String medallionNetAmount) {
        this.medallionNetAmount = medallionNetAmount;
    }

    public DEALDISC1 withMedallionNetAmount(String medallionNetAmount) {
        this.medallionNetAmount = medallionNetAmount;
        return this;
    }

    @JsonProperty("InsertTimestamp")
    public String getInsertTimestamp() {
        return insertTimestamp;
    }

    @JsonProperty("InsertTimestamp")
    public void setInsertTimestamp(String insertTimestamp) {
        this.insertTimestamp = insertTimestamp;
    }

    public DEALDISC1 withInsertTimestamp(String insertTimestamp) {
        this.insertTimestamp = insertTimestamp;
        return this;
    }

    @JsonProperty("UpdateTimestamp")
    public String getUpdateTimestamp() {
        return updateTimestamp;
    }

    @JsonProperty("UpdateTimestamp")
    public void setUpdateTimestamp(String updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    public DEALDISC1 withUpdateTimestamp(String updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DEALDISC1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(scaleIdentifier).append(scaleStartDate).append(dealLineItemNumber).append(dealVersionNumber).append(dealIdentifier).append(sourceSystemCode).append(requestedIncrementalDiscountAmount).append(authorizedIncrementalDiscountAmount).append(standardDiscountPercentage).append(discountPercentage).append(maximumBoundaryAmount).append(minimumBoundaryAmount).append(scaleEndDate).append(requestedDiscountPercentage).append(sourceSystemCreateDate).append(sourceSystemUpdateDate).append(authorizedStatusCode).append(productCostAmount).append(costStatusCode).append(requestedFixedDiscountAmount).append(authorizedFixedDiscountAmount).append(targetAdditionalDiscountPercentage).append(minimumMarginalDiscountPercentage).append(targetMarginalDiscountPercentage).append(lineProgressIndiator).append(medallionNetAmount).append(insertTimestamp).append(updateTimestamp).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DEALDISC1) == false) {
            return false;
        }
        DEALDISC1 rhs = ((DEALDISC1) other);
        return new EqualsBuilder().append(scaleIdentifier, rhs.scaleIdentifier).append(scaleStartDate, rhs.scaleStartDate).append(dealLineItemNumber, rhs.dealLineItemNumber).append(dealVersionNumber, rhs.dealVersionNumber).append(dealIdentifier, rhs.dealIdentifier).append(sourceSystemCode, rhs.sourceSystemCode).append(requestedIncrementalDiscountAmount, rhs.requestedIncrementalDiscountAmount).append(authorizedIncrementalDiscountAmount, rhs.authorizedIncrementalDiscountAmount).append(standardDiscountPercentage, rhs.standardDiscountPercentage).append(discountPercentage, rhs.discountPercentage).append(maximumBoundaryAmount, rhs.maximumBoundaryAmount).append(minimumBoundaryAmount, rhs.minimumBoundaryAmount).append(scaleEndDate, rhs.scaleEndDate).append(requestedDiscountPercentage, rhs.requestedDiscountPercentage).append(sourceSystemCreateDate, rhs.sourceSystemCreateDate).append(sourceSystemUpdateDate, rhs.sourceSystemUpdateDate).append(authorizedStatusCode, rhs.authorizedStatusCode).append(productCostAmount, rhs.productCostAmount).append(costStatusCode, rhs.costStatusCode).append(requestedFixedDiscountAmount, rhs.requestedFixedDiscountAmount).append(authorizedFixedDiscountAmount, rhs.authorizedFixedDiscountAmount).append(targetAdditionalDiscountPercentage, rhs.targetAdditionalDiscountPercentage).append(minimumMarginalDiscountPercentage, rhs.minimumMarginalDiscountPercentage).append(targetMarginalDiscountPercentage, rhs.targetMarginalDiscountPercentage).append(lineProgressIndiator, rhs.lineProgressIndiator).append(medallionNetAmount, rhs.medallionNetAmount).append(insertTimestamp, rhs.insertTimestamp).append(updateTimestamp, rhs.updateTimestamp).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
