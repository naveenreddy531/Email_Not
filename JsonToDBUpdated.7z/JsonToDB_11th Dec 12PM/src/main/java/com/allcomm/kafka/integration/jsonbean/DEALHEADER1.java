
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "DealIdentifier",
    "DealVersionNumber",
    "SAPDocumentNumber",
    "LeadBusinessAreaGroupCode",
    "LeadBusinessUnitCode",
    "ValueVolumeOptionCode",
    "RouteToMarketTypeCode",
    "PriceListTypeCode",
    "CurrencyCode",
    "GeographicScopeName",
    "RegionCode",
    "DiscountTypeCode",
    "LanguageCode",
    "EclipseDealIdentifier",
    "SourceDealCode",
    "TenantCompanyCode",
    "DealCreatorCode",
    "ValidStartDate",
    "ValidEndDate",
    "CustomerPartyIdentifier",
    "CityName",
    "StateName",
    "PostalCode",
    "CustomerSegmentCode",
    "IndustryCode",
    "PredefinedPricingStatusName",
    "EntitledPartyIdentifier",
    "PriceProtectionIndicator",
    "PriceProtectionDays",
    "ASAPIndicator",
    "DealSourceSystemCode",
    "DealDescription",
    "SourceDealIdentifier",
    "ComplexIndicator",
    "ConflictCheckIndicator",
    "CashTradeIndicator",
    "CorporateResellerIndicator",
    "AllCommsSuppressIndicator",
    "GlobalListPriceIndicator",
    "NonReusableIndicator",
    "CatalogIndicator",
    "ExpirationDisplayIndicator",
    "PaymentDaysDisplayIndicator",
    "ExternalQuoteDisplayIndicator",
    "DealConsumptionTrackingIndicator",
    "EMailNotifyIndicator",
    "PredefinedPricingIndicator",
    "PromotionIndicator",
    "CustomerSatisfactionIndicator",
    "GlobalDealIndicator",
    "CustomOptionCode",
    "DealTypeCode",
    "LeadCountryCode",
    "PriceTermCode",
    "PaymentTermCode",
    "VersionTime",
    "DealVersionStatusName",
    "RequestIdentifier",
    "SalesOpportunityDescription",
    "CustomerLatinName",
    "CountryCode",
    "ServiceRequestNumber",
    "DealRegistrationIdentifier",
    "DealStatusName",
    "MiscellaneousChargeCode",
    "CustomerEngagementTypeName",
    "FrameworkIndicator",
    "OtherPartySiteInstanceIdentifier",
    "OrganizationIdentifier",
    "SiteInstanceIdentifier",
    "BusinessRelationshipTypeCode",
    "BusinessModelCode",
    "PayerPartyIdentifier",
    "BillToPartyIdentifier",
    "ShipToPartyIdentifier",
    "IncotermCode"
})
public class DEALHEADER1 {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("DealIdentifier")
    private String dealIdentifier;
    @JsonProperty("DealVersionNumber")
    private String dealVersionNumber;
    @JsonProperty("SAPDocumentNumber")
    private String sAPDocumentNumber;
    @JsonProperty("LeadBusinessAreaGroupCode")
    private String leadBusinessAreaGroupCode;
    @JsonProperty("LeadBusinessUnitCode")
    private String leadBusinessUnitCode;
    @JsonProperty("ValueVolumeOptionCode")
    private String valueVolumeOptionCode;
    @JsonProperty("RouteToMarketTypeCode")
    private String routeToMarketTypeCode;
    @JsonProperty("PriceListTypeCode")
    private String priceListTypeCode;
    @JsonProperty("CurrencyCode")
    private String currencyCode;
    @JsonProperty("GeographicScopeName")
    private String geographicScopeName;
    @JsonProperty("RegionCode")
    private String regionCode;
    @JsonProperty("DiscountTypeCode")
    private String discountTypeCode;
    @JsonProperty("LanguageCode")
    private String languageCode;
    @JsonProperty("EclipseDealIdentifier")
    private String eclipseDealIdentifier;
    @JsonProperty("SourceDealCode")
    private String sourceDealCode;
    @JsonProperty("TenantCompanyCode")
    private String tenantCompanyCode;
    @JsonProperty("DealCreatorCode")
    private String dealCreatorCode;
    @JsonProperty("ValidStartDate")
    private String validStartDate;
    @JsonProperty("ValidEndDate")
    private String validEndDate;
    @JsonProperty("CustomerPartyIdentifier")
    private String customerPartyIdentifier;
    @JsonProperty("CityName")
    private String cityName;
    @JsonProperty("StateName")
    private String stateName;
    @JsonProperty("PostalCode")
    private String postalCode;
    @JsonProperty("CustomerSegmentCode")
    private String customerSegmentCode;
    @JsonProperty("IndustryCode")
    private String industryCode;
    @JsonProperty("PredefinedPricingStatusName")
    private String predefinedPricingStatusName;
    @JsonProperty("EntitledPartyIdentifier")
    private String entitledPartyIdentifier;
    @JsonProperty("PriceProtectionIndicator")
    private String priceProtectionIndicator;
    @JsonProperty("PriceProtectionDays")
    private String priceProtectionDays;
    @JsonProperty("ASAPIndicator")
    private String aSAPIndicator;
    @JsonProperty("DealSourceSystemCode")
    private String dealSourceSystemCode;
    @JsonProperty("DealDescription")
    private String dealDescription;
    @JsonProperty("SourceDealIdentifier")
    private String sourceDealIdentifier;
    @JsonProperty("ComplexIndicator")
    private String complexIndicator;
    @JsonProperty("ConflictCheckIndicator")
    private String conflictCheckIndicator;
    @JsonProperty("CashTradeIndicator")
    private String cashTradeIndicator;
    @JsonProperty("CorporateResellerIndicator")
    private String corporateResellerIndicator;
    @JsonProperty("AllCommsSuppressIndicator")
    private String allCommsSuppressIndicator;
    @JsonProperty("GlobalListPriceIndicator")
    private String globalListPriceIndicator;
    @JsonProperty("NonReusableIndicator")
    private String nonReusableIndicator;
    @JsonProperty("CatalogIndicator")
    private String catalogIndicator;
    @JsonProperty("ExpirationDisplayIndicator")
    private String expirationDisplayIndicator;
    @JsonProperty("PaymentDaysDisplayIndicator")
    private String paymentDaysDisplayIndicator;
    @JsonProperty("ExternalQuoteDisplayIndicator")
    private String externalQuoteDisplayIndicator;
    @JsonProperty("DealConsumptionTrackingIndicator")
    private String dealConsumptionTrackingIndicator;
    @JsonProperty("EMailNotifyIndicator")
    private String eMailNotifyIndicator;
    @JsonProperty("PredefinedPricingIndicator")
    private String predefinedPricingIndicator;
    @JsonProperty("PromotionIndicator")
    private String promotionIndicator;
    @JsonProperty("CustomerSatisfactionIndicator")
    private String customerSatisfactionIndicator;
    @JsonProperty("GlobalDealIndicator")
    private String globalDealIndicator;
    @JsonProperty("CustomOptionCode")
    private String customOptionCode;
    @JsonProperty("DealTypeCode")
    private String dealTypeCode;
    @JsonProperty("LeadCountryCode")
    private String leadCountryCode;
    @JsonProperty("PriceTermCode")
    private String priceTermCode;
    @JsonProperty("PaymentTermCode")
    private String paymentTermCode;
    @JsonProperty("VersionTime")
    private String versionTime;
    @JsonProperty("DealVersionStatusName")
    private String dealVersionStatusName;
    @JsonProperty("RequestIdentifier")
    private String requestIdentifier;
    @JsonProperty("SalesOpportunityDescription")
    private String salesOpportunityDescription;
    @JsonProperty("CustomerLatinName")
    private String customerLatinName;
    @JsonProperty("CountryCode")
    private String countryCode;
    @JsonProperty("ServiceRequestNumber")
    private String serviceRequestNumber;
    @JsonProperty("DealRegistrationIdentifier")
    private String dealRegistrationIdentifier;
    @JsonProperty("DealStatusName")
    private String dealStatusName;
    @JsonProperty("MiscellaneousChargeCode")
    private String miscellaneousChargeCode;
    @JsonProperty("CustomerEngagementTypeName")
    private String customerEngagementTypeName;
    @JsonProperty("FrameworkIndicator")
    private String frameworkIndicator;
    @JsonProperty("OtherPartySiteInstanceIdentifier")
    private String otherPartySiteInstanceIdentifier;
    @JsonProperty("OrganizationIdentifier")
    private String organizationIdentifier;
    @JsonProperty("SiteInstanceIdentifier")
    private String siteInstanceIdentifier;
    @JsonProperty("BusinessRelationshipTypeCode")
    private String businessRelationshipTypeCode;
    @JsonProperty("BusinessModelCode")
    private String businessModelCode;
    @JsonProperty("PayerPartyIdentifier")
    private String payerPartyIdentifier;
    @JsonProperty("BillToPartyIdentifier")
    private String billToPartyIdentifier;
    @JsonProperty("ShipToPartyIdentifier")
    private String shipToPartyIdentifier;
    @JsonProperty("IncotermCode")
    private String incotermCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public DEALHEADER1 withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("DealIdentifier")
    public String getDealIdentifier() {
        return dealIdentifier;
    }

    @JsonProperty("DealIdentifier")
    public void setDealIdentifier(String dealIdentifier) {
        this.dealIdentifier = dealIdentifier;
    }

    public DEALHEADER1 withDealIdentifier(String dealIdentifier) {
        this.dealIdentifier = dealIdentifier;
        return this;
    }

    @JsonProperty("DealVersionNumber")
    public String getDealVersionNumber() {
        return dealVersionNumber;
    }

    @JsonProperty("DealVersionNumber")
    public void setDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
    }

    public DEALHEADER1 withDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
        return this;
    }

    @JsonProperty("SAPDocumentNumber")
    public String getSAPDocumentNumber() {
        return sAPDocumentNumber;
    }

    @JsonProperty("SAPDocumentNumber")
    public void setSAPDocumentNumber(String sAPDocumentNumber) {
        this.sAPDocumentNumber = sAPDocumentNumber;
    }

    public DEALHEADER1 withSAPDocumentNumber(String sAPDocumentNumber) {
        this.sAPDocumentNumber = sAPDocumentNumber;
        return this;
    }

    @JsonProperty("LeadBusinessAreaGroupCode")
    public String getLeadBusinessAreaGroupCode() {
        return leadBusinessAreaGroupCode;
    }

    @JsonProperty("LeadBusinessAreaGroupCode")
    public void setLeadBusinessAreaGroupCode(String leadBusinessAreaGroupCode) {
        this.leadBusinessAreaGroupCode = leadBusinessAreaGroupCode;
    }

    public DEALHEADER1 withLeadBusinessAreaGroupCode(String leadBusinessAreaGroupCode) {
        this.leadBusinessAreaGroupCode = leadBusinessAreaGroupCode;
        return this;
    }

    @JsonProperty("LeadBusinessUnitCode")
    public String getLeadBusinessUnitCode() {
        return leadBusinessUnitCode;
    }

    @JsonProperty("LeadBusinessUnitCode")
    public void setLeadBusinessUnitCode(String leadBusinessUnitCode) {
        this.leadBusinessUnitCode = leadBusinessUnitCode;
    }

    public DEALHEADER1 withLeadBusinessUnitCode(String leadBusinessUnitCode) {
        this.leadBusinessUnitCode = leadBusinessUnitCode;
        return this;
    }

    @JsonProperty("ValueVolumeOptionCode")
    public String getValueVolumeOptionCode() {
        return valueVolumeOptionCode;
    }

    @JsonProperty("ValueVolumeOptionCode")
    public void setValueVolumeOptionCode(String valueVolumeOptionCode) {
        this.valueVolumeOptionCode = valueVolumeOptionCode;
    }

    public DEALHEADER1 withValueVolumeOptionCode(String valueVolumeOptionCode) {
        this.valueVolumeOptionCode = valueVolumeOptionCode;
        return this;
    }

    @JsonProperty("RouteToMarketTypeCode")
    public String getRouteToMarketTypeCode() {
        return routeToMarketTypeCode;
    }

    @JsonProperty("RouteToMarketTypeCode")
    public void setRouteToMarketTypeCode(String routeToMarketTypeCode) {
        this.routeToMarketTypeCode = routeToMarketTypeCode;
    }

    public DEALHEADER1 withRouteToMarketTypeCode(String routeToMarketTypeCode) {
        this.routeToMarketTypeCode = routeToMarketTypeCode;
        return this;
    }

    @JsonProperty("PriceListTypeCode")
    public String getPriceListTypeCode() {
        return priceListTypeCode;
    }

    @JsonProperty("PriceListTypeCode")
    public void setPriceListTypeCode(String priceListTypeCode) {
        this.priceListTypeCode = priceListTypeCode;
    }

    public DEALHEADER1 withPriceListTypeCode(String priceListTypeCode) {
        this.priceListTypeCode = priceListTypeCode;
        return this;
    }

    @JsonProperty("CurrencyCode")
    public String getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("CurrencyCode")
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public DEALHEADER1 withCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
        return this;
    }

    @JsonProperty("GeographicScopeName")
    public String getGeographicScopeName() {
        return geographicScopeName;
    }

    @JsonProperty("GeographicScopeName")
    public void setGeographicScopeName(String geographicScopeName) {
        this.geographicScopeName = geographicScopeName;
    }

    public DEALHEADER1 withGeographicScopeName(String geographicScopeName) {
        this.geographicScopeName = geographicScopeName;
        return this;
    }

    @JsonProperty("RegionCode")
    public String getRegionCode() {
        return regionCode;
    }

    @JsonProperty("RegionCode")
    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public DEALHEADER1 withRegionCode(String regionCode) {
        this.regionCode = regionCode;
        return this;
    }

    @JsonProperty("DiscountTypeCode")
    public String getDiscountTypeCode() {
        return discountTypeCode;
    }

    @JsonProperty("DiscountTypeCode")
    public void setDiscountTypeCode(String discountTypeCode) {
        this.discountTypeCode = discountTypeCode;
    }

    public DEALHEADER1 withDiscountTypeCode(String discountTypeCode) {
        this.discountTypeCode = discountTypeCode;
        return this;
    }

    @JsonProperty("LanguageCode")
    public String getLanguageCode() {
        return languageCode;
    }

    @JsonProperty("LanguageCode")
    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    public DEALHEADER1 withLanguageCode(String languageCode) {
        this.languageCode = languageCode;
        return this;
    }

    @JsonProperty("EclipseDealIdentifier")
    public String getEclipseDealIdentifier() {
        return eclipseDealIdentifier;
    }

    @JsonProperty("EclipseDealIdentifier")
    public void setEclipseDealIdentifier(String eclipseDealIdentifier) {
        this.eclipseDealIdentifier = eclipseDealIdentifier;
    }

    public DEALHEADER1 withEclipseDealIdentifier(String eclipseDealIdentifier) {
        this.eclipseDealIdentifier = eclipseDealIdentifier;
        return this;
    }

    @JsonProperty("SourceDealCode")
    public String getSourceDealCode() {
        return sourceDealCode;
    }

    @JsonProperty("SourceDealCode")
    public void setSourceDealCode(String sourceDealCode) {
        this.sourceDealCode = sourceDealCode;
    }

    public DEALHEADER1 withSourceDealCode(String sourceDealCode) {
        this.sourceDealCode = sourceDealCode;
        return this;
    }

    @JsonProperty("TenantCompanyCode")
    public String getTenantCompanyCode() {
        return tenantCompanyCode;
    }

    @JsonProperty("TenantCompanyCode")
    public void setTenantCompanyCode(String tenantCompanyCode) {
        this.tenantCompanyCode = tenantCompanyCode;
    }

    public DEALHEADER1 withTenantCompanyCode(String tenantCompanyCode) {
        this.tenantCompanyCode = tenantCompanyCode;
        return this;
    }

    @JsonProperty("DealCreatorCode")
    public String getDealCreatorCode() {
        return dealCreatorCode;
    }

    @JsonProperty("DealCreatorCode")
    public void setDealCreatorCode(String dealCreatorCode) {
        this.dealCreatorCode = dealCreatorCode;
    }

    public DEALHEADER1 withDealCreatorCode(String dealCreatorCode) {
        this.dealCreatorCode = dealCreatorCode;
        return this;
    }

    @JsonProperty("ValidStartDate")
    public String getValidStartDate() {
        return validStartDate;
    }

    @JsonProperty("ValidStartDate")
    public void setValidStartDate(String validStartDate) {
        this.validStartDate = validStartDate;
    }

    public DEALHEADER1 withValidStartDate(String validStartDate) {
        this.validStartDate = validStartDate;
        return this;
    }

    @JsonProperty("ValidEndDate")
    public String getValidEndDate() {
        return validEndDate;
    }

    @JsonProperty("ValidEndDate")
    public void setValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
    }

    public DEALHEADER1 withValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
        return this;
    }

    @JsonProperty("CustomerPartyIdentifier")
    public String getCustomerPartyIdentifier() {
        return customerPartyIdentifier;
    }

    @JsonProperty("CustomerPartyIdentifier")
    public void setCustomerPartyIdentifier(String customerPartyIdentifier) {
        this.customerPartyIdentifier = customerPartyIdentifier;
    }

    public DEALHEADER1 withCustomerPartyIdentifier(String customerPartyIdentifier) {
        this.customerPartyIdentifier = customerPartyIdentifier;
        return this;
    }

    @JsonProperty("CityName")
    public String getCityName() {
        return cityName;
    }

    @JsonProperty("CityName")
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public DEALHEADER1 withCityName(String cityName) {
        this.cityName = cityName;
        return this;
    }

    @JsonProperty("StateName")
    public String getStateName() {
        return stateName;
    }

    @JsonProperty("StateName")
    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public DEALHEADER1 withStateName(String stateName) {
        this.stateName = stateName;
        return this;
    }

    @JsonProperty("PostalCode")
    public String getPostalCode() {
        return postalCode;
    }

    @JsonProperty("PostalCode")
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public DEALHEADER1 withPostalCode(String postalCode) {
        this.postalCode = postalCode;
        return this;
    }

    @JsonProperty("CustomerSegmentCode")
    public String getCustomerSegmentCode() {
        return customerSegmentCode;
    }

    @JsonProperty("CustomerSegmentCode")
    public void setCustomerSegmentCode(String customerSegmentCode) {
        this.customerSegmentCode = customerSegmentCode;
    }

    public DEALHEADER1 withCustomerSegmentCode(String customerSegmentCode) {
        this.customerSegmentCode = customerSegmentCode;
        return this;
    }

    @JsonProperty("IndustryCode")
    public String getIndustryCode() {
        return industryCode;
    }

    @JsonProperty("IndustryCode")
    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }

    public DEALHEADER1 withIndustryCode(String industryCode) {
        this.industryCode = industryCode;
        return this;
    }

    @JsonProperty("PredefinedPricingStatusName")
    public String getPredefinedPricingStatusName() {
        return predefinedPricingStatusName;
    }

    @JsonProperty("PredefinedPricingStatusName")
    public void setPredefinedPricingStatusName(String predefinedPricingStatusName) {
        this.predefinedPricingStatusName = predefinedPricingStatusName;
    }

    public DEALHEADER1 withPredefinedPricingStatusName(String predefinedPricingStatusName) {
        this.predefinedPricingStatusName = predefinedPricingStatusName;
        return this;
    }

    @JsonProperty("EntitledPartyIdentifier")
    public String getEntitledPartyIdentifier() {
        return entitledPartyIdentifier;
    }

    @JsonProperty("EntitledPartyIdentifier")
    public void setEntitledPartyIdentifier(String entitledPartyIdentifier) {
        this.entitledPartyIdentifier = entitledPartyIdentifier;
    }

    public DEALHEADER1 withEntitledPartyIdentifier(String entitledPartyIdentifier) {
        this.entitledPartyIdentifier = entitledPartyIdentifier;
        return this;
    }

    @JsonProperty("PriceProtectionIndicator")
    public String getPriceProtectionIndicator() {
        return priceProtectionIndicator;
    }

    @JsonProperty("PriceProtectionIndicator")
    public void setPriceProtectionIndicator(String priceProtectionIndicator) {
        this.priceProtectionIndicator = priceProtectionIndicator;
    }

    public DEALHEADER1 withPriceProtectionIndicator(String priceProtectionIndicator) {
        this.priceProtectionIndicator = priceProtectionIndicator;
        return this;
    }

    @JsonProperty("PriceProtectionDays")
    public String getPriceProtectionDays() {
        return priceProtectionDays;
    }

    @JsonProperty("PriceProtectionDays")
    public void setPriceProtectionDays(String priceProtectionDays) {
        this.priceProtectionDays = priceProtectionDays;
    }

    public DEALHEADER1 withPriceProtectionDays(String priceProtectionDays) {
        this.priceProtectionDays = priceProtectionDays;
        return this;
    }

    @JsonProperty("ASAPIndicator")
    public String getASAPIndicator() {
        return aSAPIndicator;
    }

    @JsonProperty("ASAPIndicator")
    public void setASAPIndicator(String aSAPIndicator) {
        this.aSAPIndicator = aSAPIndicator;
    }

    public DEALHEADER1 withASAPIndicator(String aSAPIndicator) {
        this.aSAPIndicator = aSAPIndicator;
        return this;
    }

    @JsonProperty("DealSourceSystemCode")
    public String getDealSourceSystemCode() {
        return dealSourceSystemCode;
    }

    @JsonProperty("DealSourceSystemCode")
    public void setDealSourceSystemCode(String dealSourceSystemCode) {
        this.dealSourceSystemCode = dealSourceSystemCode;
    }

    public DEALHEADER1 withDealSourceSystemCode(String dealSourceSystemCode) {
        this.dealSourceSystemCode = dealSourceSystemCode;
        return this;
    }

    @JsonProperty("DealDescription")
    public String getDealDescription() {
        return dealDescription;
    }

    @JsonProperty("DealDescription")
    public void setDealDescription(String dealDescription) {
        this.dealDescription = dealDescription;
    }

    public DEALHEADER1 withDealDescription(String dealDescription) {
        this.dealDescription = dealDescription;
        return this;
    }

    @JsonProperty("SourceDealIdentifier")
    public String getSourceDealIdentifier() {
        return sourceDealIdentifier;
    }

    @JsonProperty("SourceDealIdentifier")
    public void setSourceDealIdentifier(String sourceDealIdentifier) {
        this.sourceDealIdentifier = sourceDealIdentifier;
    }

    public DEALHEADER1 withSourceDealIdentifier(String sourceDealIdentifier) {
        this.sourceDealIdentifier = sourceDealIdentifier;
        return this;
    }

    @JsonProperty("ComplexIndicator")
    public String getComplexIndicator() {
        return complexIndicator;
    }

    @JsonProperty("ComplexIndicator")
    public void setComplexIndicator(String complexIndicator) {
        this.complexIndicator = complexIndicator;
    }

    public DEALHEADER1 withComplexIndicator(String complexIndicator) {
        this.complexIndicator = complexIndicator;
        return this;
    }

    @JsonProperty("ConflictCheckIndicator")
    public String getConflictCheckIndicator() {
        return conflictCheckIndicator;
    }

    @JsonProperty("ConflictCheckIndicator")
    public void setConflictCheckIndicator(String conflictCheckIndicator) {
        this.conflictCheckIndicator = conflictCheckIndicator;
    }

    public DEALHEADER1 withConflictCheckIndicator(String conflictCheckIndicator) {
        this.conflictCheckIndicator = conflictCheckIndicator;
        return this;
    }

    @JsonProperty("CashTradeIndicator")
    public String getCashTradeIndicator() {
        return cashTradeIndicator;
    }

    @JsonProperty("CashTradeIndicator")
    public void setCashTradeIndicator(String cashTradeIndicator) {
        this.cashTradeIndicator = cashTradeIndicator;
    }

    public DEALHEADER1 withCashTradeIndicator(String cashTradeIndicator) {
        this.cashTradeIndicator = cashTradeIndicator;
        return this;
    }

    @JsonProperty("CorporateResellerIndicator")
    public String getCorporateResellerIndicator() {
        return corporateResellerIndicator;
    }

    @JsonProperty("CorporateResellerIndicator")
    public void setCorporateResellerIndicator(String corporateResellerIndicator) {
        this.corporateResellerIndicator = corporateResellerIndicator;
    }

    public DEALHEADER1 withCorporateResellerIndicator(String corporateResellerIndicator) {
        this.corporateResellerIndicator = corporateResellerIndicator;
        return this;
    }

    @JsonProperty("AllCommsSuppressIndicator")
    public String getAllCommsSuppressIndicator() {
        return allCommsSuppressIndicator;
    }

    @JsonProperty("AllCommsSuppressIndicator")
    public void setAllCommsSuppressIndicator(String allCommsSuppressIndicator) {
        this.allCommsSuppressIndicator = allCommsSuppressIndicator;
    }

    public DEALHEADER1 withAllCommsSuppressIndicator(String allCommsSuppressIndicator) {
        this.allCommsSuppressIndicator = allCommsSuppressIndicator;
        return this;
    }

    @JsonProperty("GlobalListPriceIndicator")
    public String getGlobalListPriceIndicator() {
        return globalListPriceIndicator;
    }

    @JsonProperty("GlobalListPriceIndicator")
    public void setGlobalListPriceIndicator(String globalListPriceIndicator) {
        this.globalListPriceIndicator = globalListPriceIndicator;
    }

    public DEALHEADER1 withGlobalListPriceIndicator(String globalListPriceIndicator) {
        this.globalListPriceIndicator = globalListPriceIndicator;
        return this;
    }

    @JsonProperty("NonReusableIndicator")
    public String getNonReusableIndicator() {
        return nonReusableIndicator;
    }

    @JsonProperty("NonReusableIndicator")
    public void setNonReusableIndicator(String nonReusableIndicator) {
        this.nonReusableIndicator = nonReusableIndicator;
    }

    public DEALHEADER1 withNonReusableIndicator(String nonReusableIndicator) {
        this.nonReusableIndicator = nonReusableIndicator;
        return this;
    }

    @JsonProperty("CatalogIndicator")
    public String getCatalogIndicator() {
        return catalogIndicator;
    }

    @JsonProperty("CatalogIndicator")
    public void setCatalogIndicator(String catalogIndicator) {
        this.catalogIndicator = catalogIndicator;
    }

    public DEALHEADER1 withCatalogIndicator(String catalogIndicator) {
        this.catalogIndicator = catalogIndicator;
        return this;
    }

    @JsonProperty("ExpirationDisplayIndicator")
    public String getExpirationDisplayIndicator() {
        return expirationDisplayIndicator;
    }

    @JsonProperty("ExpirationDisplayIndicator")
    public void setExpirationDisplayIndicator(String expirationDisplayIndicator) {
        this.expirationDisplayIndicator = expirationDisplayIndicator;
    }

    public DEALHEADER1 withExpirationDisplayIndicator(String expirationDisplayIndicator) {
        this.expirationDisplayIndicator = expirationDisplayIndicator;
        return this;
    }

    @JsonProperty("PaymentDaysDisplayIndicator")
    public String getPaymentDaysDisplayIndicator() {
        return paymentDaysDisplayIndicator;
    }

    @JsonProperty("PaymentDaysDisplayIndicator")
    public void setPaymentDaysDisplayIndicator(String paymentDaysDisplayIndicator) {
        this.paymentDaysDisplayIndicator = paymentDaysDisplayIndicator;
    }

    public DEALHEADER1 withPaymentDaysDisplayIndicator(String paymentDaysDisplayIndicator) {
        this.paymentDaysDisplayIndicator = paymentDaysDisplayIndicator;
        return this;
    }

    @JsonProperty("ExternalQuoteDisplayIndicator")
    public String getExternalQuoteDisplayIndicator() {
        return externalQuoteDisplayIndicator;
    }

    @JsonProperty("ExternalQuoteDisplayIndicator")
    public void setExternalQuoteDisplayIndicator(String externalQuoteDisplayIndicator) {
        this.externalQuoteDisplayIndicator = externalQuoteDisplayIndicator;
    }

    public DEALHEADER1 withExternalQuoteDisplayIndicator(String externalQuoteDisplayIndicator) {
        this.externalQuoteDisplayIndicator = externalQuoteDisplayIndicator;
        return this;
    }

    @JsonProperty("DealConsumptionTrackingIndicator")
    public String getDealConsumptionTrackingIndicator() {
        return dealConsumptionTrackingIndicator;
    }

    @JsonProperty("DealConsumptionTrackingIndicator")
    public void setDealConsumptionTrackingIndicator(String dealConsumptionTrackingIndicator) {
        this.dealConsumptionTrackingIndicator = dealConsumptionTrackingIndicator;
    }

    public DEALHEADER1 withDealConsumptionTrackingIndicator(String dealConsumptionTrackingIndicator) {
        this.dealConsumptionTrackingIndicator = dealConsumptionTrackingIndicator;
        return this;
    }

    @JsonProperty("EMailNotifyIndicator")
    public String getEMailNotifyIndicator() {
        return eMailNotifyIndicator;
    }

    @JsonProperty("EMailNotifyIndicator")
    public void setEMailNotifyIndicator(String eMailNotifyIndicator) {
        this.eMailNotifyIndicator = eMailNotifyIndicator;
    }

    public DEALHEADER1 withEMailNotifyIndicator(String eMailNotifyIndicator) {
        this.eMailNotifyIndicator = eMailNotifyIndicator;
        return this;
    }

    @JsonProperty("PredefinedPricingIndicator")
    public String getPredefinedPricingIndicator() {
        return predefinedPricingIndicator;
    }

    @JsonProperty("PredefinedPricingIndicator")
    public void setPredefinedPricingIndicator(String predefinedPricingIndicator) {
        this.predefinedPricingIndicator = predefinedPricingIndicator;
    }

    public DEALHEADER1 withPredefinedPricingIndicator(String predefinedPricingIndicator) {
        this.predefinedPricingIndicator = predefinedPricingIndicator;
        return this;
    }

    @JsonProperty("PromotionIndicator")
    public String getPromotionIndicator() {
        return promotionIndicator;
    }

    @JsonProperty("PromotionIndicator")
    public void setPromotionIndicator(String promotionIndicator) {
        this.promotionIndicator = promotionIndicator;
    }

    public DEALHEADER1 withPromotionIndicator(String promotionIndicator) {
        this.promotionIndicator = promotionIndicator;
        return this;
    }

    @JsonProperty("CustomerSatisfactionIndicator")
    public String getCustomerSatisfactionIndicator() {
        return customerSatisfactionIndicator;
    }

    @JsonProperty("CustomerSatisfactionIndicator")
    public void setCustomerSatisfactionIndicator(String customerSatisfactionIndicator) {
        this.customerSatisfactionIndicator = customerSatisfactionIndicator;
    }

    public DEALHEADER1 withCustomerSatisfactionIndicator(String customerSatisfactionIndicator) {
        this.customerSatisfactionIndicator = customerSatisfactionIndicator;
        return this;
    }

    @JsonProperty("GlobalDealIndicator")
    public String getGlobalDealIndicator() {
        return globalDealIndicator;
    }

    @JsonProperty("GlobalDealIndicator")
    public void setGlobalDealIndicator(String globalDealIndicator) {
        this.globalDealIndicator = globalDealIndicator;
    }

    public DEALHEADER1 withGlobalDealIndicator(String globalDealIndicator) {
        this.globalDealIndicator = globalDealIndicator;
        return this;
    }

    @JsonProperty("CustomOptionCode")
    public String getCustomOptionCode() {
        return customOptionCode;
    }

    @JsonProperty("CustomOptionCode")
    public void setCustomOptionCode(String customOptionCode) {
        this.customOptionCode = customOptionCode;
    }

    public DEALHEADER1 withCustomOptionCode(String customOptionCode) {
        this.customOptionCode = customOptionCode;
        return this;
    }

    @JsonProperty("DealTypeCode")
    public String getDealTypeCode() {
        return dealTypeCode;
    }

    @JsonProperty("DealTypeCode")
    public void setDealTypeCode(String dealTypeCode) {
        this.dealTypeCode = dealTypeCode;
    }

    public DEALHEADER1 withDealTypeCode(String dealTypeCode) {
        this.dealTypeCode = dealTypeCode;
        return this;
    }

    @JsonProperty("LeadCountryCode")
    public String getLeadCountryCode() {
        return leadCountryCode;
    }

    @JsonProperty("LeadCountryCode")
    public void setLeadCountryCode(String leadCountryCode) {
        this.leadCountryCode = leadCountryCode;
    }

    public DEALHEADER1 withLeadCountryCode(String leadCountryCode) {
        this.leadCountryCode = leadCountryCode;
        return this;
    }

    @JsonProperty("PriceTermCode")
    public String getPriceTermCode() {
        return priceTermCode;
    }

    @JsonProperty("PriceTermCode")
    public void setPriceTermCode(String priceTermCode) {
        this.priceTermCode = priceTermCode;
    }

    public DEALHEADER1 withPriceTermCode(String priceTermCode) {
        this.priceTermCode = priceTermCode;
        return this;
    }

    @JsonProperty("PaymentTermCode")
    public String getPaymentTermCode() {
        return paymentTermCode;
    }

    @JsonProperty("PaymentTermCode")
    public void setPaymentTermCode(String paymentTermCode) {
        this.paymentTermCode = paymentTermCode;
    }

    public DEALHEADER1 withPaymentTermCode(String paymentTermCode) {
        this.paymentTermCode = paymentTermCode;
        return this;
    }

    @JsonProperty("VersionTime")
    public String getVersionTime() {
        return versionTime;
    }

    @JsonProperty("VersionTime")
    public void setVersionTime(String versionTime) {
        this.versionTime = versionTime;
    }

    public DEALHEADER1 withVersionTime(String versionTime) {
        this.versionTime = versionTime;
        return this;
    }

    @JsonProperty("DealVersionStatusName")
    public String getDealVersionStatusName() {
        return dealVersionStatusName;
    }

    @JsonProperty("DealVersionStatusName")
    public void setDealVersionStatusName(String dealVersionStatusName) {
        this.dealVersionStatusName = dealVersionStatusName;
    }

    public DEALHEADER1 withDealVersionStatusName(String dealVersionStatusName) {
        this.dealVersionStatusName = dealVersionStatusName;
        return this;
    }

    @JsonProperty("RequestIdentifier")
    public String getRequestIdentifier() {
        return requestIdentifier;
    }

    @JsonProperty("RequestIdentifier")
    public void setRequestIdentifier(String requestIdentifier) {
        this.requestIdentifier = requestIdentifier;
    }

    public DEALHEADER1 withRequestIdentifier(String requestIdentifier) {
        this.requestIdentifier = requestIdentifier;
        return this;
    }

    @JsonProperty("SalesOpportunityDescription")
    public String getSalesOpportunityDescription() {
        return salesOpportunityDescription;
    }

    @JsonProperty("SalesOpportunityDescription")
    public void setSalesOpportunityDescription(String salesOpportunityDescription) {
        this.salesOpportunityDescription = salesOpportunityDescription;
    }

    public DEALHEADER1 withSalesOpportunityDescription(String salesOpportunityDescription) {
        this.salesOpportunityDescription = salesOpportunityDescription;
        return this;
    }

    @JsonProperty("CustomerLatinName")
    public String getCustomerLatinName() {
        return customerLatinName;
    }

    @JsonProperty("CustomerLatinName")
    public void setCustomerLatinName(String customerLatinName) {
        this.customerLatinName = customerLatinName;
    }

    public DEALHEADER1 withCustomerLatinName(String customerLatinName) {
        this.customerLatinName = customerLatinName;
        return this;
    }

    @JsonProperty("CountryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("CountryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public DEALHEADER1 withCountryCode(String countryCode) {
        this.countryCode = countryCode;
        return this;
    }

    @JsonProperty("ServiceRequestNumber")
    public String getServiceRequestNumber() {
        return serviceRequestNumber;
    }

    @JsonProperty("ServiceRequestNumber")
    public void setServiceRequestNumber(String serviceRequestNumber) {
        this.serviceRequestNumber = serviceRequestNumber;
    }

    public DEALHEADER1 withServiceRequestNumber(String serviceRequestNumber) {
        this.serviceRequestNumber = serviceRequestNumber;
        return this;
    }

    @JsonProperty("DealRegistrationIdentifier")
    public String getDealRegistrationIdentifier() {
        return dealRegistrationIdentifier;
    }

    @JsonProperty("DealRegistrationIdentifier")
    public void setDealRegistrationIdentifier(String dealRegistrationIdentifier) {
        this.dealRegistrationIdentifier = dealRegistrationIdentifier;
    }

    public DEALHEADER1 withDealRegistrationIdentifier(String dealRegistrationIdentifier) {
        this.dealRegistrationIdentifier = dealRegistrationIdentifier;
        return this;
    }

    @JsonProperty("DealStatusName")
    public String getDealStatusName() {
        return dealStatusName;
    }

    @JsonProperty("DealStatusName")
    public void setDealStatusName(String dealStatusName) {
        this.dealStatusName = dealStatusName;
    }

    public DEALHEADER1 withDealStatusName(String dealStatusName) {
        this.dealStatusName = dealStatusName;
        return this;
    }

    @JsonProperty("MiscellaneousChargeCode")
    public String getMiscellaneousChargeCode() {
        return miscellaneousChargeCode;
    }

    @JsonProperty("MiscellaneousChargeCode")
    public void setMiscellaneousChargeCode(String miscellaneousChargeCode) {
        this.miscellaneousChargeCode = miscellaneousChargeCode;
    }

    public DEALHEADER1 withMiscellaneousChargeCode(String miscellaneousChargeCode) {
        this.miscellaneousChargeCode = miscellaneousChargeCode;
        return this;
    }

    @JsonProperty("CustomerEngagementTypeName")
    public String getCustomerEngagementTypeName() {
        return customerEngagementTypeName;
    }

    @JsonProperty("CustomerEngagementTypeName")
    public void setCustomerEngagementTypeName(String customerEngagementTypeName) {
        this.customerEngagementTypeName = customerEngagementTypeName;
    }

    public DEALHEADER1 withCustomerEngagementTypeName(String customerEngagementTypeName) {
        this.customerEngagementTypeName = customerEngagementTypeName;
        return this;
    }

    @JsonProperty("FrameworkIndicator")
    public String getFrameworkIndicator() {
        return frameworkIndicator;
    }

    @JsonProperty("FrameworkIndicator")
    public void setFrameworkIndicator(String frameworkIndicator) {
        this.frameworkIndicator = frameworkIndicator;
    }

    public DEALHEADER1 withFrameworkIndicator(String frameworkIndicator) {
        this.frameworkIndicator = frameworkIndicator;
        return this;
    }

    @JsonProperty("OtherPartySiteInstanceIdentifier")
    public String getOtherPartySiteInstanceIdentifier() {
        return otherPartySiteInstanceIdentifier;
    }

    @JsonProperty("OtherPartySiteInstanceIdentifier")
    public void setOtherPartySiteInstanceIdentifier(String otherPartySiteInstanceIdentifier) {
        this.otherPartySiteInstanceIdentifier = otherPartySiteInstanceIdentifier;
    }

    public DEALHEADER1 withOtherPartySiteInstanceIdentifier(String otherPartySiteInstanceIdentifier) {
        this.otherPartySiteInstanceIdentifier = otherPartySiteInstanceIdentifier;
        return this;
    }

    @JsonProperty("OrganizationIdentifier")
    public String getOrganizationIdentifier() {
        return organizationIdentifier;
    }

    @JsonProperty("OrganizationIdentifier")
    public void setOrganizationIdentifier(String organizationIdentifier) {
        this.organizationIdentifier = organizationIdentifier;
    }

    public DEALHEADER1 withOrganizationIdentifier(String organizationIdentifier) {
        this.organizationIdentifier = organizationIdentifier;
        return this;
    }

    @JsonProperty("SiteInstanceIdentifier")
    public String getSiteInstanceIdentifier() {
        return siteInstanceIdentifier;
    }

    @JsonProperty("SiteInstanceIdentifier")
    public void setSiteInstanceIdentifier(String siteInstanceIdentifier) {
        this.siteInstanceIdentifier = siteInstanceIdentifier;
    }

    public DEALHEADER1 withSiteInstanceIdentifier(String siteInstanceIdentifier) {
        this.siteInstanceIdentifier = siteInstanceIdentifier;
        return this;
    }

    @JsonProperty("BusinessRelationshipTypeCode")
    public String getBusinessRelationshipTypeCode() {
        return businessRelationshipTypeCode;
    }

    @JsonProperty("BusinessRelationshipTypeCode")
    public void setBusinessRelationshipTypeCode(String businessRelationshipTypeCode) {
        this.businessRelationshipTypeCode = businessRelationshipTypeCode;
    }

    public DEALHEADER1 withBusinessRelationshipTypeCode(String businessRelationshipTypeCode) {
        this.businessRelationshipTypeCode = businessRelationshipTypeCode;
        return this;
    }

    @JsonProperty("BusinessModelCode")
    public String getBusinessModelCode() {
        return businessModelCode;
    }

    @JsonProperty("BusinessModelCode")
    public void setBusinessModelCode(String businessModelCode) {
        this.businessModelCode = businessModelCode;
    }

    public DEALHEADER1 withBusinessModelCode(String businessModelCode) {
        this.businessModelCode = businessModelCode;
        return this;
    }

    @JsonProperty("PayerPartyIdentifier")
    public String getPayerPartyIdentifier() {
        return payerPartyIdentifier;
    }

    @JsonProperty("PayerPartyIdentifier")
    public void setPayerPartyIdentifier(String payerPartyIdentifier) {
        this.payerPartyIdentifier = payerPartyIdentifier;
    }

    public DEALHEADER1 withPayerPartyIdentifier(String payerPartyIdentifier) {
        this.payerPartyIdentifier = payerPartyIdentifier;
        return this;
    }

    @JsonProperty("BillToPartyIdentifier")
    public String getBillToPartyIdentifier() {
        return billToPartyIdentifier;
    }

    @JsonProperty("BillToPartyIdentifier")
    public void setBillToPartyIdentifier(String billToPartyIdentifier) {
        this.billToPartyIdentifier = billToPartyIdentifier;
    }

    public DEALHEADER1 withBillToPartyIdentifier(String billToPartyIdentifier) {
        this.billToPartyIdentifier = billToPartyIdentifier;
        return this;
    }

    @JsonProperty("ShipToPartyIdentifier")
    public String getShipToPartyIdentifier() {
        return shipToPartyIdentifier;
    }

    @JsonProperty("ShipToPartyIdentifier")
    public void setShipToPartyIdentifier(String shipToPartyIdentifier) {
        this.shipToPartyIdentifier = shipToPartyIdentifier;
    }

    public DEALHEADER1 withShipToPartyIdentifier(String shipToPartyIdentifier) {
        this.shipToPartyIdentifier = shipToPartyIdentifier;
        return this;
    }

    @JsonProperty("IncotermCode")
    public String getIncotermCode() {
        return incotermCode;
    }

    @JsonProperty("IncotermCode")
    public void setIncotermCode(String incotermCode) {
        this.incotermCode = incotermCode;
    }

    public DEALHEADER1 withIncotermCode(String incotermCode) {
        this.incotermCode = incotermCode;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DEALHEADER1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(dealIdentifier).append(dealVersionNumber).append(sAPDocumentNumber).append(leadBusinessAreaGroupCode).append(leadBusinessUnitCode).append(valueVolumeOptionCode).append(routeToMarketTypeCode).append(priceListTypeCode).append(currencyCode).append(geographicScopeName).append(regionCode).append(discountTypeCode).append(languageCode).append(eclipseDealIdentifier).append(sourceDealCode).append(tenantCompanyCode).append(dealCreatorCode).append(validStartDate).append(validEndDate).append(customerPartyIdentifier).append(cityName).append(stateName).append(postalCode).append(customerSegmentCode).append(industryCode).append(predefinedPricingStatusName).append(entitledPartyIdentifier).append(priceProtectionIndicator).append(priceProtectionDays).append(aSAPIndicator).append(dealSourceSystemCode).append(dealDescription).append(sourceDealIdentifier).append(complexIndicator).append(conflictCheckIndicator).append(cashTradeIndicator).append(corporateResellerIndicator).append(allCommsSuppressIndicator).append(globalListPriceIndicator).append(nonReusableIndicator).append(catalogIndicator).append(expirationDisplayIndicator).append(paymentDaysDisplayIndicator).append(externalQuoteDisplayIndicator).append(dealConsumptionTrackingIndicator).append(eMailNotifyIndicator).append(predefinedPricingIndicator).append(promotionIndicator).append(customerSatisfactionIndicator).append(globalDealIndicator).append(customOptionCode).append(dealTypeCode).append(leadCountryCode).append(priceTermCode).append(paymentTermCode).append(versionTime).append(dealVersionStatusName).append(requestIdentifier).append(salesOpportunityDescription).append(customerLatinName).append(countryCode).append(serviceRequestNumber).append(dealRegistrationIdentifier).append(dealStatusName).append(miscellaneousChargeCode).append(customerEngagementTypeName).append(frameworkIndicator).append(otherPartySiteInstanceIdentifier).append(organizationIdentifier).append(siteInstanceIdentifier).append(businessRelationshipTypeCode).append(businessModelCode).append(payerPartyIdentifier).append(billToPartyIdentifier).append(shipToPartyIdentifier).append(incotermCode).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DEALHEADER1) == false) {
            return false;
        }
        DEALHEADER1 rhs = ((DEALHEADER1) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(dealIdentifier, rhs.dealIdentifier).append(dealVersionNumber, rhs.dealVersionNumber).append(sAPDocumentNumber, rhs.sAPDocumentNumber).append(leadBusinessAreaGroupCode, rhs.leadBusinessAreaGroupCode).append(leadBusinessUnitCode, rhs.leadBusinessUnitCode).append(valueVolumeOptionCode, rhs.valueVolumeOptionCode).append(routeToMarketTypeCode, rhs.routeToMarketTypeCode).append(priceListTypeCode, rhs.priceListTypeCode).append(currencyCode, rhs.currencyCode).append(geographicScopeName, rhs.geographicScopeName).append(regionCode, rhs.regionCode).append(discountTypeCode, rhs.discountTypeCode).append(languageCode, rhs.languageCode).append(eclipseDealIdentifier, rhs.eclipseDealIdentifier).append(sourceDealCode, rhs.sourceDealCode).append(tenantCompanyCode, rhs.tenantCompanyCode).append(dealCreatorCode, rhs.dealCreatorCode).append(validStartDate, rhs.validStartDate).append(validEndDate, rhs.validEndDate).append(customerPartyIdentifier, rhs.customerPartyIdentifier).append(cityName, rhs.cityName).append(stateName, rhs.stateName).append(postalCode, rhs.postalCode).append(customerSegmentCode, rhs.customerSegmentCode).append(industryCode, rhs.industryCode).append(predefinedPricingStatusName, rhs.predefinedPricingStatusName).append(entitledPartyIdentifier, rhs.entitledPartyIdentifier).append(priceProtectionIndicator, rhs.priceProtectionIndicator).append(priceProtectionDays, rhs.priceProtectionDays).append(aSAPIndicator, rhs.aSAPIndicator).append(dealSourceSystemCode, rhs.dealSourceSystemCode).append(dealDescription, rhs.dealDescription).append(sourceDealIdentifier, rhs.sourceDealIdentifier).append(complexIndicator, rhs.complexIndicator).append(conflictCheckIndicator, rhs.conflictCheckIndicator).append(cashTradeIndicator, rhs.cashTradeIndicator).append(corporateResellerIndicator, rhs.corporateResellerIndicator).append(allCommsSuppressIndicator, rhs.allCommsSuppressIndicator).append(globalListPriceIndicator, rhs.globalListPriceIndicator).append(nonReusableIndicator, rhs.nonReusableIndicator).append(catalogIndicator, rhs.catalogIndicator).append(expirationDisplayIndicator, rhs.expirationDisplayIndicator).append(paymentDaysDisplayIndicator, rhs.paymentDaysDisplayIndicator).append(externalQuoteDisplayIndicator, rhs.externalQuoteDisplayIndicator).append(dealConsumptionTrackingIndicator, rhs.dealConsumptionTrackingIndicator).append(eMailNotifyIndicator, rhs.eMailNotifyIndicator).append(predefinedPricingIndicator, rhs.predefinedPricingIndicator).append(promotionIndicator, rhs.promotionIndicator).append(customerSatisfactionIndicator, rhs.customerSatisfactionIndicator).append(globalDealIndicator, rhs.globalDealIndicator).append(customOptionCode, rhs.customOptionCode).append(dealTypeCode, rhs.dealTypeCode).append(leadCountryCode, rhs.leadCountryCode).append(priceTermCode, rhs.priceTermCode).append(paymentTermCode, rhs.paymentTermCode).append(versionTime, rhs.versionTime).append(dealVersionStatusName, rhs.dealVersionStatusName).append(requestIdentifier, rhs.requestIdentifier).append(salesOpportunityDescription, rhs.salesOpportunityDescription).append(customerLatinName, rhs.customerLatinName).append(countryCode, rhs.countryCode).append(serviceRequestNumber, rhs.serviceRequestNumber).append(dealRegistrationIdentifier, rhs.dealRegistrationIdentifier).append(dealStatusName, rhs.dealStatusName).append(miscellaneousChargeCode, rhs.miscellaneousChargeCode).append(customerEngagementTypeName, rhs.customerEngagementTypeName).append(frameworkIndicator, rhs.frameworkIndicator).append(otherPartySiteInstanceIdentifier, rhs.otherPartySiteInstanceIdentifier).append(organizationIdentifier, rhs.organizationIdentifier).append(siteInstanceIdentifier, rhs.siteInstanceIdentifier).append(businessRelationshipTypeCode, rhs.businessRelationshipTypeCode).append(businessModelCode, rhs.businessModelCode).append(payerPartyIdentifier, rhs.payerPartyIdentifier).append(billToPartyIdentifier, rhs.billToPartyIdentifier).append(shipToPartyIdentifier, rhs.shipToPartyIdentifier).append(incotermCode, rhs.incotermCode).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
