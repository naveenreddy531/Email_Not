
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "LineItemNumber",
    "DealVersionNumber",
    "SAPDocumentNumber",
    "ClassCode",
    "BusinessGroupCode",
    "BusinessUnitCode",
    "ListPriceAmount",
    "StandardDiscountPercentage",
    "PriceTypeCode",
    "RequestedBigDealNetAmount",
    "RequestedAddPercentage",
    "RequestedTotalPercentage",
    "ExpertAddPercentage",
    "FloorAddPercentage",
    "TypicalAddPercentage",
    "PreviousRequestedAddPercentage",
    "AuthorizedBigDealNetAmount",
    "AuthorizedAdditionalPercentage",
    "AuthorizedTotalPercentage",
    "RequestedGrossMarginAmount",
    "RequestedGrossMarginPercentage",
    "AuthorizedGrossMarginAmount",
    "AuthorizedGrossMarginPercentage",
    "ExtendedRequestBigDealNetAmount",
    "ExtendedAuthorizedBigDealNetAmount",
    "EstimatedKAmount",
    "ExtendedEstimatedKAmount",
    "ConsumedAmount",
    "ConsumedQuantity",
    "RemainingAmount",
    "RThresholdQuantity",
    "SegregationofDutiesCode",
    "LastQuotedQuantity",
    "PredefinedDiscountPercentage",
    "PredefinedSourceIdentifier",
    "InstantPricingAmount",
    "RequestBackEndContraPercentage",
    "AuthorizedBackEndContraPercentage",
    "ExternalContraAmount",
    "RequestBackEndContraAmount",
    "AuthorizedBackEndContraAmount",
    "RequestNetRevenuePercentage",
    "AuthorizedNetRevenuePercentage",
    "RequestNetRevenueAmount",
    "AuthorizedNetRevenueAmount",
    "AuthorizedNetMarginPercentage",
    "AuthorizedNetMarginAmount",
    "RequestNetMarginAmount",
    "RequestNetMarginPercentage",
    "MedallionPercentage",
    "DealValueDiscountAmount",
    "ExpertNetAmount",
    "ExtendedListPriceAmount",
    "FloorNetAmount",
    "LinedAddedByUserId",
    "PaymentAmount",
    "RemainingQuantity",
    "AuthorizedStatusCode",
    "SourceSystemQuantity",
    "MaterialIdentifier",
    "OptionCode",
    "InstantPricingMethodAmount",
    "MedallionLevelCode"
})
public class DEALITEM1 {

    @JsonProperty("LineItemNumber")
    private String lineItemNumber;
    @JsonProperty("DealVersionNumber")
    private String dealVersionNumber;
    @JsonProperty("SAPDocumentNumber")
    private String sAPDocumentNumber;
    @JsonProperty("ClassCode")
    private String classCode;
    @JsonProperty("BusinessGroupCode")
    private String businessGroupCode;
    @JsonProperty("BusinessUnitCode")
    private String businessUnitCode;
    @JsonProperty("ListPriceAmount")
    private String listPriceAmount;
    @JsonProperty("StandardDiscountPercentage")
    private String standardDiscountPercentage;
    @JsonProperty("PriceTypeCode")
    private String priceTypeCode;
    @JsonProperty("RequestedBigDealNetAmount")
    private String requestedBigDealNetAmount;
    @JsonProperty("RequestedAddPercentage")
    private String requestedAddPercentage;
    @JsonProperty("RequestedTotalPercentage")
    private String requestedTotalPercentage;
    @JsonProperty("ExpertAddPercentage")
    private String expertAddPercentage;
    @JsonProperty("FloorAddPercentage")
    private String floorAddPercentage;
    @JsonProperty("TypicalAddPercentage")
    private String typicalAddPercentage;
    @JsonProperty("PreviousRequestedAddPercentage")
    private String previousRequestedAddPercentage;
    @JsonProperty("AuthorizedBigDealNetAmount")
    private String authorizedBigDealNetAmount;
    @JsonProperty("AuthorizedAdditionalPercentage")
    private String authorizedAdditionalPercentage;
    @JsonProperty("AuthorizedTotalPercentage")
    private String authorizedTotalPercentage;
    @JsonProperty("RequestedGrossMarginAmount")
    private String requestedGrossMarginAmount;
    @JsonProperty("RequestedGrossMarginPercentage")
    private String requestedGrossMarginPercentage;
    @JsonProperty("AuthorizedGrossMarginAmount")
    private String authorizedGrossMarginAmount;
    @JsonProperty("AuthorizedGrossMarginPercentage")
    private String authorizedGrossMarginPercentage;
    @JsonProperty("ExtendedRequestBigDealNetAmount")
    private String extendedRequestBigDealNetAmount;
    @JsonProperty("ExtendedAuthorizedBigDealNetAmount")
    private String extendedAuthorizedBigDealNetAmount;
    @JsonProperty("EstimatedKAmount")
    private String estimatedKAmount;
    @JsonProperty("ExtendedEstimatedKAmount")
    private String extendedEstimatedKAmount;
    @JsonProperty("ConsumedAmount")
    private String consumedAmount;
    @JsonProperty("ConsumedQuantity")
    private String consumedQuantity;
    @JsonProperty("RemainingAmount")
    private String remainingAmount;
    @JsonProperty("RThresholdQuantity")
    private String rThresholdQuantity;
    @JsonProperty("SegregationofDutiesCode")
    private String segregationofDutiesCode;
    @JsonProperty("LastQuotedQuantity")
    private String lastQuotedQuantity;
    @JsonProperty("PredefinedDiscountPercentage")
    private String predefinedDiscountPercentage;
    @JsonProperty("PredefinedSourceIdentifier")
    private String predefinedSourceIdentifier;
    @JsonProperty("InstantPricingAmount")
    private String instantPricingAmount;
    @JsonProperty("RequestBackEndContraPercentage")
    private String requestBackEndContraPercentage;
    @JsonProperty("AuthorizedBackEndContraPercentage")
    private String authorizedBackEndContraPercentage;
    @JsonProperty("ExternalContraAmount")
    private String externalContraAmount;
    @JsonProperty("RequestBackEndContraAmount")
    private String requestBackEndContraAmount;
    @JsonProperty("AuthorizedBackEndContraAmount")
    private String authorizedBackEndContraAmount;
    @JsonProperty("RequestNetRevenuePercentage")
    private String requestNetRevenuePercentage;
    @JsonProperty("AuthorizedNetRevenuePercentage")
    private String authorizedNetRevenuePercentage;
    @JsonProperty("RequestNetRevenueAmount")
    private String requestNetRevenueAmount;
    @JsonProperty("AuthorizedNetRevenueAmount")
    private String authorizedNetRevenueAmount;
    @JsonProperty("AuthorizedNetMarginPercentage")
    private String authorizedNetMarginPercentage;
    @JsonProperty("AuthorizedNetMarginAmount")
    private String authorizedNetMarginAmount;
    @JsonProperty("RequestNetMarginAmount")
    private String requestNetMarginAmount;
    @JsonProperty("RequestNetMarginPercentage")
    private String requestNetMarginPercentage;
    @JsonProperty("MedallionPercentage")
    private String medallionPercentage;
    @JsonProperty("DealValueDiscountAmount")
    private String dealValueDiscountAmount;
    @JsonProperty("ExpertNetAmount")
    private String expertNetAmount;
    @JsonProperty("ExtendedListPriceAmount")
    private String extendedListPriceAmount;
    @JsonProperty("FloorNetAmount")
    private String floorNetAmount;
    @JsonProperty("LinedAddedByUserId")
    private String linedAddedByUserId;
    @JsonProperty("PaymentAmount")
    private String paymentAmount;
    @JsonProperty("RemainingQuantity")
    private String remainingQuantity;
    @JsonProperty("AuthorizedStatusCode")
    private String authorizedStatusCode;
    @JsonProperty("SourceSystemQuantity")
    private String sourceSystemQuantity;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("OptionCode")
    private String optionCode;
    @JsonProperty("InstantPricingMethodAmount")
    private String instantPricingMethodAmount;
    @JsonProperty("MedallionLevelCode")
    private String medallionLevelCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("LineItemNumber")
    public String getLineItemNumber() {
        return lineItemNumber;
    }

    @JsonProperty("LineItemNumber")
    public void setLineItemNumber(String lineItemNumber) {
        this.lineItemNumber = lineItemNumber;
    }

    public DEALITEM1 withLineItemNumber(String lineItemNumber) {
        this.lineItemNumber = lineItemNumber;
        return this;
    }

    @JsonProperty("DealVersionNumber")
    public String getDealVersionNumber() {
        return dealVersionNumber;
    }

    @JsonProperty("DealVersionNumber")
    public void setDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
    }

    public DEALITEM1 withDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
        return this;
    }

    @JsonProperty("SAPDocumentNumber")
    public String getSAPDocumentNumber() {
        return sAPDocumentNumber;
    }

    @JsonProperty("SAPDocumentNumber")
    public void setSAPDocumentNumber(String sAPDocumentNumber) {
        this.sAPDocumentNumber = sAPDocumentNumber;
    }

    public DEALITEM1 withSAPDocumentNumber(String sAPDocumentNumber) {
        this.sAPDocumentNumber = sAPDocumentNumber;
        return this;
    }

    @JsonProperty("ClassCode")
    public String getClassCode() {
        return classCode;
    }

    @JsonProperty("ClassCode")
    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public DEALITEM1 withClassCode(String classCode) {
        this.classCode = classCode;
        return this;
    }

    @JsonProperty("BusinessGroupCode")
    public String getBusinessGroupCode() {
        return businessGroupCode;
    }

    @JsonProperty("BusinessGroupCode")
    public void setBusinessGroupCode(String businessGroupCode) {
        this.businessGroupCode = businessGroupCode;
    }

    public DEALITEM1 withBusinessGroupCode(String businessGroupCode) {
        this.businessGroupCode = businessGroupCode;
        return this;
    }

    @JsonProperty("BusinessUnitCode")
    public String getBusinessUnitCode() {
        return businessUnitCode;
    }

    @JsonProperty("BusinessUnitCode")
    public void setBusinessUnitCode(String businessUnitCode) {
        this.businessUnitCode = businessUnitCode;
    }

    public DEALITEM1 withBusinessUnitCode(String businessUnitCode) {
        this.businessUnitCode = businessUnitCode;
        return this;
    }

    @JsonProperty("ListPriceAmount")
    public String getListPriceAmount() {
        return listPriceAmount;
    }

    @JsonProperty("ListPriceAmount")
    public void setListPriceAmount(String listPriceAmount) {
        this.listPriceAmount = listPriceAmount;
    }

    public DEALITEM1 withListPriceAmount(String listPriceAmount) {
        this.listPriceAmount = listPriceAmount;
        return this;
    }

    @JsonProperty("StandardDiscountPercentage")
    public String getStandardDiscountPercentage() {
        return standardDiscountPercentage;
    }

    @JsonProperty("StandardDiscountPercentage")
    public void setStandardDiscountPercentage(String standardDiscountPercentage) {
        this.standardDiscountPercentage = standardDiscountPercentage;
    }

    public DEALITEM1 withStandardDiscountPercentage(String standardDiscountPercentage) {
        this.standardDiscountPercentage = standardDiscountPercentage;
        return this;
    }

    @JsonProperty("PriceTypeCode")
    public String getPriceTypeCode() {
        return priceTypeCode;
    }

    @JsonProperty("PriceTypeCode")
    public void setPriceTypeCode(String priceTypeCode) {
        this.priceTypeCode = priceTypeCode;
    }

    public DEALITEM1 withPriceTypeCode(String priceTypeCode) {
        this.priceTypeCode = priceTypeCode;
        return this;
    }

    @JsonProperty("RequestedBigDealNetAmount")
    public String getRequestedBigDealNetAmount() {
        return requestedBigDealNetAmount;
    }

    @JsonProperty("RequestedBigDealNetAmount")
    public void setRequestedBigDealNetAmount(String requestedBigDealNetAmount) {
        this.requestedBigDealNetAmount = requestedBigDealNetAmount;
    }

    public DEALITEM1 withRequestedBigDealNetAmount(String requestedBigDealNetAmount) {
        this.requestedBigDealNetAmount = requestedBigDealNetAmount;
        return this;
    }

    @JsonProperty("RequestedAddPercentage")
    public String getRequestedAddPercentage() {
        return requestedAddPercentage;
    }

    @JsonProperty("RequestedAddPercentage")
    public void setRequestedAddPercentage(String requestedAddPercentage) {
        this.requestedAddPercentage = requestedAddPercentage;
    }

    public DEALITEM1 withRequestedAddPercentage(String requestedAddPercentage) {
        this.requestedAddPercentage = requestedAddPercentage;
        return this;
    }

    @JsonProperty("RequestedTotalPercentage")
    public String getRequestedTotalPercentage() {
        return requestedTotalPercentage;
    }

    @JsonProperty("RequestedTotalPercentage")
    public void setRequestedTotalPercentage(String requestedTotalPercentage) {
        this.requestedTotalPercentage = requestedTotalPercentage;
    }

    public DEALITEM1 withRequestedTotalPercentage(String requestedTotalPercentage) {
        this.requestedTotalPercentage = requestedTotalPercentage;
        return this;
    }

    @JsonProperty("ExpertAddPercentage")
    public String getExpertAddPercentage() {
        return expertAddPercentage;
    }

    @JsonProperty("ExpertAddPercentage")
    public void setExpertAddPercentage(String expertAddPercentage) {
        this.expertAddPercentage = expertAddPercentage;
    }

    public DEALITEM1 withExpertAddPercentage(String expertAddPercentage) {
        this.expertAddPercentage = expertAddPercentage;
        return this;
    }

    @JsonProperty("FloorAddPercentage")
    public String getFloorAddPercentage() {
        return floorAddPercentage;
    }

    @JsonProperty("FloorAddPercentage")
    public void setFloorAddPercentage(String floorAddPercentage) {
        this.floorAddPercentage = floorAddPercentage;
    }

    public DEALITEM1 withFloorAddPercentage(String floorAddPercentage) {
        this.floorAddPercentage = floorAddPercentage;
        return this;
    }

    @JsonProperty("TypicalAddPercentage")
    public String getTypicalAddPercentage() {
        return typicalAddPercentage;
    }

    @JsonProperty("TypicalAddPercentage")
    public void setTypicalAddPercentage(String typicalAddPercentage) {
        this.typicalAddPercentage = typicalAddPercentage;
    }

    public DEALITEM1 withTypicalAddPercentage(String typicalAddPercentage) {
        this.typicalAddPercentage = typicalAddPercentage;
        return this;
    }

    @JsonProperty("PreviousRequestedAddPercentage")
    public String getPreviousRequestedAddPercentage() {
        return previousRequestedAddPercentage;
    }

    @JsonProperty("PreviousRequestedAddPercentage")
    public void setPreviousRequestedAddPercentage(String previousRequestedAddPercentage) {
        this.previousRequestedAddPercentage = previousRequestedAddPercentage;
    }

    public DEALITEM1 withPreviousRequestedAddPercentage(String previousRequestedAddPercentage) {
        this.previousRequestedAddPercentage = previousRequestedAddPercentage;
        return this;
    }

    @JsonProperty("AuthorizedBigDealNetAmount")
    public String getAuthorizedBigDealNetAmount() {
        return authorizedBigDealNetAmount;
    }

    @JsonProperty("AuthorizedBigDealNetAmount")
    public void setAuthorizedBigDealNetAmount(String authorizedBigDealNetAmount) {
        this.authorizedBigDealNetAmount = authorizedBigDealNetAmount;
    }

    public DEALITEM1 withAuthorizedBigDealNetAmount(String authorizedBigDealNetAmount) {
        this.authorizedBigDealNetAmount = authorizedBigDealNetAmount;
        return this;
    }

    @JsonProperty("AuthorizedAdditionalPercentage")
    public String getAuthorizedAdditionalPercentage() {
        return authorizedAdditionalPercentage;
    }

    @JsonProperty("AuthorizedAdditionalPercentage")
    public void setAuthorizedAdditionalPercentage(String authorizedAdditionalPercentage) {
        this.authorizedAdditionalPercentage = authorizedAdditionalPercentage;
    }

    public DEALITEM1 withAuthorizedAdditionalPercentage(String authorizedAdditionalPercentage) {
        this.authorizedAdditionalPercentage = authorizedAdditionalPercentage;
        return this;
    }

    @JsonProperty("AuthorizedTotalPercentage")
    public String getAuthorizedTotalPercentage() {
        return authorizedTotalPercentage;
    }

    @JsonProperty("AuthorizedTotalPercentage")
    public void setAuthorizedTotalPercentage(String authorizedTotalPercentage) {
        this.authorizedTotalPercentage = authorizedTotalPercentage;
    }

    public DEALITEM1 withAuthorizedTotalPercentage(String authorizedTotalPercentage) {
        this.authorizedTotalPercentage = authorizedTotalPercentage;
        return this;
    }

    @JsonProperty("RequestedGrossMarginAmount")
    public String getRequestedGrossMarginAmount() {
        return requestedGrossMarginAmount;
    }

    @JsonProperty("RequestedGrossMarginAmount")
    public void setRequestedGrossMarginAmount(String requestedGrossMarginAmount) {
        this.requestedGrossMarginAmount = requestedGrossMarginAmount;
    }

    public DEALITEM1 withRequestedGrossMarginAmount(String requestedGrossMarginAmount) {
        this.requestedGrossMarginAmount = requestedGrossMarginAmount;
        return this;
    }

    @JsonProperty("RequestedGrossMarginPercentage")
    public String getRequestedGrossMarginPercentage() {
        return requestedGrossMarginPercentage;
    }

    @JsonProperty("RequestedGrossMarginPercentage")
    public void setRequestedGrossMarginPercentage(String requestedGrossMarginPercentage) {
        this.requestedGrossMarginPercentage = requestedGrossMarginPercentage;
    }

    public DEALITEM1 withRequestedGrossMarginPercentage(String requestedGrossMarginPercentage) {
        this.requestedGrossMarginPercentage = requestedGrossMarginPercentage;
        return this;
    }

    @JsonProperty("AuthorizedGrossMarginAmount")
    public String getAuthorizedGrossMarginAmount() {
        return authorizedGrossMarginAmount;
    }

    @JsonProperty("AuthorizedGrossMarginAmount")
    public void setAuthorizedGrossMarginAmount(String authorizedGrossMarginAmount) {
        this.authorizedGrossMarginAmount = authorizedGrossMarginAmount;
    }

    public DEALITEM1 withAuthorizedGrossMarginAmount(String authorizedGrossMarginAmount) {
        this.authorizedGrossMarginAmount = authorizedGrossMarginAmount;
        return this;
    }

    @JsonProperty("AuthorizedGrossMarginPercentage")
    public String getAuthorizedGrossMarginPercentage() {
        return authorizedGrossMarginPercentage;
    }

    @JsonProperty("AuthorizedGrossMarginPercentage")
    public void setAuthorizedGrossMarginPercentage(String authorizedGrossMarginPercentage) {
        this.authorizedGrossMarginPercentage = authorizedGrossMarginPercentage;
    }

    public DEALITEM1 withAuthorizedGrossMarginPercentage(String authorizedGrossMarginPercentage) {
        this.authorizedGrossMarginPercentage = authorizedGrossMarginPercentage;
        return this;
    }

    @JsonProperty("ExtendedRequestBigDealNetAmount")
    public String getExtendedRequestBigDealNetAmount() {
        return extendedRequestBigDealNetAmount;
    }

    @JsonProperty("ExtendedRequestBigDealNetAmount")
    public void setExtendedRequestBigDealNetAmount(String extendedRequestBigDealNetAmount) {
        this.extendedRequestBigDealNetAmount = extendedRequestBigDealNetAmount;
    }

    public DEALITEM1 withExtendedRequestBigDealNetAmount(String extendedRequestBigDealNetAmount) {
        this.extendedRequestBigDealNetAmount = extendedRequestBigDealNetAmount;
        return this;
    }

    @JsonProperty("ExtendedAuthorizedBigDealNetAmount")
    public String getExtendedAuthorizedBigDealNetAmount() {
        return extendedAuthorizedBigDealNetAmount;
    }

    @JsonProperty("ExtendedAuthorizedBigDealNetAmount")
    public void setExtendedAuthorizedBigDealNetAmount(String extendedAuthorizedBigDealNetAmount) {
        this.extendedAuthorizedBigDealNetAmount = extendedAuthorizedBigDealNetAmount;
    }

    public DEALITEM1 withExtendedAuthorizedBigDealNetAmount(String extendedAuthorizedBigDealNetAmount) {
        this.extendedAuthorizedBigDealNetAmount = extendedAuthorizedBigDealNetAmount;
        return this;
    }

    @JsonProperty("EstimatedKAmount")
    public String getEstimatedKAmount() {
        return estimatedKAmount;
    }

    @JsonProperty("EstimatedKAmount")
    public void setEstimatedKAmount(String estimatedKAmount) {
        this.estimatedKAmount = estimatedKAmount;
    }

    public DEALITEM1 withEstimatedKAmount(String estimatedKAmount) {
        this.estimatedKAmount = estimatedKAmount;
        return this;
    }

    @JsonProperty("ExtendedEstimatedKAmount")
    public String getExtendedEstimatedKAmount() {
        return extendedEstimatedKAmount;
    }

    @JsonProperty("ExtendedEstimatedKAmount")
    public void setExtendedEstimatedKAmount(String extendedEstimatedKAmount) {
        this.extendedEstimatedKAmount = extendedEstimatedKAmount;
    }

    public DEALITEM1 withExtendedEstimatedKAmount(String extendedEstimatedKAmount) {
        this.extendedEstimatedKAmount = extendedEstimatedKAmount;
        return this;
    }

    @JsonProperty("ConsumedAmount")
    public String getConsumedAmount() {
        return consumedAmount;
    }

    @JsonProperty("ConsumedAmount")
    public void setConsumedAmount(String consumedAmount) {
        this.consumedAmount = consumedAmount;
    }

    public DEALITEM1 withConsumedAmount(String consumedAmount) {
        this.consumedAmount = consumedAmount;
        return this;
    }

    @JsonProperty("ConsumedQuantity")
    public String getConsumedQuantity() {
        return consumedQuantity;
    }

    @JsonProperty("ConsumedQuantity")
    public void setConsumedQuantity(String consumedQuantity) {
        this.consumedQuantity = consumedQuantity;
    }

    public DEALITEM1 withConsumedQuantity(String consumedQuantity) {
        this.consumedQuantity = consumedQuantity;
        return this;
    }

    @JsonProperty("RemainingAmount")
    public String getRemainingAmount() {
        return remainingAmount;
    }

    @JsonProperty("RemainingAmount")
    public void setRemainingAmount(String remainingAmount) {
        this.remainingAmount = remainingAmount;
    }

    public DEALITEM1 withRemainingAmount(String remainingAmount) {
        this.remainingAmount = remainingAmount;
        return this;
    }

    @JsonProperty("RThresholdQuantity")
    public String getRThresholdQuantity() {
        return rThresholdQuantity;
    }

    @JsonProperty("RThresholdQuantity")
    public void setRThresholdQuantity(String rThresholdQuantity) {
        this.rThresholdQuantity = rThresholdQuantity;
    }

    public DEALITEM1 withRThresholdQuantity(String rThresholdQuantity) {
        this.rThresholdQuantity = rThresholdQuantity;
        return this;
    }

    @JsonProperty("SegregationofDutiesCode")
    public String getSegregationofDutiesCode() {
        return segregationofDutiesCode;
    }

    @JsonProperty("SegregationofDutiesCode")
    public void setSegregationofDutiesCode(String segregationofDutiesCode) {
        this.segregationofDutiesCode = segregationofDutiesCode;
    }

    public DEALITEM1 withSegregationofDutiesCode(String segregationofDutiesCode) {
        this.segregationofDutiesCode = segregationofDutiesCode;
        return this;
    }

    @JsonProperty("LastQuotedQuantity")
    public String getLastQuotedQuantity() {
        return lastQuotedQuantity;
    }

    @JsonProperty("LastQuotedQuantity")
    public void setLastQuotedQuantity(String lastQuotedQuantity) {
        this.lastQuotedQuantity = lastQuotedQuantity;
    }

    public DEALITEM1 withLastQuotedQuantity(String lastQuotedQuantity) {
        this.lastQuotedQuantity = lastQuotedQuantity;
        return this;
    }

    @JsonProperty("PredefinedDiscountPercentage")
    public String getPredefinedDiscountPercentage() {
        return predefinedDiscountPercentage;
    }

    @JsonProperty("PredefinedDiscountPercentage")
    public void setPredefinedDiscountPercentage(String predefinedDiscountPercentage) {
        this.predefinedDiscountPercentage = predefinedDiscountPercentage;
    }

    public DEALITEM1 withPredefinedDiscountPercentage(String predefinedDiscountPercentage) {
        this.predefinedDiscountPercentage = predefinedDiscountPercentage;
        return this;
    }

    @JsonProperty("PredefinedSourceIdentifier")
    public String getPredefinedSourceIdentifier() {
        return predefinedSourceIdentifier;
    }

    @JsonProperty("PredefinedSourceIdentifier")
    public void setPredefinedSourceIdentifier(String predefinedSourceIdentifier) {
        this.predefinedSourceIdentifier = predefinedSourceIdentifier;
    }

    public DEALITEM1 withPredefinedSourceIdentifier(String predefinedSourceIdentifier) {
        this.predefinedSourceIdentifier = predefinedSourceIdentifier;
        return this;
    }

    @JsonProperty("InstantPricingAmount")
    public String getInstantPricingAmount() {
        return instantPricingAmount;
    }

    @JsonProperty("InstantPricingAmount")
    public void setInstantPricingAmount(String instantPricingAmount) {
        this.instantPricingAmount = instantPricingAmount;
    }

    public DEALITEM1 withInstantPricingAmount(String instantPricingAmount) {
        this.instantPricingAmount = instantPricingAmount;
        return this;
    }

    @JsonProperty("RequestBackEndContraPercentage")
    public String getRequestBackEndContraPercentage() {
        return requestBackEndContraPercentage;
    }

    @JsonProperty("RequestBackEndContraPercentage")
    public void setRequestBackEndContraPercentage(String requestBackEndContraPercentage) {
        this.requestBackEndContraPercentage = requestBackEndContraPercentage;
    }

    public DEALITEM1 withRequestBackEndContraPercentage(String requestBackEndContraPercentage) {
        this.requestBackEndContraPercentage = requestBackEndContraPercentage;
        return this;
    }

    @JsonProperty("AuthorizedBackEndContraPercentage")
    public String getAuthorizedBackEndContraPercentage() {
        return authorizedBackEndContraPercentage;
    }

    @JsonProperty("AuthorizedBackEndContraPercentage")
    public void setAuthorizedBackEndContraPercentage(String authorizedBackEndContraPercentage) {
        this.authorizedBackEndContraPercentage = authorizedBackEndContraPercentage;
    }

    public DEALITEM1 withAuthorizedBackEndContraPercentage(String authorizedBackEndContraPercentage) {
        this.authorizedBackEndContraPercentage = authorizedBackEndContraPercentage;
        return this;
    }

    @JsonProperty("ExternalContraAmount")
    public String getExternalContraAmount() {
        return externalContraAmount;
    }

    @JsonProperty("ExternalContraAmount")
    public void setExternalContraAmount(String externalContraAmount) {
        this.externalContraAmount = externalContraAmount;
    }

    public DEALITEM1 withExternalContraAmount(String externalContraAmount) {
        this.externalContraAmount = externalContraAmount;
        return this;
    }

    @JsonProperty("RequestBackEndContraAmount")
    public String getRequestBackEndContraAmount() {
        return requestBackEndContraAmount;
    }

    @JsonProperty("RequestBackEndContraAmount")
    public void setRequestBackEndContraAmount(String requestBackEndContraAmount) {
        this.requestBackEndContraAmount = requestBackEndContraAmount;
    }

    public DEALITEM1 withRequestBackEndContraAmount(String requestBackEndContraAmount) {
        this.requestBackEndContraAmount = requestBackEndContraAmount;
        return this;
    }

    @JsonProperty("AuthorizedBackEndContraAmount")
    public String getAuthorizedBackEndContraAmount() {
        return authorizedBackEndContraAmount;
    }

    @JsonProperty("AuthorizedBackEndContraAmount")
    public void setAuthorizedBackEndContraAmount(String authorizedBackEndContraAmount) {
        this.authorizedBackEndContraAmount = authorizedBackEndContraAmount;
    }

    public DEALITEM1 withAuthorizedBackEndContraAmount(String authorizedBackEndContraAmount) {
        this.authorizedBackEndContraAmount = authorizedBackEndContraAmount;
        return this;
    }

    @JsonProperty("RequestNetRevenuePercentage")
    public String getRequestNetRevenuePercentage() {
        return requestNetRevenuePercentage;
    }

    @JsonProperty("RequestNetRevenuePercentage")
    public void setRequestNetRevenuePercentage(String requestNetRevenuePercentage) {
        this.requestNetRevenuePercentage = requestNetRevenuePercentage;
    }

    public DEALITEM1 withRequestNetRevenuePercentage(String requestNetRevenuePercentage) {
        this.requestNetRevenuePercentage = requestNetRevenuePercentage;
        return this;
    }

    @JsonProperty("AuthorizedNetRevenuePercentage")
    public String getAuthorizedNetRevenuePercentage() {
        return authorizedNetRevenuePercentage;
    }

    @JsonProperty("AuthorizedNetRevenuePercentage")
    public void setAuthorizedNetRevenuePercentage(String authorizedNetRevenuePercentage) {
        this.authorizedNetRevenuePercentage = authorizedNetRevenuePercentage;
    }

    public DEALITEM1 withAuthorizedNetRevenuePercentage(String authorizedNetRevenuePercentage) {
        this.authorizedNetRevenuePercentage = authorizedNetRevenuePercentage;
        return this;
    }

    @JsonProperty("RequestNetRevenueAmount")
    public String getRequestNetRevenueAmount() {
        return requestNetRevenueAmount;
    }

    @JsonProperty("RequestNetRevenueAmount")
    public void setRequestNetRevenueAmount(String requestNetRevenueAmount) {
        this.requestNetRevenueAmount = requestNetRevenueAmount;
    }

    public DEALITEM1 withRequestNetRevenueAmount(String requestNetRevenueAmount) {
        this.requestNetRevenueAmount = requestNetRevenueAmount;
        return this;
    }

    @JsonProperty("AuthorizedNetRevenueAmount")
    public String getAuthorizedNetRevenueAmount() {
        return authorizedNetRevenueAmount;
    }

    @JsonProperty("AuthorizedNetRevenueAmount")
    public void setAuthorizedNetRevenueAmount(String authorizedNetRevenueAmount) {
        this.authorizedNetRevenueAmount = authorizedNetRevenueAmount;
    }

    public DEALITEM1 withAuthorizedNetRevenueAmount(String authorizedNetRevenueAmount) {
        this.authorizedNetRevenueAmount = authorizedNetRevenueAmount;
        return this;
    }

    @JsonProperty("AuthorizedNetMarginPercentage")
    public String getAuthorizedNetMarginPercentage() {
        return authorizedNetMarginPercentage;
    }

    @JsonProperty("AuthorizedNetMarginPercentage")
    public void setAuthorizedNetMarginPercentage(String authorizedNetMarginPercentage) {
        this.authorizedNetMarginPercentage = authorizedNetMarginPercentage;
    }

    public DEALITEM1 withAuthorizedNetMarginPercentage(String authorizedNetMarginPercentage) {
        this.authorizedNetMarginPercentage = authorizedNetMarginPercentage;
        return this;
    }

    @JsonProperty("AuthorizedNetMarginAmount")
    public String getAuthorizedNetMarginAmount() {
        return authorizedNetMarginAmount;
    }

    @JsonProperty("AuthorizedNetMarginAmount")
    public void setAuthorizedNetMarginAmount(String authorizedNetMarginAmount) {
        this.authorizedNetMarginAmount = authorizedNetMarginAmount;
    }

    public DEALITEM1 withAuthorizedNetMarginAmount(String authorizedNetMarginAmount) {
        this.authorizedNetMarginAmount = authorizedNetMarginAmount;
        return this;
    }

    @JsonProperty("RequestNetMarginAmount")
    public String getRequestNetMarginAmount() {
        return requestNetMarginAmount;
    }

    @JsonProperty("RequestNetMarginAmount")
    public void setRequestNetMarginAmount(String requestNetMarginAmount) {
        this.requestNetMarginAmount = requestNetMarginAmount;
    }

    public DEALITEM1 withRequestNetMarginAmount(String requestNetMarginAmount) {
        this.requestNetMarginAmount = requestNetMarginAmount;
        return this;
    }

    @JsonProperty("RequestNetMarginPercentage")
    public String getRequestNetMarginPercentage() {
        return requestNetMarginPercentage;
    }

    @JsonProperty("RequestNetMarginPercentage")
    public void setRequestNetMarginPercentage(String requestNetMarginPercentage) {
        this.requestNetMarginPercentage = requestNetMarginPercentage;
    }

    public DEALITEM1 withRequestNetMarginPercentage(String requestNetMarginPercentage) {
        this.requestNetMarginPercentage = requestNetMarginPercentage;
        return this;
    }

    @JsonProperty("MedallionPercentage")
    public String getMedallionPercentage() {
        return medallionPercentage;
    }

    @JsonProperty("MedallionPercentage")
    public void setMedallionPercentage(String medallionPercentage) {
        this.medallionPercentage = medallionPercentage;
    }

    public DEALITEM1 withMedallionPercentage(String medallionPercentage) {
        this.medallionPercentage = medallionPercentage;
        return this;
    }

    @JsonProperty("DealValueDiscountAmount")
    public String getDealValueDiscountAmount() {
        return dealValueDiscountAmount;
    }

    @JsonProperty("DealValueDiscountAmount")
    public void setDealValueDiscountAmount(String dealValueDiscountAmount) {
        this.dealValueDiscountAmount = dealValueDiscountAmount;
    }

    public DEALITEM1 withDealValueDiscountAmount(String dealValueDiscountAmount) {
        this.dealValueDiscountAmount = dealValueDiscountAmount;
        return this;
    }

    @JsonProperty("ExpertNetAmount")
    public String getExpertNetAmount() {
        return expertNetAmount;
    }

    @JsonProperty("ExpertNetAmount")
    public void setExpertNetAmount(String expertNetAmount) {
        this.expertNetAmount = expertNetAmount;
    }

    public DEALITEM1 withExpertNetAmount(String expertNetAmount) {
        this.expertNetAmount = expertNetAmount;
        return this;
    }

    @JsonProperty("ExtendedListPriceAmount")
    public String getExtendedListPriceAmount() {
        return extendedListPriceAmount;
    }

    @JsonProperty("ExtendedListPriceAmount")
    public void setExtendedListPriceAmount(String extendedListPriceAmount) {
        this.extendedListPriceAmount = extendedListPriceAmount;
    }

    public DEALITEM1 withExtendedListPriceAmount(String extendedListPriceAmount) {
        this.extendedListPriceAmount = extendedListPriceAmount;
        return this;
    }

    @JsonProperty("FloorNetAmount")
    public String getFloorNetAmount() {
        return floorNetAmount;
    }

    @JsonProperty("FloorNetAmount")
    public void setFloorNetAmount(String floorNetAmount) {
        this.floorNetAmount = floorNetAmount;
    }

    public DEALITEM1 withFloorNetAmount(String floorNetAmount) {
        this.floorNetAmount = floorNetAmount;
        return this;
    }

    @JsonProperty("LinedAddedByUserId")
    public String getLinedAddedByUserId() {
        return linedAddedByUserId;
    }

    @JsonProperty("LinedAddedByUserId")
    public void setLinedAddedByUserId(String linedAddedByUserId) {
        this.linedAddedByUserId = linedAddedByUserId;
    }

    public DEALITEM1 withLinedAddedByUserId(String linedAddedByUserId) {
        this.linedAddedByUserId = linedAddedByUserId;
        return this;
    }

    @JsonProperty("PaymentAmount")
    public String getPaymentAmount() {
        return paymentAmount;
    }

    @JsonProperty("PaymentAmount")
    public void setPaymentAmount(String paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public DEALITEM1 withPaymentAmount(String paymentAmount) {
        this.paymentAmount = paymentAmount;
        return this;
    }

    @JsonProperty("RemainingQuantity")
    public String getRemainingQuantity() {
        return remainingQuantity;
    }

    @JsonProperty("RemainingQuantity")
    public void setRemainingQuantity(String remainingQuantity) {
        this.remainingQuantity = remainingQuantity;
    }

    public DEALITEM1 withRemainingQuantity(String remainingQuantity) {
        this.remainingQuantity = remainingQuantity;
        return this;
    }

    @JsonProperty("AuthorizedStatusCode")
    public String getAuthorizedStatusCode() {
        return authorizedStatusCode;
    }

    @JsonProperty("AuthorizedStatusCode")
    public void setAuthorizedStatusCode(String authorizedStatusCode) {
        this.authorizedStatusCode = authorizedStatusCode;
    }

    public DEALITEM1 withAuthorizedStatusCode(String authorizedStatusCode) {
        this.authorizedStatusCode = authorizedStatusCode;
        return this;
    }

    @JsonProperty("SourceSystemQuantity")
    public String getSourceSystemQuantity() {
        return sourceSystemQuantity;
    }

    @JsonProperty("SourceSystemQuantity")
    public void setSourceSystemQuantity(String sourceSystemQuantity) {
        this.sourceSystemQuantity = sourceSystemQuantity;
    }

    public DEALITEM1 withSourceSystemQuantity(String sourceSystemQuantity) {
        this.sourceSystemQuantity = sourceSystemQuantity;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public DEALITEM1 withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("OptionCode")
    public String getOptionCode() {
        return optionCode;
    }

    @JsonProperty("OptionCode")
    public void setOptionCode(String optionCode) {
        this.optionCode = optionCode;
    }

    public DEALITEM1 withOptionCode(String optionCode) {
        this.optionCode = optionCode;
        return this;
    }

    @JsonProperty("InstantPricingMethodAmount")
    public String getInstantPricingMethodAmount() {
        return instantPricingMethodAmount;
    }

    @JsonProperty("InstantPricingMethodAmount")
    public void setInstantPricingMethodAmount(String instantPricingMethodAmount) {
        this.instantPricingMethodAmount = instantPricingMethodAmount;
    }

    public DEALITEM1 withInstantPricingMethodAmount(String instantPricingMethodAmount) {
        this.instantPricingMethodAmount = instantPricingMethodAmount;
        return this;
    }

    @JsonProperty("MedallionLevelCode")
    public String getMedallionLevelCode() {
        return medallionLevelCode;
    }

    @JsonProperty("MedallionLevelCode")
    public void setMedallionLevelCode(String medallionLevelCode) {
        this.medallionLevelCode = medallionLevelCode;
    }

    public DEALITEM1 withMedallionLevelCode(String medallionLevelCode) {
        this.medallionLevelCode = medallionLevelCode;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DEALITEM1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(lineItemNumber).append(dealVersionNumber).append(sAPDocumentNumber).append(classCode).append(businessGroupCode).append(businessUnitCode).append(listPriceAmount).append(standardDiscountPercentage).append(priceTypeCode).append(requestedBigDealNetAmount).append(requestedAddPercentage).append(requestedTotalPercentage).append(expertAddPercentage).append(floorAddPercentage).append(typicalAddPercentage).append(previousRequestedAddPercentage).append(authorizedBigDealNetAmount).append(authorizedAdditionalPercentage).append(authorizedTotalPercentage).append(requestedGrossMarginAmount).append(requestedGrossMarginPercentage).append(authorizedGrossMarginAmount).append(authorizedGrossMarginPercentage).append(extendedRequestBigDealNetAmount).append(extendedAuthorizedBigDealNetAmount).append(estimatedKAmount).append(extendedEstimatedKAmount).append(consumedAmount).append(consumedQuantity).append(remainingAmount).append(rThresholdQuantity).append(segregationofDutiesCode).append(lastQuotedQuantity).append(predefinedDiscountPercentage).append(predefinedSourceIdentifier).append(instantPricingAmount).append(requestBackEndContraPercentage).append(authorizedBackEndContraPercentage).append(externalContraAmount).append(requestBackEndContraAmount).append(authorizedBackEndContraAmount).append(requestNetRevenuePercentage).append(authorizedNetRevenuePercentage).append(requestNetRevenueAmount).append(authorizedNetRevenueAmount).append(authorizedNetMarginPercentage).append(authorizedNetMarginAmount).append(requestNetMarginAmount).append(requestNetMarginPercentage).append(medallionPercentage).append(dealValueDiscountAmount).append(expertNetAmount).append(extendedListPriceAmount).append(floorNetAmount).append(linedAddedByUserId).append(paymentAmount).append(remainingQuantity).append(authorizedStatusCode).append(sourceSystemQuantity).append(materialIdentifier).append(optionCode).append(instantPricingMethodAmount).append(medallionLevelCode).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DEALITEM1) == false) {
            return false;
        }
        DEALITEM1 rhs = ((DEALITEM1) other);
        return new EqualsBuilder().append(lineItemNumber, rhs.lineItemNumber).append(dealVersionNumber, rhs.dealVersionNumber).append(sAPDocumentNumber, rhs.sAPDocumentNumber).append(classCode, rhs.classCode).append(businessGroupCode, rhs.businessGroupCode).append(businessUnitCode, rhs.businessUnitCode).append(listPriceAmount, rhs.listPriceAmount).append(standardDiscountPercentage, rhs.standardDiscountPercentage).append(priceTypeCode, rhs.priceTypeCode).append(requestedBigDealNetAmount, rhs.requestedBigDealNetAmount).append(requestedAddPercentage, rhs.requestedAddPercentage).append(requestedTotalPercentage, rhs.requestedTotalPercentage).append(expertAddPercentage, rhs.expertAddPercentage).append(floorAddPercentage, rhs.floorAddPercentage).append(typicalAddPercentage, rhs.typicalAddPercentage).append(previousRequestedAddPercentage, rhs.previousRequestedAddPercentage).append(authorizedBigDealNetAmount, rhs.authorizedBigDealNetAmount).append(authorizedAdditionalPercentage, rhs.authorizedAdditionalPercentage).append(authorizedTotalPercentage, rhs.authorizedTotalPercentage).append(requestedGrossMarginAmount, rhs.requestedGrossMarginAmount).append(requestedGrossMarginPercentage, rhs.requestedGrossMarginPercentage).append(authorizedGrossMarginAmount, rhs.authorizedGrossMarginAmount).append(authorizedGrossMarginPercentage, rhs.authorizedGrossMarginPercentage).append(extendedRequestBigDealNetAmount, rhs.extendedRequestBigDealNetAmount).append(extendedAuthorizedBigDealNetAmount, rhs.extendedAuthorizedBigDealNetAmount).append(estimatedKAmount, rhs.estimatedKAmount).append(extendedEstimatedKAmount, rhs.extendedEstimatedKAmount).append(consumedAmount, rhs.consumedAmount).append(consumedQuantity, rhs.consumedQuantity).append(remainingAmount, rhs.remainingAmount).append(rThresholdQuantity, rhs.rThresholdQuantity).append(segregationofDutiesCode, rhs.segregationofDutiesCode).append(lastQuotedQuantity, rhs.lastQuotedQuantity).append(predefinedDiscountPercentage, rhs.predefinedDiscountPercentage).append(predefinedSourceIdentifier, rhs.predefinedSourceIdentifier).append(instantPricingAmount, rhs.instantPricingAmount).append(requestBackEndContraPercentage, rhs.requestBackEndContraPercentage).append(authorizedBackEndContraPercentage, rhs.authorizedBackEndContraPercentage).append(externalContraAmount, rhs.externalContraAmount).append(requestBackEndContraAmount, rhs.requestBackEndContraAmount).append(authorizedBackEndContraAmount, rhs.authorizedBackEndContraAmount).append(requestNetRevenuePercentage, rhs.requestNetRevenuePercentage).append(authorizedNetRevenuePercentage, rhs.authorizedNetRevenuePercentage).append(requestNetRevenueAmount, rhs.requestNetRevenueAmount).append(authorizedNetRevenueAmount, rhs.authorizedNetRevenueAmount).append(authorizedNetMarginPercentage, rhs.authorizedNetMarginPercentage).append(authorizedNetMarginAmount, rhs.authorizedNetMarginAmount).append(requestNetMarginAmount, rhs.requestNetMarginAmount).append(requestNetMarginPercentage, rhs.requestNetMarginPercentage).append(medallionPercentage, rhs.medallionPercentage).append(dealValueDiscountAmount, rhs.dealValueDiscountAmount).append(expertNetAmount, rhs.expertNetAmount).append(extendedListPriceAmount, rhs.extendedListPriceAmount).append(floorNetAmount, rhs.floorNetAmount).append(linedAddedByUserId, rhs.linedAddedByUserId).append(paymentAmount, rhs.paymentAmount).append(remainingQuantity, rhs.remainingQuantity).append(authorizedStatusCode, rhs.authorizedStatusCode).append(sourceSystemQuantity, rhs.sourceSystemQuantity).append(materialIdentifier, rhs.materialIdentifier).append(optionCode, rhs.optionCode).append(instantPricingMethodAmount, rhs.instantPricingMethodAmount).append(medallionLevelCode, rhs.medallionLevelCode).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
