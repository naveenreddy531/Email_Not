
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "NonDiscountableIndicator",
    "ValidStartDate",
    "ValidEndDate",
    "AuthorizerUserID",
    "AuthorizationBasisText",
    "ConfigurationIdentifier",
    "MinimumQuantity",
    "FutureProductFl",
    "LineTypeCode",
    "MaterialDescription",
    "UserEmailIdentifier",
    "SpecialTermsText",
    "ProductLineCode",
    "AuthorizedDate"
})
public class DEALITEM2 {

    @JsonProperty("NonDiscountableIndicator")
    private String nonDiscountableIndicator;
    @JsonProperty("ValidStartDate")
    private String validStartDate;
    @JsonProperty("ValidEndDate")
    private String validEndDate;
    @JsonProperty("AuthorizerUserID")
    private String authorizerUserID;
    @JsonProperty("AuthorizationBasisText")
    private String authorizationBasisText;
    @JsonProperty("ConfigurationIdentifier")
    private String configurationIdentifier;
    @JsonProperty("MinimumQuantity")
    private String minimumQuantity;
    @JsonProperty("FutureProductFl")
    private String futureProductFl;
    @JsonProperty("LineTypeCode")
    private String lineTypeCode;
    @JsonProperty("MaterialDescription")
    private String materialDescription;
    @JsonProperty("UserEmailIdentifier")
    private String userEmailIdentifier;
    @JsonProperty("SpecialTermsText")
    private String specialTermsText;
    @JsonProperty("ProductLineCode")
    private String productLineCode;
    @JsonProperty("AuthorizedDate")
    private String authorizedDate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("NonDiscountableIndicator")
    public String getNonDiscountableIndicator() {
        return nonDiscountableIndicator;
    }

    @JsonProperty("NonDiscountableIndicator")
    public void setNonDiscountableIndicator(String nonDiscountableIndicator) {
        this.nonDiscountableIndicator = nonDiscountableIndicator;
    }

    public DEALITEM2 withNonDiscountableIndicator(String nonDiscountableIndicator) {
        this.nonDiscountableIndicator = nonDiscountableIndicator;
        return this;
    }

    @JsonProperty("ValidStartDate")
    public String getValidStartDate() {
        return validStartDate;
    }

    @JsonProperty("ValidStartDate")
    public void setValidStartDate(String validStartDate) {
        this.validStartDate = validStartDate;
    }

    public DEALITEM2 withValidStartDate(String validStartDate) {
        this.validStartDate = validStartDate;
        return this;
    }

    @JsonProperty("ValidEndDate")
    public String getValidEndDate() {
        return validEndDate;
    }

    @JsonProperty("ValidEndDate")
    public void setValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
    }

    public DEALITEM2 withValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
        return this;
    }

    @JsonProperty("AuthorizerUserID")
    public String getAuthorizerUserID() {
        return authorizerUserID;
    }

    @JsonProperty("AuthorizerUserID")
    public void setAuthorizerUserID(String authorizerUserID) {
        this.authorizerUserID = authorizerUserID;
    }

    public DEALITEM2 withAuthorizerUserID(String authorizerUserID) {
        this.authorizerUserID = authorizerUserID;
        return this;
    }

    @JsonProperty("AuthorizationBasisText")
    public String getAuthorizationBasisText() {
        return authorizationBasisText;
    }

    @JsonProperty("AuthorizationBasisText")
    public void setAuthorizationBasisText(String authorizationBasisText) {
        this.authorizationBasisText = authorizationBasisText;
    }

    public DEALITEM2 withAuthorizationBasisText(String authorizationBasisText) {
        this.authorizationBasisText = authorizationBasisText;
        return this;
    }

    @JsonProperty("ConfigurationIdentifier")
    public String getConfigurationIdentifier() {
        return configurationIdentifier;
    }

    @JsonProperty("ConfigurationIdentifier")
    public void setConfigurationIdentifier(String configurationIdentifier) {
        this.configurationIdentifier = configurationIdentifier;
    }

    public DEALITEM2 withConfigurationIdentifier(String configurationIdentifier) {
        this.configurationIdentifier = configurationIdentifier;
        return this;
    }

    @JsonProperty("MinimumQuantity")
    public String getMinimumQuantity() {
        return minimumQuantity;
    }

    @JsonProperty("MinimumQuantity")
    public void setMinimumQuantity(String minimumQuantity) {
        this.minimumQuantity = minimumQuantity;
    }

    public DEALITEM2 withMinimumQuantity(String minimumQuantity) {
        this.minimumQuantity = minimumQuantity;
        return this;
    }

    @JsonProperty("FutureProductFl")
    public String getFutureProductFl() {
        return futureProductFl;
    }

    @JsonProperty("FutureProductFl")
    public void setFutureProductFl(String futureProductFl) {
        this.futureProductFl = futureProductFl;
    }

    public DEALITEM2 withFutureProductFl(String futureProductFl) {
        this.futureProductFl = futureProductFl;
        return this;
    }

    @JsonProperty("LineTypeCode")
    public String getLineTypeCode() {
        return lineTypeCode;
    }

    @JsonProperty("LineTypeCode")
    public void setLineTypeCode(String lineTypeCode) {
        this.lineTypeCode = lineTypeCode;
    }

    public DEALITEM2 withLineTypeCode(String lineTypeCode) {
        this.lineTypeCode = lineTypeCode;
        return this;
    }

    @JsonProperty("MaterialDescription")
    public String getMaterialDescription() {
        return materialDescription;
    }

    @JsonProperty("MaterialDescription")
    public void setMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
    }

    public DEALITEM2 withMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
        return this;
    }

    @JsonProperty("UserEmailIdentifier")
    public String getUserEmailIdentifier() {
        return userEmailIdentifier;
    }

    @JsonProperty("UserEmailIdentifier")
    public void setUserEmailIdentifier(String userEmailIdentifier) {
        this.userEmailIdentifier = userEmailIdentifier;
    }

    public DEALITEM2 withUserEmailIdentifier(String userEmailIdentifier) {
        this.userEmailIdentifier = userEmailIdentifier;
        return this;
    }

    @JsonProperty("SpecialTermsText")
    public String getSpecialTermsText() {
        return specialTermsText;
    }

    @JsonProperty("SpecialTermsText")
    public void setSpecialTermsText(String specialTermsText) {
        this.specialTermsText = specialTermsText;
    }

    public DEALITEM2 withSpecialTermsText(String specialTermsText) {
        this.specialTermsText = specialTermsText;
        return this;
    }

    @JsonProperty("ProductLineCode")
    public String getProductLineCode() {
        return productLineCode;
    }

    @JsonProperty("ProductLineCode")
    public void setProductLineCode(String productLineCode) {
        this.productLineCode = productLineCode;
    }

    public DEALITEM2 withProductLineCode(String productLineCode) {
        this.productLineCode = productLineCode;
        return this;
    }

    @JsonProperty("AuthorizedDate")
    public String getAuthorizedDate() {
        return authorizedDate;
    }

    @JsonProperty("AuthorizedDate")
    public void setAuthorizedDate(String authorizedDate) {
        this.authorizedDate = authorizedDate;
    }

    public DEALITEM2 withAuthorizedDate(String authorizedDate) {
        this.authorizedDate = authorizedDate;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DEALITEM2 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(nonDiscountableIndicator).append(validStartDate).append(validEndDate).append(authorizerUserID).append(authorizationBasisText).append(configurationIdentifier).append(minimumQuantity).append(futureProductFl).append(lineTypeCode).append(materialDescription).append(userEmailIdentifier).append(specialTermsText).append(productLineCode).append(authorizedDate).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DEALITEM2) == false) {
            return false;
        }
        DEALITEM2 rhs = ((DEALITEM2) other);
        return new EqualsBuilder().append(nonDiscountableIndicator, rhs.nonDiscountableIndicator).append(validStartDate, rhs.validStartDate).append(validEndDate, rhs.validEndDate).append(authorizerUserID, rhs.authorizerUserID).append(authorizationBasisText, rhs.authorizationBasisText).append(configurationIdentifier, rhs.configurationIdentifier).append(minimumQuantity, rhs.minimumQuantity).append(futureProductFl, rhs.futureProductFl).append(lineTypeCode, rhs.lineTypeCode).append(materialDescription, rhs.materialDescription).append(userEmailIdentifier, rhs.userEmailIdentifier).append(specialTermsText, rhs.specialTermsText).append(productLineCode, rhs.productLineCode).append(authorizedDate, rhs.authorizedDate).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
