
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "DealVersionNumber",
    "SequenceNumber",
    "USER_ID",
    "EmployeeIdentifier",
    "InsertTimestamp",
    "UpdateTimestamp",
    "UserTypeCode",
    "EmployeeEmailIdentifier"
})
public class DEALUSER1 {

    @JsonProperty("DealVersionNumber")
    private String dealVersionNumber;
    @JsonProperty("SequenceNumber")
    private String sequenceNumber;
    @JsonProperty("USER_ID")
    private String uSERID;
    @JsonProperty("EmployeeIdentifier")
    private String employeeIdentifier;
    @JsonProperty("InsertTimestamp")
    private String insertTimestamp;
    @JsonProperty("UpdateTimestamp")
    private String updateTimestamp;
    @JsonProperty("UserTypeCode")
    private String userTypeCode;
    @JsonProperty("EmployeeEmailIdentifier")
    private String employeeEmailIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("DealVersionNumber")
    public String getDealVersionNumber() {
        return dealVersionNumber;
    }

    @JsonProperty("DealVersionNumber")
    public void setDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
    }

    public DEALUSER1 withDealVersionNumber(String dealVersionNumber) {
        this.dealVersionNumber = dealVersionNumber;
        return this;
    }

    @JsonProperty("SequenceNumber")
    public String getSequenceNumber() {
        return sequenceNumber;
    }

    @JsonProperty("SequenceNumber")
    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public DEALUSER1 withSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
        return this;
    }

    @JsonProperty("USER_ID")
    public String getUSERID() {
        return uSERID;
    }

    @JsonProperty("USER_ID")
    public void setUSERID(String uSERID) {
        this.uSERID = uSERID;
    }

    public DEALUSER1 withUSERID(String uSERID) {
        this.uSERID = uSERID;
        return this;
    }

    @JsonProperty("EmployeeIdentifier")
    public String getEmployeeIdentifier() {
        return employeeIdentifier;
    }

    @JsonProperty("EmployeeIdentifier")
    public void setEmployeeIdentifier(String employeeIdentifier) {
        this.employeeIdentifier = employeeIdentifier;
    }

    public DEALUSER1 withEmployeeIdentifier(String employeeIdentifier) {
        this.employeeIdentifier = employeeIdentifier;
        return this;
    }

    @JsonProperty("InsertTimestamp")
    public String getInsertTimestamp() {
        return insertTimestamp;
    }

    @JsonProperty("InsertTimestamp")
    public void setInsertTimestamp(String insertTimestamp) {
        this.insertTimestamp = insertTimestamp;
    }

    public DEALUSER1 withInsertTimestamp(String insertTimestamp) {
        this.insertTimestamp = insertTimestamp;
        return this;
    }

    @JsonProperty("UpdateTimestamp")
    public String getUpdateTimestamp() {
        return updateTimestamp;
    }

    @JsonProperty("UpdateTimestamp")
    public void setUpdateTimestamp(String updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    public DEALUSER1 withUpdateTimestamp(String updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
        return this;
    }

    @JsonProperty("UserTypeCode")
    public String getUserTypeCode() {
        return userTypeCode;
    }

    @JsonProperty("UserTypeCode")
    public void setUserTypeCode(String userTypeCode) {
        this.userTypeCode = userTypeCode;
    }

    public DEALUSER1 withUserTypeCode(String userTypeCode) {
        this.userTypeCode = userTypeCode;
        return this;
    }

    @JsonProperty("EmployeeEmailIdentifier")
    public String getEmployeeEmailIdentifier() {
        return employeeEmailIdentifier;
    }

    @JsonProperty("EmployeeEmailIdentifier")
    public void setEmployeeEmailIdentifier(String employeeEmailIdentifier) {
        this.employeeEmailIdentifier = employeeEmailIdentifier;
    }

    public DEALUSER1 withEmployeeEmailIdentifier(String employeeEmailIdentifier) {
        this.employeeEmailIdentifier = employeeEmailIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DEALUSER1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dealVersionNumber).append(sequenceNumber).append(uSERID).append(employeeIdentifier).append(insertTimestamp).append(updateTimestamp).append(userTypeCode).append(employeeEmailIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DEALUSER1) == false) {
            return false;
        }
        DEALUSER1 rhs = ((DEALUSER1) other);
        return new EqualsBuilder().append(dealVersionNumber, rhs.dealVersionNumber).append(sequenceNumber, rhs.sequenceNumber).append(uSERID, rhs.uSERID).append(employeeIdentifier, rhs.employeeIdentifier).append(insertTimestamp, rhs.insertTimestamp).append(updateTimestamp, rhs.updateTimestamp).append(userTypeCode, rhs.userTypeCode).append(employeeEmailIdentifier, rhs.employeeEmailIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
