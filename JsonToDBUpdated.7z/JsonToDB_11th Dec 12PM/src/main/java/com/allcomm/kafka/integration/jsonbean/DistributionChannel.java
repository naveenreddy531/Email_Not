
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "DistributionChannelCode",
    "DistributionChannelDescription"
})
public class DistributionChannel {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("DistributionChannelCode")
    private String distributionChannelCode;
    @JsonProperty("DistributionChannelDescription")
    private String distributionChannelDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public DistributionChannel withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("DistributionChannelCode")
    public String getDistributionChannelCode() {
        return distributionChannelCode;
    }

    @JsonProperty("DistributionChannelCode")
    public void setDistributionChannelCode(String distributionChannelCode) {
        this.distributionChannelCode = distributionChannelCode;
    }

    public DistributionChannel withDistributionChannelCode(String distributionChannelCode) {
        this.distributionChannelCode = distributionChannelCode;
        return this;
    }

    @JsonProperty("DistributionChannelDescription")
    public String getDistributionChannelDescription() {
        return distributionChannelDescription;
    }

    @JsonProperty("DistributionChannelDescription")
    public void setDistributionChannelDescription(String distributionChannelDescription) {
        this.distributionChannelDescription = distributionChannelDescription;
    }

    public DistributionChannel withDistributionChannelDescription(String distributionChannelDescription) {
        this.distributionChannelDescription = distributionChannelDescription;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DistributionChannel withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(distributionChannelCode).append(distributionChannelDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DistributionChannel) == false) {
            return false;
        }
        DistributionChannel rhs = ((DistributionChannel) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(distributionChannelCode, rhs.distributionChannelCode).append(distributionChannelDescription, rhs.distributionChannelDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
