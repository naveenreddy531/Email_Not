
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "TABNAM",
    "MANDT",
    "DOCNUM",
    "DOCREL",
    "STATUS",
    "DIRECT",
    "OUTMOD",
    "IDOCTYP",
    "MESTYP",
    "SNDPOR",
    "SNDPRT",
    "SNDPRN",
    "RCVPOR",
    "RCVPRT",
    "RCVPRN",
    "CREDAT",
    "CRETIM",
    "_SEGMENT"
})
public class EDIDC40 {

    @JsonProperty("TABNAM")
    private String tABNAM;
    @JsonProperty("MANDT")
    private String mANDT;
    @JsonProperty("DOCNUM")
    private String dOCNUM;
    @JsonProperty("DOCREL")
    private String dOCREL;
    @JsonProperty("STATUS")
    private String sTATUS;
    @JsonProperty("DIRECT")
    private String dIRECT;
    @JsonProperty("OUTMOD")
    private String oUTMOD;
    @JsonProperty("IDOCTYP")
    private String iDOCTYP;
    @JsonProperty("MESTYP")
    private String mESTYP;
    @JsonProperty("SNDPOR")
    private String sNDPOR;
    @JsonProperty("SNDPRT")
    private String sNDPRT;
    @JsonProperty("SNDPRN")
    private String sNDPRN;
    @JsonProperty("RCVPOR")
    private String rCVPOR;
    @JsonProperty("RCVPRT")
    private String rCVPRT;
    @JsonProperty("RCVPRN")
    private String rCVPRN;
    @JsonProperty("CREDAT")
    private String cREDAT;
    @JsonProperty("CRETIM")
    private String cRETIM;
    @JsonProperty("_SEGMENT")
    private String sEGMENT;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("TABNAM")
    public String getTABNAM() {
        return tABNAM;
    }

    @JsonProperty("TABNAM")
    public void setTABNAM(String tABNAM) {
        this.tABNAM = tABNAM;
    }

    public EDIDC40 withTABNAM(String tABNAM) {
        this.tABNAM = tABNAM;
        return this;
    }

    @JsonProperty("MANDT")
    public String getMANDT() {
        return mANDT;
    }

    @JsonProperty("MANDT")
    public void setMANDT(String mANDT) {
        this.mANDT = mANDT;
    }

    public EDIDC40 withMANDT(String mANDT) {
        this.mANDT = mANDT;
        return this;
    }

    @JsonProperty("DOCNUM")
    public String getDOCNUM() {
        return dOCNUM;
    }

    @JsonProperty("DOCNUM")
    public void setDOCNUM(String dOCNUM) {
        this.dOCNUM = dOCNUM;
    }

    public EDIDC40 withDOCNUM(String dOCNUM) {
        this.dOCNUM = dOCNUM;
        return this;
    }

    @JsonProperty("DOCREL")
    public String getDOCREL() {
        return dOCREL;
    }

    @JsonProperty("DOCREL")
    public void setDOCREL(String dOCREL) {
        this.dOCREL = dOCREL;
    }

    public EDIDC40 withDOCREL(String dOCREL) {
        this.dOCREL = dOCREL;
        return this;
    }

    @JsonProperty("STATUS")
    public String getSTATUS() {
        return sTATUS;
    }

    @JsonProperty("STATUS")
    public void setSTATUS(String sTATUS) {
        this.sTATUS = sTATUS;
    }

    public EDIDC40 withSTATUS(String sTATUS) {
        this.sTATUS = sTATUS;
        return this;
    }

    @JsonProperty("DIRECT")
    public String getDIRECT() {
        return dIRECT;
    }

    @JsonProperty("DIRECT")
    public void setDIRECT(String dIRECT) {
        this.dIRECT = dIRECT;
    }

    public EDIDC40 withDIRECT(String dIRECT) {
        this.dIRECT = dIRECT;
        return this;
    }

    @JsonProperty("OUTMOD")
    public String getOUTMOD() {
        return oUTMOD;
    }

    @JsonProperty("OUTMOD")
    public void setOUTMOD(String oUTMOD) {
        this.oUTMOD = oUTMOD;
    }

    public EDIDC40 withOUTMOD(String oUTMOD) {
        this.oUTMOD = oUTMOD;
        return this;
    }

    @JsonProperty("IDOCTYP")
    public String getIDOCTYP() {
        return iDOCTYP;
    }

    @JsonProperty("IDOCTYP")
    public void setIDOCTYP(String iDOCTYP) {
        this.iDOCTYP = iDOCTYP;
    }

    public EDIDC40 withIDOCTYP(String iDOCTYP) {
        this.iDOCTYP = iDOCTYP;
        return this;
    }

    @JsonProperty("MESTYP")
    public String getMESTYP() {
        return mESTYP;
    }

    @JsonProperty("MESTYP")
    public void setMESTYP(String mESTYP) {
        this.mESTYP = mESTYP;
    }

    public EDIDC40 withMESTYP(String mESTYP) {
        this.mESTYP = mESTYP;
        return this;
    }

    @JsonProperty("SNDPOR")
    public String getSNDPOR() {
        return sNDPOR;
    }

    @JsonProperty("SNDPOR")
    public void setSNDPOR(String sNDPOR) {
        this.sNDPOR = sNDPOR;
    }

    public EDIDC40 withSNDPOR(String sNDPOR) {
        this.sNDPOR = sNDPOR;
        return this;
    }

    @JsonProperty("SNDPRT")
    public String getSNDPRT() {
        return sNDPRT;
    }

    @JsonProperty("SNDPRT")
    public void setSNDPRT(String sNDPRT) {
        this.sNDPRT = sNDPRT;
    }

    public EDIDC40 withSNDPRT(String sNDPRT) {
        this.sNDPRT = sNDPRT;
        return this;
    }

    @JsonProperty("SNDPRN")
    public String getSNDPRN() {
        return sNDPRN;
    }

    @JsonProperty("SNDPRN")
    public void setSNDPRN(String sNDPRN) {
        this.sNDPRN = sNDPRN;
    }

    public EDIDC40 withSNDPRN(String sNDPRN) {
        this.sNDPRN = sNDPRN;
        return this;
    }

    @JsonProperty("RCVPOR")
    public String getRCVPOR() {
        return rCVPOR;
    }

    @JsonProperty("RCVPOR")
    public void setRCVPOR(String rCVPOR) {
        this.rCVPOR = rCVPOR;
    }

    public EDIDC40 withRCVPOR(String rCVPOR) {
        this.rCVPOR = rCVPOR;
        return this;
    }

    @JsonProperty("RCVPRT")
    public String getRCVPRT() {
        return rCVPRT;
    }

    @JsonProperty("RCVPRT")
    public void setRCVPRT(String rCVPRT) {
        this.rCVPRT = rCVPRT;
    }

    public EDIDC40 withRCVPRT(String rCVPRT) {
        this.rCVPRT = rCVPRT;
        return this;
    }

    @JsonProperty("RCVPRN")
    public String getRCVPRN() {
        return rCVPRN;
    }

    @JsonProperty("RCVPRN")
    public void setRCVPRN(String rCVPRN) {
        this.rCVPRN = rCVPRN;
    }

    public EDIDC40 withRCVPRN(String rCVPRN) {
        this.rCVPRN = rCVPRN;
        return this;
    }

    @JsonProperty("CREDAT")
    public String getCREDAT() {
        return cREDAT;
    }

    @JsonProperty("CREDAT")
    public void setCREDAT(String cREDAT) {
        this.cREDAT = cREDAT;
    }

    public EDIDC40 withCREDAT(String cREDAT) {
        this.cREDAT = cREDAT;
        return this;
    }

    @JsonProperty("CRETIM")
    public String getCRETIM() {
        return cRETIM;
    }

    @JsonProperty("CRETIM")
    public void setCRETIM(String cRETIM) {
        this.cRETIM = cRETIM;
    }

    public EDIDC40 withCRETIM(String cRETIM) {
        this.cRETIM = cRETIM;
        return this;
    }

    @JsonProperty("_SEGMENT")
    public String getSEGMENT() {
        return sEGMENT;
    }

    @JsonProperty("_SEGMENT")
    public void setSEGMENT(String sEGMENT) {
        this.sEGMENT = sEGMENT;
    }

    public EDIDC40 withSEGMENT(String sEGMENT) {
        this.sEGMENT = sEGMENT;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public EDIDC40 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(tABNAM).append(mANDT).append(dOCNUM).append(dOCREL).append(sTATUS).append(dIRECT).append(oUTMOD).append(iDOCTYP).append(mESTYP).append(sNDPOR).append(sNDPRT).append(sNDPRN).append(rCVPOR).append(rCVPRT).append(rCVPRN).append(cREDAT).append(cRETIM).append(sEGMENT).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof EDIDC40) == false) {
            return false;
        }
        EDIDC40 rhs = ((EDIDC40) other);
        return new EqualsBuilder().append(tABNAM, rhs.tABNAM).append(mANDT, rhs.mANDT).append(dOCNUM, rhs.dOCNUM).append(dOCREL, rhs.dOCREL).append(sTATUS, rhs.sTATUS).append(dIRECT, rhs.dIRECT).append(oUTMOD, rhs.oUTMOD).append(iDOCTYP, rhs.iDOCTYP).append(mESTYP, rhs.mESTYP).append(sNDPOR, rhs.sNDPOR).append(sNDPRT, rhs.sNDPRT).append(sNDPRN, rhs.sNDPRN).append(rCVPOR, rhs.rCVPOR).append(rCVPRT, rhs.rCVPRT).append(rCVPRN, rhs.rCVPRN).append(cREDAT, rhs.cREDAT).append(cRETIM, rhs.cRETIM).append(sEGMENT, rhs.sEGMENT).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
