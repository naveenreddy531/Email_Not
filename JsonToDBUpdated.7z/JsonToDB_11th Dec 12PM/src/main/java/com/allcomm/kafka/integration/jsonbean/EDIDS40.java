
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "MANDT",
    "DOCNUM",
    "LOGDAT",
    "LOGTIM",
    "STATUS",
    "STAMQU",
    "STAMID",
    "STAMNO",
    "STATYP",
    "STAPA1",
    "STAPA2",
    "UNAME",
    "SEGNUM",
    "_SEGMENT",
    "STATXT",
    "REPID",
    "ROUTID"
})
public class EDIDS40 {

    @JsonProperty("MANDT")
    private String mANDT;
    @JsonProperty("DOCNUM")
    private String dOCNUM;
    @JsonProperty("LOGDAT")
    private String lOGDAT;
    @JsonProperty("LOGTIM")
    private String lOGTIM;
    @JsonProperty("STATUS")
    private String sTATUS;
    @JsonProperty("STAMQU")
    private String sTAMQU;
    @JsonProperty("STAMID")
    private String sTAMID;
    @JsonProperty("STAMNO")
    private String sTAMNO;
    @JsonProperty("STATYP")
    private String sTATYP;
    @JsonProperty("STAPA1")
    private String sTAPA1;
    @JsonProperty("STAPA2")
    private String sTAPA2;
    @JsonProperty("UNAME")
    private String uNAME;
    @JsonProperty("SEGNUM")
    private String sEGNUM;
    @JsonProperty("_SEGMENT")
    private String sEGMENT;
    @JsonProperty("STATXT")
    private String sTATXT;
    @JsonProperty("REPID")
    private String rEPID;
    @JsonProperty("ROUTID")
    private String rOUTID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("MANDT")
    public String getMANDT() {
        return mANDT;
    }

    @JsonProperty("MANDT")
    public void setMANDT(String mANDT) {
        this.mANDT = mANDT;
    }

    public EDIDS40 withMANDT(String mANDT) {
        this.mANDT = mANDT;
        return this;
    }

    @JsonProperty("DOCNUM")
    public String getDOCNUM() {
        return dOCNUM;
    }

    @JsonProperty("DOCNUM")
    public void setDOCNUM(String dOCNUM) {
        this.dOCNUM = dOCNUM;
    }

    public EDIDS40 withDOCNUM(String dOCNUM) {
        this.dOCNUM = dOCNUM;
        return this;
    }

    @JsonProperty("LOGDAT")
    public String getLOGDAT() {
        return lOGDAT;
    }

    @JsonProperty("LOGDAT")
    public void setLOGDAT(String lOGDAT) {
        this.lOGDAT = lOGDAT;
    }

    public EDIDS40 withLOGDAT(String lOGDAT) {
        this.lOGDAT = lOGDAT;
        return this;
    }

    @JsonProperty("LOGTIM")
    public String getLOGTIM() {
        return lOGTIM;
    }

    @JsonProperty("LOGTIM")
    public void setLOGTIM(String lOGTIM) {
        this.lOGTIM = lOGTIM;
    }

    public EDIDS40 withLOGTIM(String lOGTIM) {
        this.lOGTIM = lOGTIM;
        return this;
    }

    @JsonProperty("STATUS")
    public String getSTATUS() {
        return sTATUS;
    }

    @JsonProperty("STATUS")
    public void setSTATUS(String sTATUS) {
        this.sTATUS = sTATUS;
    }

    public EDIDS40 withSTATUS(String sTATUS) {
        this.sTATUS = sTATUS;
        return this;
    }

    @JsonProperty("STAMQU")
    public String getSTAMQU() {
        return sTAMQU;
    }

    @JsonProperty("STAMQU")
    public void setSTAMQU(String sTAMQU) {
        this.sTAMQU = sTAMQU;
    }

    public EDIDS40 withSTAMQU(String sTAMQU) {
        this.sTAMQU = sTAMQU;
        return this;
    }

    @JsonProperty("STAMID")
    public String getSTAMID() {
        return sTAMID;
    }

    @JsonProperty("STAMID")
    public void setSTAMID(String sTAMID) {
        this.sTAMID = sTAMID;
    }

    public EDIDS40 withSTAMID(String sTAMID) {
        this.sTAMID = sTAMID;
        return this;
    }

    @JsonProperty("STAMNO")
    public String getSTAMNO() {
        return sTAMNO;
    }

    @JsonProperty("STAMNO")
    public void setSTAMNO(String sTAMNO) {
        this.sTAMNO = sTAMNO;
    }

    public EDIDS40 withSTAMNO(String sTAMNO) {
        this.sTAMNO = sTAMNO;
        return this;
    }

    @JsonProperty("STATYP")
    public String getSTATYP() {
        return sTATYP;
    }

    @JsonProperty("STATYP")
    public void setSTATYP(String sTATYP) {
        this.sTATYP = sTATYP;
    }

    public EDIDS40 withSTATYP(String sTATYP) {
        this.sTATYP = sTATYP;
        return this;
    }

    @JsonProperty("STAPA1")
    public String getSTAPA1() {
        return sTAPA1;
    }

    @JsonProperty("STAPA1")
    public void setSTAPA1(String sTAPA1) {
        this.sTAPA1 = sTAPA1;
    }

    public EDIDS40 withSTAPA1(String sTAPA1) {
        this.sTAPA1 = sTAPA1;
        return this;
    }

    @JsonProperty("STAPA2")
    public String getSTAPA2() {
        return sTAPA2;
    }

    @JsonProperty("STAPA2")
    public void setSTAPA2(String sTAPA2) {
        this.sTAPA2 = sTAPA2;
    }

    public EDIDS40 withSTAPA2(String sTAPA2) {
        this.sTAPA2 = sTAPA2;
        return this;
    }

    @JsonProperty("UNAME")
    public String getUNAME() {
        return uNAME;
    }

    @JsonProperty("UNAME")
    public void setUNAME(String uNAME) {
        this.uNAME = uNAME;
    }

    public EDIDS40 withUNAME(String uNAME) {
        this.uNAME = uNAME;
        return this;
    }

    @JsonProperty("SEGNUM")
    public String getSEGNUM() {
        return sEGNUM;
    }

    @JsonProperty("SEGNUM")
    public void setSEGNUM(String sEGNUM) {
        this.sEGNUM = sEGNUM;
    }

    public EDIDS40 withSEGNUM(String sEGNUM) {
        this.sEGNUM = sEGNUM;
        return this;
    }

    @JsonProperty("_SEGMENT")
    public String getSEGMENT() {
        return sEGMENT;
    }

    @JsonProperty("_SEGMENT")
    public void setSEGMENT(String sEGMENT) {
        this.sEGMENT = sEGMENT;
    }

    public EDIDS40 withSEGMENT(String sEGMENT) {
        this.sEGMENT = sEGMENT;
        return this;
    }

    @JsonProperty("STATXT")
    public String getSTATXT() {
        return sTATXT;
    }

    @JsonProperty("STATXT")
    public void setSTATXT(String sTATXT) {
        this.sTATXT = sTATXT;
    }

    public EDIDS40 withSTATXT(String sTATXT) {
        this.sTATXT = sTATXT;
        return this;
    }

    @JsonProperty("REPID")
    public String getREPID() {
        return rEPID;
    }

    @JsonProperty("REPID")
    public void setREPID(String rEPID) {
        this.rEPID = rEPID;
    }

    public EDIDS40 withREPID(String rEPID) {
        this.rEPID = rEPID;
        return this;
    }

    @JsonProperty("ROUTID")
    public String getROUTID() {
        return rOUTID;
    }

    @JsonProperty("ROUTID")
    public void setROUTID(String rOUTID) {
        this.rOUTID = rOUTID;
    }

    public EDIDS40 withROUTID(String rOUTID) {
        this.rOUTID = rOUTID;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public EDIDS40 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(mANDT).append(dOCNUM).append(lOGDAT).append(lOGTIM).append(sTATUS).append(sTAMQU).append(sTAMID).append(sTAMNO).append(sTATYP).append(sTAPA1).append(sTAPA2).append(uNAME).append(sEGNUM).append(sEGMENT).append(sTATXT).append(rEPID).append(rOUTID).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof EDIDS40) == false) {
            return false;
        }
        EDIDS40 rhs = ((EDIDS40) other);
        return new EqualsBuilder().append(mANDT, rhs.mANDT).append(dOCNUM, rhs.dOCNUM).append(lOGDAT, rhs.lOGDAT).append(lOGTIM, rhs.lOGTIM).append(sTATUS, rhs.sTATUS).append(sTAMQU, rhs.sTAMQU).append(sTAMID, rhs.sTAMID).append(sTAMNO, rhs.sTAMNO).append(sTATYP, rhs.sTATYP).append(sTAPA1, rhs.sTAPA1).append(sTAPA2, rhs.sTAPA2).append(uNAME, rhs.uNAME).append(sEGNUM, rhs.sEGNUM).append(sEGMENT, rhs.sEGMENT).append(sTATXT, rhs.sTATXT).append(rEPID, rhs.rEPID).append(rOUTID, rhs.rOUTID).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
