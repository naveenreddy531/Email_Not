
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "EDI_DC40",
    "ZDEAL_INDICATIVE",
    "EDI_DS40",
    "_BEGIN"
})
public class IDOC {

    @JsonProperty("EDI_DC40")
    private EDIDC40 eDIDC40;
    @JsonProperty("ZDEAL_INDICATIVE")
    private ZDEALINDICATIVE zDEALINDICATIVE;
    @JsonProperty("EDI_DS40")
    private List<EDIDS40> eDIDS40 = new ArrayList<EDIDS40>();
    @JsonProperty("_BEGIN")
    private String bEGIN;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("EDI_DC40")
    public EDIDC40 getEDIDC40() {
        return eDIDC40;
    }

    @JsonProperty("EDI_DC40")
    public void setEDIDC40(EDIDC40 eDIDC40) {
        this.eDIDC40 = eDIDC40;
    }

    public IDOC withEDIDC40(EDIDC40 eDIDC40) {
        this.eDIDC40 = eDIDC40;
        return this;
    }

    @JsonProperty("ZDEAL_INDICATIVE")
    public ZDEALINDICATIVE getZDEALINDICATIVE() {
        return zDEALINDICATIVE;
    }

    @JsonProperty("ZDEAL_INDICATIVE")
    public void setZDEALINDICATIVE(ZDEALINDICATIVE zDEALINDICATIVE) {
        this.zDEALINDICATIVE = zDEALINDICATIVE;
    }

    public IDOC withZDEALINDICATIVE(ZDEALINDICATIVE zDEALINDICATIVE) {
        this.zDEALINDICATIVE = zDEALINDICATIVE;
        return this;
    }

    @JsonProperty("EDI_DS40")
    public List<EDIDS40> getEDIDS40() {
        return eDIDS40;
    }

    @JsonProperty("EDI_DS40")
    public void setEDIDS40(List<EDIDS40> eDIDS40) {
        this.eDIDS40 = eDIDS40;
    }

    public IDOC withEDIDS40(List<EDIDS40> eDIDS40) {
        this.eDIDS40 = eDIDS40;
        return this;
    }

    @JsonProperty("_BEGIN")
    public String getBEGIN() {
        return bEGIN;
    }

    @JsonProperty("_BEGIN")
    public void setBEGIN(String bEGIN) {
        this.bEGIN = bEGIN;
    }

    public IDOC withBEGIN(String bEGIN) {
        this.bEGIN = bEGIN;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public IDOC withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(eDIDC40).append(zDEALINDICATIVE).append(eDIDS40).append(bEGIN).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IDOC) == false) {
            return false;
        }
        IDOC rhs = ((IDOC) other);
        return new EqualsBuilder().append(eDIDC40, rhs.eDIDC40).append(zDEALINDICATIVE, rhs.zDEALINDICATIVE).append(eDIDS40, rhs.eDIDS40).append(bEGIN, rhs.bEGIN).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
