
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "IndustrySectorCode",
    "IndustrySectorDescription"
})
public class IndustrySector {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("IndustrySectorCode")
    private String industrySectorCode;
    @JsonProperty("IndustrySectorDescription")
    private String industrySectorDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public IndustrySector withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("IndustrySectorCode")
    public String getIndustrySectorCode() {
        return industrySectorCode;
    }

    @JsonProperty("IndustrySectorCode")
    public void setIndustrySectorCode(String industrySectorCode) {
        this.industrySectorCode = industrySectorCode;
    }

    public IndustrySector withIndustrySectorCode(String industrySectorCode) {
        this.industrySectorCode = industrySectorCode;
        return this;
    }

    @JsonProperty("IndustrySectorDescription")
    public String getIndustrySectorDescription() {
        return industrySectorDescription;
    }

    @JsonProperty("IndustrySectorDescription")
    public void setIndustrySectorDescription(String industrySectorDescription) {
        this.industrySectorDescription = industrySectorDescription;
    }

    public IndustrySector withIndustrySectorDescription(String industrySectorDescription) {
        this.industrySectorDescription = industrySectorDescription;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public IndustrySector withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(industrySectorCode).append(industrySectorDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IndustrySector) == false) {
            return false;
        }
        IndustrySector rhs = ((IndustrySector) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(industrySectorCode, rhs.industrySectorCode).append(industrySectorDescription, rhs.industrySectorDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
