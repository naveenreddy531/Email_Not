
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "DEAL_HEADER1",
    "DEAL_ITEM1",
    "DEAL_ITEM2",
    "RESELLERA1",
    "RESELLERB1",
    "SALES_REP1",
    "DEAL_DEFAULT1",
    "DEAL_USER1",
    "DEAL_DISC1",
    "DEAL_CTRY1",
    "BUNDLE_HEAD_ITEM",
    "DEAL_HEADER2"
})
public class KafkaDealsDetail {

    @JsonProperty("DEAL_HEADER1")
    private DEALHEADER1 dEALHEADER1;
    @JsonProperty("DEAL_ITEM1")
    private List<DEALITEM1> dEALITEM1 = new ArrayList<DEALITEM1>();
    @JsonProperty("DEAL_ITEM2")
    private List<DEALITEM2> dEALITEM2 = new ArrayList<DEALITEM2>();
    @JsonProperty("RESELLERA1")
    private List<RESELLERA1> rESELLERA1 = new ArrayList<RESELLERA1>();
    @JsonProperty("RESELLERB1")
    private List<RESELLERB1> rESELLERB1 = new ArrayList<RESELLERB1>();
    @JsonProperty("SALES_REP1")
    private List<SALESREP1> sALESREP1 = new ArrayList<SALESREP1>();
    @JsonProperty("DEAL_DEFAULT1")
    private List<DEALDEFAULT1> dEALDEFAULT1 = new ArrayList<DEALDEFAULT1>();
    @JsonProperty("DEAL_USER1")
    private List<DEALUSER1> dEALUSER1 = new ArrayList<DEALUSER1>();
    @JsonProperty("DEAL_DISC1")
    private List<DEALDISC1> dEALDISC1 = new ArrayList<DEALDISC1>();
    @JsonProperty("DEAL_CTRY1")
    private List<DEALCTRY1> dEALCTRY1 = new ArrayList<DEALCTRY1>();
    @JsonProperty("BUNDLE_HEAD_ITEM")
    private List<BUNDLEHEADITEM> bUNDLEHEADITEM = new ArrayList<BUNDLEHEADITEM>();
    @JsonProperty("DEAL_HEADER2")
    private DEALHEADER2 dEALHEADER2;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("DEAL_HEADER1")
    public DEALHEADER1 getDEALHEADER1() {
        return dEALHEADER1;
    }

    @JsonProperty("DEAL_HEADER1")
    public void setDEALHEADER1(DEALHEADER1 dEALHEADER1) {
        this.dEALHEADER1 = dEALHEADER1;
    }

    public KafkaDealsDetail withDEALHEADER1(DEALHEADER1 dEALHEADER1) {
        this.dEALHEADER1 = dEALHEADER1;
        return this;
    }

    @JsonProperty("DEAL_ITEM1")
    public List<DEALITEM1> getDEALITEM1() {
        return dEALITEM1;
    }

    @JsonProperty("DEAL_ITEM1")
    public void setDEALITEM1(List<DEALITEM1> dEALITEM1) {
        this.dEALITEM1 = dEALITEM1;
    }

    public KafkaDealsDetail withDEALITEM1(List<DEALITEM1> dEALITEM1) {
        this.dEALITEM1 = dEALITEM1;
        return this;
    }

    @JsonProperty("DEAL_ITEM2")
    public List<DEALITEM2> getDEALITEM2() {
        return dEALITEM2;
    }

    @JsonProperty("DEAL_ITEM2")
    public void setDEALITEM2(List<DEALITEM2> dEALITEM2) {
        this.dEALITEM2 = dEALITEM2;
    }

    public KafkaDealsDetail withDEALITEM2(List<DEALITEM2> dEALITEM2) {
        this.dEALITEM2 = dEALITEM2;
        return this;
    }

    @JsonProperty("RESELLERA1")
    public List<RESELLERA1> getRESELLERA1() {
        return rESELLERA1;
    }

    @JsonProperty("RESELLERA1")
    public void setRESELLERA1(List<RESELLERA1> rESELLERA1) {
        this.rESELLERA1 = rESELLERA1;
    }

    public KafkaDealsDetail withRESELLERA1(List<RESELLERA1> rESELLERA1) {
        this.rESELLERA1 = rESELLERA1;
        return this;
    }

    @JsonProperty("RESELLERB1")
    public List<RESELLERB1> getRESELLERB1() {
        return rESELLERB1;
    }

    @JsonProperty("RESELLERB1")
    public void setRESELLERB1(List<RESELLERB1> rESELLERB1) {
        this.rESELLERB1 = rESELLERB1;
    }

    public KafkaDealsDetail withRESELLERB1(List<RESELLERB1> rESELLERB1) {
        this.rESELLERB1 = rESELLERB1;
        return this;
    }

    @JsonProperty("SALES_REP1")
    public List<SALESREP1> getSALESREP1() {
        return sALESREP1;
    }

    @JsonProperty("SALES_REP1")
    public void setSALESREP1(List<SALESREP1> sALESREP1) {
        this.sALESREP1 = sALESREP1;
    }

    public KafkaDealsDetail withSALESREP1(List<SALESREP1> sALESREP1) {
        this.sALESREP1 = sALESREP1;
        return this;
    }

    @JsonProperty("DEAL_DEFAULT1")
    public List<DEALDEFAULT1> getDEALDEFAULT1() {
        return dEALDEFAULT1;
    }

    @JsonProperty("DEAL_DEFAULT1")
    public void setDEALDEFAULT1(List<DEALDEFAULT1> dEALDEFAULT1) {
        this.dEALDEFAULT1 = dEALDEFAULT1;
    }

    public KafkaDealsDetail withDEALDEFAULT1(List<DEALDEFAULT1> dEALDEFAULT1) {
        this.dEALDEFAULT1 = dEALDEFAULT1;
        return this;
    }

    @JsonProperty("DEAL_USER1")
    public List<DEALUSER1> getDEALUSER1() {
        return dEALUSER1;
    }

    @JsonProperty("DEAL_USER1")
    public void setDEALUSER1(List<DEALUSER1> dEALUSER1) {
        this.dEALUSER1 = dEALUSER1;
    }

    public KafkaDealsDetail withDEALUSER1(List<DEALUSER1> dEALUSER1) {
        this.dEALUSER1 = dEALUSER1;
        return this;
    }

    @JsonProperty("DEAL_DISC1")
    public List<DEALDISC1> getDEALDISC1() {
        return dEALDISC1;
    }

    @JsonProperty("DEAL_DISC1")
    public void setDEALDISC1(List<DEALDISC1> dEALDISC1) {
        this.dEALDISC1 = dEALDISC1;
    }

    public KafkaDealsDetail withDEALDISC1(List<DEALDISC1> dEALDISC1) {
        this.dEALDISC1 = dEALDISC1;
        return this;
    }

    @JsonProperty("DEAL_CTRY1")
    public List<DEALCTRY1> getDEALCTRY1() {
        return dEALCTRY1;
    }

    @JsonProperty("DEAL_CTRY1")
    public void setDEALCTRY1(List<DEALCTRY1> dEALCTRY1) {
        this.dEALCTRY1 = dEALCTRY1;
    }

    public KafkaDealsDetail withDEALCTRY1(List<DEALCTRY1> dEALCTRY1) {
        this.dEALCTRY1 = dEALCTRY1;
        return this;
    }

    @JsonProperty("BUNDLE_HEAD_ITEM")
    public List<BUNDLEHEADITEM> getBUNDLEHEADITEM() {
        return bUNDLEHEADITEM;
    }

    @JsonProperty("BUNDLE_HEAD_ITEM")
    public void setBUNDLEHEADITEM(List<BUNDLEHEADITEM> bUNDLEHEADITEM) {
        this.bUNDLEHEADITEM = bUNDLEHEADITEM;
    }

    public KafkaDealsDetail withBUNDLEHEADITEM(List<BUNDLEHEADITEM> bUNDLEHEADITEM) {
        this.bUNDLEHEADITEM = bUNDLEHEADITEM;
        return this;
    }

    @JsonProperty("DEAL_HEADER2")
    public DEALHEADER2 getDEALHEADER2() {
        return dEALHEADER2;
    }

    @JsonProperty("DEAL_HEADER2")
    public void setDEALHEADER2(DEALHEADER2 dEALHEADER2) {
        this.dEALHEADER2 = dEALHEADER2;
    }

    public KafkaDealsDetail withDEALHEADER2(DEALHEADER2 dEALHEADER2) {
        this.dEALHEADER2 = dEALHEADER2;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public KafkaDealsDetail withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dEALHEADER1).append(dEALITEM1).append(dEALITEM2).append(rESELLERA1).append(rESELLERB1).append(sALESREP1).append(dEALDEFAULT1).append(dEALUSER1).append(dEALDISC1).append(dEALCTRY1).append(bUNDLEHEADITEM).append(dEALHEADER2).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof KafkaDealsDetail) == false) {
            return false;
        }
        KafkaDealsDetail rhs = ((KafkaDealsDetail) other);
        return new EqualsBuilder().append(dEALHEADER1, rhs.dEALHEADER1).append(dEALITEM1, rhs.dEALITEM1).append(dEALITEM2, rhs.dEALITEM2).append(rESELLERA1, rhs.rESELLERA1).append(rESELLERB1, rhs.rESELLERB1).append(sALESREP1, rhs.sALESREP1).append(dEALDEFAULT1, rhs.dEALDEFAULT1).append(dEALUSER1, rhs.dEALUSER1).append(dEALDISC1, rhs.dEALDISC1).append(dEALCTRY1, rhs.dEALCTRY1).append(bUNDLEHEADITEM, rhs.bUNDLEHEADITEM).append(dEALHEADER2, rhs.dEALHEADER2).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
