
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "InternalClassNumber",
    "MaterialIdentifier",
    "ClassTypeCode",
    "SortPositionNumber",
    "ClassificationStatusCode",
    "ValidEndDate",
    "ClassType",
    "ClassHeader"
})
public class MaterialClassAllocation {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("InternalClassNumber")
    private Integer internalClassNumber;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("ClassTypeCode")
    private String classTypeCode;
    @JsonProperty("SortPositionNumber")
    private Integer sortPositionNumber;
    @JsonProperty("ClassificationStatusCode")
    private String classificationStatusCode;
    @JsonProperty("ValidEndDate")
    private String validEndDate;
    @JsonProperty("ClassType")
    private ClassType classType;
    @JsonProperty("ClassHeader")
    private ClassHeader classHeader;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialClassAllocation withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("InternalClassNumber")
    public Integer getInternalClassNumber() {
        return internalClassNumber;
    }

    @JsonProperty("InternalClassNumber")
    public void setInternalClassNumber(Integer internalClassNumber) {
        this.internalClassNumber = internalClassNumber;
    }

    public MaterialClassAllocation withInternalClassNumber(Integer internalClassNumber) {
        this.internalClassNumber = internalClassNumber;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public MaterialClassAllocation withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("ClassTypeCode")
    public String getClassTypeCode() {
        return classTypeCode;
    }

    @JsonProperty("ClassTypeCode")
    public void setClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
    }

    public MaterialClassAllocation withClassTypeCode(String classTypeCode) {
        this.classTypeCode = classTypeCode;
        return this;
    }

    @JsonProperty("SortPositionNumber")
    public Integer getSortPositionNumber() {
        return sortPositionNumber;
    }

    @JsonProperty("SortPositionNumber")
    public void setSortPositionNumber(Integer sortPositionNumber) {
        this.sortPositionNumber = sortPositionNumber;
    }

    public MaterialClassAllocation withSortPositionNumber(Integer sortPositionNumber) {
        this.sortPositionNumber = sortPositionNumber;
        return this;
    }

    @JsonProperty("ClassificationStatusCode")
    public String getClassificationStatusCode() {
        return classificationStatusCode;
    }

    @JsonProperty("ClassificationStatusCode")
    public void setClassificationStatusCode(String classificationStatusCode) {
        this.classificationStatusCode = classificationStatusCode;
    }

    public MaterialClassAllocation withClassificationStatusCode(String classificationStatusCode) {
        this.classificationStatusCode = classificationStatusCode;
        return this;
    }

    @JsonProperty("ValidEndDate")
    public String getValidEndDate() {
        return validEndDate;
    }

    @JsonProperty("ValidEndDate")
    public void setValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
    }

    public MaterialClassAllocation withValidEndDate(String validEndDate) {
        this.validEndDate = validEndDate;
        return this;
    }

    @JsonProperty("ClassType")
    public ClassType getClassType() {
        return classType;
    }

    @JsonProperty("ClassType")
    public void setClassType(ClassType classType) {
        this.classType = classType;
    }

    public MaterialClassAllocation withClassType(ClassType classType) {
        this.classType = classType;
        return this;
    }

    @JsonProperty("ClassHeader")
    public ClassHeader getClassHeader() {
        return classHeader;
    }

    @JsonProperty("ClassHeader")
    public void setClassHeader(ClassHeader classHeader) {
        this.classHeader = classHeader;
    }

    public MaterialClassAllocation withClassHeader(ClassHeader classHeader) {
        this.classHeader = classHeader;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialClassAllocation withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(internalClassNumber).append(materialIdentifier).append(classTypeCode).append(sortPositionNumber).append(classificationStatusCode).append(validEndDate).append(classType).append(classHeader).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialClassAllocation) == false) {
            return false;
        }
        MaterialClassAllocation rhs = ((MaterialClassAllocation) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(internalClassNumber, rhs.internalClassNumber).append(materialIdentifier, rhs.materialIdentifier).append(classTypeCode, rhs.classTypeCode).append(sortPositionNumber, rhs.sortPositionNumber).append(classificationStatusCode, rhs.classificationStatusCode).append(validEndDate, rhs.validEndDate).append(classType, rhs.classType).append(classHeader, rhs.classHeader).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
