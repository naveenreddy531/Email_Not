
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialItemCategoryGroupCode",
    "MaterialItemCategoryGroupDescription"
})
public class MaterialItemCategoryGroup {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialItemCategoryGroupCode")
    private String materialItemCategoryGroupCode;
    @JsonProperty("MaterialItemCategoryGroupDescription")
    private String materialItemCategoryGroupDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialItemCategoryGroup withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialItemCategoryGroupCode")
    public String getMaterialItemCategoryGroupCode() {
        return materialItemCategoryGroupCode;
    }

    @JsonProperty("MaterialItemCategoryGroupCode")
    public void setMaterialItemCategoryGroupCode(String materialItemCategoryGroupCode) {
        this.materialItemCategoryGroupCode = materialItemCategoryGroupCode;
    }

    public MaterialItemCategoryGroup withMaterialItemCategoryGroupCode(String materialItemCategoryGroupCode) {
        this.materialItemCategoryGroupCode = materialItemCategoryGroupCode;
        return this;
    }

    @JsonProperty("MaterialItemCategoryGroupDescription")
    public String getMaterialItemCategoryGroupDescription() {
        return materialItemCategoryGroupDescription;
    }

    @JsonProperty("MaterialItemCategoryGroupDescription")
    public void setMaterialItemCategoryGroupDescription(String materialItemCategoryGroupDescription) {
        this.materialItemCategoryGroupDescription = materialItemCategoryGroupDescription;
    }

    public MaterialItemCategoryGroup withMaterialItemCategoryGroupDescription(String materialItemCategoryGroupDescription) {
        this.materialItemCategoryGroupDescription = materialItemCategoryGroupDescription;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialItemCategoryGroup withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialItemCategoryGroupCode).append(materialItemCategoryGroupDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialItemCategoryGroup) == false) {
            return false;
        }
        MaterialItemCategoryGroup rhs = ((MaterialItemCategoryGroup) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialItemCategoryGroupCode, rhs.materialItemCategoryGroupCode).append(materialItemCategoryGroupDescription, rhs.materialItemCategoryGroupDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
