
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialIdentifier",
    "ISOLanguageCode",
    "MaterialDescription"
})
public class MaterialLanguage {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("ISOLanguageCode")
    private String iSOLanguageCode;
    @JsonProperty("MaterialDescription")
    private String materialDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialLanguage withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public MaterialLanguage withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("ISOLanguageCode")
    public String getISOLanguageCode() {
        return iSOLanguageCode;
    }

    @JsonProperty("ISOLanguageCode")
    public void setISOLanguageCode(String iSOLanguageCode) {
        this.iSOLanguageCode = iSOLanguageCode;
    }

    public MaterialLanguage withISOLanguageCode(String iSOLanguageCode) {
        this.iSOLanguageCode = iSOLanguageCode;
        return this;
    }

    @JsonProperty("MaterialDescription")
    public String getMaterialDescription() {
        return materialDescription;
    }

    @JsonProperty("MaterialDescription")
    public void setMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
    }

    public MaterialLanguage withMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialLanguage withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialIdentifier).append(iSOLanguageCode).append(materialDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialLanguage) == false) {
            return false;
        }
        MaterialLanguage rhs = ((MaterialLanguage) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialIdentifier, rhs.materialIdentifier).append(iSOLanguageCode, rhs.iSOLanguageCode).append(materialDescription, rhs.materialDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
