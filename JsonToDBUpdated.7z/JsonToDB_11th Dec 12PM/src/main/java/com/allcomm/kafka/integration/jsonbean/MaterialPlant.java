
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialIdentifier",
    "PlantCode",
    "PlanningMaterialIdentifier",
    "MaterialProcurementType",
    "MaterialRequirementPlanning",
    "MaterialRequirementPlanningController",
    "MaterialRequirementPlanningGroup",
    "LoadingGroup",
    "MaterialABCAnalysis",
    "CostingVariance",
    "MaterialPlanningStrategyGroup",
    "ProductionSupplyArea",
    "RepetitiveManufacturingProfile",
    "ValuationCategory",
    "ManagementProfile",
    "PurchasingGroup",
    "MaterialStatus",
    "LoadingGroupCode",
    "MRPTypeCode",
    "MRPControllerCode",
    "PurchasingGroupCode",
    "MRPGroupCode",
    "IssueStorageLocationCode",
    "SchedulingMarginCode",
    "MaterialPlanningStrategyGroupCode",
    "MaterialProcurementTypeCode",
    "SpecialProcurementTypeCode",
    "DependentRequirementCode"
})
public class MaterialPlant {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("PlantCode")
    private String plantCode;
    @JsonProperty("PlanningMaterialIdentifier")
    private String planningMaterialIdentifier;
    @JsonProperty("MaterialProcurementType")
    private MaterialProcurementType materialProcurementType;
    @JsonProperty("MaterialRequirementPlanning")
    private MaterialRequirementPlanning materialRequirementPlanning;
    @JsonProperty("MaterialRequirementPlanningController")
    private MaterialRequirementPlanningController materialRequirementPlanningController;
    @JsonProperty("MaterialRequirementPlanningGroup")
    private MaterialRequirementPlanningGroup materialRequirementPlanningGroup;
    @JsonProperty("LoadingGroup")
    private LoadingGroup loadingGroup;
    @JsonProperty("MaterialABCAnalysis")
    private MaterialABCAnalysis materialABCAnalysis;
    @JsonProperty("CostingVariance")
    private CostingVariance costingVariance;
    @JsonProperty("MaterialPlanningStrategyGroup")
    private MaterialPlanningStrategyGroup materialPlanningStrategyGroup;
    @JsonProperty("ProductionSupplyArea")
    private ProductionSupplyArea productionSupplyArea;
    @JsonProperty("RepetitiveManufacturingProfile")
    private RepetitiveManufacturingProfile repetitiveManufacturingProfile;
    @JsonProperty("ValuationCategory")
    private ValuationCategory valuationCategory;
    @JsonProperty("ManagementProfile")
    private ManagementProfile managementProfile;
    @JsonProperty("PurchasingGroup")
    private PurchasingGroup purchasingGroup;
    @JsonProperty("MaterialStatus")
    private MaterialStatus materialStatus;
    @JsonProperty("LoadingGroupCode")
    private String loadingGroupCode;
    @JsonProperty("MRPTypeCode")
    private String mRPTypeCode;
    @JsonProperty("MRPControllerCode")
    private String mRPControllerCode;
    @JsonProperty("PurchasingGroupCode")
    private String purchasingGroupCode;
    @JsonProperty("MRPGroupCode")
    private String mRPGroupCode;
    @JsonProperty("IssueStorageLocationCode")
    private String issueStorageLocationCode;
    @JsonProperty("SchedulingMarginCode")
    private String schedulingMarginCode;
    @JsonProperty("MaterialPlanningStrategyGroupCode")
    private String materialPlanningStrategyGroupCode;
    @JsonProperty("MaterialProcurementTypeCode")
    private String materialProcurementTypeCode;
    @JsonProperty("SpecialProcurementTypeCode")
    private String specialProcurementTypeCode;
    @JsonProperty("DependentRequirementCode")
    private String dependentRequirementCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialPlant withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public MaterialPlant withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("PlantCode")
    public String getPlantCode() {
        return plantCode;
    }

    @JsonProperty("PlantCode")
    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public MaterialPlant withPlantCode(String plantCode) {
        this.plantCode = plantCode;
        return this;
    }

    @JsonProperty("PlanningMaterialIdentifier")
    public String getPlanningMaterialIdentifier() {
        return planningMaterialIdentifier;
    }

    @JsonProperty("PlanningMaterialIdentifier")
    public void setPlanningMaterialIdentifier(String planningMaterialIdentifier) {
        this.planningMaterialIdentifier = planningMaterialIdentifier;
    }

    public MaterialPlant withPlanningMaterialIdentifier(String planningMaterialIdentifier) {
        this.planningMaterialIdentifier = planningMaterialIdentifier;
        return this;
    }

    @JsonProperty("MaterialProcurementType")
    public MaterialProcurementType getMaterialProcurementType() {
        return materialProcurementType;
    }

    @JsonProperty("MaterialProcurementType")
    public void setMaterialProcurementType(MaterialProcurementType materialProcurementType) {
        this.materialProcurementType = materialProcurementType;
    }

    public MaterialPlant withMaterialProcurementType(MaterialProcurementType materialProcurementType) {
        this.materialProcurementType = materialProcurementType;
        return this;
    }

    @JsonProperty("MaterialRequirementPlanning")
    public MaterialRequirementPlanning getMaterialRequirementPlanning() {
        return materialRequirementPlanning;
    }

    @JsonProperty("MaterialRequirementPlanning")
    public void setMaterialRequirementPlanning(MaterialRequirementPlanning materialRequirementPlanning) {
        this.materialRequirementPlanning = materialRequirementPlanning;
    }

    public MaterialPlant withMaterialRequirementPlanning(MaterialRequirementPlanning materialRequirementPlanning) {
        this.materialRequirementPlanning = materialRequirementPlanning;
        return this;
    }

    @JsonProperty("MaterialRequirementPlanningController")
    public MaterialRequirementPlanningController getMaterialRequirementPlanningController() {
        return materialRequirementPlanningController;
    }

    @JsonProperty("MaterialRequirementPlanningController")
    public void setMaterialRequirementPlanningController(MaterialRequirementPlanningController materialRequirementPlanningController) {
        this.materialRequirementPlanningController = materialRequirementPlanningController;
    }

    public MaterialPlant withMaterialRequirementPlanningController(MaterialRequirementPlanningController materialRequirementPlanningController) {
        this.materialRequirementPlanningController = materialRequirementPlanningController;
        return this;
    }

    @JsonProperty("MaterialRequirementPlanningGroup")
    public MaterialRequirementPlanningGroup getMaterialRequirementPlanningGroup() {
        return materialRequirementPlanningGroup;
    }

    @JsonProperty("MaterialRequirementPlanningGroup")
    public void setMaterialRequirementPlanningGroup(MaterialRequirementPlanningGroup materialRequirementPlanningGroup) {
        this.materialRequirementPlanningGroup = materialRequirementPlanningGroup;
    }

    public MaterialPlant withMaterialRequirementPlanningGroup(MaterialRequirementPlanningGroup materialRequirementPlanningGroup) {
        this.materialRequirementPlanningGroup = materialRequirementPlanningGroup;
        return this;
    }

    @JsonProperty("LoadingGroup")
    public LoadingGroup getLoadingGroup() {
        return loadingGroup;
    }

    @JsonProperty("LoadingGroup")
    public void setLoadingGroup(LoadingGroup loadingGroup) {
        this.loadingGroup = loadingGroup;
    }

    public MaterialPlant withLoadingGroup(LoadingGroup loadingGroup) {
        this.loadingGroup = loadingGroup;
        return this;
    }

    @JsonProperty("MaterialABCAnalysis")
    public MaterialABCAnalysis getMaterialABCAnalysis() {
        return materialABCAnalysis;
    }

    @JsonProperty("MaterialABCAnalysis")
    public void setMaterialABCAnalysis(MaterialABCAnalysis materialABCAnalysis) {
        this.materialABCAnalysis = materialABCAnalysis;
    }

    public MaterialPlant withMaterialABCAnalysis(MaterialABCAnalysis materialABCAnalysis) {
        this.materialABCAnalysis = materialABCAnalysis;
        return this;
    }

    @JsonProperty("CostingVariance")
    public CostingVariance getCostingVariance() {
        return costingVariance;
    }

    @JsonProperty("CostingVariance")
    public void setCostingVariance(CostingVariance costingVariance) {
        this.costingVariance = costingVariance;
    }

    public MaterialPlant withCostingVariance(CostingVariance costingVariance) {
        this.costingVariance = costingVariance;
        return this;
    }

    @JsonProperty("MaterialPlanningStrategyGroup")
    public MaterialPlanningStrategyGroup getMaterialPlanningStrategyGroup() {
        return materialPlanningStrategyGroup;
    }

    @JsonProperty("MaterialPlanningStrategyGroup")
    public void setMaterialPlanningStrategyGroup(MaterialPlanningStrategyGroup materialPlanningStrategyGroup) {
        this.materialPlanningStrategyGroup = materialPlanningStrategyGroup;
    }

    public MaterialPlant withMaterialPlanningStrategyGroup(MaterialPlanningStrategyGroup materialPlanningStrategyGroup) {
        this.materialPlanningStrategyGroup = materialPlanningStrategyGroup;
        return this;
    }

    @JsonProperty("ProductionSupplyArea")
    public ProductionSupplyArea getProductionSupplyArea() {
        return productionSupplyArea;
    }

    @JsonProperty("ProductionSupplyArea")
    public void setProductionSupplyArea(ProductionSupplyArea productionSupplyArea) {
        this.productionSupplyArea = productionSupplyArea;
    }

    public MaterialPlant withProductionSupplyArea(ProductionSupplyArea productionSupplyArea) {
        this.productionSupplyArea = productionSupplyArea;
        return this;
    }

    @JsonProperty("RepetitiveManufacturingProfile")
    public RepetitiveManufacturingProfile getRepetitiveManufacturingProfile() {
        return repetitiveManufacturingProfile;
    }

    @JsonProperty("RepetitiveManufacturingProfile")
    public void setRepetitiveManufacturingProfile(RepetitiveManufacturingProfile repetitiveManufacturingProfile) {
        this.repetitiveManufacturingProfile = repetitiveManufacturingProfile;
    }

    public MaterialPlant withRepetitiveManufacturingProfile(RepetitiveManufacturingProfile repetitiveManufacturingProfile) {
        this.repetitiveManufacturingProfile = repetitiveManufacturingProfile;
        return this;
    }

    @JsonProperty("ValuationCategory")
    public ValuationCategory getValuationCategory() {
        return valuationCategory;
    }

    @JsonProperty("ValuationCategory")
    public void setValuationCategory(ValuationCategory valuationCategory) {
        this.valuationCategory = valuationCategory;
    }

    public MaterialPlant withValuationCategory(ValuationCategory valuationCategory) {
        this.valuationCategory = valuationCategory;
        return this;
    }

    @JsonProperty("ManagementProfile")
    public ManagementProfile getManagementProfile() {
        return managementProfile;
    }

    @JsonProperty("ManagementProfile")
    public void setManagementProfile(ManagementProfile managementProfile) {
        this.managementProfile = managementProfile;
    }

    public MaterialPlant withManagementProfile(ManagementProfile managementProfile) {
        this.managementProfile = managementProfile;
        return this;
    }

    @JsonProperty("PurchasingGroup")
    public PurchasingGroup getPurchasingGroup() {
        return purchasingGroup;
    }

    @JsonProperty("PurchasingGroup")
    public void setPurchasingGroup(PurchasingGroup purchasingGroup) {
        this.purchasingGroup = purchasingGroup;
    }

    public MaterialPlant withPurchasingGroup(PurchasingGroup purchasingGroup) {
        this.purchasingGroup = purchasingGroup;
        return this;
    }

    @JsonProperty("MaterialStatus")
    public MaterialStatus getMaterialStatus() {
        return materialStatus;
    }

    @JsonProperty("MaterialStatus")
    public void setMaterialStatus(MaterialStatus materialStatus) {
        this.materialStatus = materialStatus;
    }

    public MaterialPlant withMaterialStatus(MaterialStatus materialStatus) {
        this.materialStatus = materialStatus;
        return this;
    }

    @JsonProperty("LoadingGroupCode")
    public String getLoadingGroupCode() {
        return loadingGroupCode;
    }

    @JsonProperty("LoadingGroupCode")
    public void setLoadingGroupCode(String loadingGroupCode) {
        this.loadingGroupCode = loadingGroupCode;
    }

    public MaterialPlant withLoadingGroupCode(String loadingGroupCode) {
        this.loadingGroupCode = loadingGroupCode;
        return this;
    }

    @JsonProperty("MRPTypeCode")
    public String getMRPTypeCode() {
        return mRPTypeCode;
    }

    @JsonProperty("MRPTypeCode")
    public void setMRPTypeCode(String mRPTypeCode) {
        this.mRPTypeCode = mRPTypeCode;
    }

    public MaterialPlant withMRPTypeCode(String mRPTypeCode) {
        this.mRPTypeCode = mRPTypeCode;
        return this;
    }

    @JsonProperty("MRPControllerCode")
    public String getMRPControllerCode() {
        return mRPControllerCode;
    }

    @JsonProperty("MRPControllerCode")
    public void setMRPControllerCode(String mRPControllerCode) {
        this.mRPControllerCode = mRPControllerCode;
    }

    public MaterialPlant withMRPControllerCode(String mRPControllerCode) {
        this.mRPControllerCode = mRPControllerCode;
        return this;
    }

    @JsonProperty("PurchasingGroupCode")
    public String getPurchasingGroupCode() {
        return purchasingGroupCode;
    }

    @JsonProperty("PurchasingGroupCode")
    public void setPurchasingGroupCode(String purchasingGroupCode) {
        this.purchasingGroupCode = purchasingGroupCode;
    }

    public MaterialPlant withPurchasingGroupCode(String purchasingGroupCode) {
        this.purchasingGroupCode = purchasingGroupCode;
        return this;
    }

    @JsonProperty("MRPGroupCode")
    public String getMRPGroupCode() {
        return mRPGroupCode;
    }

    @JsonProperty("MRPGroupCode")
    public void setMRPGroupCode(String mRPGroupCode) {
        this.mRPGroupCode = mRPGroupCode;
    }

    public MaterialPlant withMRPGroupCode(String mRPGroupCode) {
        this.mRPGroupCode = mRPGroupCode;
        return this;
    }

    @JsonProperty("IssueStorageLocationCode")
    public String getIssueStorageLocationCode() {
        return issueStorageLocationCode;
    }

    @JsonProperty("IssueStorageLocationCode")
    public void setIssueStorageLocationCode(String issueStorageLocationCode) {
        this.issueStorageLocationCode = issueStorageLocationCode;
    }

    public MaterialPlant withIssueStorageLocationCode(String issueStorageLocationCode) {
        this.issueStorageLocationCode = issueStorageLocationCode;
        return this;
    }

    @JsonProperty("SchedulingMarginCode")
    public String getSchedulingMarginCode() {
        return schedulingMarginCode;
    }

    @JsonProperty("SchedulingMarginCode")
    public void setSchedulingMarginCode(String schedulingMarginCode) {
        this.schedulingMarginCode = schedulingMarginCode;
    }

    public MaterialPlant withSchedulingMarginCode(String schedulingMarginCode) {
        this.schedulingMarginCode = schedulingMarginCode;
        return this;
    }

    @JsonProperty("MaterialPlanningStrategyGroupCode")
    public String getMaterialPlanningStrategyGroupCode() {
        return materialPlanningStrategyGroupCode;
    }

    @JsonProperty("MaterialPlanningStrategyGroupCode")
    public void setMaterialPlanningStrategyGroupCode(String materialPlanningStrategyGroupCode) {
        this.materialPlanningStrategyGroupCode = materialPlanningStrategyGroupCode;
    }

    public MaterialPlant withMaterialPlanningStrategyGroupCode(String materialPlanningStrategyGroupCode) {
        this.materialPlanningStrategyGroupCode = materialPlanningStrategyGroupCode;
        return this;
    }

    @JsonProperty("MaterialProcurementTypeCode")
    public String getMaterialProcurementTypeCode() {
        return materialProcurementTypeCode;
    }

    @JsonProperty("MaterialProcurementTypeCode")
    public void setMaterialProcurementTypeCode(String materialProcurementTypeCode) {
        this.materialProcurementTypeCode = materialProcurementTypeCode;
    }

    public MaterialPlant withMaterialProcurementTypeCode(String materialProcurementTypeCode) {
        this.materialProcurementTypeCode = materialProcurementTypeCode;
        return this;
    }

    @JsonProperty("SpecialProcurementTypeCode")
    public String getSpecialProcurementTypeCode() {
        return specialProcurementTypeCode;
    }

    @JsonProperty("SpecialProcurementTypeCode")
    public void setSpecialProcurementTypeCode(String specialProcurementTypeCode) {
        this.specialProcurementTypeCode = specialProcurementTypeCode;
    }

    public MaterialPlant withSpecialProcurementTypeCode(String specialProcurementTypeCode) {
        this.specialProcurementTypeCode = specialProcurementTypeCode;
        return this;
    }

    @JsonProperty("DependentRequirementCode")
    public String getDependentRequirementCode() {
        return dependentRequirementCode;
    }

    @JsonProperty("DependentRequirementCode")
    public void setDependentRequirementCode(String dependentRequirementCode) {
        this.dependentRequirementCode = dependentRequirementCode;
    }

    public MaterialPlant withDependentRequirementCode(String dependentRequirementCode) {
        this.dependentRequirementCode = dependentRequirementCode;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialPlant withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialIdentifier).append(plantCode).append(planningMaterialIdentifier).append(materialProcurementType).append(materialRequirementPlanning).append(materialRequirementPlanningController).append(materialRequirementPlanningGroup).append(loadingGroup).append(materialABCAnalysis).append(costingVariance).append(materialPlanningStrategyGroup).append(productionSupplyArea).append(repetitiveManufacturingProfile).append(valuationCategory).append(managementProfile).append(purchasingGroup).append(materialStatus).append(loadingGroupCode).append(mRPTypeCode).append(mRPControllerCode).append(purchasingGroupCode).append(mRPGroupCode).append(issueStorageLocationCode).append(schedulingMarginCode).append(materialPlanningStrategyGroupCode).append(materialProcurementTypeCode).append(specialProcurementTypeCode).append(dependentRequirementCode).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialPlant) == false) {
            return false;
        }
        MaterialPlant rhs = ((MaterialPlant) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialIdentifier, rhs.materialIdentifier).append(plantCode, rhs.plantCode).append(planningMaterialIdentifier, rhs.planningMaterialIdentifier).append(materialProcurementType, rhs.materialProcurementType).append(materialRequirementPlanning, rhs.materialRequirementPlanning).append(materialRequirementPlanningController, rhs.materialRequirementPlanningController).append(materialRequirementPlanningGroup, rhs.materialRequirementPlanningGroup).append(loadingGroup, rhs.loadingGroup).append(materialABCAnalysis, rhs.materialABCAnalysis).append(costingVariance, rhs.costingVariance).append(materialPlanningStrategyGroup, rhs.materialPlanningStrategyGroup).append(productionSupplyArea, rhs.productionSupplyArea).append(repetitiveManufacturingProfile, rhs.repetitiveManufacturingProfile).append(valuationCategory, rhs.valuationCategory).append(managementProfile, rhs.managementProfile).append(purchasingGroup, rhs.purchasingGroup).append(materialStatus, rhs.materialStatus).append(loadingGroupCode, rhs.loadingGroupCode).append(mRPTypeCode, rhs.mRPTypeCode).append(mRPControllerCode, rhs.mRPControllerCode).append(purchasingGroupCode, rhs.purchasingGroupCode).append(mRPGroupCode, rhs.mRPGroupCode).append(issueStorageLocationCode, rhs.issueStorageLocationCode).append(schedulingMarginCode, rhs.schedulingMarginCode).append(materialPlanningStrategyGroupCode, rhs.materialPlanningStrategyGroupCode).append(materialProcurementTypeCode, rhs.materialProcurementTypeCode).append(specialProcurementTypeCode, rhs.specialProcurementTypeCode).append(dependentRequirementCode, rhs.dependentRequirementCode).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
