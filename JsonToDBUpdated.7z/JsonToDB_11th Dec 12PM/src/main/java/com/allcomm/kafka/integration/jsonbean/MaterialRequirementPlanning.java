
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "PlantCode",
    "MRPTypeCode",
    "MRPTypeDescription"
})
public class MaterialRequirementPlanning {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("PlantCode")
    private String plantCode;
    @JsonProperty("MRPTypeCode")
    private String mRPTypeCode;
    @JsonProperty("MRPTypeDescription")
    private String mRPTypeDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialRequirementPlanning withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("PlantCode")
    public String getPlantCode() {
        return plantCode;
    }

    @JsonProperty("PlantCode")
    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public MaterialRequirementPlanning withPlantCode(String plantCode) {
        this.plantCode = plantCode;
        return this;
    }

    @JsonProperty("MRPTypeCode")
    public String getMRPTypeCode() {
        return mRPTypeCode;
    }

    @JsonProperty("MRPTypeCode")
    public void setMRPTypeCode(String mRPTypeCode) {
        this.mRPTypeCode = mRPTypeCode;
    }

    public MaterialRequirementPlanning withMRPTypeCode(String mRPTypeCode) {
        this.mRPTypeCode = mRPTypeCode;
        return this;
    }

    @JsonProperty("MRPTypeDescription")
    public String getMRPTypeDescription() {
        return mRPTypeDescription;
    }

    @JsonProperty("MRPTypeDescription")
    public void setMRPTypeDescription(String mRPTypeDescription) {
        this.mRPTypeDescription = mRPTypeDescription;
    }

    public MaterialRequirementPlanning withMRPTypeDescription(String mRPTypeDescription) {
        this.mRPTypeDescription = mRPTypeDescription;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialRequirementPlanning withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(plantCode).append(mRPTypeCode).append(mRPTypeDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialRequirementPlanning) == false) {
            return false;
        }
        MaterialRequirementPlanning rhs = ((MaterialRequirementPlanning) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(plantCode, rhs.plantCode).append(mRPTypeCode, rhs.mRPTypeCode).append(mRPTypeDescription, rhs.mRPTypeDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
