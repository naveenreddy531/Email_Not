
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialIdentifier",
    "SalesOrganizationCode",
    "DistributionChannelCode",
    "PlantCode",
    "MaterialItemCategoryGroupCode",
    "MaterialItemCategoryGroup",
    "SalesOrganization",
    "MaterialDistributionStatus",
    "MaterialAccountAssignmentGroup",
    "MaterialTaxSalesOrganization",
    "MaterialTaxCondition",
    "DistributionChannel"
})
public class MaterialSale {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("SalesOrganizationCode")
    private String salesOrganizationCode;
    @JsonProperty("DistributionChannelCode")
    private String distributionChannelCode;
    @JsonProperty("PlantCode")
    private String plantCode;
    @JsonProperty("MaterialItemCategoryGroupCode")
    private String materialItemCategoryGroupCode;
    @JsonProperty("MaterialItemCategoryGroup")
    private MaterialItemCategoryGroup materialItemCategoryGroup;
    @JsonProperty("SalesOrganization")
    private SalesOrganization salesOrganization;
    @JsonProperty("MaterialDistributionStatus")
    private MaterialDistributionStatus materialDistributionStatus;
    @JsonProperty("MaterialAccountAssignmentGroup")
    private MaterialAccountAssignmentGroup materialAccountAssignmentGroup;
    @JsonProperty("MaterialTaxSalesOrganization")
    private MaterialTaxSalesOrganization materialTaxSalesOrganization;
    @JsonProperty("MaterialTaxCondition")
    private MaterialTaxCondition materialTaxCondition;
    @JsonProperty("DistributionChannel")
    private DistributionChannel distributionChannel;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialSale withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public MaterialSale withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("SalesOrganizationCode")
    public String getSalesOrganizationCode() {
        return salesOrganizationCode;
    }

    @JsonProperty("SalesOrganizationCode")
    public void setSalesOrganizationCode(String salesOrganizationCode) {
        this.salesOrganizationCode = salesOrganizationCode;
    }

    public MaterialSale withSalesOrganizationCode(String salesOrganizationCode) {
        this.salesOrganizationCode = salesOrganizationCode;
        return this;
    }

    @JsonProperty("DistributionChannelCode")
    public String getDistributionChannelCode() {
        return distributionChannelCode;
    }

    @JsonProperty("DistributionChannelCode")
    public void setDistributionChannelCode(String distributionChannelCode) {
        this.distributionChannelCode = distributionChannelCode;
    }

    public MaterialSale withDistributionChannelCode(String distributionChannelCode) {
        this.distributionChannelCode = distributionChannelCode;
        return this;
    }

    @JsonProperty("PlantCode")
    public String getPlantCode() {
        return plantCode;
    }

    @JsonProperty("PlantCode")
    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public MaterialSale withPlantCode(String plantCode) {
        this.plantCode = plantCode;
        return this;
    }

    @JsonProperty("MaterialItemCategoryGroupCode")
    public String getMaterialItemCategoryGroupCode() {
        return materialItemCategoryGroupCode;
    }

    @JsonProperty("MaterialItemCategoryGroupCode")
    public void setMaterialItemCategoryGroupCode(String materialItemCategoryGroupCode) {
        this.materialItemCategoryGroupCode = materialItemCategoryGroupCode;
    }

    public MaterialSale withMaterialItemCategoryGroupCode(String materialItemCategoryGroupCode) {
        this.materialItemCategoryGroupCode = materialItemCategoryGroupCode;
        return this;
    }

    @JsonProperty("MaterialItemCategoryGroup")
    public MaterialItemCategoryGroup getMaterialItemCategoryGroup() {
        return materialItemCategoryGroup;
    }

    @JsonProperty("MaterialItemCategoryGroup")
    public void setMaterialItemCategoryGroup(MaterialItemCategoryGroup materialItemCategoryGroup) {
        this.materialItemCategoryGroup = materialItemCategoryGroup;
    }

    public MaterialSale withMaterialItemCategoryGroup(MaterialItemCategoryGroup materialItemCategoryGroup) {
        this.materialItemCategoryGroup = materialItemCategoryGroup;
        return this;
    }

    @JsonProperty("SalesOrganization")
    public SalesOrganization getSalesOrganization() {
        return salesOrganization;
    }

    @JsonProperty("SalesOrganization")
    public void setSalesOrganization(SalesOrganization salesOrganization) {
        this.salesOrganization = salesOrganization;
    }

    public MaterialSale withSalesOrganization(SalesOrganization salesOrganization) {
        this.salesOrganization = salesOrganization;
        return this;
    }

    @JsonProperty("MaterialDistributionStatus")
    public MaterialDistributionStatus getMaterialDistributionStatus() {
        return materialDistributionStatus;
    }

    @JsonProperty("MaterialDistributionStatus")
    public void setMaterialDistributionStatus(MaterialDistributionStatus materialDistributionStatus) {
        this.materialDistributionStatus = materialDistributionStatus;
    }

    public MaterialSale withMaterialDistributionStatus(MaterialDistributionStatus materialDistributionStatus) {
        this.materialDistributionStatus = materialDistributionStatus;
        return this;
    }

    @JsonProperty("MaterialAccountAssignmentGroup")
    public MaterialAccountAssignmentGroup getMaterialAccountAssignmentGroup() {
        return materialAccountAssignmentGroup;
    }

    @JsonProperty("MaterialAccountAssignmentGroup")
    public void setMaterialAccountAssignmentGroup(MaterialAccountAssignmentGroup materialAccountAssignmentGroup) {
        this.materialAccountAssignmentGroup = materialAccountAssignmentGroup;
    }

    public MaterialSale withMaterialAccountAssignmentGroup(MaterialAccountAssignmentGroup materialAccountAssignmentGroup) {
        this.materialAccountAssignmentGroup = materialAccountAssignmentGroup;
        return this;
    }

    @JsonProperty("MaterialTaxSalesOrganization")
    public MaterialTaxSalesOrganization getMaterialTaxSalesOrganization() {
        return materialTaxSalesOrganization;
    }

    @JsonProperty("MaterialTaxSalesOrganization")
    public void setMaterialTaxSalesOrganization(MaterialTaxSalesOrganization materialTaxSalesOrganization) {
        this.materialTaxSalesOrganization = materialTaxSalesOrganization;
    }

    public MaterialSale withMaterialTaxSalesOrganization(MaterialTaxSalesOrganization materialTaxSalesOrganization) {
        this.materialTaxSalesOrganization = materialTaxSalesOrganization;
        return this;
    }

    @JsonProperty("MaterialTaxCondition")
    public MaterialTaxCondition getMaterialTaxCondition() {
        return materialTaxCondition;
    }

    @JsonProperty("MaterialTaxCondition")
    public void setMaterialTaxCondition(MaterialTaxCondition materialTaxCondition) {
        this.materialTaxCondition = materialTaxCondition;
    }

    public MaterialSale withMaterialTaxCondition(MaterialTaxCondition materialTaxCondition) {
        this.materialTaxCondition = materialTaxCondition;
        return this;
    }

    @JsonProperty("DistributionChannel")
    public DistributionChannel getDistributionChannel() {
        return distributionChannel;
    }

    @JsonProperty("DistributionChannel")
    public void setDistributionChannel(DistributionChannel distributionChannel) {
        this.distributionChannel = distributionChannel;
    }

    public MaterialSale withDistributionChannel(DistributionChannel distributionChannel) {
        this.distributionChannel = distributionChannel;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialSale withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialIdentifier).append(salesOrganizationCode).append(distributionChannelCode).append(plantCode).append(materialItemCategoryGroupCode).append(materialItemCategoryGroup).append(salesOrganization).append(materialDistributionStatus).append(materialAccountAssignmentGroup).append(materialTaxSalesOrganization).append(materialTaxCondition).append(distributionChannel).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialSale) == false) {
            return false;
        }
        MaterialSale rhs = ((MaterialSale) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialIdentifier, rhs.materialIdentifier).append(salesOrganizationCode, rhs.salesOrganizationCode).append(distributionChannelCode, rhs.distributionChannelCode).append(plantCode, rhs.plantCode).append(materialItemCategoryGroupCode, rhs.materialItemCategoryGroupCode).append(materialItemCategoryGroup, rhs.materialItemCategoryGroup).append(salesOrganization, rhs.salesOrganization).append(materialDistributionStatus, rhs.materialDistributionStatus).append(materialAccountAssignmentGroup, rhs.materialAccountAssignmentGroup).append(materialTaxSalesOrganization, rhs.materialTaxSalesOrganization).append(materialTaxCondition, rhs.materialTaxCondition).append(distributionChannel, rhs.distributionChannel).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
