
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialIdentifier",
    "DestinationCountryCode",
    "MaterialTaxClassification1Code",
    "MaterialTaxPurchasing",
    "MaterialTaxClassification2Code"
})
public class MaterialTax {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("DestinationCountryCode")
    private String destinationCountryCode;
    @JsonProperty("MaterialTaxClassification1Code")
    private String materialTaxClassification1Code;
    @JsonProperty("MaterialTaxPurchasing")
    private MaterialTaxPurchasing materialTaxPurchasing;
    @JsonProperty("MaterialTaxClassification2Code")
    private String materialTaxClassification2Code;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialTax withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public MaterialTax withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("DestinationCountryCode")
    public String getDestinationCountryCode() {
        return destinationCountryCode;
    }

    @JsonProperty("DestinationCountryCode")
    public void setDestinationCountryCode(String destinationCountryCode) {
        this.destinationCountryCode = destinationCountryCode;
    }

    public MaterialTax withDestinationCountryCode(String destinationCountryCode) {
        this.destinationCountryCode = destinationCountryCode;
        return this;
    }

    @JsonProperty("MaterialTaxClassification1Code")
    public String getMaterialTaxClassification1Code() {
        return materialTaxClassification1Code;
    }

    @JsonProperty("MaterialTaxClassification1Code")
    public void setMaterialTaxClassification1Code(String materialTaxClassification1Code) {
        this.materialTaxClassification1Code = materialTaxClassification1Code;
    }

    public MaterialTax withMaterialTaxClassification1Code(String materialTaxClassification1Code) {
        this.materialTaxClassification1Code = materialTaxClassification1Code;
        return this;
    }

    @JsonProperty("MaterialTaxPurchasing")
    public MaterialTaxPurchasing getMaterialTaxPurchasing() {
        return materialTaxPurchasing;
    }

    @JsonProperty("MaterialTaxPurchasing")
    public void setMaterialTaxPurchasing(MaterialTaxPurchasing materialTaxPurchasing) {
        this.materialTaxPurchasing = materialTaxPurchasing;
    }

    public MaterialTax withMaterialTaxPurchasing(MaterialTaxPurchasing materialTaxPurchasing) {
        this.materialTaxPurchasing = materialTaxPurchasing;
        return this;
    }

    @JsonProperty("MaterialTaxClassification2Code")
    public String getMaterialTaxClassification2Code() {
        return materialTaxClassification2Code;
    }

    @JsonProperty("MaterialTaxClassification2Code")
    public void setMaterialTaxClassification2Code(String materialTaxClassification2Code) {
        this.materialTaxClassification2Code = materialTaxClassification2Code;
    }

    public MaterialTax withMaterialTaxClassification2Code(String materialTaxClassification2Code) {
        this.materialTaxClassification2Code = materialTaxClassification2Code;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialTax withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialIdentifier).append(destinationCountryCode).append(materialTaxClassification1Code).append(materialTaxPurchasing).append(materialTaxClassification2Code).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialTax) == false) {
            return false;
        }
        MaterialTax rhs = ((MaterialTax) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialIdentifier, rhs.materialIdentifier).append(destinationCountryCode, rhs.destinationCountryCode).append(materialTaxClassification1Code, rhs.materialTaxClassification1Code).append(materialTaxPurchasing, rhs.materialTaxPurchasing).append(materialTaxClassification2Code, rhs.materialTaxClassification2Code).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
