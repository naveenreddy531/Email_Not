
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialTaxClassificationCode",
    "MaterialTaxCategoryCode",
    "MaterialTaxClassificationDescription"
})
public class MaterialTaxClassification {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialTaxClassificationCode")
    private String materialTaxClassificationCode;
    @JsonProperty("MaterialTaxCategoryCode")
    private String materialTaxCategoryCode;
    @JsonProperty("MaterialTaxClassificationDescription")
    private String materialTaxClassificationDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialTaxClassification withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialTaxClassificationCode")
    public String getMaterialTaxClassificationCode() {
        return materialTaxClassificationCode;
    }

    @JsonProperty("MaterialTaxClassificationCode")
    public void setMaterialTaxClassificationCode(String materialTaxClassificationCode) {
        this.materialTaxClassificationCode = materialTaxClassificationCode;
    }

    public MaterialTaxClassification withMaterialTaxClassificationCode(String materialTaxClassificationCode) {
        this.materialTaxClassificationCode = materialTaxClassificationCode;
        return this;
    }

    @JsonProperty("MaterialTaxCategoryCode")
    public String getMaterialTaxCategoryCode() {
        return materialTaxCategoryCode;
    }

    @JsonProperty("MaterialTaxCategoryCode")
    public void setMaterialTaxCategoryCode(String materialTaxCategoryCode) {
        this.materialTaxCategoryCode = materialTaxCategoryCode;
    }

    public MaterialTaxClassification withMaterialTaxCategoryCode(String materialTaxCategoryCode) {
        this.materialTaxCategoryCode = materialTaxCategoryCode;
        return this;
    }

    @JsonProperty("MaterialTaxClassificationDescription")
    public String getMaterialTaxClassificationDescription() {
        return materialTaxClassificationDescription;
    }

    @JsonProperty("MaterialTaxClassificationDescription")
    public void setMaterialTaxClassificationDescription(String materialTaxClassificationDescription) {
        this.materialTaxClassificationDescription = materialTaxClassificationDescription;
    }

    public MaterialTaxClassification withMaterialTaxClassificationDescription(String materialTaxClassificationDescription) {
        this.materialTaxClassificationDescription = materialTaxClassificationDescription;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialTaxClassification withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialTaxClassificationCode).append(materialTaxCategoryCode).append(materialTaxClassificationDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialTaxClassification) == false) {
            return false;
        }
        MaterialTaxClassification rhs = ((MaterialTaxClassification) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialTaxClassificationCode, rhs.materialTaxClassificationCode).append(materialTaxCategoryCode, rhs.materialTaxCategoryCode).append(materialTaxClassificationDescription, rhs.materialTaxClassificationDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
