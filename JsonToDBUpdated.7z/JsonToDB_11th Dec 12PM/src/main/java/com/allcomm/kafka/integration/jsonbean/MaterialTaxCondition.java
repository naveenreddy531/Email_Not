
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialTaxConditionUsageCode",
    "MaterialTaxConditionApplicationCode",
    "MaterialTaxConditionTypeCode",
    "MaterialTaxConditionName"
})
public class MaterialTaxCondition {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialTaxConditionUsageCode")
    private String materialTaxConditionUsageCode;
    @JsonProperty("MaterialTaxConditionApplicationCode")
    private String materialTaxConditionApplicationCode;
    @JsonProperty("MaterialTaxConditionTypeCode")
    private String materialTaxConditionTypeCode;
    @JsonProperty("MaterialTaxConditionName")
    private String materialTaxConditionName;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialTaxCondition withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialTaxConditionUsageCode")
    public String getMaterialTaxConditionUsageCode() {
        return materialTaxConditionUsageCode;
    }

    @JsonProperty("MaterialTaxConditionUsageCode")
    public void setMaterialTaxConditionUsageCode(String materialTaxConditionUsageCode) {
        this.materialTaxConditionUsageCode = materialTaxConditionUsageCode;
    }

    public MaterialTaxCondition withMaterialTaxConditionUsageCode(String materialTaxConditionUsageCode) {
        this.materialTaxConditionUsageCode = materialTaxConditionUsageCode;
        return this;
    }

    @JsonProperty("MaterialTaxConditionApplicationCode")
    public String getMaterialTaxConditionApplicationCode() {
        return materialTaxConditionApplicationCode;
    }

    @JsonProperty("MaterialTaxConditionApplicationCode")
    public void setMaterialTaxConditionApplicationCode(String materialTaxConditionApplicationCode) {
        this.materialTaxConditionApplicationCode = materialTaxConditionApplicationCode;
    }

    public MaterialTaxCondition withMaterialTaxConditionApplicationCode(String materialTaxConditionApplicationCode) {
        this.materialTaxConditionApplicationCode = materialTaxConditionApplicationCode;
        return this;
    }

    @JsonProperty("MaterialTaxConditionTypeCode")
    public String getMaterialTaxConditionTypeCode() {
        return materialTaxConditionTypeCode;
    }

    @JsonProperty("MaterialTaxConditionTypeCode")
    public void setMaterialTaxConditionTypeCode(String materialTaxConditionTypeCode) {
        this.materialTaxConditionTypeCode = materialTaxConditionTypeCode;
    }

    public MaterialTaxCondition withMaterialTaxConditionTypeCode(String materialTaxConditionTypeCode) {
        this.materialTaxConditionTypeCode = materialTaxConditionTypeCode;
        return this;
    }

    @JsonProperty("MaterialTaxConditionName")
    public String getMaterialTaxConditionName() {
        return materialTaxConditionName;
    }

    @JsonProperty("MaterialTaxConditionName")
    public void setMaterialTaxConditionName(String materialTaxConditionName) {
        this.materialTaxConditionName = materialTaxConditionName;
    }

    public MaterialTaxCondition withMaterialTaxConditionName(String materialTaxConditionName) {
        this.materialTaxConditionName = materialTaxConditionName;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialTaxCondition withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialTaxConditionUsageCode).append(materialTaxConditionApplicationCode).append(materialTaxConditionTypeCode).append(materialTaxConditionName).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialTaxCondition) == false) {
            return false;
        }
        MaterialTaxCondition rhs = ((MaterialTaxCondition) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialTaxConditionUsageCode, rhs.materialTaxConditionUsageCode).append(materialTaxConditionApplicationCode, rhs.materialTaxConditionApplicationCode).append(materialTaxConditionTypeCode, rhs.materialTaxConditionTypeCode).append(materialTaxConditionName, rhs.materialTaxConditionName).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
