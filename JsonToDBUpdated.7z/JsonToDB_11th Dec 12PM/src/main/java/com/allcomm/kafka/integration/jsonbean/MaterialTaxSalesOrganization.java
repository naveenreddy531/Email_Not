
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialIdentifier",
    "DistributionChannelCode",
    "SalesOrganizationCode",
    "DepartureCountryCode",
    "MaterialTaxClassificationCode",
    "MaterialTaxCategoryCode",
    "MaterialTaxClassification"
})
public class MaterialTaxSalesOrganization {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("DistributionChannelCode")
    private String distributionChannelCode;
    @JsonProperty("SalesOrganizationCode")
    private String salesOrganizationCode;
    @JsonProperty("DepartureCountryCode")
    private String departureCountryCode;
    @JsonProperty("MaterialTaxClassificationCode")
    private String materialTaxClassificationCode;
    @JsonProperty("MaterialTaxCategoryCode")
    private String materialTaxCategoryCode;
    @JsonProperty("MaterialTaxClassification")
    private MaterialTaxClassification materialTaxClassification;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialTaxSalesOrganization withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public MaterialTaxSalesOrganization withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("DistributionChannelCode")
    public String getDistributionChannelCode() {
        return distributionChannelCode;
    }

    @JsonProperty("DistributionChannelCode")
    public void setDistributionChannelCode(String distributionChannelCode) {
        this.distributionChannelCode = distributionChannelCode;
    }

    public MaterialTaxSalesOrganization withDistributionChannelCode(String distributionChannelCode) {
        this.distributionChannelCode = distributionChannelCode;
        return this;
    }

    @JsonProperty("SalesOrganizationCode")
    public String getSalesOrganizationCode() {
        return salesOrganizationCode;
    }

    @JsonProperty("SalesOrganizationCode")
    public void setSalesOrganizationCode(String salesOrganizationCode) {
        this.salesOrganizationCode = salesOrganizationCode;
    }

    public MaterialTaxSalesOrganization withSalesOrganizationCode(String salesOrganizationCode) {
        this.salesOrganizationCode = salesOrganizationCode;
        return this;
    }

    @JsonProperty("DepartureCountryCode")
    public String getDepartureCountryCode() {
        return departureCountryCode;
    }

    @JsonProperty("DepartureCountryCode")
    public void setDepartureCountryCode(String departureCountryCode) {
        this.departureCountryCode = departureCountryCode;
    }

    public MaterialTaxSalesOrganization withDepartureCountryCode(String departureCountryCode) {
        this.departureCountryCode = departureCountryCode;
        return this;
    }

    @JsonProperty("MaterialTaxClassificationCode")
    public String getMaterialTaxClassificationCode() {
        return materialTaxClassificationCode;
    }

    @JsonProperty("MaterialTaxClassificationCode")
    public void setMaterialTaxClassificationCode(String materialTaxClassificationCode) {
        this.materialTaxClassificationCode = materialTaxClassificationCode;
    }

    public MaterialTaxSalesOrganization withMaterialTaxClassificationCode(String materialTaxClassificationCode) {
        this.materialTaxClassificationCode = materialTaxClassificationCode;
        return this;
    }

    @JsonProperty("MaterialTaxCategoryCode")
    public String getMaterialTaxCategoryCode() {
        return materialTaxCategoryCode;
    }

    @JsonProperty("MaterialTaxCategoryCode")
    public void setMaterialTaxCategoryCode(String materialTaxCategoryCode) {
        this.materialTaxCategoryCode = materialTaxCategoryCode;
    }

    public MaterialTaxSalesOrganization withMaterialTaxCategoryCode(String materialTaxCategoryCode) {
        this.materialTaxCategoryCode = materialTaxCategoryCode;
        return this;
    }

    @JsonProperty("MaterialTaxClassification")
    public MaterialTaxClassification getMaterialTaxClassification() {
        return materialTaxClassification;
    }

    @JsonProperty("MaterialTaxClassification")
    public void setMaterialTaxClassification(MaterialTaxClassification materialTaxClassification) {
        this.materialTaxClassification = materialTaxClassification;
    }

    public MaterialTaxSalesOrganization withMaterialTaxClassification(MaterialTaxClassification materialTaxClassification) {
        this.materialTaxClassification = materialTaxClassification;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialTaxSalesOrganization withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialIdentifier).append(distributionChannelCode).append(salesOrganizationCode).append(departureCountryCode).append(materialTaxClassificationCode).append(materialTaxCategoryCode).append(materialTaxClassification).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialTaxSalesOrganization) == false) {
            return false;
        }
        MaterialTaxSalesOrganization rhs = ((MaterialTaxSalesOrganization) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialIdentifier, rhs.materialIdentifier).append(distributionChannelCode, rhs.distributionChannelCode).append(salesOrganizationCode, rhs.salesOrganizationCode).append(departureCountryCode, rhs.departureCountryCode).append(materialTaxClassificationCode, rhs.materialTaxClassificationCode).append(materialTaxCategoryCode, rhs.materialTaxCategoryCode).append(materialTaxClassification, rhs.materialTaxClassification).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
