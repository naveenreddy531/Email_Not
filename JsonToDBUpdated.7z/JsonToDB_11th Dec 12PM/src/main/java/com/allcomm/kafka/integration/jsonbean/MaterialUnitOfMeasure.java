
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialIdentifier",
    "UnitOfMeasureCode",
    "NumeratorConversionNumber",
    "DonominatorConversionNumber",
    "WeightUnitofMeasureCode",
    "InternationalArticleCategory",
    "UnitOfMeasure"
})
public class MaterialUnitOfMeasure {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("UnitOfMeasureCode")
    private String unitOfMeasureCode;
    @JsonProperty("NumeratorConversionNumber")
    private Integer numeratorConversionNumber;
    @JsonProperty("DonominatorConversionNumber")
    private Integer donominatorConversionNumber;
    @JsonProperty("WeightUnitofMeasureCode")
    private String weightUnitofMeasureCode;
    @JsonProperty("InternationalArticleCategory")
    private InternationalArticleCategory internationalArticleCategory;
    @JsonProperty("UnitOfMeasure")
    private List<UnitOfMeasure> unitOfMeasure = new ArrayList<UnitOfMeasure>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public MaterialUnitOfMeasure withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public MaterialUnitOfMeasure withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("UnitOfMeasureCode")
    public String getUnitOfMeasureCode() {
        return unitOfMeasureCode;
    }

    @JsonProperty("UnitOfMeasureCode")
    public void setUnitOfMeasureCode(String unitOfMeasureCode) {
        this.unitOfMeasureCode = unitOfMeasureCode;
    }

    public MaterialUnitOfMeasure withUnitOfMeasureCode(String unitOfMeasureCode) {
        this.unitOfMeasureCode = unitOfMeasureCode;
        return this;
    }

    @JsonProperty("NumeratorConversionNumber")
    public Integer getNumeratorConversionNumber() {
        return numeratorConversionNumber;
    }

    @JsonProperty("NumeratorConversionNumber")
    public void setNumeratorConversionNumber(Integer numeratorConversionNumber) {
        this.numeratorConversionNumber = numeratorConversionNumber;
    }

    public MaterialUnitOfMeasure withNumeratorConversionNumber(Integer numeratorConversionNumber) {
        this.numeratorConversionNumber = numeratorConversionNumber;
        return this;
    }

    @JsonProperty("DonominatorConversionNumber")
    public Integer getDonominatorConversionNumber() {
        return donominatorConversionNumber;
    }

    @JsonProperty("DonominatorConversionNumber")
    public void setDonominatorConversionNumber(Integer donominatorConversionNumber) {
        this.donominatorConversionNumber = donominatorConversionNumber;
    }

    public MaterialUnitOfMeasure withDonominatorConversionNumber(Integer donominatorConversionNumber) {
        this.donominatorConversionNumber = donominatorConversionNumber;
        return this;
    }

    @JsonProperty("WeightUnitofMeasureCode")
    public String getWeightUnitofMeasureCode() {
        return weightUnitofMeasureCode;
    }

    @JsonProperty("WeightUnitofMeasureCode")
    public void setWeightUnitofMeasureCode(String weightUnitofMeasureCode) {
        this.weightUnitofMeasureCode = weightUnitofMeasureCode;
    }

    public MaterialUnitOfMeasure withWeightUnitofMeasureCode(String weightUnitofMeasureCode) {
        this.weightUnitofMeasureCode = weightUnitofMeasureCode;
        return this;
    }

    @JsonProperty("InternationalArticleCategory")
    public InternationalArticleCategory getInternationalArticleCategory() {
        return internationalArticleCategory;
    }

    @JsonProperty("InternationalArticleCategory")
    public void setInternationalArticleCategory(InternationalArticleCategory internationalArticleCategory) {
        this.internationalArticleCategory = internationalArticleCategory;
    }

    public MaterialUnitOfMeasure withInternationalArticleCategory(InternationalArticleCategory internationalArticleCategory) {
        this.internationalArticleCategory = internationalArticleCategory;
        return this;
    }

    @JsonProperty("UnitOfMeasure")
    public List<UnitOfMeasure> getUnitOfMeasure() {
        return unitOfMeasure;
    }

    @JsonProperty("UnitOfMeasure")
    public void setUnitOfMeasure(List<UnitOfMeasure> unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public MaterialUnitOfMeasure withUnitOfMeasure(List<UnitOfMeasure> unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MaterialUnitOfMeasure withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialIdentifier).append(unitOfMeasureCode).append(numeratorConversionNumber).append(donominatorConversionNumber).append(weightUnitofMeasureCode).append(internationalArticleCategory).append(unitOfMeasure).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MaterialUnitOfMeasure) == false) {
            return false;
        }
        MaterialUnitOfMeasure rhs = ((MaterialUnitOfMeasure) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialIdentifier, rhs.materialIdentifier).append(unitOfMeasureCode, rhs.unitOfMeasureCode).append(numeratorConversionNumber, rhs.numeratorConversionNumber).append(donominatorConversionNumber, rhs.donominatorConversionNumber).append(weightUnitofMeasureCode, rhs.weightUnitofMeasureCode).append(internationalArticleCategory, rhs.internationalArticleCategory).append(unitOfMeasure, rhs.unitOfMeasure).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
