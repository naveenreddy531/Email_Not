
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "MaterialIdentifier",
    "MaterialGroupCode",
    "BaseUnitofMeasureCode",
    "ExternalMaterialGroupCode",
    "SalesDivisionCode",
    "LaboratoryDesignCode",
    "MaterialTypeCode",
    "IndustrySectorCode",
    "WeightUnitofMeasureCode",
    "CrossPlantMaterialStatusCode",
    "CrossPlantMaterialStatusEffectiveDate",
    "GeneralMaterialItemCategoryGroupCode",
    "UpdatedByUserID",
    "CreatedByUserID",
    "SourceSystemCreateTimestamp",
    "SourceSystemUpdateTimestamp",
    "MaterialLanguage",
    "MaterialUnitOfMeasure",
    "MaterialType",
    "MaterialGroup",
    "CrossPlantMaterialStatus",
    "CrossSalesMaterialStatus",
    "DangerousGoods",
    "ExternalMaterialGroup",
    "IndustrySector",
    "LaboratoryDesign",
    "PackagingMaterialGroup",
    "SalesDivision",
    "ProductLifeCycle",
    "UnitOfMeasure",
    "MaterialPlant",
    "MaterialSales",
    "MaterialTax",
    "MaterialClassAllocation"
})
public class Pmdm {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("MaterialGroupCode")
    private String materialGroupCode;
    @JsonProperty("BaseUnitofMeasureCode")
    private String baseUnitofMeasureCode;
    @JsonProperty("ExternalMaterialGroupCode")
    private String externalMaterialGroupCode;
    @JsonProperty("SalesDivisionCode")
    private String salesDivisionCode;
    @JsonProperty("LaboratoryDesignCode")
    private String laboratoryDesignCode;
    @JsonProperty("MaterialTypeCode")
    private String materialTypeCode;
    @JsonProperty("IndustrySectorCode")
    private String industrySectorCode;
    @JsonProperty("WeightUnitofMeasureCode")
    private String weightUnitofMeasureCode;
    @JsonProperty("CrossPlantMaterialStatusCode")
    private String crossPlantMaterialStatusCode;
    @JsonProperty("CrossPlantMaterialStatusEffectiveDate")
    private String crossPlantMaterialStatusEffectiveDate;
    @JsonProperty("GeneralMaterialItemCategoryGroupCode")
    private String generalMaterialItemCategoryGroupCode;
    @JsonProperty("UpdatedByUserID")
    private String updatedByUserID;
    @JsonProperty("CreatedByUserID")
    private String createdByUserID;
    @JsonProperty("SourceSystemCreateTimestamp")
    private String sourceSystemCreateTimestamp;
    @JsonProperty("SourceSystemUpdateTimestamp")
    private String sourceSystemUpdateTimestamp;
    @JsonProperty("MaterialLanguage")
    private List<MaterialLanguage> materialLanguage = new ArrayList<MaterialLanguage>();
    @JsonProperty("MaterialUnitOfMeasure")
    private List<MaterialUnitOfMeasure> materialUnitOfMeasure = new ArrayList<MaterialUnitOfMeasure>();
    @JsonProperty("MaterialType")
    private MaterialType materialType;
    @JsonProperty("MaterialGroup")
    private MaterialGroup materialGroup;
    @JsonProperty("CrossPlantMaterialStatus")
    private CrossPlantMaterialStatus crossPlantMaterialStatus;
    @JsonProperty("CrossSalesMaterialStatus")
    private CrossSalesMaterialStatus crossSalesMaterialStatus;
    @JsonProperty("DangerousGoods")
    private DangerousGoods dangerousGoods;
    @JsonProperty("ExternalMaterialGroup")
    private ExternalMaterialGroup externalMaterialGroup;
    @JsonProperty("IndustrySector")
    private IndustrySector industrySector;
    @JsonProperty("LaboratoryDesign")
    private LaboratoryDesign laboratoryDesign;
    @JsonProperty("PackagingMaterialGroup")
    private PackagingMaterialGroup packagingMaterialGroup;
    @JsonProperty("SalesDivision")
    private SalesDivision salesDivision;
    @JsonProperty("ProductLifeCycle")
    private List<ProductLifeCycle> productLifeCycle = new ArrayList<ProductLifeCycle>();
    @JsonProperty("UnitOfMeasure")
    private List<UnitOfMeasure_> unitOfMeasure = new ArrayList<UnitOfMeasure_>();
    @JsonProperty("MaterialPlant")
    private List<MaterialPlant> materialPlant = new ArrayList<MaterialPlant>();
    @JsonProperty("MaterialSales")
    private List<MaterialSale> materialSales = new ArrayList<MaterialSale>();
    @JsonProperty("MaterialTax")
    private List<MaterialTax> materialTax = new ArrayList<MaterialTax>();
    @JsonProperty("MaterialClassAllocation")
    private List<MaterialClassAllocation> materialClassAllocation = new ArrayList<MaterialClassAllocation>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public Pmdm withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public Pmdm withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("MaterialGroupCode")
    public String getMaterialGroupCode() {
        return materialGroupCode;
    }

    @JsonProperty("MaterialGroupCode")
    public void setMaterialGroupCode(String materialGroupCode) {
        this.materialGroupCode = materialGroupCode;
    }

    public Pmdm withMaterialGroupCode(String materialGroupCode) {
        this.materialGroupCode = materialGroupCode;
        return this;
    }

    @JsonProperty("BaseUnitofMeasureCode")
    public String getBaseUnitofMeasureCode() {
        return baseUnitofMeasureCode;
    }

    @JsonProperty("BaseUnitofMeasureCode")
    public void setBaseUnitofMeasureCode(String baseUnitofMeasureCode) {
        this.baseUnitofMeasureCode = baseUnitofMeasureCode;
    }

    public Pmdm withBaseUnitofMeasureCode(String baseUnitofMeasureCode) {
        this.baseUnitofMeasureCode = baseUnitofMeasureCode;
        return this;
    }

    @JsonProperty("ExternalMaterialGroupCode")
    public String getExternalMaterialGroupCode() {
        return externalMaterialGroupCode;
    }

    @JsonProperty("ExternalMaterialGroupCode")
    public void setExternalMaterialGroupCode(String externalMaterialGroupCode) {
        this.externalMaterialGroupCode = externalMaterialGroupCode;
    }

    public Pmdm withExternalMaterialGroupCode(String externalMaterialGroupCode) {
        this.externalMaterialGroupCode = externalMaterialGroupCode;
        return this;
    }

    @JsonProperty("SalesDivisionCode")
    public String getSalesDivisionCode() {
        return salesDivisionCode;
    }

    @JsonProperty("SalesDivisionCode")
    public void setSalesDivisionCode(String salesDivisionCode) {
        this.salesDivisionCode = salesDivisionCode;
    }

    public Pmdm withSalesDivisionCode(String salesDivisionCode) {
        this.salesDivisionCode = salesDivisionCode;
        return this;
    }

    @JsonProperty("LaboratoryDesignCode")
    public String getLaboratoryDesignCode() {
        return laboratoryDesignCode;
    }

    @JsonProperty("LaboratoryDesignCode")
    public void setLaboratoryDesignCode(String laboratoryDesignCode) {
        this.laboratoryDesignCode = laboratoryDesignCode;
    }

    public Pmdm withLaboratoryDesignCode(String laboratoryDesignCode) {
        this.laboratoryDesignCode = laboratoryDesignCode;
        return this;
    }

    @JsonProperty("MaterialTypeCode")
    public String getMaterialTypeCode() {
        return materialTypeCode;
    }

    @JsonProperty("MaterialTypeCode")
    public void setMaterialTypeCode(String materialTypeCode) {
        this.materialTypeCode = materialTypeCode;
    }

    public Pmdm withMaterialTypeCode(String materialTypeCode) {
        this.materialTypeCode = materialTypeCode;
        return this;
    }

    @JsonProperty("IndustrySectorCode")
    public String getIndustrySectorCode() {
        return industrySectorCode;
    }

    @JsonProperty("IndustrySectorCode")
    public void setIndustrySectorCode(String industrySectorCode) {
        this.industrySectorCode = industrySectorCode;
    }

    public Pmdm withIndustrySectorCode(String industrySectorCode) {
        this.industrySectorCode = industrySectorCode;
        return this;
    }

    @JsonProperty("WeightUnitofMeasureCode")
    public String getWeightUnitofMeasureCode() {
        return weightUnitofMeasureCode;
    }

    @JsonProperty("WeightUnitofMeasureCode")
    public void setWeightUnitofMeasureCode(String weightUnitofMeasureCode) {
        this.weightUnitofMeasureCode = weightUnitofMeasureCode;
    }

    public Pmdm withWeightUnitofMeasureCode(String weightUnitofMeasureCode) {
        this.weightUnitofMeasureCode = weightUnitofMeasureCode;
        return this;
    }

    @JsonProperty("CrossPlantMaterialStatusCode")
    public String getCrossPlantMaterialStatusCode() {
        return crossPlantMaterialStatusCode;
    }

    @JsonProperty("CrossPlantMaterialStatusCode")
    public void setCrossPlantMaterialStatusCode(String crossPlantMaterialStatusCode) {
        this.crossPlantMaterialStatusCode = crossPlantMaterialStatusCode;
    }

    public Pmdm withCrossPlantMaterialStatusCode(String crossPlantMaterialStatusCode) {
        this.crossPlantMaterialStatusCode = crossPlantMaterialStatusCode;
        return this;
    }

    @JsonProperty("CrossPlantMaterialStatusEffectiveDate")
    public String getCrossPlantMaterialStatusEffectiveDate() {
        return crossPlantMaterialStatusEffectiveDate;
    }

    @JsonProperty("CrossPlantMaterialStatusEffectiveDate")
    public void setCrossPlantMaterialStatusEffectiveDate(String crossPlantMaterialStatusEffectiveDate) {
        this.crossPlantMaterialStatusEffectiveDate = crossPlantMaterialStatusEffectiveDate;
    }

    public Pmdm withCrossPlantMaterialStatusEffectiveDate(String crossPlantMaterialStatusEffectiveDate) {
        this.crossPlantMaterialStatusEffectiveDate = crossPlantMaterialStatusEffectiveDate;
        return this;
    }

    @JsonProperty("GeneralMaterialItemCategoryGroupCode")
    public String getGeneralMaterialItemCategoryGroupCode() {
        return generalMaterialItemCategoryGroupCode;
    }

    @JsonProperty("GeneralMaterialItemCategoryGroupCode")
    public void setGeneralMaterialItemCategoryGroupCode(String generalMaterialItemCategoryGroupCode) {
        this.generalMaterialItemCategoryGroupCode = generalMaterialItemCategoryGroupCode;
    }

    public Pmdm withGeneralMaterialItemCategoryGroupCode(String generalMaterialItemCategoryGroupCode) {
        this.generalMaterialItemCategoryGroupCode = generalMaterialItemCategoryGroupCode;
        return this;
    }

    @JsonProperty("UpdatedByUserID")
    public String getUpdatedByUserID() {
        return updatedByUserID;
    }

    @JsonProperty("UpdatedByUserID")
    public void setUpdatedByUserID(String updatedByUserID) {
        this.updatedByUserID = updatedByUserID;
    }

    public Pmdm withUpdatedByUserID(String updatedByUserID) {
        this.updatedByUserID = updatedByUserID;
        return this;
    }

    @JsonProperty("CreatedByUserID")
    public String getCreatedByUserID() {
        return createdByUserID;
    }

    @JsonProperty("CreatedByUserID")
    public void setCreatedByUserID(String createdByUserID) {
        this.createdByUserID = createdByUserID;
    }

    public Pmdm withCreatedByUserID(String createdByUserID) {
        this.createdByUserID = createdByUserID;
        return this;
    }

    @JsonProperty("SourceSystemCreateTimestamp")
    public String getSourceSystemCreateTimestamp() {
        return sourceSystemCreateTimestamp;
    }

    @JsonProperty("SourceSystemCreateTimestamp")
    public void setSourceSystemCreateTimestamp(String sourceSystemCreateTimestamp) {
        this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
    }

    public Pmdm withSourceSystemCreateTimestamp(String sourceSystemCreateTimestamp) {
        this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
        return this;
    }

    @JsonProperty("SourceSystemUpdateTimestamp")
    public String getSourceSystemUpdateTimestamp() {
        return sourceSystemUpdateTimestamp;
    }

    @JsonProperty("SourceSystemUpdateTimestamp")
    public void setSourceSystemUpdateTimestamp(String sourceSystemUpdateTimestamp) {
        this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
    }

    public Pmdm withSourceSystemUpdateTimestamp(String sourceSystemUpdateTimestamp) {
        this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
        return this;
    }

    @JsonProperty("MaterialLanguage")
    public List<MaterialLanguage> getMaterialLanguage() {
        return materialLanguage;
    }

    @JsonProperty("MaterialLanguage")
    public void setMaterialLanguage(List<MaterialLanguage> materialLanguage) {
        this.materialLanguage = materialLanguage;
    }

    public Pmdm withMaterialLanguage(List<MaterialLanguage> materialLanguage) {
        this.materialLanguage = materialLanguage;
        return this;
    }

    @JsonProperty("MaterialUnitOfMeasure")
    public List<MaterialUnitOfMeasure> getMaterialUnitOfMeasure() {
        return materialUnitOfMeasure;
    }

    @JsonProperty("MaterialUnitOfMeasure")
    public void setMaterialUnitOfMeasure(List<MaterialUnitOfMeasure> materialUnitOfMeasure) {
        this.materialUnitOfMeasure = materialUnitOfMeasure;
    }

    public Pmdm withMaterialUnitOfMeasure(List<MaterialUnitOfMeasure> materialUnitOfMeasure) {
        this.materialUnitOfMeasure = materialUnitOfMeasure;
        return this;
    }

    @JsonProperty("MaterialType")
    public MaterialType getMaterialType() {
        return materialType;
    }

    @JsonProperty("MaterialType")
    public void setMaterialType(MaterialType materialType) {
        this.materialType = materialType;
    }

    public Pmdm withMaterialType(MaterialType materialType) {
        this.materialType = materialType;
        return this;
    }

    @JsonProperty("MaterialGroup")
    public MaterialGroup getMaterialGroup() {
        return materialGroup;
    }

    @JsonProperty("MaterialGroup")
    public void setMaterialGroup(MaterialGroup materialGroup) {
        this.materialGroup = materialGroup;
    }

    public Pmdm withMaterialGroup(MaterialGroup materialGroup) {
        this.materialGroup = materialGroup;
        return this;
    }

    @JsonProperty("CrossPlantMaterialStatus")
    public CrossPlantMaterialStatus getCrossPlantMaterialStatus() {
        return crossPlantMaterialStatus;
    }

    @JsonProperty("CrossPlantMaterialStatus")
    public void setCrossPlantMaterialStatus(CrossPlantMaterialStatus crossPlantMaterialStatus) {
        this.crossPlantMaterialStatus = crossPlantMaterialStatus;
    }

    public Pmdm withCrossPlantMaterialStatus(CrossPlantMaterialStatus crossPlantMaterialStatus) {
        this.crossPlantMaterialStatus = crossPlantMaterialStatus;
        return this;
    }

    @JsonProperty("CrossSalesMaterialStatus")
    public CrossSalesMaterialStatus getCrossSalesMaterialStatus() {
        return crossSalesMaterialStatus;
    }

    @JsonProperty("CrossSalesMaterialStatus")
    public void setCrossSalesMaterialStatus(CrossSalesMaterialStatus crossSalesMaterialStatus) {
        this.crossSalesMaterialStatus = crossSalesMaterialStatus;
    }

    public Pmdm withCrossSalesMaterialStatus(CrossSalesMaterialStatus crossSalesMaterialStatus) {
        this.crossSalesMaterialStatus = crossSalesMaterialStatus;
        return this;
    }

    @JsonProperty("DangerousGoods")
    public DangerousGoods getDangerousGoods() {
        return dangerousGoods;
    }

    @JsonProperty("DangerousGoods")
    public void setDangerousGoods(DangerousGoods dangerousGoods) {
        this.dangerousGoods = dangerousGoods;
    }

    public Pmdm withDangerousGoods(DangerousGoods dangerousGoods) {
        this.dangerousGoods = dangerousGoods;
        return this;
    }

    @JsonProperty("ExternalMaterialGroup")
    public ExternalMaterialGroup getExternalMaterialGroup() {
        return externalMaterialGroup;
    }

    @JsonProperty("ExternalMaterialGroup")
    public void setExternalMaterialGroup(ExternalMaterialGroup externalMaterialGroup) {
        this.externalMaterialGroup = externalMaterialGroup;
    }

    public Pmdm withExternalMaterialGroup(ExternalMaterialGroup externalMaterialGroup) {
        this.externalMaterialGroup = externalMaterialGroup;
        return this;
    }

    @JsonProperty("IndustrySector")
    public IndustrySector getIndustrySector() {
        return industrySector;
    }

    @JsonProperty("IndustrySector")
    public void setIndustrySector(IndustrySector industrySector) {
        this.industrySector = industrySector;
    }

    public Pmdm withIndustrySector(IndustrySector industrySector) {
        this.industrySector = industrySector;
        return this;
    }

    @JsonProperty("LaboratoryDesign")
    public LaboratoryDesign getLaboratoryDesign() {
        return laboratoryDesign;
    }

    @JsonProperty("LaboratoryDesign")
    public void setLaboratoryDesign(LaboratoryDesign laboratoryDesign) {
        this.laboratoryDesign = laboratoryDesign;
    }

    public Pmdm withLaboratoryDesign(LaboratoryDesign laboratoryDesign) {
        this.laboratoryDesign = laboratoryDesign;
        return this;
    }

    @JsonProperty("PackagingMaterialGroup")
    public PackagingMaterialGroup getPackagingMaterialGroup() {
        return packagingMaterialGroup;
    }

    @JsonProperty("PackagingMaterialGroup")
    public void setPackagingMaterialGroup(PackagingMaterialGroup packagingMaterialGroup) {
        this.packagingMaterialGroup = packagingMaterialGroup;
    }

    public Pmdm withPackagingMaterialGroup(PackagingMaterialGroup packagingMaterialGroup) {
        this.packagingMaterialGroup = packagingMaterialGroup;
        return this;
    }

    @JsonProperty("SalesDivision")
    public SalesDivision getSalesDivision() {
        return salesDivision;
    }

    @JsonProperty("SalesDivision")
    public void setSalesDivision(SalesDivision salesDivision) {
        this.salesDivision = salesDivision;
    }

    public Pmdm withSalesDivision(SalesDivision salesDivision) {
        this.salesDivision = salesDivision;
        return this;
    }

    @JsonProperty("ProductLifeCycle")
    public List<ProductLifeCycle> getProductLifeCycle() {
        return productLifeCycle;
    }

    @JsonProperty("ProductLifeCycle")
    public void setProductLifeCycle(List<ProductLifeCycle> productLifeCycle) {
        this.productLifeCycle = productLifeCycle;
    }

    public Pmdm withProductLifeCycle(List<ProductLifeCycle> productLifeCycle) {
        this.productLifeCycle = productLifeCycle;
        return this;
    }

    @JsonProperty("UnitOfMeasure")
    public List<UnitOfMeasure_> getUnitOfMeasure() {
        return unitOfMeasure;
    }

    @JsonProperty("UnitOfMeasure")
    public void setUnitOfMeasure(List<UnitOfMeasure_> unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public Pmdm withUnitOfMeasure(List<UnitOfMeasure_> unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
        return this;
    }

    @JsonProperty("MaterialPlant")
    public List<MaterialPlant> getMaterialPlant() {
        return materialPlant;
    }

    @JsonProperty("MaterialPlant")
    public void setMaterialPlant(List<MaterialPlant> materialPlant) {
        this.materialPlant = materialPlant;
    }

    public Pmdm withMaterialPlant(List<MaterialPlant> materialPlant) {
        this.materialPlant = materialPlant;
        return this;
    }

    @JsonProperty("MaterialSales")
    public List<MaterialSale> getMaterialSales() {
        return materialSales;
    }

    @JsonProperty("MaterialSales")
    public void setMaterialSales(List<MaterialSale> materialSales) {
        this.materialSales = materialSales;
    }

    public Pmdm withMaterialSales(List<MaterialSale> materialSales) {
        this.materialSales = materialSales;
        return this;
    }

    @JsonProperty("MaterialTax")
    public List<MaterialTax> getMaterialTax() {
        return materialTax;
    }

    @JsonProperty("MaterialTax")
    public void setMaterialTax(List<MaterialTax> materialTax) {
        this.materialTax = materialTax;
    }

    public Pmdm withMaterialTax(List<MaterialTax> materialTax) {
        this.materialTax = materialTax;
        return this;
    }

    @JsonProperty("MaterialClassAllocation")
    public List<MaterialClassAllocation> getMaterialClassAllocation() {
        return materialClassAllocation;
    }

    @JsonProperty("MaterialClassAllocation")
    public void setMaterialClassAllocation(List<MaterialClassAllocation> materialClassAllocation) {
        this.materialClassAllocation = materialClassAllocation;
    }

    public Pmdm withMaterialClassAllocation(List<MaterialClassAllocation> materialClassAllocation) {
        this.materialClassAllocation = materialClassAllocation;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Pmdm withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(materialIdentifier).append(materialGroupCode).append(baseUnitofMeasureCode).append(externalMaterialGroupCode).append(salesDivisionCode).append(laboratoryDesignCode).append(materialTypeCode).append(industrySectorCode).append(weightUnitofMeasureCode).append(crossPlantMaterialStatusCode).append(crossPlantMaterialStatusEffectiveDate).append(generalMaterialItemCategoryGroupCode).append(updatedByUserID).append(createdByUserID).append(sourceSystemCreateTimestamp).append(sourceSystemUpdateTimestamp).append(materialLanguage).append(materialUnitOfMeasure).append(materialType).append(materialGroup).append(crossPlantMaterialStatus).append(crossSalesMaterialStatus).append(dangerousGoods).append(externalMaterialGroup).append(industrySector).append(laboratoryDesign).append(packagingMaterialGroup).append(salesDivision).append(productLifeCycle).append(unitOfMeasure).append(materialPlant).append(materialSales).append(materialTax).append(materialClassAllocation).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Pmdm) == false) {
            return false;
        }
        Pmdm rhs = ((Pmdm) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(materialIdentifier, rhs.materialIdentifier).append(materialGroupCode, rhs.materialGroupCode).append(baseUnitofMeasureCode, rhs.baseUnitofMeasureCode).append(externalMaterialGroupCode, rhs.externalMaterialGroupCode).append(salesDivisionCode, rhs.salesDivisionCode).append(laboratoryDesignCode, rhs.laboratoryDesignCode).append(materialTypeCode, rhs.materialTypeCode).append(industrySectorCode, rhs.industrySectorCode).append(weightUnitofMeasureCode, rhs.weightUnitofMeasureCode).append(crossPlantMaterialStatusCode, rhs.crossPlantMaterialStatusCode).append(crossPlantMaterialStatusEffectiveDate, rhs.crossPlantMaterialStatusEffectiveDate).append(generalMaterialItemCategoryGroupCode, rhs.generalMaterialItemCategoryGroupCode).append(updatedByUserID, rhs.updatedByUserID).append(createdByUserID, rhs.createdByUserID).append(sourceSystemCreateTimestamp, rhs.sourceSystemCreateTimestamp).append(sourceSystemUpdateTimestamp, rhs.sourceSystemUpdateTimestamp).append(materialLanguage, rhs.materialLanguage).append(materialUnitOfMeasure, rhs.materialUnitOfMeasure).append(materialType, rhs.materialType).append(materialGroup, rhs.materialGroup).append(crossPlantMaterialStatus, rhs.crossPlantMaterialStatus).append(crossSalesMaterialStatus, rhs.crossSalesMaterialStatus).append(dangerousGoods, rhs.dangerousGoods).append(externalMaterialGroup, rhs.externalMaterialGroup).append(industrySector, rhs.industrySector).append(laboratoryDesign, rhs.laboratoryDesign).append(packagingMaterialGroup, rhs.packagingMaterialGroup).append(salesDivision, rhs.salesDivision).append(productLifeCycle, rhs.productLifeCycle).append(unitOfMeasure, rhs.unitOfMeasure).append(materialPlant, rhs.materialPlant).append(materialSales, rhs.materialSales).append(materialTax, rhs.materialTax).append(materialClassAllocation, rhs.materialClassAllocation).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
