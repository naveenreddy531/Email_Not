
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "PricingConditionIdentifier",
    "PricingConditionItemNumber",
    "ConditionTypeCode",
    "ScaleTypeCode",
    "CalculationTypeCode",
    "UnitListPriceAmount",
    "CurrencyCode",
    "PricingConditionItemQuantity",
    "ConditionUnitQuantity",
    "ConditionItemIndexNumber",
    "PricingConditionDimensionDepend",
    "PricingConditionType",
    "ScaleBasisCode",
    "ScaleUnitofMeasureCode",
    "ConditionQuantityScale"
})
public class PricingConditionItem {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("PricingConditionIdentifier")
    private String pricingConditionIdentifier;
    @JsonProperty("PricingConditionItemNumber")
    private Integer pricingConditionItemNumber;
    @JsonProperty("ConditionTypeCode")
    private String conditionTypeCode;
    @JsonProperty("ScaleTypeCode")
    private String scaleTypeCode;
    @JsonProperty("CalculationTypeCode")
    private String calculationTypeCode;
    @JsonProperty("UnitListPriceAmount")
    private Integer unitListPriceAmount;
    @JsonProperty("CurrencyCode")
    private String currencyCode;
    @JsonProperty("PricingConditionItemQuantity")
    private Integer pricingConditionItemQuantity;
    @JsonProperty("ConditionUnitQuantity")
    private String conditionUnitQuantity;
    @JsonProperty("ConditionItemIndexNumber")
    private Integer conditionItemIndexNumber;
    @JsonProperty("PricingConditionDimensionDepend")
    private List<PricingConditionDimensionDepend> pricingConditionDimensionDepend = new ArrayList<PricingConditionDimensionDepend>();
    @JsonProperty("PricingConditionType")
    private PricingConditionType pricingConditionType;
    @JsonProperty("ScaleBasisCode")
    private String scaleBasisCode;
    @JsonProperty("ScaleUnitofMeasureCode")
    private String scaleUnitofMeasureCode;
    @JsonProperty("ConditionQuantityScale")
    private List<ConditionQuantityScale> conditionQuantityScale = new ArrayList<ConditionQuantityScale>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public PricingConditionItem withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("PricingConditionIdentifier")
    public String getPricingConditionIdentifier() {
        return pricingConditionIdentifier;
    }

    @JsonProperty("PricingConditionIdentifier")
    public void setPricingConditionIdentifier(String pricingConditionIdentifier) {
        this.pricingConditionIdentifier = pricingConditionIdentifier;
    }

    public PricingConditionItem withPricingConditionIdentifier(String pricingConditionIdentifier) {
        this.pricingConditionIdentifier = pricingConditionIdentifier;
        return this;
    }

    @JsonProperty("PricingConditionItemNumber")
    public Integer getPricingConditionItemNumber() {
        return pricingConditionItemNumber;
    }

    @JsonProperty("PricingConditionItemNumber")
    public void setPricingConditionItemNumber(Integer pricingConditionItemNumber) {
        this.pricingConditionItemNumber = pricingConditionItemNumber;
    }

    public PricingConditionItem withPricingConditionItemNumber(Integer pricingConditionItemNumber) {
        this.pricingConditionItemNumber = pricingConditionItemNumber;
        return this;
    }

    @JsonProperty("ConditionTypeCode")
    public String getConditionTypeCode() {
        return conditionTypeCode;
    }

    @JsonProperty("ConditionTypeCode")
    public void setConditionTypeCode(String conditionTypeCode) {
        this.conditionTypeCode = conditionTypeCode;
    }

    public PricingConditionItem withConditionTypeCode(String conditionTypeCode) {
        this.conditionTypeCode = conditionTypeCode;
        return this;
    }

    @JsonProperty("ScaleTypeCode")
    public String getScaleTypeCode() {
        return scaleTypeCode;
    }

    @JsonProperty("ScaleTypeCode")
    public void setScaleTypeCode(String scaleTypeCode) {
        this.scaleTypeCode = scaleTypeCode;
    }

    public PricingConditionItem withScaleTypeCode(String scaleTypeCode) {
        this.scaleTypeCode = scaleTypeCode;
        return this;
    }

    @JsonProperty("CalculationTypeCode")
    public String getCalculationTypeCode() {
        return calculationTypeCode;
    }

    @JsonProperty("CalculationTypeCode")
    public void setCalculationTypeCode(String calculationTypeCode) {
        this.calculationTypeCode = calculationTypeCode;
    }

    public PricingConditionItem withCalculationTypeCode(String calculationTypeCode) {
        this.calculationTypeCode = calculationTypeCode;
        return this;
    }

    @JsonProperty("UnitListPriceAmount")
    public Integer getUnitListPriceAmount() {
        return unitListPriceAmount;
    }

    @JsonProperty("UnitListPriceAmount")
    public void setUnitListPriceAmount(Integer unitListPriceAmount) {
        this.unitListPriceAmount = unitListPriceAmount;
    }

    public PricingConditionItem withUnitListPriceAmount(Integer unitListPriceAmount) {
        this.unitListPriceAmount = unitListPriceAmount;
        return this;
    }

    @JsonProperty("CurrencyCode")
    public String getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("CurrencyCode")
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public PricingConditionItem withCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
        return this;
    }

    @JsonProperty("PricingConditionItemQuantity")
    public Integer getPricingConditionItemQuantity() {
        return pricingConditionItemQuantity;
    }

    @JsonProperty("PricingConditionItemQuantity")
    public void setPricingConditionItemQuantity(Integer pricingConditionItemQuantity) {
        this.pricingConditionItemQuantity = pricingConditionItemQuantity;
    }

    public PricingConditionItem withPricingConditionItemQuantity(Integer pricingConditionItemQuantity) {
        this.pricingConditionItemQuantity = pricingConditionItemQuantity;
        return this;
    }

    @JsonProperty("ConditionUnitQuantity")
    public String getConditionUnitQuantity() {
        return conditionUnitQuantity;
    }

    @JsonProperty("ConditionUnitQuantity")
    public void setConditionUnitQuantity(String conditionUnitQuantity) {
        this.conditionUnitQuantity = conditionUnitQuantity;
    }

    public PricingConditionItem withConditionUnitQuantity(String conditionUnitQuantity) {
        this.conditionUnitQuantity = conditionUnitQuantity;
        return this;
    }

    @JsonProperty("ConditionItemIndexNumber")
    public Integer getConditionItemIndexNumber() {
        return conditionItemIndexNumber;
    }

    @JsonProperty("ConditionItemIndexNumber")
    public void setConditionItemIndexNumber(Integer conditionItemIndexNumber) {
        this.conditionItemIndexNumber = conditionItemIndexNumber;
    }

    public PricingConditionItem withConditionItemIndexNumber(Integer conditionItemIndexNumber) {
        this.conditionItemIndexNumber = conditionItemIndexNumber;
        return this;
    }

    @JsonProperty("PricingConditionDimensionDepend")
    public List<PricingConditionDimensionDepend> getPricingConditionDimensionDepend() {
        return pricingConditionDimensionDepend;
    }

    @JsonProperty("PricingConditionDimensionDepend")
    public void setPricingConditionDimensionDepend(List<PricingConditionDimensionDepend> pricingConditionDimensionDepend) {
        this.pricingConditionDimensionDepend = pricingConditionDimensionDepend;
    }

    public PricingConditionItem withPricingConditionDimensionDepend(List<PricingConditionDimensionDepend> pricingConditionDimensionDepend) {
        this.pricingConditionDimensionDepend = pricingConditionDimensionDepend;
        return this;
    }

    @JsonProperty("PricingConditionType")
    public PricingConditionType getPricingConditionType() {
        return pricingConditionType;
    }

    @JsonProperty("PricingConditionType")
    public void setPricingConditionType(PricingConditionType pricingConditionType) {
        this.pricingConditionType = pricingConditionType;
    }

    public PricingConditionItem withPricingConditionType(PricingConditionType pricingConditionType) {
        this.pricingConditionType = pricingConditionType;
        return this;
    }

    @JsonProperty("ScaleBasisCode")
    public String getScaleBasisCode() {
        return scaleBasisCode;
    }

    @JsonProperty("ScaleBasisCode")
    public void setScaleBasisCode(String scaleBasisCode) {
        this.scaleBasisCode = scaleBasisCode;
    }

    public PricingConditionItem withScaleBasisCode(String scaleBasisCode) {
        this.scaleBasisCode = scaleBasisCode;
        return this;
    }

    @JsonProperty("ScaleUnitofMeasureCode")
    public String getScaleUnitofMeasureCode() {
        return scaleUnitofMeasureCode;
    }

    @JsonProperty("ScaleUnitofMeasureCode")
    public void setScaleUnitofMeasureCode(String scaleUnitofMeasureCode) {
        this.scaleUnitofMeasureCode = scaleUnitofMeasureCode;
    }

    public PricingConditionItem withScaleUnitofMeasureCode(String scaleUnitofMeasureCode) {
        this.scaleUnitofMeasureCode = scaleUnitofMeasureCode;
        return this;
    }

    @JsonProperty("ConditionQuantityScale")
    public List<ConditionQuantityScale> getConditionQuantityScale() {
        return conditionQuantityScale;
    }

    @JsonProperty("ConditionQuantityScale")
    public void setConditionQuantityScale(List<ConditionQuantityScale> conditionQuantityScale) {
        this.conditionQuantityScale = conditionQuantityScale;
    }

    public PricingConditionItem withConditionQuantityScale(List<ConditionQuantityScale> conditionQuantityScale) {
        this.conditionQuantityScale = conditionQuantityScale;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PricingConditionItem withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(pricingConditionIdentifier).append(pricingConditionItemNumber).append(conditionTypeCode).append(scaleTypeCode).append(calculationTypeCode).append(unitListPriceAmount).append(currencyCode).append(pricingConditionItemQuantity).append(conditionUnitQuantity).append(conditionItemIndexNumber).append(pricingConditionDimensionDepend).append(pricingConditionType).append(scaleBasisCode).append(scaleUnitofMeasureCode).append(conditionQuantityScale).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PricingConditionItem) == false) {
            return false;
        }
        PricingConditionItem rhs = ((PricingConditionItem) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(pricingConditionIdentifier, rhs.pricingConditionIdentifier).append(pricingConditionItemNumber, rhs.pricingConditionItemNumber).append(conditionTypeCode, rhs.conditionTypeCode).append(scaleTypeCode, rhs.scaleTypeCode).append(calculationTypeCode, rhs.calculationTypeCode).append(unitListPriceAmount, rhs.unitListPriceAmount).append(currencyCode, rhs.currencyCode).append(pricingConditionItemQuantity, rhs.pricingConditionItemQuantity).append(conditionUnitQuantity, rhs.conditionUnitQuantity).append(conditionItemIndexNumber, rhs.conditionItemIndexNumber).append(pricingConditionDimensionDepend, rhs.pricingConditionDimensionDepend).append(pricingConditionType, rhs.pricingConditionType).append(scaleBasisCode, rhs.scaleBasisCode).append(scaleUnitofMeasureCode, rhs.scaleUnitofMeasureCode).append(conditionQuantityScale, rhs.conditionQuantityScale).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
