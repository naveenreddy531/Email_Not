
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "ConditionUsageTypeCode",
    "ApplicationAreaCode",
    "ConditionTypeCode",
    "AccessSequenceCode",
    "PricingConditionTypeDescription"
})
public class PricingConditionType {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("ConditionUsageTypeCode")
    private String conditionUsageTypeCode;
    @JsonProperty("ApplicationAreaCode")
    private String applicationAreaCode;
    @JsonProperty("ConditionTypeCode")
    private String conditionTypeCode;
    @JsonProperty("AccessSequenceCode")
    private String accessSequenceCode;
    @JsonProperty("PricingConditionTypeDescription")
    private String pricingConditionTypeDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public PricingConditionType withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("ConditionUsageTypeCode")
    public String getConditionUsageTypeCode() {
        return conditionUsageTypeCode;
    }

    @JsonProperty("ConditionUsageTypeCode")
    public void setConditionUsageTypeCode(String conditionUsageTypeCode) {
        this.conditionUsageTypeCode = conditionUsageTypeCode;
    }

    public PricingConditionType withConditionUsageTypeCode(String conditionUsageTypeCode) {
        this.conditionUsageTypeCode = conditionUsageTypeCode;
        return this;
    }

    @JsonProperty("ApplicationAreaCode")
    public String getApplicationAreaCode() {
        return applicationAreaCode;
    }

    @JsonProperty("ApplicationAreaCode")
    public void setApplicationAreaCode(String applicationAreaCode) {
        this.applicationAreaCode = applicationAreaCode;
    }

    public PricingConditionType withApplicationAreaCode(String applicationAreaCode) {
        this.applicationAreaCode = applicationAreaCode;
        return this;
    }

    @JsonProperty("ConditionTypeCode")
    public String getConditionTypeCode() {
        return conditionTypeCode;
    }

    @JsonProperty("ConditionTypeCode")
    public void setConditionTypeCode(String conditionTypeCode) {
        this.conditionTypeCode = conditionTypeCode;
    }

    public PricingConditionType withConditionTypeCode(String conditionTypeCode) {
        this.conditionTypeCode = conditionTypeCode;
        return this;
    }

    @JsonProperty("AccessSequenceCode")
    public String getAccessSequenceCode() {
        return accessSequenceCode;
    }

    @JsonProperty("AccessSequenceCode")
    public void setAccessSequenceCode(String accessSequenceCode) {
        this.accessSequenceCode = accessSequenceCode;
    }

    public PricingConditionType withAccessSequenceCode(String accessSequenceCode) {
        this.accessSequenceCode = accessSequenceCode;
        return this;
    }

    @JsonProperty("PricingConditionTypeDescription")
    public String getPricingConditionTypeDescription() {
        return pricingConditionTypeDescription;
    }

    @JsonProperty("PricingConditionTypeDescription")
    public void setPricingConditionTypeDescription(String pricingConditionTypeDescription) {
        this.pricingConditionTypeDescription = pricingConditionTypeDescription;
    }

    public PricingConditionType withPricingConditionTypeDescription(String pricingConditionTypeDescription) {
        this.pricingConditionTypeDescription = pricingConditionTypeDescription;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PricingConditionType withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(conditionUsageTypeCode).append(applicationAreaCode).append(conditionTypeCode).append(accessSequenceCode).append(pricingConditionTypeDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PricingConditionType) == false) {
            return false;
        }
        PricingConditionType rhs = ((PricingConditionType) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(conditionUsageTypeCode, rhs.conditionUsageTypeCode).append(applicationAreaCode, rhs.applicationAreaCode).append(conditionTypeCode, rhs.conditionTypeCode).append(accessSequenceCode, rhs.accessSequenceCode).append(pricingConditionTypeDescription, rhs.pricingConditionTypeDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
