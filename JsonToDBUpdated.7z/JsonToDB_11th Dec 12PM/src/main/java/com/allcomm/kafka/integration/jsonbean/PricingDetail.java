
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "PricingConditionIdentifier",
    "ConditionTableName",
    "ListPriceValidFromDate",
    "ListPriceValidtoDate",
    "CurrencyCode",
    "AvailableMaterialIdentifier",
    "Incotermscode",
    "CountryCode",
    "PricingConditionItem",
    "OptionID",
    "PriceListTypeCode"
})
public class PricingDetail {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("PricingConditionIdentifier")
    private String pricingConditionIdentifier;
    @JsonProperty("ConditionTableName")
    private String conditionTableName;
    @JsonProperty("ListPriceValidFromDate")
    private String listPriceValidFromDate;
    @JsonProperty("ListPriceValidtoDate")
    private String listPriceValidtoDate;
    @JsonProperty("CurrencyCode")
    private String currencyCode;
    @JsonProperty("AvailableMaterialIdentifier")
    private String availableMaterialIdentifier;
    @JsonProperty("Incotermscode")
    private String incotermscode;
    @JsonProperty("CountryCode")
    private String countryCode;
    @JsonProperty("PricingConditionItem")
    private List<PricingConditionItem> pricingConditionItem = new ArrayList<PricingConditionItem>();
    @JsonProperty("OptionID")
    private String optionID;
    @JsonProperty("PriceListTypeCode")
    private String priceListTypeCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public PricingDetail withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("PricingConditionIdentifier")
    public String getPricingConditionIdentifier() {
        return pricingConditionIdentifier;
    }

    @JsonProperty("PricingConditionIdentifier")
    public void setPricingConditionIdentifier(String pricingConditionIdentifier) {
        this.pricingConditionIdentifier = pricingConditionIdentifier;
    }

    public PricingDetail withPricingConditionIdentifier(String pricingConditionIdentifier) {
        this.pricingConditionIdentifier = pricingConditionIdentifier;
        return this;
    }

    @JsonProperty("ConditionTableName")
    public String getConditionTableName() {
        return conditionTableName;
    }

    @JsonProperty("ConditionTableName")
    public void setConditionTableName(String conditionTableName) {
        this.conditionTableName = conditionTableName;
    }

    public PricingDetail withConditionTableName(String conditionTableName) {
        this.conditionTableName = conditionTableName;
        return this;
    }

    @JsonProperty("ListPriceValidFromDate")
    public String getListPriceValidFromDate() {
        return listPriceValidFromDate;
    }

    @JsonProperty("ListPriceValidFromDate")
    public void setListPriceValidFromDate(String listPriceValidFromDate) {
        this.listPriceValidFromDate = listPriceValidFromDate;
    }

    public PricingDetail withListPriceValidFromDate(String listPriceValidFromDate) {
        this.listPriceValidFromDate = listPriceValidFromDate;
        return this;
    }

    @JsonProperty("ListPriceValidtoDate")
    public String getListPriceValidtoDate() {
        return listPriceValidtoDate;
    }

    @JsonProperty("ListPriceValidtoDate")
    public void setListPriceValidtoDate(String listPriceValidtoDate) {
        this.listPriceValidtoDate = listPriceValidtoDate;
    }

    public PricingDetail withListPriceValidtoDate(String listPriceValidtoDate) {
        this.listPriceValidtoDate = listPriceValidtoDate;
        return this;
    }

    @JsonProperty("CurrencyCode")
    public String getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("CurrencyCode")
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public PricingDetail withCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
        return this;
    }

    @JsonProperty("AvailableMaterialIdentifier")
    public String getAvailableMaterialIdentifier() {
        return availableMaterialIdentifier;
    }

    @JsonProperty("AvailableMaterialIdentifier")
    public void setAvailableMaterialIdentifier(String availableMaterialIdentifier) {
        this.availableMaterialIdentifier = availableMaterialIdentifier;
    }

    public PricingDetail withAvailableMaterialIdentifier(String availableMaterialIdentifier) {
        this.availableMaterialIdentifier = availableMaterialIdentifier;
        return this;
    }

    @JsonProperty("Incotermscode")
    public String getIncotermscode() {
        return incotermscode;
    }

    @JsonProperty("Incotermscode")
    public void setIncotermscode(String incotermscode) {
        this.incotermscode = incotermscode;
    }

    public PricingDetail withIncotermscode(String incotermscode) {
        this.incotermscode = incotermscode;
        return this;
    }

    @JsonProperty("CountryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("CountryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public PricingDetail withCountryCode(String countryCode) {
        this.countryCode = countryCode;
        return this;
    }

    @JsonProperty("PricingConditionItem")
    public List<PricingConditionItem> getPricingConditionItem() {
        return pricingConditionItem;
    }

    @JsonProperty("PricingConditionItem")
    public void setPricingConditionItem(List<PricingConditionItem> pricingConditionItem) {
        this.pricingConditionItem = pricingConditionItem;
    }

    public PricingDetail withPricingConditionItem(List<PricingConditionItem> pricingConditionItem) {
        this.pricingConditionItem = pricingConditionItem;
        return this;
    }

    @JsonProperty("OptionID")
    public String getOptionID() {
        return optionID;
    }

    @JsonProperty("OptionID")
    public void setOptionID(String optionID) {
        this.optionID = optionID;
    }

    public PricingDetail withOptionID(String optionID) {
        this.optionID = optionID;
        return this;
    }

    @JsonProperty("PriceListTypeCode")
    public String getPriceListTypeCode() {
        return priceListTypeCode;
    }

    @JsonProperty("PriceListTypeCode")
    public void setPriceListTypeCode(String priceListTypeCode) {
        this.priceListTypeCode = priceListTypeCode;
    }

    public PricingDetail withPriceListTypeCode(String priceListTypeCode) {
        this.priceListTypeCode = priceListTypeCode;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PricingDetail withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(pricingConditionIdentifier).append(conditionTableName).append(listPriceValidFromDate).append(listPriceValidtoDate).append(currencyCode).append(availableMaterialIdentifier).append(incotermscode).append(countryCode).append(pricingConditionItem).append(optionID).append(priceListTypeCode).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PricingDetail) == false) {
            return false;
        }
        PricingDetail rhs = ((PricingDetail) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(pricingConditionIdentifier, rhs.pricingConditionIdentifier).append(conditionTableName, rhs.conditionTableName).append(listPriceValidFromDate, rhs.listPriceValidFromDate).append(listPriceValidtoDate, rhs.listPriceValidtoDate).append(currencyCode, rhs.currencyCode).append(availableMaterialIdentifier, rhs.availableMaterialIdentifier).append(incotermscode, rhs.incotermscode).append(countryCode, rhs.countryCode).append(pricingConditionItem, rhs.pricingConditionItem).append(optionID, rhs.optionID).append(priceListTypeCode, rhs.priceListTypeCode).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
