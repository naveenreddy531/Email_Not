
package com.allcomm.kafka.integration.jsonbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "ProductLifeCycleEventCode",
    "MaterialIdentifier",
    "SourceSystemCreateTimestamp",
    "SourceSystemUpdateTimestamp",
    "ProductLifeCycleEvent",
    "PlannedDate",
    "GeneralIndicator",
    "CreatedByUserID"
})
public class ProductLifeCycle {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("ProductLifeCycleEventCode")
    private String productLifeCycleEventCode;
    @JsonProperty("MaterialIdentifier")
    private String materialIdentifier;
    @JsonProperty("SourceSystemCreateTimestamp")
    private String sourceSystemCreateTimestamp;
    @JsonProperty("SourceSystemUpdateTimestamp")
    private String sourceSystemUpdateTimestamp;
    @JsonProperty("ProductLifeCycleEvent")
    private List<ProductLifeCycleEvent> productLifeCycleEvent = new ArrayList<ProductLifeCycleEvent>();
    @JsonProperty("PlannedDate")
    private String plannedDate;
    @JsonProperty("GeneralIndicator")
    private String generalIndicator;
    @JsonProperty("CreatedByUserID")
    private String createdByUserID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public ProductLifeCycle withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("ProductLifeCycleEventCode")
    public String getProductLifeCycleEventCode() {
        return productLifeCycleEventCode;
    }

    @JsonProperty("ProductLifeCycleEventCode")
    public void setProductLifeCycleEventCode(String productLifeCycleEventCode) {
        this.productLifeCycleEventCode = productLifeCycleEventCode;
    }

    public ProductLifeCycle withProductLifeCycleEventCode(String productLifeCycleEventCode) {
        this.productLifeCycleEventCode = productLifeCycleEventCode;
        return this;
    }

    @JsonProperty("MaterialIdentifier")
    public String getMaterialIdentifier() {
        return materialIdentifier;
    }

    @JsonProperty("MaterialIdentifier")
    public void setMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
    }

    public ProductLifeCycle withMaterialIdentifier(String materialIdentifier) {
        this.materialIdentifier = materialIdentifier;
        return this;
    }

    @JsonProperty("SourceSystemCreateTimestamp")
    public String getSourceSystemCreateTimestamp() {
        return sourceSystemCreateTimestamp;
    }

    @JsonProperty("SourceSystemCreateTimestamp")
    public void setSourceSystemCreateTimestamp(String sourceSystemCreateTimestamp) {
        this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
    }

    public ProductLifeCycle withSourceSystemCreateTimestamp(String sourceSystemCreateTimestamp) {
        this.sourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
        return this;
    }

    @JsonProperty("SourceSystemUpdateTimestamp")
    public String getSourceSystemUpdateTimestamp() {
        return sourceSystemUpdateTimestamp;
    }

    @JsonProperty("SourceSystemUpdateTimestamp")
    public void setSourceSystemUpdateTimestamp(String sourceSystemUpdateTimestamp) {
        this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
    }

    public ProductLifeCycle withSourceSystemUpdateTimestamp(String sourceSystemUpdateTimestamp) {
        this.sourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
        return this;
    }

    @JsonProperty("ProductLifeCycleEvent")
    public List<ProductLifeCycleEvent> getProductLifeCycleEvent() {
        return productLifeCycleEvent;
    }

    @JsonProperty("ProductLifeCycleEvent")
    public void setProductLifeCycleEvent(List<ProductLifeCycleEvent> productLifeCycleEvent) {
        this.productLifeCycleEvent = productLifeCycleEvent;
    }

    public ProductLifeCycle withProductLifeCycleEvent(List<ProductLifeCycleEvent> productLifeCycleEvent) {
        this.productLifeCycleEvent = productLifeCycleEvent;
        return this;
    }

    @JsonProperty("PlannedDate")
    public String getPlannedDate() {
        return plannedDate;
    }

    @JsonProperty("PlannedDate")
    public void setPlannedDate(String plannedDate) {
        this.plannedDate = plannedDate;
    }

    public ProductLifeCycle withPlannedDate(String plannedDate) {
        this.plannedDate = plannedDate;
        return this;
    }

    @JsonProperty("GeneralIndicator")
    public String getGeneralIndicator() {
        return generalIndicator;
    }

    @JsonProperty("GeneralIndicator")
    public void setGeneralIndicator(String generalIndicator) {
        this.generalIndicator = generalIndicator;
    }

    public ProductLifeCycle withGeneralIndicator(String generalIndicator) {
        this.generalIndicator = generalIndicator;
        return this;
    }

    @JsonProperty("CreatedByUserID")
    public String getCreatedByUserID() {
        return createdByUserID;
    }

    @JsonProperty("CreatedByUserID")
    public void setCreatedByUserID(String createdByUserID) {
        this.createdByUserID = createdByUserID;
    }

    public ProductLifeCycle withCreatedByUserID(String createdByUserID) {
        this.createdByUserID = createdByUserID;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ProductLifeCycle withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(productLifeCycleEventCode).append(materialIdentifier).append(sourceSystemCreateTimestamp).append(sourceSystemUpdateTimestamp).append(productLifeCycleEvent).append(plannedDate).append(generalIndicator).append(createdByUserID).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ProductLifeCycle) == false) {
            return false;
        }
        ProductLifeCycle rhs = ((ProductLifeCycle) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(productLifeCycleEventCode, rhs.productLifeCycleEventCode).append(materialIdentifier, rhs.materialIdentifier).append(sourceSystemCreateTimestamp, rhs.sourceSystemCreateTimestamp).append(sourceSystemUpdateTimestamp, rhs.sourceSystemUpdateTimestamp).append(productLifeCycleEvent, rhs.productLifeCycleEvent).append(plannedDate, rhs.plannedDate).append(generalIndicator, rhs.generalIndicator).append(createdByUserID, rhs.createdByUserID).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
