
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "ProductLifeCycleEventCode",
    "EventSequenceNumber",
    "CrossPlantMaterialStatusCode",
    "CrossSalesMaterialStatusCode",
    "CrossPlantMaterialStatus",
    "CrossSalesMaterialStatus"
})
public class ProductLifeCycleEventstatus {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("ProductLifeCycleEventCode")
    private String productLifeCycleEventCode;
    @JsonProperty("EventSequenceNumber")
    private Integer eventSequenceNumber;
    @JsonProperty("CrossPlantMaterialStatusCode")
    private String crossPlantMaterialStatusCode;
    @JsonProperty("CrossSalesMaterialStatusCode")
    private String crossSalesMaterialStatusCode;
    @JsonProperty("CrossPlantMaterialStatus")
    private CrossPlantMaterialStatus_ crossPlantMaterialStatus;
    @JsonProperty("CrossSalesMaterialStatus")
    private CrossSalesMaterialStatus_ crossSalesMaterialStatus;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public ProductLifeCycleEventstatus withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("ProductLifeCycleEventCode")
    public String getProductLifeCycleEventCode() {
        return productLifeCycleEventCode;
    }

    @JsonProperty("ProductLifeCycleEventCode")
    public void setProductLifeCycleEventCode(String productLifeCycleEventCode) {
        this.productLifeCycleEventCode = productLifeCycleEventCode;
    }

    public ProductLifeCycleEventstatus withProductLifeCycleEventCode(String productLifeCycleEventCode) {
        this.productLifeCycleEventCode = productLifeCycleEventCode;
        return this;
    }

    @JsonProperty("EventSequenceNumber")
    public Integer getEventSequenceNumber() {
        return eventSequenceNumber;
    }

    @JsonProperty("EventSequenceNumber")
    public void setEventSequenceNumber(Integer eventSequenceNumber) {
        this.eventSequenceNumber = eventSequenceNumber;
    }

    public ProductLifeCycleEventstatus withEventSequenceNumber(Integer eventSequenceNumber) {
        this.eventSequenceNumber = eventSequenceNumber;
        return this;
    }

    @JsonProperty("CrossPlantMaterialStatusCode")
    public String getCrossPlantMaterialStatusCode() {
        return crossPlantMaterialStatusCode;
    }

    @JsonProperty("CrossPlantMaterialStatusCode")
    public void setCrossPlantMaterialStatusCode(String crossPlantMaterialStatusCode) {
        this.crossPlantMaterialStatusCode = crossPlantMaterialStatusCode;
    }

    public ProductLifeCycleEventstatus withCrossPlantMaterialStatusCode(String crossPlantMaterialStatusCode) {
        this.crossPlantMaterialStatusCode = crossPlantMaterialStatusCode;
        return this;
    }

    @JsonProperty("CrossSalesMaterialStatusCode")
    public String getCrossSalesMaterialStatusCode() {
        return crossSalesMaterialStatusCode;
    }

    @JsonProperty("CrossSalesMaterialStatusCode")
    public void setCrossSalesMaterialStatusCode(String crossSalesMaterialStatusCode) {
        this.crossSalesMaterialStatusCode = crossSalesMaterialStatusCode;
    }

    public ProductLifeCycleEventstatus withCrossSalesMaterialStatusCode(String crossSalesMaterialStatusCode) {
        this.crossSalesMaterialStatusCode = crossSalesMaterialStatusCode;
        return this;
    }

    @JsonProperty("CrossPlantMaterialStatus")
    public CrossPlantMaterialStatus_ getCrossPlantMaterialStatus() {
        return crossPlantMaterialStatus;
    }

    @JsonProperty("CrossPlantMaterialStatus")
    public void setCrossPlantMaterialStatus(CrossPlantMaterialStatus_ crossPlantMaterialStatus) {
        this.crossPlantMaterialStatus = crossPlantMaterialStatus;
    }

    public ProductLifeCycleEventstatus withCrossPlantMaterialStatus(CrossPlantMaterialStatus_ crossPlantMaterialStatus) {
        this.crossPlantMaterialStatus = crossPlantMaterialStatus;
        return this;
    }

    @JsonProperty("CrossSalesMaterialStatus")
    public CrossSalesMaterialStatus_ getCrossSalesMaterialStatus() {
        return crossSalesMaterialStatus;
    }

    @JsonProperty("CrossSalesMaterialStatus")
    public void setCrossSalesMaterialStatus(CrossSalesMaterialStatus_ crossSalesMaterialStatus) {
        this.crossSalesMaterialStatus = crossSalesMaterialStatus;
    }

    public ProductLifeCycleEventstatus withCrossSalesMaterialStatus(CrossSalesMaterialStatus_ crossSalesMaterialStatus) {
        this.crossSalesMaterialStatus = crossSalesMaterialStatus;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ProductLifeCycleEventstatus withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(productLifeCycleEventCode).append(eventSequenceNumber).append(crossPlantMaterialStatusCode).append(crossSalesMaterialStatusCode).append(crossPlantMaterialStatus).append(crossSalesMaterialStatus).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ProductLifeCycleEventstatus) == false) {
            return false;
        }
        ProductLifeCycleEventstatus rhs = ((ProductLifeCycleEventstatus) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(productLifeCycleEventCode, rhs.productLifeCycleEventCode).append(eventSequenceNumber, rhs.eventSequenceNumber).append(crossPlantMaterialStatusCode, rhs.crossPlantMaterialStatusCode).append(crossSalesMaterialStatusCode, rhs.crossSalesMaterialStatusCode).append(crossPlantMaterialStatus, rhs.crossPlantMaterialStatus).append(crossSalesMaterialStatus, rhs.crossSalesMaterialStatus).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
