
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "PurchasingGroupCode",
    "PurchasingGroupDescription",
    "PurchasingGroupTelephoneNumber",
    "PurchasingGroupFaxNumber"
})
public class PurchasingGroup {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("PurchasingGroupCode")
    private String purchasingGroupCode;
    @JsonProperty("PurchasingGroupDescription")
    private String purchasingGroupDescription;
    @JsonProperty("PurchasingGroupTelephoneNumber")
    private String purchasingGroupTelephoneNumber;
    @JsonProperty("PurchasingGroupFaxNumber")
    private String purchasingGroupFaxNumber;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public PurchasingGroup withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("PurchasingGroupCode")
    public String getPurchasingGroupCode() {
        return purchasingGroupCode;
    }

    @JsonProperty("PurchasingGroupCode")
    public void setPurchasingGroupCode(String purchasingGroupCode) {
        this.purchasingGroupCode = purchasingGroupCode;
    }

    public PurchasingGroup withPurchasingGroupCode(String purchasingGroupCode) {
        this.purchasingGroupCode = purchasingGroupCode;
        return this;
    }

    @JsonProperty("PurchasingGroupDescription")
    public String getPurchasingGroupDescription() {
        return purchasingGroupDescription;
    }

    @JsonProperty("PurchasingGroupDescription")
    public void setPurchasingGroupDescription(String purchasingGroupDescription) {
        this.purchasingGroupDescription = purchasingGroupDescription;
    }

    public PurchasingGroup withPurchasingGroupDescription(String purchasingGroupDescription) {
        this.purchasingGroupDescription = purchasingGroupDescription;
        return this;
    }

    @JsonProperty("PurchasingGroupTelephoneNumber")
    public String getPurchasingGroupTelephoneNumber() {
        return purchasingGroupTelephoneNumber;
    }

    @JsonProperty("PurchasingGroupTelephoneNumber")
    public void setPurchasingGroupTelephoneNumber(String purchasingGroupTelephoneNumber) {
        this.purchasingGroupTelephoneNumber = purchasingGroupTelephoneNumber;
    }

    public PurchasingGroup withPurchasingGroupTelephoneNumber(String purchasingGroupTelephoneNumber) {
        this.purchasingGroupTelephoneNumber = purchasingGroupTelephoneNumber;
        return this;
    }

    @JsonProperty("PurchasingGroupFaxNumber")
    public String getPurchasingGroupFaxNumber() {
        return purchasingGroupFaxNumber;
    }

    @JsonProperty("PurchasingGroupFaxNumber")
    public void setPurchasingGroupFaxNumber(String purchasingGroupFaxNumber) {
        this.purchasingGroupFaxNumber = purchasingGroupFaxNumber;
    }

    public PurchasingGroup withPurchasingGroupFaxNumber(String purchasingGroupFaxNumber) {
        this.purchasingGroupFaxNumber = purchasingGroupFaxNumber;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PurchasingGroup withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(purchasingGroupCode).append(purchasingGroupDescription).append(purchasingGroupTelephoneNumber).append(purchasingGroupFaxNumber).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PurchasingGroup) == false) {
            return false;
        }
        PurchasingGroup rhs = ((PurchasingGroup) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(purchasingGroupCode, rhs.purchasingGroupCode).append(purchasingGroupDescription, rhs.purchasingGroupDescription).append(purchasingGroupTelephoneNumber, rhs.purchasingGroupTelephoneNumber).append(purchasingGroupFaxNumber, rhs.purchasingGroupFaxNumber).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
