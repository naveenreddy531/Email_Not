
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ResellerAIdentifier",
    "SAPDocumentIdentifier",
    "ZipCode",
    "ResellerAddedDate",
    "ContactNumber",
    "ContractCreatedEmployeeIdentifier",
    "ResellerDUNSNumber",
    "TenantID",
    "StateText",
    "CountryText",
    "CurrentValidContractIdentifier",
    "ResellerCustomerApplicationCode",
    "ResellerAISOCountryCode",
    "ResellerAName",
    "ContractNumber",
    "PartnerProfileIdentifier",
    "ContactFirstName",
    "ContactLastName",
    "ContactEmailIdentifier",
    "ContractCreatedEmployeeName"
})
public class RESELLERA1 {

    @JsonProperty("ResellerAIdentifier")
    private String resellerAIdentifier;
    @JsonProperty("SAPDocumentIdentifier")
    private String sAPDocumentIdentifier;
    @JsonProperty("ZipCode")
    private String zipCode;
    @JsonProperty("ResellerAddedDate")
    private String resellerAddedDate;
    @JsonProperty("ContactNumber")
    private String contactNumber;
    @JsonProperty("ContractCreatedEmployeeIdentifier")
    private String contractCreatedEmployeeIdentifier;
    @JsonProperty("ResellerDUNSNumber")
    private String resellerDUNSNumber;
    @JsonProperty("TenantID")
    private String tenantID;
    @JsonProperty("StateText")
    private String stateText;
    @JsonProperty("CountryText")
    private String countryText;
    @JsonProperty("CurrentValidContractIdentifier")
    private String currentValidContractIdentifier;
    @JsonProperty("ResellerCustomerApplicationCode")
    private String resellerCustomerApplicationCode;
    @JsonProperty("ResellerAISOCountryCode")
    private String resellerAISOCountryCode;
    @JsonProperty("ResellerAName")
    private String resellerAName;
    @JsonProperty("ContractNumber")
    private String contractNumber;
    @JsonProperty("PartnerProfileIdentifier")
    private String partnerProfileIdentifier;
    @JsonProperty("ContactFirstName")
    private String contactFirstName;
    @JsonProperty("ContactLastName")
    private String contactLastName;
    @JsonProperty("ContactEmailIdentifier")
    private String contactEmailIdentifier;
    @JsonProperty("ContractCreatedEmployeeName")
    private String contractCreatedEmployeeName;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ResellerAIdentifier")
    public String getResellerAIdentifier() {
        return resellerAIdentifier;
    }

    @JsonProperty("ResellerAIdentifier")
    public void setResellerAIdentifier(String resellerAIdentifier) {
        this.resellerAIdentifier = resellerAIdentifier;
    }

    public RESELLERA1 withResellerAIdentifier(String resellerAIdentifier) {
        this.resellerAIdentifier = resellerAIdentifier;
        return this;
    }

    @JsonProperty("SAPDocumentIdentifier")
    public String getSAPDocumentIdentifier() {
        return sAPDocumentIdentifier;
    }

    @JsonProperty("SAPDocumentIdentifier")
    public void setSAPDocumentIdentifier(String sAPDocumentIdentifier) {
        this.sAPDocumentIdentifier = sAPDocumentIdentifier;
    }

    public RESELLERA1 withSAPDocumentIdentifier(String sAPDocumentIdentifier) {
        this.sAPDocumentIdentifier = sAPDocumentIdentifier;
        return this;
    }

    @JsonProperty("ZipCode")
    public String getZipCode() {
        return zipCode;
    }

    @JsonProperty("ZipCode")
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public RESELLERA1 withZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    @JsonProperty("ResellerAddedDate")
    public String getResellerAddedDate() {
        return resellerAddedDate;
    }

    @JsonProperty("ResellerAddedDate")
    public void setResellerAddedDate(String resellerAddedDate) {
        this.resellerAddedDate = resellerAddedDate;
    }

    public RESELLERA1 withResellerAddedDate(String resellerAddedDate) {
        this.resellerAddedDate = resellerAddedDate;
        return this;
    }

    @JsonProperty("ContactNumber")
    public String getContactNumber() {
        return contactNumber;
    }

    @JsonProperty("ContactNumber")
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public RESELLERA1 withContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
        return this;
    }

    @JsonProperty("ContractCreatedEmployeeIdentifier")
    public String getContractCreatedEmployeeIdentifier() {
        return contractCreatedEmployeeIdentifier;
    }

    @JsonProperty("ContractCreatedEmployeeIdentifier")
    public void setContractCreatedEmployeeIdentifier(String contractCreatedEmployeeIdentifier) {
        this.contractCreatedEmployeeIdentifier = contractCreatedEmployeeIdentifier;
    }

    public RESELLERA1 withContractCreatedEmployeeIdentifier(String contractCreatedEmployeeIdentifier) {
        this.contractCreatedEmployeeIdentifier = contractCreatedEmployeeIdentifier;
        return this;
    }

    @JsonProperty("ResellerDUNSNumber")
    public String getResellerDUNSNumber() {
        return resellerDUNSNumber;
    }

    @JsonProperty("ResellerDUNSNumber")
    public void setResellerDUNSNumber(String resellerDUNSNumber) {
        this.resellerDUNSNumber = resellerDUNSNumber;
    }

    public RESELLERA1 withResellerDUNSNumber(String resellerDUNSNumber) {
        this.resellerDUNSNumber = resellerDUNSNumber;
        return this;
    }

    @JsonProperty("TenantID")
    public String getTenantID() {
        return tenantID;
    }

    @JsonProperty("TenantID")
    public void setTenantID(String tenantID) {
        this.tenantID = tenantID;
    }

    public RESELLERA1 withTenantID(String tenantID) {
        this.tenantID = tenantID;
        return this;
    }

    @JsonProperty("StateText")
    public String getStateText() {
        return stateText;
    }

    @JsonProperty("StateText")
    public void setStateText(String stateText) {
        this.stateText = stateText;
    }

    public RESELLERA1 withStateText(String stateText) {
        this.stateText = stateText;
        return this;
    }

    @JsonProperty("CountryText")
    public String getCountryText() {
        return countryText;
    }

    @JsonProperty("CountryText")
    public void setCountryText(String countryText) {
        this.countryText = countryText;
    }

    public RESELLERA1 withCountryText(String countryText) {
        this.countryText = countryText;
        return this;
    }

    @JsonProperty("CurrentValidContractIdentifier")
    public String getCurrentValidContractIdentifier() {
        return currentValidContractIdentifier;
    }

    @JsonProperty("CurrentValidContractIdentifier")
    public void setCurrentValidContractIdentifier(String currentValidContractIdentifier) {
        this.currentValidContractIdentifier = currentValidContractIdentifier;
    }

    public RESELLERA1 withCurrentValidContractIdentifier(String currentValidContractIdentifier) {
        this.currentValidContractIdentifier = currentValidContractIdentifier;
        return this;
    }

    @JsonProperty("ResellerCustomerApplicationCode")
    public String getResellerCustomerApplicationCode() {
        return resellerCustomerApplicationCode;
    }

    @JsonProperty("ResellerCustomerApplicationCode")
    public void setResellerCustomerApplicationCode(String resellerCustomerApplicationCode) {
        this.resellerCustomerApplicationCode = resellerCustomerApplicationCode;
    }

    public RESELLERA1 withResellerCustomerApplicationCode(String resellerCustomerApplicationCode) {
        this.resellerCustomerApplicationCode = resellerCustomerApplicationCode;
        return this;
    }

    @JsonProperty("ResellerAISOCountryCode")
    public String getResellerAISOCountryCode() {
        return resellerAISOCountryCode;
    }

    @JsonProperty("ResellerAISOCountryCode")
    public void setResellerAISOCountryCode(String resellerAISOCountryCode) {
        this.resellerAISOCountryCode = resellerAISOCountryCode;
    }

    public RESELLERA1 withResellerAISOCountryCode(String resellerAISOCountryCode) {
        this.resellerAISOCountryCode = resellerAISOCountryCode;
        return this;
    }

    @JsonProperty("ResellerAName")
    public String getResellerAName() {
        return resellerAName;
    }

    @JsonProperty("ResellerAName")
    public void setResellerAName(String resellerAName) {
        this.resellerAName = resellerAName;
    }

    public RESELLERA1 withResellerAName(String resellerAName) {
        this.resellerAName = resellerAName;
        return this;
    }

    @JsonProperty("ContractNumber")
    public String getContractNumber() {
        return contractNumber;
    }

    @JsonProperty("ContractNumber")
    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public RESELLERA1 withContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
        return this;
    }

    @JsonProperty("PartnerProfileIdentifier")
    public String getPartnerProfileIdentifier() {
        return partnerProfileIdentifier;
    }

    @JsonProperty("PartnerProfileIdentifier")
    public void setPartnerProfileIdentifier(String partnerProfileIdentifier) {
        this.partnerProfileIdentifier = partnerProfileIdentifier;
    }

    public RESELLERA1 withPartnerProfileIdentifier(String partnerProfileIdentifier) {
        this.partnerProfileIdentifier = partnerProfileIdentifier;
        return this;
    }

    @JsonProperty("ContactFirstName")
    public String getContactFirstName() {
        return contactFirstName;
    }

    @JsonProperty("ContactFirstName")
    public void setContactFirstName(String contactFirstName) {
        this.contactFirstName = contactFirstName;
    }

    public RESELLERA1 withContactFirstName(String contactFirstName) {
        this.contactFirstName = contactFirstName;
        return this;
    }

    @JsonProperty("ContactLastName")
    public String getContactLastName() {
        return contactLastName;
    }

    @JsonProperty("ContactLastName")
    public void setContactLastName(String contactLastName) {
        this.contactLastName = contactLastName;
    }

    public RESELLERA1 withContactLastName(String contactLastName) {
        this.contactLastName = contactLastName;
        return this;
    }

    @JsonProperty("ContactEmailIdentifier")
    public String getContactEmailIdentifier() {
        return contactEmailIdentifier;
    }

    @JsonProperty("ContactEmailIdentifier")
    public void setContactEmailIdentifier(String contactEmailIdentifier) {
        this.contactEmailIdentifier = contactEmailIdentifier;
    }

    public RESELLERA1 withContactEmailIdentifier(String contactEmailIdentifier) {
        this.contactEmailIdentifier = contactEmailIdentifier;
        return this;
    }

    @JsonProperty("ContractCreatedEmployeeName")
    public String getContractCreatedEmployeeName() {
        return contractCreatedEmployeeName;
    }

    @JsonProperty("ContractCreatedEmployeeName")
    public void setContractCreatedEmployeeName(String contractCreatedEmployeeName) {
        this.contractCreatedEmployeeName = contractCreatedEmployeeName;
    }

    public RESELLERA1 withContractCreatedEmployeeName(String contractCreatedEmployeeName) {
        this.contractCreatedEmployeeName = contractCreatedEmployeeName;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RESELLERA1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(resellerAIdentifier).append(sAPDocumentIdentifier).append(zipCode).append(resellerAddedDate).append(contactNumber).append(contractCreatedEmployeeIdentifier).append(resellerDUNSNumber).append(tenantID).append(stateText).append(countryText).append(currentValidContractIdentifier).append(resellerCustomerApplicationCode).append(resellerAISOCountryCode).append(resellerAName).append(contractNumber).append(partnerProfileIdentifier).append(contactFirstName).append(contactLastName).append(contactEmailIdentifier).append(contractCreatedEmployeeName).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RESELLERA1) == false) {
            return false;
        }
        RESELLERA1 rhs = ((RESELLERA1) other);
        return new EqualsBuilder().append(resellerAIdentifier, rhs.resellerAIdentifier).append(sAPDocumentIdentifier, rhs.sAPDocumentIdentifier).append(zipCode, rhs.zipCode).append(resellerAddedDate, rhs.resellerAddedDate).append(contactNumber, rhs.contactNumber).append(contractCreatedEmployeeIdentifier, rhs.contractCreatedEmployeeIdentifier).append(resellerDUNSNumber, rhs.resellerDUNSNumber).append(tenantID, rhs.tenantID).append(stateText, rhs.stateText).append(countryText, rhs.countryText).append(currentValidContractIdentifier, rhs.currentValidContractIdentifier).append(resellerCustomerApplicationCode, rhs.resellerCustomerApplicationCode).append(resellerAISOCountryCode, rhs.resellerAISOCountryCode).append(resellerAName, rhs.resellerAName).append(contractNumber, rhs.contractNumber).append(partnerProfileIdentifier, rhs.partnerProfileIdentifier).append(contactFirstName, rhs.contactFirstName).append(contactLastName, rhs.contactLastName).append(contactEmailIdentifier, rhs.contactEmailIdentifier).append(contractCreatedEmployeeName, rhs.contractCreatedEmployeeName).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
