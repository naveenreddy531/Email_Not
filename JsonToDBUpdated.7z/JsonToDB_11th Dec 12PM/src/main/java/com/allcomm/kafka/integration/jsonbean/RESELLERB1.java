
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ResellerBIdentifier",
    "SAPDocumentIdentifier",
    "ZipCode",
    "ResellerAddedDate",
    "ContactNumber",
    "ContractCreatedEmployeeIdentifier",
    "ResellerDUNSNumber",
    "DVPPercentage",
    "SALES_REPRESENTATIVE_CONTACT",
    "TenantID",
    "ContractNumber",
    "StateText",
    "CountryText",
    "CurrentValidContractIdentifier",
    "ResellerBName",
    "PartnerProfileIdentifier",
    "ResellerCustomerApplicationCode",
    "ContactFirstName",
    "ContactLastName",
    "ContactEmailIdentifier",
    "ContractCreatedEmployeeName",
    "CityName",
    "AddressText"
})
public class RESELLERB1 {

    @JsonProperty("ResellerBIdentifier")
    private String resellerBIdentifier;
    @JsonProperty("SAPDocumentIdentifier")
    private String sAPDocumentIdentifier;
    @JsonProperty("ZipCode")
    private String zipCode;
    @JsonProperty("ResellerAddedDate")
    private String resellerAddedDate;
    @JsonProperty("ContactNumber")
    private String contactNumber;
    @JsonProperty("ContractCreatedEmployeeIdentifier")
    private String contractCreatedEmployeeIdentifier;
    @JsonProperty("ResellerDUNSNumber")
    private String resellerDUNSNumber;
    @JsonProperty("DVPPercentage")
    private String dVPPercentage;
    @JsonProperty("SALES_REPRESENTATIVE_CONTACT")
    private String sALESREPRESENTATIVECONTACT;
    @JsonProperty("TenantID")
    private String tenantID;
    @JsonProperty("ContractNumber")
    private String contractNumber;
    @JsonProperty("StateText")
    private String stateText;
    @JsonProperty("CountryText")
    private String countryText;
    @JsonProperty("CurrentValidContractIdentifier")
    private String currentValidContractIdentifier;
    @JsonProperty("ResellerBName")
    private String resellerBName;
    @JsonProperty("PartnerProfileIdentifier")
    private String partnerProfileIdentifier;
    @JsonProperty("ResellerCustomerApplicationCode")
    private String resellerCustomerApplicationCode;
    @JsonProperty("ContactFirstName")
    private String contactFirstName;
    @JsonProperty("ContactLastName")
    private String contactLastName;
    @JsonProperty("ContactEmailIdentifier")
    private String contactEmailIdentifier;
    @JsonProperty("ContractCreatedEmployeeName")
    private String contractCreatedEmployeeName;
    @JsonProperty("CityName")
    private String cityName;
    @JsonProperty("AddressText")
    private String addressText;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ResellerBIdentifier")
    public String getResellerBIdentifier() {
        return resellerBIdentifier;
    }

    @JsonProperty("ResellerBIdentifier")
    public void setResellerBIdentifier(String resellerBIdentifier) {
        this.resellerBIdentifier = resellerBIdentifier;
    }

    public RESELLERB1 withResellerBIdentifier(String resellerBIdentifier) {
        this.resellerBIdentifier = resellerBIdentifier;
        return this;
    }

    @JsonProperty("SAPDocumentIdentifier")
    public String getSAPDocumentIdentifier() {
        return sAPDocumentIdentifier;
    }

    @JsonProperty("SAPDocumentIdentifier")
    public void setSAPDocumentIdentifier(String sAPDocumentIdentifier) {
        this.sAPDocumentIdentifier = sAPDocumentIdentifier;
    }

    public RESELLERB1 withSAPDocumentIdentifier(String sAPDocumentIdentifier) {
        this.sAPDocumentIdentifier = sAPDocumentIdentifier;
        return this;
    }

    @JsonProperty("ZipCode")
    public String getZipCode() {
        return zipCode;
    }

    @JsonProperty("ZipCode")
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public RESELLERB1 withZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    @JsonProperty("ResellerAddedDate")
    public String getResellerAddedDate() {
        return resellerAddedDate;
    }

    @JsonProperty("ResellerAddedDate")
    public void setResellerAddedDate(String resellerAddedDate) {
        this.resellerAddedDate = resellerAddedDate;
    }

    public RESELLERB1 withResellerAddedDate(String resellerAddedDate) {
        this.resellerAddedDate = resellerAddedDate;
        return this;
    }

    @JsonProperty("ContactNumber")
    public String getContactNumber() {
        return contactNumber;
    }

    @JsonProperty("ContactNumber")
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public RESELLERB1 withContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
        return this;
    }

    @JsonProperty("ContractCreatedEmployeeIdentifier")
    public String getContractCreatedEmployeeIdentifier() {
        return contractCreatedEmployeeIdentifier;
    }

    @JsonProperty("ContractCreatedEmployeeIdentifier")
    public void setContractCreatedEmployeeIdentifier(String contractCreatedEmployeeIdentifier) {
        this.contractCreatedEmployeeIdentifier = contractCreatedEmployeeIdentifier;
    }

    public RESELLERB1 withContractCreatedEmployeeIdentifier(String contractCreatedEmployeeIdentifier) {
        this.contractCreatedEmployeeIdentifier = contractCreatedEmployeeIdentifier;
        return this;
    }

    @JsonProperty("ResellerDUNSNumber")
    public String getResellerDUNSNumber() {
        return resellerDUNSNumber;
    }

    @JsonProperty("ResellerDUNSNumber")
    public void setResellerDUNSNumber(String resellerDUNSNumber) {
        this.resellerDUNSNumber = resellerDUNSNumber;
    }

    public RESELLERB1 withResellerDUNSNumber(String resellerDUNSNumber) {
        this.resellerDUNSNumber = resellerDUNSNumber;
        return this;
    }

    @JsonProperty("DVPPercentage")
    public String getDVPPercentage() {
        return dVPPercentage;
    }

    @JsonProperty("DVPPercentage")
    public void setDVPPercentage(String dVPPercentage) {
        this.dVPPercentage = dVPPercentage;
    }

    public RESELLERB1 withDVPPercentage(String dVPPercentage) {
        this.dVPPercentage = dVPPercentage;
        return this;
    }

    @JsonProperty("SALES_REPRESENTATIVE_CONTACT")
    public String getSALESREPRESENTATIVECONTACT() {
        return sALESREPRESENTATIVECONTACT;
    }

    @JsonProperty("SALES_REPRESENTATIVE_CONTACT")
    public void setSALESREPRESENTATIVECONTACT(String sALESREPRESENTATIVECONTACT) {
        this.sALESREPRESENTATIVECONTACT = sALESREPRESENTATIVECONTACT;
    }

    public RESELLERB1 withSALESREPRESENTATIVECONTACT(String sALESREPRESENTATIVECONTACT) {
        this.sALESREPRESENTATIVECONTACT = sALESREPRESENTATIVECONTACT;
        return this;
    }

    @JsonProperty("TenantID")
    public String getTenantID() {
        return tenantID;
    }

    @JsonProperty("TenantID")
    public void setTenantID(String tenantID) {
        this.tenantID = tenantID;
    }

    public RESELLERB1 withTenantID(String tenantID) {
        this.tenantID = tenantID;
        return this;
    }

    @JsonProperty("ContractNumber")
    public String getContractNumber() {
        return contractNumber;
    }

    @JsonProperty("ContractNumber")
    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public RESELLERB1 withContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
        return this;
    }

    @JsonProperty("StateText")
    public String getStateText() {
        return stateText;
    }

    @JsonProperty("StateText")
    public void setStateText(String stateText) {
        this.stateText = stateText;
    }

    public RESELLERB1 withStateText(String stateText) {
        this.stateText = stateText;
        return this;
    }

    @JsonProperty("CountryText")
    public String getCountryText() {
        return countryText;
    }

    @JsonProperty("CountryText")
    public void setCountryText(String countryText) {
        this.countryText = countryText;
    }

    public RESELLERB1 withCountryText(String countryText) {
        this.countryText = countryText;
        return this;
    }

    @JsonProperty("CurrentValidContractIdentifier")
    public String getCurrentValidContractIdentifier() {
        return currentValidContractIdentifier;
    }

    @JsonProperty("CurrentValidContractIdentifier")
    public void setCurrentValidContractIdentifier(String currentValidContractIdentifier) {
        this.currentValidContractIdentifier = currentValidContractIdentifier;
    }

    public RESELLERB1 withCurrentValidContractIdentifier(String currentValidContractIdentifier) {
        this.currentValidContractIdentifier = currentValidContractIdentifier;
        return this;
    }

    @JsonProperty("ResellerBName")
    public String getResellerBName() {
        return resellerBName;
    }

    @JsonProperty("ResellerBName")
    public void setResellerBName(String resellerBName) {
        this.resellerBName = resellerBName;
    }

    public RESELLERB1 withResellerBName(String resellerBName) {
        this.resellerBName = resellerBName;
        return this;
    }

    @JsonProperty("PartnerProfileIdentifier")
    public String getPartnerProfileIdentifier() {
        return partnerProfileIdentifier;
    }

    @JsonProperty("PartnerProfileIdentifier")
    public void setPartnerProfileIdentifier(String partnerProfileIdentifier) {
        this.partnerProfileIdentifier = partnerProfileIdentifier;
    }

    public RESELLERB1 withPartnerProfileIdentifier(String partnerProfileIdentifier) {
        this.partnerProfileIdentifier = partnerProfileIdentifier;
        return this;
    }

    @JsonProperty("ResellerCustomerApplicationCode")
    public String getResellerCustomerApplicationCode() {
        return resellerCustomerApplicationCode;
    }

    @JsonProperty("ResellerCustomerApplicationCode")
    public void setResellerCustomerApplicationCode(String resellerCustomerApplicationCode) {
        this.resellerCustomerApplicationCode = resellerCustomerApplicationCode;
    }

    public RESELLERB1 withResellerCustomerApplicationCode(String resellerCustomerApplicationCode) {
        this.resellerCustomerApplicationCode = resellerCustomerApplicationCode;
        return this;
    }

    @JsonProperty("ContactFirstName")
    public String getContactFirstName() {
        return contactFirstName;
    }

    @JsonProperty("ContactFirstName")
    public void setContactFirstName(String contactFirstName) {
        this.contactFirstName = contactFirstName;
    }

    public RESELLERB1 withContactFirstName(String contactFirstName) {
        this.contactFirstName = contactFirstName;
        return this;
    }

    @JsonProperty("ContactLastName")
    public String getContactLastName() {
        return contactLastName;
    }

    @JsonProperty("ContactLastName")
    public void setContactLastName(String contactLastName) {
        this.contactLastName = contactLastName;
    }

    public RESELLERB1 withContactLastName(String contactLastName) {
        this.contactLastName = contactLastName;
        return this;
    }

    @JsonProperty("ContactEmailIdentifier")
    public String getContactEmailIdentifier() {
        return contactEmailIdentifier;
    }

    @JsonProperty("ContactEmailIdentifier")
    public void setContactEmailIdentifier(String contactEmailIdentifier) {
        this.contactEmailIdentifier = contactEmailIdentifier;
    }

    public RESELLERB1 withContactEmailIdentifier(String contactEmailIdentifier) {
        this.contactEmailIdentifier = contactEmailIdentifier;
        return this;
    }

    @JsonProperty("ContractCreatedEmployeeName")
    public String getContractCreatedEmployeeName() {
        return contractCreatedEmployeeName;
    }

    @JsonProperty("ContractCreatedEmployeeName")
    public void setContractCreatedEmployeeName(String contractCreatedEmployeeName) {
        this.contractCreatedEmployeeName = contractCreatedEmployeeName;
    }

    public RESELLERB1 withContractCreatedEmployeeName(String contractCreatedEmployeeName) {
        this.contractCreatedEmployeeName = contractCreatedEmployeeName;
        return this;
    }

    @JsonProperty("CityName")
    public String getCityName() {
        return cityName;
    }

    @JsonProperty("CityName")
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public RESELLERB1 withCityName(String cityName) {
        this.cityName = cityName;
        return this;
    }

    @JsonProperty("AddressText")
    public String getAddressText() {
        return addressText;
    }

    @JsonProperty("AddressText")
    public void setAddressText(String addressText) {
        this.addressText = addressText;
    }

    public RESELLERB1 withAddressText(String addressText) {
        this.addressText = addressText;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RESELLERB1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(resellerBIdentifier).append(sAPDocumentIdentifier).append(zipCode).append(resellerAddedDate).append(contactNumber).append(contractCreatedEmployeeIdentifier).append(resellerDUNSNumber).append(dVPPercentage).append(sALESREPRESENTATIVECONTACT).append(tenantID).append(contractNumber).append(stateText).append(countryText).append(currentValidContractIdentifier).append(resellerBName).append(partnerProfileIdentifier).append(resellerCustomerApplicationCode).append(contactFirstName).append(contactLastName).append(contactEmailIdentifier).append(contractCreatedEmployeeName).append(cityName).append(addressText).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RESELLERB1) == false) {
            return false;
        }
        RESELLERB1 rhs = ((RESELLERB1) other);
        return new EqualsBuilder().append(resellerBIdentifier, rhs.resellerBIdentifier).append(sAPDocumentIdentifier, rhs.sAPDocumentIdentifier).append(zipCode, rhs.zipCode).append(resellerAddedDate, rhs.resellerAddedDate).append(contactNumber, rhs.contactNumber).append(contractCreatedEmployeeIdentifier, rhs.contractCreatedEmployeeIdentifier).append(resellerDUNSNumber, rhs.resellerDUNSNumber).append(dVPPercentage, rhs.dVPPercentage).append(sALESREPRESENTATIVECONTACT, rhs.sALESREPRESENTATIVECONTACT).append(tenantID, rhs.tenantID).append(contractNumber, rhs.contractNumber).append(stateText, rhs.stateText).append(countryText, rhs.countryText).append(currentValidContractIdentifier, rhs.currentValidContractIdentifier).append(resellerBName, rhs.resellerBName).append(partnerProfileIdentifier, rhs.partnerProfileIdentifier).append(resellerCustomerApplicationCode, rhs.resellerCustomerApplicationCode).append(contactFirstName, rhs.contactFirstName).append(contactLastName, rhs.contactLastName).append(contactEmailIdentifier, rhs.contactEmailIdentifier).append(contractCreatedEmployeeName, rhs.contractCreatedEmployeeName).append(cityName, rhs.cityName).append(addressText, rhs.addressText).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
