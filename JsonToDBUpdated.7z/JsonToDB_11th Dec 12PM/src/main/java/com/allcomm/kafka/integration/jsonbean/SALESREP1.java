
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SalesRepresentativeContactNumber",
    "SAPDocumentIdentifier",
    "SequenceNumber"
})
public class SALESREP1 {

    @JsonProperty("SalesRepresentativeContactNumber")
    private String salesRepresentativeContactNumber;
    @JsonProperty("SAPDocumentIdentifier")
    private String sAPDocumentIdentifier;
    @JsonProperty("SequenceNumber")
    private String sequenceNumber;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SalesRepresentativeContactNumber")
    public String getSalesRepresentativeContactNumber() {
        return salesRepresentativeContactNumber;
    }

    @JsonProperty("SalesRepresentativeContactNumber")
    public void setSalesRepresentativeContactNumber(String salesRepresentativeContactNumber) {
        this.salesRepresentativeContactNumber = salesRepresentativeContactNumber;
    }

    public SALESREP1 withSalesRepresentativeContactNumber(String salesRepresentativeContactNumber) {
        this.salesRepresentativeContactNumber = salesRepresentativeContactNumber;
        return this;
    }

    @JsonProperty("SAPDocumentIdentifier")
    public String getSAPDocumentIdentifier() {
        return sAPDocumentIdentifier;
    }

    @JsonProperty("SAPDocumentIdentifier")
    public void setSAPDocumentIdentifier(String sAPDocumentIdentifier) {
        this.sAPDocumentIdentifier = sAPDocumentIdentifier;
    }

    public SALESREP1 withSAPDocumentIdentifier(String sAPDocumentIdentifier) {
        this.sAPDocumentIdentifier = sAPDocumentIdentifier;
        return this;
    }

    @JsonProperty("SequenceNumber")
    public String getSequenceNumber() {
        return sequenceNumber;
    }

    @JsonProperty("SequenceNumber")
    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public SALESREP1 withSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SALESREP1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(salesRepresentativeContactNumber).append(sAPDocumentIdentifier).append(sequenceNumber).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SALESREP1) == false) {
            return false;
        }
        SALESREP1 rhs = ((SALESREP1) other);
        return new EqualsBuilder().append(salesRepresentativeContactNumber, rhs.salesRepresentativeContactNumber).append(sAPDocumentIdentifier, rhs.sAPDocumentIdentifier).append(sequenceNumber, rhs.sequenceNumber).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
