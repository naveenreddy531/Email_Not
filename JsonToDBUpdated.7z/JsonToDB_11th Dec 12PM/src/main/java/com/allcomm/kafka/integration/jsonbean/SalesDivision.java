
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "SalesDivisionCode",
    "SalesDivisionDescription"
})
public class SalesDivision {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("SalesDivisionCode")
    private String salesDivisionCode;
    @JsonProperty("SalesDivisionDescription")
    private String salesDivisionDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public SalesDivision withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("SalesDivisionCode")
    public String getSalesDivisionCode() {
        return salesDivisionCode;
    }

    @JsonProperty("SalesDivisionCode")
    public void setSalesDivisionCode(String salesDivisionCode) {
        this.salesDivisionCode = salesDivisionCode;
    }

    public SalesDivision withSalesDivisionCode(String salesDivisionCode) {
        this.salesDivisionCode = salesDivisionCode;
        return this;
    }

    @JsonProperty("SalesDivisionDescription")
    public String getSalesDivisionDescription() {
        return salesDivisionDescription;
    }

    @JsonProperty("SalesDivisionDescription")
    public void setSalesDivisionDescription(String salesDivisionDescription) {
        this.salesDivisionDescription = salesDivisionDescription;
    }

    public SalesDivision withSalesDivisionDescription(String salesDivisionDescription) {
        this.salesDivisionDescription = salesDivisionDescription;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SalesDivision withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(salesDivisionCode).append(salesDivisionDescription).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SalesDivision) == false) {
            return false;
        }
        SalesDivision rhs = ((SalesDivision) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(salesDivisionCode, rhs.salesDivisionCode).append(salesDivisionDescription, rhs.salesDivisionDescription).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
