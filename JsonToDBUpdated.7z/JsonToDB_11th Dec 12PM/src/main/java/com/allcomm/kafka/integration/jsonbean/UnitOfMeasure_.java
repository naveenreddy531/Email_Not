
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SourceSystemCode",
    "UnitOfMeasureCode",
    "UnitOfMeasureLongDescription",
    "UnitOfMeasureDescription",
    "CommericalFormatUnitOfMeasureCode",
    "TechnicalFormatUnitOfMeasureCode"
})
public class UnitOfMeasure_ {

    @JsonProperty("SourceSystemCode")
    private String sourceSystemCode;
    @JsonProperty("UnitOfMeasureCode")
    private String unitOfMeasureCode;
    @JsonProperty("UnitOfMeasureLongDescription")
    private String unitOfMeasureLongDescription;
    @JsonProperty("UnitOfMeasureDescription")
    private String unitOfMeasureDescription;
    @JsonProperty("CommericalFormatUnitOfMeasureCode")
    private String commericalFormatUnitOfMeasureCode;
    @JsonProperty("TechnicalFormatUnitOfMeasureCode")
    private String technicalFormatUnitOfMeasureCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("SourceSystemCode")
    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    @JsonProperty("SourceSystemCode")
    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public UnitOfMeasure_ withSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
        return this;
    }

    @JsonProperty("UnitOfMeasureCode")
    public String getUnitOfMeasureCode() {
        return unitOfMeasureCode;
    }

    @JsonProperty("UnitOfMeasureCode")
    public void setUnitOfMeasureCode(String unitOfMeasureCode) {
        this.unitOfMeasureCode = unitOfMeasureCode;
    }

    public UnitOfMeasure_ withUnitOfMeasureCode(String unitOfMeasureCode) {
        this.unitOfMeasureCode = unitOfMeasureCode;
        return this;
    }

    @JsonProperty("UnitOfMeasureLongDescription")
    public String getUnitOfMeasureLongDescription() {
        return unitOfMeasureLongDescription;
    }

    @JsonProperty("UnitOfMeasureLongDescription")
    public void setUnitOfMeasureLongDescription(String unitOfMeasureLongDescription) {
        this.unitOfMeasureLongDescription = unitOfMeasureLongDescription;
    }

    public UnitOfMeasure_ withUnitOfMeasureLongDescription(String unitOfMeasureLongDescription) {
        this.unitOfMeasureLongDescription = unitOfMeasureLongDescription;
        return this;
    }

    @JsonProperty("UnitOfMeasureDescription")
    public String getUnitOfMeasureDescription() {
        return unitOfMeasureDescription;
    }

    @JsonProperty("UnitOfMeasureDescription")
    public void setUnitOfMeasureDescription(String unitOfMeasureDescription) {
        this.unitOfMeasureDescription = unitOfMeasureDescription;
    }

    public UnitOfMeasure_ withUnitOfMeasureDescription(String unitOfMeasureDescription) {
        this.unitOfMeasureDescription = unitOfMeasureDescription;
        return this;
    }

    @JsonProperty("CommericalFormatUnitOfMeasureCode")
    public String getCommericalFormatUnitOfMeasureCode() {
        return commericalFormatUnitOfMeasureCode;
    }

    @JsonProperty("CommericalFormatUnitOfMeasureCode")
    public void setCommericalFormatUnitOfMeasureCode(String commericalFormatUnitOfMeasureCode) {
        this.commericalFormatUnitOfMeasureCode = commericalFormatUnitOfMeasureCode;
    }

    public UnitOfMeasure_ withCommericalFormatUnitOfMeasureCode(String commericalFormatUnitOfMeasureCode) {
        this.commericalFormatUnitOfMeasureCode = commericalFormatUnitOfMeasureCode;
        return this;
    }

    @JsonProperty("TechnicalFormatUnitOfMeasureCode")
    public String getTechnicalFormatUnitOfMeasureCode() {
        return technicalFormatUnitOfMeasureCode;
    }

    @JsonProperty("TechnicalFormatUnitOfMeasureCode")
    public void setTechnicalFormatUnitOfMeasureCode(String technicalFormatUnitOfMeasureCode) {
        this.technicalFormatUnitOfMeasureCode = technicalFormatUnitOfMeasureCode;
    }

    public UnitOfMeasure_ withTechnicalFormatUnitOfMeasureCode(String technicalFormatUnitOfMeasureCode) {
        this.technicalFormatUnitOfMeasureCode = technicalFormatUnitOfMeasureCode;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public UnitOfMeasure_ withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(sourceSystemCode).append(unitOfMeasureCode).append(unitOfMeasureLongDescription).append(unitOfMeasureDescription).append(commericalFormatUnitOfMeasureCode).append(technicalFormatUnitOfMeasureCode).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UnitOfMeasure_) == false) {
            return false;
        }
        UnitOfMeasure_ rhs = ((UnitOfMeasure_) other);
        return new EqualsBuilder().append(sourceSystemCode, rhs.sourceSystemCode).append(unitOfMeasureCode, rhs.unitOfMeasureCode).append(unitOfMeasureLongDescription, rhs.unitOfMeasureLongDescription).append(unitOfMeasureDescription, rhs.unitOfMeasureDescription).append(commericalFormatUnitOfMeasureCode, rhs.commericalFormatUnitOfMeasureCode).append(technicalFormatUnitOfMeasureCode, rhs.technicalFormatUnitOfMeasureCode).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
