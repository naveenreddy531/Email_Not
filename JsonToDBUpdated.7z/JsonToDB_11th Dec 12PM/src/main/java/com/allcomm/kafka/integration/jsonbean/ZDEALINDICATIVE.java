
package com.allcomm.kafka.integration.jsonbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "DEAL_TYPE",
    "ROUTE_TO_MARKET",
    "COUNTRY_CODE",
    "COUNTRY_NAME",
    "REGION",
    "PRODUCT_LINE_CODE",
    "PRODUCT_LINE_DESCRIPTION",
    "PRICE_TYPE_CODE",
    "PRICE_TYPE_DESCRIPTION",
    "UPLIFT_BD_NET_PERCENT",
    "UPLIFT_DISCOUNT_PERCENT",
    "START_DATE",
    "END_DATE",
    "DISPLAY_TEXT",
    "SHOW_VPA_IBP",
    "CATEGORY",
    "MEDAL_TYPE",
    "CERT",
    "DEAL_REG",
    "_SEGMENT"
})
public class ZDEALINDICATIVE {

    @JsonProperty("DEAL_TYPE")
    private String dEALTYPE;
    @JsonProperty("ROUTE_TO_MARKET")
    private String rOUTETOMARKET;
    @JsonProperty("COUNTRY_CODE")
    private String cOUNTRYCODE;
    @JsonProperty("COUNTRY_NAME")
    private String cOUNTRYNAME;
    @JsonProperty("REGION")
    private String rEGION;
    @JsonProperty("PRODUCT_LINE_CODE")
    private String pRODUCTLINECODE;
    @JsonProperty("PRODUCT_LINE_DESCRIPTION")
    private String pRODUCTLINEDESCRIPTION;
    @JsonProperty("PRICE_TYPE_CODE")
    private String pRICETYPECODE;
    @JsonProperty("PRICE_TYPE_DESCRIPTION")
    private String pRICETYPEDESCRIPTION;
    @JsonProperty("UPLIFT_BD_NET_PERCENT")
    private String uPLIFTBDNETPERCENT;
    @JsonProperty("UPLIFT_DISCOUNT_PERCENT")
    private String uPLIFTDISCOUNTPERCENT;
    @JsonProperty("START_DATE")
    private String sTARTDATE;
    @JsonProperty("END_DATE")
    private String eNDDATE;
    @JsonProperty("DISPLAY_TEXT")
    private String dISPLAYTEXT;
    @JsonProperty("SHOW_VPA_IBP")
    private String sHOWVPAIBP;
    @JsonProperty("CATEGORY")
    private String cATEGORY;
    @JsonProperty("MEDAL_TYPE")
    private String mEDALTYPE;
    @JsonProperty("CERT")
    private String cERT;
    @JsonProperty("DEAL_REG")
    private String dEALREG;
    @JsonProperty("_SEGMENT")
    private String sEGMENT;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("DEAL_TYPE")
    public String getDEALTYPE() {
        return dEALTYPE;
    }

    @JsonProperty("DEAL_TYPE")
    public void setDEALTYPE(String dEALTYPE) {
        this.dEALTYPE = dEALTYPE;
    }

    public ZDEALINDICATIVE withDEALTYPE(String dEALTYPE) {
        this.dEALTYPE = dEALTYPE;
        return this;
    }

    @JsonProperty("ROUTE_TO_MARKET")
    public String getROUTETOMARKET() {
        return rOUTETOMARKET;
    }

    @JsonProperty("ROUTE_TO_MARKET")
    public void setROUTETOMARKET(String rOUTETOMARKET) {
        this.rOUTETOMARKET = rOUTETOMARKET;
    }

    public ZDEALINDICATIVE withROUTETOMARKET(String rOUTETOMARKET) {
        this.rOUTETOMARKET = rOUTETOMARKET;
        return this;
    }

    @JsonProperty("COUNTRY_CODE")
    public String getCOUNTRYCODE() {
        return cOUNTRYCODE;
    }

    @JsonProperty("COUNTRY_CODE")
    public void setCOUNTRYCODE(String cOUNTRYCODE) {
        this.cOUNTRYCODE = cOUNTRYCODE;
    }

    public ZDEALINDICATIVE withCOUNTRYCODE(String cOUNTRYCODE) {
        this.cOUNTRYCODE = cOUNTRYCODE;
        return this;
    }

    @JsonProperty("COUNTRY_NAME")
    public String getCOUNTRYNAME() {
        return cOUNTRYNAME;
    }

    @JsonProperty("COUNTRY_NAME")
    public void setCOUNTRYNAME(String cOUNTRYNAME) {
        this.cOUNTRYNAME = cOUNTRYNAME;
    }

    public ZDEALINDICATIVE withCOUNTRYNAME(String cOUNTRYNAME) {
        this.cOUNTRYNAME = cOUNTRYNAME;
        return this;
    }

    @JsonProperty("REGION")
    public String getREGION() {
        return rEGION;
    }

    @JsonProperty("REGION")
    public void setREGION(String rEGION) {
        this.rEGION = rEGION;
    }

    public ZDEALINDICATIVE withREGION(String rEGION) {
        this.rEGION = rEGION;
        return this;
    }

    @JsonProperty("PRODUCT_LINE_CODE")
    public String getPRODUCTLINECODE() {
        return pRODUCTLINECODE;
    }

    @JsonProperty("PRODUCT_LINE_CODE")
    public void setPRODUCTLINECODE(String pRODUCTLINECODE) {
        this.pRODUCTLINECODE = pRODUCTLINECODE;
    }

    public ZDEALINDICATIVE withPRODUCTLINECODE(String pRODUCTLINECODE) {
        this.pRODUCTLINECODE = pRODUCTLINECODE;
        return this;
    }

    @JsonProperty("PRODUCT_LINE_DESCRIPTION")
    public String getPRODUCTLINEDESCRIPTION() {
        return pRODUCTLINEDESCRIPTION;
    }

    @JsonProperty("PRODUCT_LINE_DESCRIPTION")
    public void setPRODUCTLINEDESCRIPTION(String pRODUCTLINEDESCRIPTION) {
        this.pRODUCTLINEDESCRIPTION = pRODUCTLINEDESCRIPTION;
    }

    public ZDEALINDICATIVE withPRODUCTLINEDESCRIPTION(String pRODUCTLINEDESCRIPTION) {
        this.pRODUCTLINEDESCRIPTION = pRODUCTLINEDESCRIPTION;
        return this;
    }

    @JsonProperty("PRICE_TYPE_CODE")
    public String getPRICETYPECODE() {
        return pRICETYPECODE;
    }

    @JsonProperty("PRICE_TYPE_CODE")
    public void setPRICETYPECODE(String pRICETYPECODE) {
        this.pRICETYPECODE = pRICETYPECODE;
    }

    public ZDEALINDICATIVE withPRICETYPECODE(String pRICETYPECODE) {
        this.pRICETYPECODE = pRICETYPECODE;
        return this;
    }

    @JsonProperty("PRICE_TYPE_DESCRIPTION")
    public String getPRICETYPEDESCRIPTION() {
        return pRICETYPEDESCRIPTION;
    }

    @JsonProperty("PRICE_TYPE_DESCRIPTION")
    public void setPRICETYPEDESCRIPTION(String pRICETYPEDESCRIPTION) {
        this.pRICETYPEDESCRIPTION = pRICETYPEDESCRIPTION;
    }

    public ZDEALINDICATIVE withPRICETYPEDESCRIPTION(String pRICETYPEDESCRIPTION) {
        this.pRICETYPEDESCRIPTION = pRICETYPEDESCRIPTION;
        return this;
    }

    @JsonProperty("UPLIFT_BD_NET_PERCENT")
    public String getUPLIFTBDNETPERCENT() {
        return uPLIFTBDNETPERCENT;
    }

    @JsonProperty("UPLIFT_BD_NET_PERCENT")
    public void setUPLIFTBDNETPERCENT(String uPLIFTBDNETPERCENT) {
        this.uPLIFTBDNETPERCENT = uPLIFTBDNETPERCENT;
    }

    public ZDEALINDICATIVE withUPLIFTBDNETPERCENT(String uPLIFTBDNETPERCENT) {
        this.uPLIFTBDNETPERCENT = uPLIFTBDNETPERCENT;
        return this;
    }

    @JsonProperty("UPLIFT_DISCOUNT_PERCENT")
    public String getUPLIFTDISCOUNTPERCENT() {
        return uPLIFTDISCOUNTPERCENT;
    }

    @JsonProperty("UPLIFT_DISCOUNT_PERCENT")
    public void setUPLIFTDISCOUNTPERCENT(String uPLIFTDISCOUNTPERCENT) {
        this.uPLIFTDISCOUNTPERCENT = uPLIFTDISCOUNTPERCENT;
    }

    public ZDEALINDICATIVE withUPLIFTDISCOUNTPERCENT(String uPLIFTDISCOUNTPERCENT) {
        this.uPLIFTDISCOUNTPERCENT = uPLIFTDISCOUNTPERCENT;
        return this;
    }

    @JsonProperty("START_DATE")
    public String getSTARTDATE() {
        return sTARTDATE;
    }

    @JsonProperty("START_DATE")
    public void setSTARTDATE(String sTARTDATE) {
        this.sTARTDATE = sTARTDATE;
    }

    public ZDEALINDICATIVE withSTARTDATE(String sTARTDATE) {
        this.sTARTDATE = sTARTDATE;
        return this;
    }

    @JsonProperty("END_DATE")
    public String getENDDATE() {
        return eNDDATE;
    }

    @JsonProperty("END_DATE")
    public void setENDDATE(String eNDDATE) {
        this.eNDDATE = eNDDATE;
    }

    public ZDEALINDICATIVE withENDDATE(String eNDDATE) {
        this.eNDDATE = eNDDATE;
        return this;
    }

    @JsonProperty("DISPLAY_TEXT")
    public String getDISPLAYTEXT() {
        return dISPLAYTEXT;
    }

    @JsonProperty("DISPLAY_TEXT")
    public void setDISPLAYTEXT(String dISPLAYTEXT) {
        this.dISPLAYTEXT = dISPLAYTEXT;
    }

    public ZDEALINDICATIVE withDISPLAYTEXT(String dISPLAYTEXT) {
        this.dISPLAYTEXT = dISPLAYTEXT;
        return this;
    }

    @JsonProperty("SHOW_VPA_IBP")
    public String getSHOWVPAIBP() {
        return sHOWVPAIBP;
    }

    @JsonProperty("SHOW_VPA_IBP")
    public void setSHOWVPAIBP(String sHOWVPAIBP) {
        this.sHOWVPAIBP = sHOWVPAIBP;
    }

    public ZDEALINDICATIVE withSHOWVPAIBP(String sHOWVPAIBP) {
        this.sHOWVPAIBP = sHOWVPAIBP;
        return this;
    }

    @JsonProperty("CATEGORY")
    public String getCATEGORY() {
        return cATEGORY;
    }

    @JsonProperty("CATEGORY")
    public void setCATEGORY(String cATEGORY) {
        this.cATEGORY = cATEGORY;
    }

    public ZDEALINDICATIVE withCATEGORY(String cATEGORY) {
        this.cATEGORY = cATEGORY;
        return this;
    }

    @JsonProperty("MEDAL_TYPE")
    public String getMEDALTYPE() {
        return mEDALTYPE;
    }

    @JsonProperty("MEDAL_TYPE")
    public void setMEDALTYPE(String mEDALTYPE) {
        this.mEDALTYPE = mEDALTYPE;
    }

    public ZDEALINDICATIVE withMEDALTYPE(String mEDALTYPE) {
        this.mEDALTYPE = mEDALTYPE;
        return this;
    }

    @JsonProperty("CERT")
    public String getCERT() {
        return cERT;
    }

    @JsonProperty("CERT")
    public void setCERT(String cERT) {
        this.cERT = cERT;
    }

    public ZDEALINDICATIVE withCERT(String cERT) {
        this.cERT = cERT;
        return this;
    }

    @JsonProperty("DEAL_REG")
    public String getDEALREG() {
        return dEALREG;
    }

    @JsonProperty("DEAL_REG")
    public void setDEALREG(String dEALREG) {
        this.dEALREG = dEALREG;
    }

    public ZDEALINDICATIVE withDEALREG(String dEALREG) {
        this.dEALREG = dEALREG;
        return this;
    }

    @JsonProperty("_SEGMENT")
    public String getSEGMENT() {
        return sEGMENT;
    }

    @JsonProperty("_SEGMENT")
    public void setSEGMENT(String sEGMENT) {
        this.sEGMENT = sEGMENT;
    }

    public ZDEALINDICATIVE withSEGMENT(String sEGMENT) {
        this.sEGMENT = sEGMENT;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ZDEALINDICATIVE withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dEALTYPE).append(rOUTETOMARKET).append(cOUNTRYCODE).append(cOUNTRYNAME).append(rEGION).append(pRODUCTLINECODE).append(pRODUCTLINEDESCRIPTION).append(pRICETYPECODE).append(pRICETYPEDESCRIPTION).append(uPLIFTBDNETPERCENT).append(uPLIFTDISCOUNTPERCENT).append(sTARTDATE).append(eNDDATE).append(dISPLAYTEXT).append(sHOWVPAIBP).append(cATEGORY).append(mEDALTYPE).append(cERT).append(dEALREG).append(sEGMENT).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ZDEALINDICATIVE) == false) {
            return false;
        }
        ZDEALINDICATIVE rhs = ((ZDEALINDICATIVE) other);
        return new EqualsBuilder().append(dEALTYPE, rhs.dEALTYPE).append(rOUTETOMARKET, rhs.rOUTETOMARKET).append(cOUNTRYCODE, rhs.cOUNTRYCODE).append(cOUNTRYNAME, rhs.cOUNTRYNAME).append(rEGION, rhs.rEGION).append(pRODUCTLINECODE, rhs.pRODUCTLINECODE).append(pRODUCTLINEDESCRIPTION, rhs.pRODUCTLINEDESCRIPTION).append(pRICETYPECODE, rhs.pRICETYPECODE).append(pRICETYPEDESCRIPTION, rhs.pRICETYPEDESCRIPTION).append(uPLIFTBDNETPERCENT, rhs.uPLIFTBDNETPERCENT).append(uPLIFTDISCOUNTPERCENT, rhs.uPLIFTDISCOUNTPERCENT).append(sTARTDATE, rhs.sTARTDATE).append(eNDDATE, rhs.eNDDATE).append(dISPLAYTEXT, rhs.dISPLAYTEXT).append(sHOWVPAIBP, rhs.sHOWVPAIBP).append(cATEGORY, rhs.cATEGORY).append(mEDALTYPE, rhs.mEDALTYPE).append(cERT, rhs.cERT).append(dEALREG, rhs.dEALREG).append(sEGMENT, rhs.sEGMENT).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
