package com.allcomm.kafka.integration.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.allcomm.kafka.integration.entities.DealAddCtryPrcDescriptors;
@Repository
public interface DealAddCtryPrcDiscriptorRepo extends JpaRepository<DealAddCtryPrcDescriptors, Long> {
	
	
	@Query(value = "SELECT t.ADDITIONAL_COUNTRY FROM PRICING_SPL_DEAL_ADD_CTRY_PRC_DESCRIPTORS t where t.sap_document_no =:docNo", nativeQuery = true)
	public List<String> findAddCtryBySapDocNo(@Param("docNo") Long docNo);

	

}
