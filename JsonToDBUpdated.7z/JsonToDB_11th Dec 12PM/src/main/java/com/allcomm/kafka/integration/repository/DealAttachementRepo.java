package com.allcomm.kafka.integration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.allcomm.kafka.integration.entities.DealAttachement;
@Repository
public interface DealAttachementRepo extends JpaRepository<DealAttachement, Long> {

}
