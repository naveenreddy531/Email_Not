package com.allcomm.kafka.integration.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.allcomm.kafka.integration.entities.DealBundleHeader;

@Repository
public interface DealBundleHeaderRepo extends JpaRepository<DealBundleHeader, Long> {
	
	@Query(value = "SELECT * FROM PRICING_SPL_DEAL_BUNDLE_HEADER t where t.sap_document_no =:docNo", nativeQuery = true)
	public List<DealBundleHeader> findAllBySapDocNo(@Param("docNo") Long docNo);


}
