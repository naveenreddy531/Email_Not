package com.allcomm.kafka.integration.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.allcomm.kafka.integration.entities.DealProductTab;
import com.allcomm.kafka.integration.entities.PriceCommDealStatus;

@Repository
public interface DealProductTabRepo extends JpaRepository<DealProductTab, Long> {
	
	@Query(value = "SELECT * FROM PRICING_SPL_DEAL_PRODUCT_TAB t where t.sap_document_no =:sapDocNo", nativeQuery = true)
	public List<DealProductTab> findAllBySapDocNO(@Param("sapDocNo") Long sapDocNo);

}
