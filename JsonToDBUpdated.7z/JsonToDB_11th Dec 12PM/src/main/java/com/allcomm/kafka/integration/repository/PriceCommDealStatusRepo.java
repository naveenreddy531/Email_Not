package com.allcomm.kafka.integration.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.allcomm.kafka.integration.entities.PriceCommDealStatus;
import com.allcomm.kafka.integration.entities.PriceCommDealSubtype;

@Repository
public interface PriceCommDealStatusRepo extends JpaRepository<PriceCommDealStatus, Long> {
	
	@Query(value = "SELECT t.STATUS_TYPE_CD FROM PRICING_SPL_PRICE_COMM_DEAL_STATUS t where t.STATUS_TYPE_CD =:statusTypeCd", nativeQuery = true)
	public List<String> findDealStatusBystatusTypeCd(@Param("statusTypeCd") String statusTypeCd);
	
	@Query(value = "SELECT * FROM PRICING_SPL_PRICE_COMM_DEAL_STATUS t where t.STATUS_TYPE_CD =:statusTypeCd", nativeQuery = true)
	public List<PriceCommDealStatus> findAllBystatusTypeCd(@Param("statusTypeCd") String statusTypeCd);

}
