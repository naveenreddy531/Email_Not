package com.allcomm.kafka.integration.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.allcomm.kafka.integration.entities.DealResellerA;
import com.allcomm.kafka.integration.entities.PriceCommDealSubtype;
@Repository
public interface PriceCommDealSubtypeRepo extends JpaRepository<PriceCommDealSubtype, Long> {
	
	@Query(value = "SELECT t.PROMO_TYPE_CD FROM PRICING_SPL_PRICE_COMM_DEAL_SUBTYPE t where t.PROMO_TYPE_CD =:promoTypeCD", nativeQuery = true)
	public List<String> findDealSubTypeByPromoTypeCd(@Param("promoTypeCD") String promoTypeCD);
	
	@Query(value = "SELECT * FROM PRICING_SPL_PRICE_COMM_DEAL_SUBTYPE t where t.PROMO_TYPE_CD =:promoTypeCD", nativeQuery = true)
	public List<PriceCommDealSubtype> findAllBypromoTypeCD(@Param("promoTypeCD") String promoTypeCD);


}
