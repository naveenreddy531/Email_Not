package com.allcomm.kafka.integration.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;

import com.allcomm.kafka.integration.entities.PriceCommSplMaster;

@Repository
public interface PriceCommSplMasterRepo extends JpaRepository<PriceCommSplMaster, Long> {

	@Query(value = "SELECT * FROM PRICING_PRICE_COMMS_SPL_MASTER t where t.partyid =:description", nativeQuery = true)
	public Optional<PriceCommSplMaster> findPartyDetails(@Param("description") String description);
}
