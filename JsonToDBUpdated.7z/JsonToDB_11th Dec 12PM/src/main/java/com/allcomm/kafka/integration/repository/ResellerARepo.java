package com.allcomm.kafka.integration.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.allcomm.kafka.integration.entities.DealResellerA;

@Repository
public interface ResellerARepo extends JpaRepository<DealResellerA, Long> {
	
	@Query(value = "SELECT t.SAP_DOCUMENT_NO FROM PRICING_SPL_DEAL_RESELLER_A t where t.sap_document_no =:docNo", nativeQuery = true)
	public List<Long> findResellerABySapDocNo(@Param("docNo") Long docNo);
	
	@Query(value = "SELECT * FROM PRICING_SPL_DEAL_RESELLER_A t where t.sap_document_no =:docNo", nativeQuery = true)
	public List<DealResellerA> findAllBySapDocNo(@Param("docNo") Long docNo);


}
