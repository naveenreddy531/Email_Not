package com.allcomm.kafka.integration.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.allcomm.kafka.integration.entities.DealHeader;
import com.allcomm.kafka.integration.entities.DealLineDescScale;
import com.allcomm.kafka.integration.entities.DealPQB;
import com.allcomm.kafka.integration.entities.DealProductTab;
import com.allcomm.kafka.integration.entities.DealResellerA;
import com.allcomm.kafka.integration.entities.DealResellerB;
import com.allcomm.kafka.integration.entities.DealSalesRep;
import com.allcomm.kafka.integration.entities.DealUsers;
import com.allcomm.kafka.integration.jsonbean.DEALCTRY1;
import com.allcomm.kafka.integration.jsonbean.DEALDEFAULT1;
import com.allcomm.kafka.integration.jsonbean.DEALDISC1;
import com.allcomm.kafka.integration.jsonbean.DEALHEADER1;
import com.allcomm.kafka.integration.jsonbean.DEALHEADER2;
import com.allcomm.kafka.integration.jsonbean.DEALITEM1;
import com.allcomm.kafka.integration.jsonbean.DEALITEM2;
import com.allcomm.kafka.integration.jsonbean.DEALUSER1;
import com.allcomm.kafka.integration.jsonbean.KafkaDealsDetail;
import com.allcomm.kafka.integration.jsonbean.RESELLERA1;
import com.allcomm.kafka.integration.jsonbean.RESELLERB1;
import com.allcomm.kafka.integration.jsonbean.SALESREP1;
import com.allcomm.kafka.integration.repository.DealAddCommentsRepo;
import com.allcomm.kafka.integration.repository.DealAttachementRepo;
import com.allcomm.kafka.integration.repository.DealBundleHeaderRepo;
import com.allcomm.kafka.integration.repository.DealBundleLineRepo;
import com.allcomm.kafka.integration.repository.DealHeaderRepo;
import com.allcomm.kafka.integration.repository.DealLineDiscScaleRepo;
import com.allcomm.kafka.integration.repository.DealProductTabRepo;
import com.allcomm.kafka.integration.repository.DealUserRepo;
import com.allcomm.kafka.integration.repository.DealsPQBRepository;
import com.allcomm.kafka.integration.repository.PriceCommDiscTypeRepo;
import com.allcomm.kafka.integration.repository.ResellerARepo;
import com.allcomm.kafka.integration.repository.ResellerBRepo;
import com.allcomm.kafka.integration.repository.SalesRepRepository;

@Component
public class DealManager  {

	@Autowired
	private DealHeaderRepo dealHeaderRepo;
	@Autowired
	private DealProductTabRepo dealProductTabRepo;
	@Autowired
	private DealUserRepo userRepo;
	@Autowired
	private DealAddCommentsRepo addCommentsRepo;
	@Autowired
	private SalesRepRepository salesRepRepo;
	@Autowired
	private DealAttachementRepo dealAttachementRepo;
	@Autowired
	private PriceCommDiscTypeRepo priceCommDiscTypeRepo;
	@Autowired
	private DealBundleHeaderRepo dealBundleHeaderRepo;
	@Autowired
	private DealBundleLineRepo dealBundleLineRepo;
	@Autowired
	private DealLineDiscScaleRepo dealLineDiscScaleRepo;
	@Autowired
	private DealsPQBRepository dealsPQBRepo;

	@Autowired
	private ResellerARepo dealResellerARepo;
	@Autowired
	private ResellerBRepo dealResellerBRepo;

	public void updateDeals(List<KafkaDealsDetail> dealsDetail) {

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		DealHeader dealHeader = null;
		KafkaDealsDetail kafkaDealsDetail = null;
		for (int i = 0; i < dealsDetail.size(); i++) {

			kafkaDealsDetail = dealsDetail.get(i);
			DEALHEADER1 dealheader1 = kafkaDealsDetail.getDEALHEADER1();
			DEALHEADER2 dealheader2 = kafkaDealsDetail.getDEALHEADER2();
			List<DEALCTRY1> dealctry1s = kafkaDealsDetail.getDEALCTRY1();
			List<DEALDISC1> dealdisc1s = kafkaDealsDetail.getDEALDISC1();
			List<DEALDEFAULT1> dealdefault1s = kafkaDealsDetail.getDEALDEFAULT1();
			DEALCTRY1 dealctry1 = null;

			if (dealctry1s.size() > 0 && i < dealctry1s.size()) {
				dealctry1 = dealctry1s.get(i);
			}

			DEALDISC1 dealdisc1 = null;
			if (dealdisc1s.size() > 0 && i < dealdisc1s.size()) {
				dealdisc1 = dealdisc1s.get(i);
			}

			DEALDEFAULT1 dealdefault1 = null;
			if (dealdefault1s.size() > 0 && i < dealdefault1s.size()) {
				dealdefault1 = dealdefault1s.get(i);
			}

			dealHeader = new DealHeader();
			long dealId = Long
					.parseLong(dealheader1.getDealIdentifier() == null ? "0" : dealheader1.getDealIdentifier());
			long sapDocNo = Long
					.parseLong(dealheader1.getSAPDocumentNumber() == null ? "0" : dealheader1.getSAPDocumentNumber());
			if (dealheader1 != null) {

				dealHeader.setDealID(dealId);
				dealHeader.setDealType(dealheader1.getDealTypeCode());
			//	dealHeader.setLEAD_BU(dealheader1.getLeadBusinessUnitCode());
				//dealHeader.setLEAD_BG(dealheader1.getLeadBusinessAreaGroupCode());
				dealHeader.setRtmRoutToMarket(dealheader1.getRouteToMarketTypeCode());
				dealHeader.setLeadCountry(dealheader1.getLeadCountryCode());
				dealHeader.setPriceListType(dealheader1.getPriceListTypeCode());
				dealHeader.setCurrency(dealheader1.getCurrencyCode());
				dealHeader.setPriceTermCode(dealheader1.getPriceTermCode());
				dealHeader.setGeographicScope(dealheader1.getGeographicScopeName());
				dealHeader.setRegion(dealheader1.getRegionCode());
				dealHeader.setUpfrontRebateMixed(dealheader1.getDiscountTypeCode());
				dealHeader.setLanguage(dealheader1.getLanguageCode());
				dealHeader.setPaymentTerms(dealheader1.getPaymentTermCode());
				//dealHeader.setEclipseDealNumber(dealheader1.getEclipseDealIdentifier());
				dealHeader.setVersionNumber(Long.parseLong(
						dealheader1.getDealVersionNumber() == null ? "0" : dealheader1.getDealVersionNumber()));
				dealHeader.setSourceDeal(dealheader1.getSourceDealCode());
				dealHeader.setTenantCompany(dealheader1.getTenantCompanyCode());
				dealHeader.setCreatedBy(dealheader1.getDealCreatorCode());
				dealHeader.setDealVersionStatus(dealheader1.getDealVersionStatusName());
				dealHeader.setOpportunity(dealheader1.getSalesOpportunityDescription());
				dealHeader.setCustNoPartyId(dealheader1.getCustomerPartyIdentifier());
				dealHeader.setCustLatinName(dealheader1.getCustomerLatinName());
				dealHeader.setCity(dealheader1.getCityName());
				dealHeader.setState(dealheader1.getStateName());
				dealHeader.setPostalZipCode(dealheader1.getPostalCode());
				dealHeader.setCountry(dealheader1.getCountryCode());
				dealHeader.setCustSegment(dealheader1.getCustomerSegmentCode());
				dealHeader.setIndustry(dealheader1.getIndustryCode());
				dealHeader.setActiveStatus(dealheader1.getDealStatusName());
				dealHeader.setServiceReqNoReqId(dealheader1.getServiceRequestNumber());
				dealHeader.setDealRegId(dealheader1.getDealRegistrationIdentifier());
				dealHeader.setDealStatus(dealheader1.getDealStatusName());
				dealHeader.setMcChangeCode(dealheader1.getMiscellaneousChargeCode());
				dealHeader.setProtectionCode(dealheader1.getPriceProtectionIndicator());
				dealHeader.setProtectionDays(Long.parseLong(
						dealheader1.getPriceProtectionDays() == null ? "0" : dealheader1.getPriceProtectionDays()));
				dealHeader.setCustmerEngagement(dealheader1.getCustomerEngagementTypeName());
				dealHeader.setAsapIndicatior(dealheader1.getASAPIndicator());
				dealHeader.setDealSource(dealheader1.getSourceDealIdentifier());
				dealHeader.setDealDescription(dealheader1.getDealDescription());
				dealHeader.setComplexDealFlag(dealheader1.getComplexIndicator());
				dealHeader.setCorporateReseller(dealheader1.getCorporateResellerIndicator());
				dealHeader.setSupressInAllcomms(dealheader1.getAllCommsSuppressIndicator());
				dealHeader.setGlpDeal(dealheader1.getGlobalListPriceIndicator());
				dealHeader.setCatalogDealFlag(dealheader1.getCatalogIndicator());
				dealHeader.setPromotionFlag(dealheader1.getPromotionIndicator());
				dealHeader.setFramworkDeal(dealheader1.getFrameworkIndicator());
				dealHeader.setGlobalDealFlag(dealheader1.getGlobalDealIndicator());
				dealHeader.setSrcDealType(dealheader1.getSourceDealCode());
				dealHeader.setSapDocumentNo(sapDocNo);

				try {
					if (dealheader1 != null) {
						String versionDateString = dealheader1.getValidEndDate();
						if (versionDateString != null && versionDateString.contains("T")) {
							dealHeader.setVersionDate(dateFormat.parse(versionDateString.split("T")[0]));
						}

						String versionTimeString = dealheader1.getVersionTime();
						if (versionTimeString != null && versionTimeString.contains("T")) {
							dealHeader.setVersionTime(dateFormat.parse(versionTimeString.split("T")[0]));
						}

						String dealValidityFromDateString = dealheader1.getValidStartDate();
						if (dealValidityFromDateString != null && dealValidityFromDateString.contains("T")) {
							dealHeader.setDealValidityFromDate(
									dateFormat.parse(dealValidityFromDateString.split("T")[0]));
						}

						String dealValidityToDateString = dealheader1.getValidEndDate();
						if (dealValidityToDateString != null && dealValidityToDateString.contains("T")) {
							dealHeader.setDealValidityToDate(dateFormat.parse(dealValidityToDateString.split("T")[0]));
						}
					}

				} catch (ParseException e) {
					e.printStackTrace();
				}

				if (dealctry1 != null) {
					dealHeader.setPriceGEO(dealctry1.getPriceGeographyCode());
					dealHeader.setAdditionalLocations(dealctry1.getCountryCode());
				}
				if (dealheader2 != null) {
					dealHeader.setOpportunityId(dealheader2.getSalesOpportunityIdentifier());
				}
				if (dealdisc1 != null) {
					dealHeader.setTotalAdditionalDiscount(
							Double.parseDouble(dealdisc1.getTargetAdditionalDiscountPercentage() == null ? "0"
									: dealdisc1.getTargetAdditionalDiscountPercentage()));
				}
				if (dealdefault1 != null) {
					dealHeader.setPrimaryRSLFL(dealdefault1.getPrimaryRslFl());
				}
				dealHeaderRepo.save(dealHeader);

			}

			List<DEALUSER1> dealusers = kafkaDealsDetail.getDEALUSER1();
			for (DEALUSER1 dealuser1 : dealusers) {
				DealUsers dealUser = new DealUsers();
				dealUser.setDealId(dealId);
				dealUser.setSapDocNo(sapDocNo);
				dealUser.setHpeUserId(dealuser1.getUSERID());
				dealUser.setDealUserTypeCD(dealuser1.getUserTypeCode());

				if (dealdefault1 != null) {
					dealUser.setCanRecieveQoteFI(dealdefault1.getCanRecvQuoteFl());
				}

				dealUser.setHpeEmpNo(Long.parseLong(
						dealuser1.getEmployeeIdentifier() == null ? "0" : dealuser1.getEmployeeIdentifier()));
				dealUser.setHpeEmpMail(dealuser1.getEmployeeEmailIdentifier());
				dealUser.setDealUsersId(Long.parseLong(dealuser1.getUSERID() == null ? "0" : dealuser1.getUSERID()));
				dealUser.setDealVrsn(Long
						.parseLong(dealuser1.getDealVersionNumber() == null ? "0" : dealuser1.getDealVersionNumber()));
				userRepo.saveAndFlush(dealUser);
			}

			List<DEALITEM1> dealitem1s = kafkaDealsDetail.getDEALITEM1();
			List<DEALITEM2> dealitem2s = kafkaDealsDetail.getDEALITEM2();
			DealProductTab productTab = null;
			DEALITEM1 kafkaDealitem1 = null;
			DEALITEM2 kafkaDealitem2 = null;

			for (int j = 0; j < dealitem1s.size(); j++) {

				kafkaDealitem1 = dealitem1s.get(j);
				productTab = new DealProductTab();
				productTab.setProdNo(kafkaDealitem1.getMaterialIdentifier());
				productTab.setOptCode(kafkaDealitem1.getOptionCode());
				productTab.setClsCode(kafkaDealitem1.getClassCode());
				productTab.setBusGroup(kafkaDealitem1.getBusinessGroupCode());
				productTab.setBusUnit(kafkaDealitem1.getBusinessUnitCode());
				productTab.setPrcType(kafkaDealitem1.getPriceTypeCode());
			//	productTab.setRequestedBDNet(kafkaDealitem1.getRequestedBigDealNetAmount());
			//	productTab.setReqestedAdd(kafkaDealitem1.getRequestedAddPercentage());
			//	productTab.setRequestedTotal(kafkaDealitem1.getRequestedTotalPercentage());
				productTab.setPrevRequestedAdd(kafkaDealitem1.getRequestedAddPercentage());
				productTab.setLineItemNo(Long.parseLong(
						kafkaDealitem1.getLineItemNumber() == null ? "0" : kafkaDealitem1.getLineItemNumber()));
				productTab.setListPrice(Double.parseDouble(
						kafkaDealitem1.getListPriceAmount() == null ? "0" : kafkaDealitem1.getListPriceAmount()));
				productTab.setStdDisc(Double.parseDouble(kafkaDealitem1.getStandardDiscountPercentage() == null ? "0"
						: kafkaDealitem1.getStandardDiscountPercentage()));
				productTab.setAuthBDNet(Double.parseDouble(kafkaDealitem1.getAuthorizedBigDealNetAmount() == null ? "0"
						: kafkaDealitem1.getAuthorizedBigDealNetAmount()));
				productTab
						.setAuthAddl(Double.parseDouble(kafkaDealitem1.getAuthorizedAdditionalPercentage() == null ? "0"
								: kafkaDealitem1.getAuthorizedAdditionalPercentage()));
				productTab.setAuthTotal(Double.parseDouble(kafkaDealitem1.getAuthorizedTotalPercentage() == null ? "0"
						: kafkaDealitem1.getAuthorizedTotalPercentage()));
				productTab.setRequestedGMAMT(
						Double.parseDouble(kafkaDealitem1.getRequestedGrossMarginAmount() == null ? "0"
								: kafkaDealitem1.getRequestedGrossMarginAmount()));
				productTab.setRequestedGM(
						Double.parseDouble(kafkaDealitem1.getRequestedGrossMarginPercentage() == null ? "0"
								: kafkaDealitem1.getRequestedGrossMarginPercentage()));
				productTab.setAuthorizedGMAMT(
						Double.parseDouble(kafkaDealitem1.getAuthorizedGrossMarginAmount() == null ? "0"
								: kafkaDealitem1.getAuthorizedGrossMarginAmount().replaceAll("-", "")));
				productTab.setAuthorizedGM(
						Double.parseDouble(kafkaDealitem1.getAuthorizedGrossMarginPercentage() == null ? "0"
								: kafkaDealitem1.getAuthorizedGrossMarginPercentage().replaceAll("-", "")));
				productTab.setExtendedAuthBDNet(
						Double.parseDouble(kafkaDealitem1.getExtendedAuthorizedBigDealNetAmount() == null ? "0"
								: kafkaDealitem1.getExtendedAuthorizedBigDealNetAmount()));
				productTab.setExtendedRqstDBNet(
						Double.parseDouble(kafkaDealitem1.getExtendedRequestBigDealNetAmount() == null ? "0"
								: kafkaDealitem1.getExtendedRequestBigDealNetAmount()));
				productTab.setEstKAmnt(Double.parseDouble(
						kafkaDealitem1.getEstimatedKAmount() == null ? "0" : kafkaDealitem1.getEstimatedKAmount()));
				productTab.setExtendedESTKAmt(
						Double.parseDouble(kafkaDealitem1.getExtendedEstimatedKAmount() == null ? "0"
								: kafkaDealitem1.getExtendedEstimatedKAmount()));
				productTab.setConsumedAmnt(Double.parseDouble(
						kafkaDealitem1.getConsumedAmount() == null ? "0" : kafkaDealitem1.getConsumedAmount()));
				productTab.setConsumedQty(Long.parseLong(
						kafkaDealitem1.getConsumedQuantity() == null ? "0" : kafkaDealitem1.getConsumedQuantity()));
				productTab.setRemAmnt(Double.parseDouble(
						kafkaDealitem1.getRemainingAmount() == null ? "0" : kafkaDealitem1.getRemainingAmount()));
				productTab.setrThresholdQty(Long.parseLong(
						kafkaDealitem1.getRThresholdQuantity() == null ? "0" : kafkaDealitem1.getRThresholdQuantity()));
				productTab.setDealValueDiscount(
						Double.parseDouble(kafkaDealitem1.getDealValueDiscountAmount() == null ? "0"
								: kafkaDealitem1.getDealValueDiscountAmount()));
				productTab.setRemQty(Long.parseLong(
						kafkaDealitem1.getRemainingQuantity() == null ? "0" : kafkaDealitem1.getRemainingQuantity()));
				productTab.setAuthrizedStatus(kafkaDealitem1.getAuthorizedStatusCode());
				productTab.setSapDocNo(Long.parseLong(
						kafkaDealitem1.getSAPDocumentNumber() == null ? "0" : kafkaDealitem1.getSAPDocumentNumber()));
				productTab.setDealVersion(Long.parseLong(
						kafkaDealitem1.getDealVersionNumber() == null ? "0" : kafkaDealitem1.getDealVersionNumber()));
				if (dealitem2s.size() > 0 && dealitem2s.size() > j) {
					kafkaDealitem2 = dealitem2s.get(j);
					if (kafkaDealitem2 != null) {
						productTab.setProdLine(kafkaDealitem2.getProductLineCode());
					}
				}
				dealProductTabRepo.save(productTab);
			}

			SALESREP1 salesrep1 = null;
			DealSalesRep dealSalesRep = null;
			List<SALESREP1> salesrep1s = kafkaDealsDetail.getSALESREP1();

			for (int salesRepIndex = 0; salesRepIndex < salesrep1s.size(); salesRepIndex++) {
				salesrep1 = salesrep1s.get(salesRepIndex);
				dealSalesRep = new DealSalesRep();
				dealSalesRep.setSapDocNo(Long.parseLong(
						salesrep1.getSAPDocumentIdentifier() == null ? "0" : salesrep1.getSAPDocumentIdentifier()));
				dealSalesRep.setDealId(dealId);
				salesRepRepo.save(dealSalesRep);
			}

			DealResellerA dealResellerA = null;
			RESELLERA1 resellera1 = null;
			List<RESELLERA1> resellera1s = kafkaDealsDetail.getRESELLERA1();

			for (int resellerIndex = 0; resellerIndex < resellera1s.size(); resellerIndex++) {
				dealResellerA = new DealResellerA();
				resellera1 = resellera1s.get(resellerIndex);
				dealResellerA.setResellerAId(Long.parseLong(
						resellera1.getResellerAIdentifier() == null ? "0" : resellera1.getResellerAIdentifier()));
				dealResellerA.setContractNo(resellera1.getContactNumber());
				dealResellerA.setStateProvince(resellera1.getStateText());
				dealResellerA.setCountry(resellera1.getCountryText());
				dealResellerA.setZip(Long.parseLong(resellera1.getZipCode() == null ? "0" : resellera1.getZipCode()));
				dealResellerA.setSapDocNo(Long.parseLong(
						resellera1.getSAPDocumentIdentifier() == null ? "0" : resellera1.getSAPDocumentIdentifier()));
				dealResellerARepo.save(dealResellerA);
			}

			DealResellerB dealResellerB = null;
			RESELLERB1 resellerb1 = null;
			List<RESELLERB1> resellerb1s = kafkaDealsDetail.getRESELLERB1();

			for (int resellerBIndex = 0; resellerBIndex < resellerb1s.size(); resellerBIndex++) {
				dealResellerB = new DealResellerB();
				resellerb1 = resellerb1s.get(resellerBIndex);
				dealResellerB.setResellerBId(Long.parseLong(
						resellerb1.getResellerBIdentifier() == null ? "0" : resellerb1.getResellerBIdentifier()));
				dealResellerB.setDealId(dealId);
				dealResellerB.setContractNo(resellerb1.getContactNumber());
				dealResellerB.setStateProvince(resellerb1.getStateText());
				dealResellerB.setCountry(resellerb1.getCountryText());
				dealResellerB.setZip(Long.parseLong(resellerb1.getZipCode() == null ? "0" : resellerb1.getZipCode()));
				dealResellerB.setPrmLocationId(resellerb1.getResellerDUNSNumber());
				dealResellerB.setSapDocumentNo(Long.parseLong(
						resellerb1.getSAPDocumentIdentifier() == null ? "0" : resellerb1.getSAPDocumentIdentifier()));
				dealResellerBRepo.save(dealResellerB);
			}

			DealLineDescScale dealLineDescScale = null;
			DEALDISC1 dealdisc12 = null;

			for (int dealdiscIndex = 0; dealdiscIndex < dealdisc1s.size(); dealdiscIndex++) {
				dealdisc12 = dealdisc1s.get(dealdiscIndex);

				dealLineDescScale = new DealLineDescScale();
			/*	dealLineDescScale.setLineDiscScaleId(Long
						.parseLong(dealdisc12.getScaleIdentifier() == null ? "0" : dealdisc12.getScaleIdentifier()));
				dealLineDescScale.setDealId(
						Long.parseLong(dealdisc12.getDealIdentifier() == null ? "0" : dealdisc12.getDealIdentifier()));
				dealLineDescScale.setAuthorizedAmnt(
						Double.parseDouble(dealdisc12.getAuthorizedIncrementalDiscountAmount() == null ? "0"
								: dealdisc12.getAuthorizedIncrementalDiscountAmount()));
				dealLineDescScale
						.setListPrice(Double.parseDouble(dealdisc12.getAuthorizedFixedDiscountAmount() == null ? "0"
								: dealdisc12.getAuthorizedFixedDiscountAmount()));
				dealLineDescScale
						.setStandardDiscount(Double.parseDouble(dealdisc12.getStandardDiscountPercentage() == null ? "0"
								: dealdisc12.getStandardDiscountPercentage()));
				dealLineDescScale.setDiscount(Double.parseDouble(
						dealdisc12.getDiscountPercentage() == null ? "0" : dealdisc12.getDiscountPercentage()));
				dealLineDescScale.setAuthorizationFlagLI(dealdisc12.getAuthorizedStatusCode());
				dealLineDescScale.setMedallionNetAmnt(Double.parseDouble(
						dealdisc12.getMedallionNetAmount() == null ? "0" : dealdisc12.getMedallionNetAmount()));
				dealLineDiscScaleRepo.save(dealLineDescScale);
			}

			DealPQB dealPQB = null;
			dealPQB = new DealPQB();
			dealPQB.setDealId(dealId);
			dealPQB.setNetPrice(123);
			dealsPQBRepo.save(dealPQB);*/

		}

	}

}
}
