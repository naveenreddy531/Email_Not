package com.allcomm.kafka.integration.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.allcomm.kafka.integration.entities.IBPLookup;
import com.allcomm.kafka.integration.jsonbean.ZDEALINDICATIVE;
import com.allcomm.kafka.integration.repository.IBPLookupRepo;

@Component
public class IBPManager {
	@Autowired
	private IBPLookupRepo ibpRepo;

	public void updateIBP(ZDEALINDICATIVE ibPModel) {
		System.out.println("IBPManager.updateIBP ["+ibPModel+"]");
		IBPLookup ibpLookup = null;

		ibpLookup = new IBPLookup();
		if (ibPModel != null) {
			ibpLookup.setCountryCode(ibPModel.getCOUNTRYCODE());
			ibpLookup.setDealType(ibPModel.getDEALTYPE());
			ibpLookup.setRouteToMarket(ibPModel.getROUTETOMARKET());
			ibpLookup.setCountryName(ibPModel.getCOUNTRYNAME());
			ibpLookup.setRegion(ibPModel.getREGION());
			ibpLookup.setProductLineCode(ibPModel.getPRODUCTLINECODE());
			ibpLookup.setProductLineDescription(ibPModel.getPRODUCTLINEDESCRIPTION());
			ibpLookup.setCert(ibPModel.getCERT());
			ibpLookup.setPriceTypeCode(ibPModel.getPRICETYPECODE());
			ibpLookup.setPriceTypeDescription(ibPModel.getPRICETYPEDESCRIPTION());
			ibpLookup.setUpliftBdnet(ibPModel.getUPLIFTBDNETPERCENT());
			ibpLookup.setUpliftDiscount(ibPModel.getUPLIFTDISCOUNTPERCENT());

			try {
				SimpleDateFormat dateFormater = new SimpleDateFormat("dd/MM/yyyy");
				String startDateString = ibPModel.getSTARTDATE();
				String endDtString = ibPModel.getENDDATE();
				if (startDateString != null) {
					startDateString = new StringBuilder(startDateString).insert(4, "/").insert(7, "/").toString();
				}
				Date startDate = dateFormater.parse(startDateString);
				ibpLookup.setStartDate(startDate);
				if (endDtString != null) {
					endDtString = new StringBuilder(endDtString).insert(4, "/").insert(7, "/").toString();
				}
				Date endDate = dateFormater.parse(endDtString);
				ibpLookup.setEndDate(endDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ibpLookup.setDisplayText(ibPModel.getDISPLAYTEXT());
			ibpLookup.setShowVpaIbp(ibPModel.getSHOWVPAIBP());
			ibpLookup.setMedalType(ibPModel.getMEDALTYPE());
//			ibpLookup.setDealScenario(ibPModel.getd);
			ibpLookup.setDealReg(ibPModel.getDEALREG());
			ibpRepo.save(ibpLookup);
			System.out.println("IBP Saved to db");
		}

	}

}
