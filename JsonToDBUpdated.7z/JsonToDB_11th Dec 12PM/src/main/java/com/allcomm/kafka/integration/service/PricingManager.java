package com.allcomm.kafka.integration.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.allcomm.kafka.integration.entities.ListPriceMstr;
import com.allcomm.kafka.integration.jsonbean.ListPriceInfo;
import com.allcomm.kafka.integration.jsonbean.PricingConditionItem;
import com.allcomm.kafka.integration.jsonbean.PricingDetail;
import com.allcomm.kafka.integration.repository.ListPriceRepo;

@Component
public class PricingManager {
	@Autowired
	private ListPriceRepo listPriceRepo;

	public void updateListPrice(List<ListPriceInfo> listPriceInfos) {

		System.out.println("---->>>>"+listPriceInfos);
		List<PricingDetail> pricingDetails = null;
		PricingConditionItem pricingConditionItem = null;
		List<PricingConditionItem> pricingConditionItems = null;
		if (listPriceInfos != null) {
			for (ListPriceInfo listPriceInfo : listPriceInfos) {

				pricingDetails = listPriceInfo.getPricingDetails();

				for (PricingDetail pricingDetail : pricingDetails) {

					ListPriceMstr listPriceMstr = new ListPriceMstr();
					if (pricingDetail != null) {
						listPriceMstr.setOptionID(pricingDetail.getOptionID());
						listPriceMstr.setCurrency(pricingDetail.getCurrencyCode());
						listPriceMstr.setCountryCode(pricingDetail.getCountryCode());
						listPriceMstr.setIncoterm(pricingDetail.getPriceListTypeCode());
						listPriceMstr.setPriceSource(pricingDetail.getSourceSystemCode());
						listPriceMstr.setId(Long.parseLong(pricingDetail.getPricingConditionIdentifier()==null?"0":pricingDetail.getPricingConditionIdentifier()));
						
						try {
							SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-mm-dd");
							String startDateString = pricingDetail.getListPriceValidtoDate();
							String endDtString = pricingDetail.getListPriceValidFromDate();
							if (startDateString != null) {
								
								startDateString = new StringBuilder(startDateString).insert(4, "-").insert(7, "-").toString();
								Date test =dateFormater.parse(startDateString);
								System.out.println(test);
							}
							Date startDate = dateFormater.parse(startDateString);
							System.out.println(startDate);
//							listPriceMstr.setLPEffectiveData(startDate);
							if (endDtString != null) {
								endDtString = new StringBuilder(endDtString).insert(4, "-").insert(7, "-").toString();
							}
							Date endDate = dateFormater.parse(endDtString);
							listPriceMstr.setEndEffectivity(endDate);
						} catch (ParseException e) {
							e.printStackTrace();
						}
						listPriceMstr.setOrderableProduct(pricingDetail.getAvailableMaterialIdentifier());
						pricingConditionItems = pricingDetail.getPricingConditionItem();
						if (pricingConditionItems != null && pricingConditionItems.size() > 0) {
							pricingConditionItem = pricingConditionItems.get(0);
							if (pricingConditionItem != null) {
								listPriceMstr.setScaleTypeCode(pricingConditionItem.getScaleTypeCode());
								listPriceMstr.setConditionTypeCode(pricingConditionItem.getConditionTypeCode());
								listPriceMstr.setCalculationTypeCode(pricingConditionItem.getCalculationTypeCode());
								System.out.println("List Price "+pricingConditionItem.getUnitListPriceAmount());
								listPriceMstr.setLP(pricingConditionItem.getUnitListPriceAmount() == null ? 0:pricingConditionItem.getUnitListPriceAmount());
								
								// calculation of list price and prev list price
								Optional<ListPriceMstr> prevListPriceMstr = listPriceRepo.findById(listPriceMstr.getId());
								if (prevListPriceMstr.isPresent()) {
									listPriceMstr.setPrevLP(prevListPriceMstr.get().getLP());
								}else {
									listPriceMstr.setPrevLP(pricingConditionItem.getUnitListPriceAmount() == null ? 0:pricingConditionItem.getUnitListPriceAmount());
								}
							}
						}

						listPriceRepo.save(listPriceMstr);
					}

				}

			}
		}

	}

}
